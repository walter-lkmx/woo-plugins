<?php 

namespace Conekta;

use \Conekta\Resource;

class WebhookLog extends Resource
{
}
