<?php
global $cjaddons_item_vars;
$cjaddons_item_type = strpos( dirname( __FILE__ ), 'wp-content/plugins' );
$cjaddons_item_vars = array();
$cjaddons_item_vars['env'] = 'development'; // development or production
$root_url = str_replace( ABSPATH, site_url('/'), dirname( __FILE__ ) );
$cjaddons_item_vars['info'] = array(
	'item_type' => ($cjaddons_item_type > 0) ? 'plugin' : 'theme',
	'item_id' => 'cssjockey-add-ons', // Unique ID of the item
	'envato_id' => 'NA', // Unique ID of the item
	'item_name' => 'CSSJockey Add-Ons',
	'item_version' => cjaddons_version,
	'text_domain' => 'cjaddons',
	'page_title' => 'CSSJockey Add-Ons',
	'menu_title' => __( 'CSSJockey', 'cssjockey-add-ons' ),
	'page_slug' => 'cjaddons',
	'options_table' => 'cjaddons_options',
	'rest_api' => false,
	'assistant' => false,

	'author_url' => 'https://cssjockey.com/',
	//'author_url' => 'http://addons.dev/',
	'addons_url' => 'https://cssjockey.com/product-type/add-on/',
	'verification_url' => 'https://cssjockey.io/verify-license/',
	'cssjockey_api_url' => 'https://cssjockey.com/wp-json/cjaddons/',
	//'cssjockey_api_url' => 'http://addons.dev/wp-json/cjaddons/',
	'docs_url' => 'https://cssjockey.com/documentation/',
	'support_url' => 'http://support.cssjockey.com',
	'customization_url' => 'https://cssjockey.com/get-in-touch/',
	'hire_us_url' => 'https://www.upwork.com/fl/mohitaneja',
	'license_url' => 'https://cssjockey.com/terms-of-use',
);
$cjaddons_item_vars['post_types']['core'] = array();
$cjaddons_item_vars['taxonomies']['core'] = array();
$cjaddons_item_vars['nav_menus']['core'] = array();

$cjaddons_item_vars['locale']['ajax_url'] = admin_url( 'admin-ajax.php' );
$cjaddons_item_vars['locale']['root_url'] = str_replace( ABSPATH, site_url('/'), dirname( __FILE__ ) );
$cjaddons_item_vars['locale']['theme_url'] = get_stylesheet_directory_uri();
// $cjaddons_item_vars['locale']['core']['item_info'] = $cjaddons_item_vars['info'];

$cjaddons_item_vars['external_libraries_frontend']['core'] = array(
	'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css',
	$root_url . '/framework/lib/social-icons/css/pe-icon-social.css',
	$root_url . '/framework/lib/social-icons/css/helper.css',
	$root_url . '/framework/lib/social-icons/css/social-style.min.css',
);

$cjaddons_item_vars['external_libraries_backend']['core'] = array(
	$root_url . '/framework/lib/social-icons/css/pe-icon-social.css',
	$root_url . '/framework/lib/social-icons/css/helper.css',
	$root_url . '/framework/lib/social-icons/css/social-style.min.css',
);

// do not remove/change above declarations