<?php
global $cjaddons_item_vars;

$cjaddons_item_vars['post_types']['cj-ui-blocks'] = array(
	'labels' => array(
		'name' => esc_attr__('UI Blocks', 'cssjockey-add-ons'),
		'singular_name' => esc_attr__('UI Block', 'cssjockey-add-ons'),
		'add_new' => _x('Add New', 'UI Blocks'),
		'add_new_item' => esc_attr__('Add New UI Block', 'cssjockey-add-ons'),
		'edit_item' => esc_attr__('Edit UI Block', 'cssjockey-add-ons'),
		'new_item' => esc_attr__('New UI Block', 'cssjockey-add-ons'),
		'view_item' => esc_attr__('View UI Block', 'cssjockey-add-ons'),
		'search_items' => esc_attr__('Search UI Blocks', 'cssjockey-add-ons'),
		'not_found' => esc_attr__('No UI Blocks found', 'cssjockey-add-ons'),
		'not_found_in_trash' => esc_attr__('No UI Blocks found in Trash', 'cssjockey-add-ons'),
		'parent_item_colon' => ''
	),
	'args' => array(
		'exclude_from_search' => true,
		'public' => false,
		'publicly_queryable' => false,
		'show_ui' => true,
		'show_in_menu' => true,
		'has_archive' => false,
		'can_export' => true,
		'query_var' => true,
		'rewrite' => array('slug' => 'cjaddons-ui-block', 'with_front' => false, 'hierarchical' => true),
		'capability_type' => 'page',
		'taxonomies' => array(),
		'hierarchical' => false,
		'menu_position' => 91,
		'menu_icon' => 'dashicons-welcome-widgets-menus',
		'supports' => array('title')
	)
);