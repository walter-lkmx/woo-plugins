<?php
global $cjaddons_item_vars;

$cjaddons_item_vars['locale']['global'] = array();
$cjaddons_item_vars['locale']['core']['item_info'] = $cjaddons_item_vars['info'];

