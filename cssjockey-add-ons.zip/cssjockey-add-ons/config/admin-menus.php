<?php
$dir_name = str_replace( '.php', '', basename( dirname( __FILE__ ) ) );

# Here we specify plugin settings page item menus.
####################################################################################################
$cjaddons_item_vars['admin_menu'][ $dir_name ] = array(
	'core-welcome' => '<span class="cj-relative" style="top: 6px;"><img src="' . $this->root_url . '/assets/cssjockey/images/icon.svg"></span>',
	array(
		'label' => __( 'Home', 'cssjockey-add-ons' ),
		'items' => array(
			'core-welcome' => __( 'Info & Addons', 'cssjockey-add-ons' ),
			'core-global-config' => __( 'Global Settings', 'cssjockey-add-ons' ),
			'core-sass' => __( 'UI Style Variables', 'cssjockey-add-ons' ),
			'core-shortcodes' => __( 'Shortcodes', 'cssjockey-add-ons' ),
			'core-backup' => __( 'Backup & Restore', 'cssjockey-add-ons' ),
			'core-uninstall' => __( 'Uninstall', 'cssjockey-add-ons' ),
		),
	),
);

$cjaddons_item_vars['option_files'][ $dir_name ] = array(
	'core-options',
	'core-global-config'
);

// Uninstall
$cjaddons_item_vars['admin_menu'][ $dir_name ][0]['items']['core-uninstall'] = __( 'Uninstall', 'cssjockey-add-ons' );

