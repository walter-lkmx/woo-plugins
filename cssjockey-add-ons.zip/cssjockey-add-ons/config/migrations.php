<?php
# Here we specify sql queries for database setup on activation and new upgrades.
####################################################################################################

$table_name = 'cjaddons_options';
$cjaddons_item_vars['migrations'][$table_name] = "CREATE TABLE IF NOT EXISTS %TABLE_NAME% (
        option_id bigint(20) NOT NULL AUTO_INCREMENT,
        option_name varchar(100) DEFAULT '' NOT NULL,
        option_value longtext  NOT NULL,
    PRIMARY KEY  (option_id),
    UNIQUE KEY option_name (option_name))
    %CHARSET_COLLATE%;";