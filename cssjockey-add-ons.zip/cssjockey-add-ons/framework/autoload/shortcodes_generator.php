<?php
if( ! class_exists( 'cssjockey_shortcodes_generator' ) ) {
	class cssjockey_shortcodes_generator {
		public $helpers;

		private static $instance;

		public static function getInstance() {

			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			$this->root_dir = wp_normalize_path( dirname( dirname( dirname( __FILE__ ) ) ) );
			$this->root_url = str_replace( str_replace( '\\', '/', $this->helpers->root_dir ), $this->helpers->root_url, $this->root_dir );

			add_action( 'init', array($this, 'tinyMceButtons') );
			add_action( 'admin_footer', array($this, 'shortcodesPanel') );
			add_action( 'wp_ajax_prepare_shortcode_tag', array($this, 'prepareShortcodeTag') );

			add_action( 'media_buttons', array($this, 'tinyMceMediaButton') );
		}

		public function tinyMceMediaButton() {

			$framework_features = $this->helpers->savedOption( 'core_features', array() );
			if( ! in_array( 'ui-blocks-editor', $framework_features ) ) {
				return false;
			}

			global $current_screen;
			$exclude_post_types = array(
				'cj-ui-blocks',
				'cj-templates'
			);
			if( isset( $current_screen->base ) && $current_screen->base == 'post' && $current_screen->parent_base == 'edit' && ! in_array( $current_screen->post_type, $exclude_post_types ) ) {
				global $post;
				$url = $this->helpers->queryString( get_permalink( $post->ID ) ) . 'cjaddons-action=cj-show-frontend-ui-blocks-editor';
				echo '<span class="cssjockey-ui"><a target="_blank" href="' . $url . '" class="cj-button cj-ml-3 cj-mb-10 cj-is-small cj-is-primary"> <i class="icon-cssjockey cj-fs-10 cj-mr-8" style="margin-right: 5px;"></i>' . __( 'Frontend UI Blocks Editor', 'cssjockey-add-ons' ) . '</a></span>';
			}
		}

		public function tinyMceButtons() {
			add_filter( "mce_external_plugins", array($this, 'addButtons') );
			add_filter( 'mce_buttons', array($this, 'registerButtons') );
		}

		public function addButtons( $plugin_array ) {
			if( ! in_array( 'cssjockey_shortcodes_btn', array_keys( $plugin_array ) ) ) {
				$plugin_array['cssjockey_shortcodes_btn'] = $this->root_url . '/framework/autoload/shortcodes/tiny-mce.js';
			}

			return $plugin_array;
		}

		public function registerButtons( $buttons ) {
			if( ! in_array( 'cssjockey_shortcodes_btn', $buttons ) ) {
				array_push( $buttons, 'cssjockey_shortcodes_btn' );
			}

			return $buttons;
		}

		public function shortcodesArray() {
			global $shortcode_tags, $cjaddons_item_vars;
			$installed_products = $cjaddons_item_vars['module_info'];
			$cssjockey_shortcodes = array();
			$shortcodes_keys = array_keys( $shortcode_tags );

			if( is_array( $shortcodes_keys ) ) {
				foreach( $shortcodes_keys as $key => $shortcodes_key ) {
					if( strpos( $shortcodes_key, 'cjaddons' ) === 0 ) {
						$class_name = $shortcodes_key . '_shortcode';
						if( class_exists( $class_name ) ) {
							$class_instance = $class_name::getInstance();
							$cssjockey_shortcodes[ $shortcodes_key ] = $class_instance->defaults;
						}
					}
				}
			}

			return $cssjockey_shortcodes;
		}

		public function shortcodesPanel() {
			ob_start();
			require_once 'shortcodes/footer-content.php';
			echo ob_get_clean();
		}

		public function prepareShortcodeTag() {

			parse_str( $_POST['form_data'], $post_data );

			$exclude_fields = array(
				'shortcode_tag',
				'shortcode_type',
				'default_content',
				'shortcode_description',
			);
			$parse_vars = '';

			foreach( $post_data as $key => $shortcode_param ) {
				if( ! in_array( $key, $exclude_fields ) ) {
					$params_val = (is_array( $shortcode_param )) ? implode( '|', $shortcode_param ) : $shortcode_param;
					$parse_vars .= ' ' . $key . '="' . htmlentities( $params_val ) . '" ';
				}
			}
			$shortcode_string = null;
			$shortcode_string = '[' . $post_data['shortcode_tag'];
			$shortcode_string .= $parse_vars;

			$shortcode_content = (isset( $post_data['default_content'] ) && $post_data['default_content'] != '') ? $post_data['default_content'] : __( 'Content goes here..', 'cssjockey-add-ons' );

			if( $post_data['shortcode_type'] == 'closed' ) {
				$shortcode_string .= ']' . $shortcode_content . '[/' . $post_data['shortcode_tag'] . ']';
			} else {
				$shortcode_string .= ']';
			}
			$shortcode_string = str_replace( ' ]', ']', $shortcode_string );
			$shortcode_option_key = sha1( $shortcode_string );
			update_option( $shortcode_option_key, $shortcode_string );
			$return = json_encode( [
				'shortcode_option_key' => $shortcode_option_key,
				'shortcode_string' => $shortcode_string,
			] );
			echo $return;
			wp_die();
		}

	}

	cssjockey_shortcodes_generator::getInstance();
}