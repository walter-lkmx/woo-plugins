<?php
if( ! class_exists( 'cjaddons_svg_support' ) ) {
	class cjaddons_svg_support {
		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			add_filter( 'upload_mimes', array($this, 'addSvgMimeTypeSupport') );
		}

		public function addSvgMimeTypeSupport( $mimes = array() ) {
			$mimes['svg'] = 'image/svg+xml';
			$mimes['svgz'] = 'image/svg+xml';

			return $mimes;
		}
	}

	cjaddons_svg_support::getInstance();
}