<?php
if( ! class_exists( 'cjaddons_vc_integration' ) ) {
	class cjaddons_vc_integration {
		private static $instance;
		public $helpers;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'vc_after_init', array($this, 'visualComposerUiBlockMap') );
			add_action( 'vc_after_init', array($this, 'visualComposerShortcodesMap') );
		}

		public function visualComposerUiBlockMap() {
			$blocks_array = array('Select UI Block' => '');

			$ui_blocks = $this->helpers->getPosts( array(
				'post_type' => 'cj-ui-blocks',
				'posts_per_page' => - 1,
				'orderby' => 'post_date',
				'order' => 'DESC',
			), 'post_title', 'ID' );

			foreach( $ui_blocks as $key => $value ) {
				$blocks_array[ $key ] = $value;
			}

			$settings = array(

				'icon' => $this->helpers->root_url . '/assets/cssjockey/images/icon.svg',
				// icon

				'name' => __( 'UI Block', 'cssjockey-add-ons' ),
				// shortcode name

				'base' => 'cjaddons_ui_block',
				// shortcode base [cjaddons_ui_block]

				'category' => __( 'CSSJockey Addons', 'cssjockey-add-ons' ),
				// param category tab in add elements view

				'description' => __( 'This will render the selected UI Block.', 'cssjockey-add-ons' ),
				// element description in add elements view

				'show_settings_on_create' => true,
				// don't show params window after adding

				'weight' => - 5,
				// Depends on ordering in list, Higher weight first

				//'html_template' => dirname( __FILE__ ) . '/vc_templates/test_element.php',
				// if you extend VC within your theme then you don't need this, VC will look for shortcode template in "wp-content/themes/your_theme/vc_templates/test_element.php" automatically. In this example we are extending VC from plugin, so we rewrite template

				// 'admin_enqueue_js' => preg_replace( '/\s/', '%20', plugins_url( 'assets/admin_enqueue_js.js', __FILE__ ) ),
				// This will load extra js file in backend (when you edit page with VC)
				// use preg replace to be sure that "space" will not break logic

				// 'admin_enqueue_css' => preg_replace( '/\s/', '%20', plugins_url( 'assets/admin_enqueue_css.css', __FILE__ ) ),
				// This will load extra css file in backend (when you edit page with VC)

				// 'front_enqueue_js' => preg_replace( '/\s/', '%20', plugins_url( 'assets/front_enqueue_js.js', __FILE__ ) ),
				// This will load extra js file in frontend editor (when you edit page with VC)

				// 'front_enqueue_css' => preg_replace( '/\s/', '%20', plugins_url( 'assets/front_enqueue_css.css', __FILE__ ) ),
				// This will load extra css file in frontend editor (when you edit page with VC)

				'js_view' => 'cjaddons_ui_block_js_view',
				// JS View name for backend. Can be used to override or add some logic for shortcodes in backend (cloning/rendering/deleting/editing).

				'params' => array(
					array(
						'type' => 'dropdown',
						'heading' => __( 'Select UI Block', 'cssjockey-add-ons' ),
						'param_name' => 'block_id', //param_name for textarea_html must be named "content"
						'value' => $blocks_array,
						'description' => __( 'Select UI block.', 'cssjockey-add-ons' )
					),
				)
			);
			vc_map( $settings );
		}

		public function visualComposerShortcodesMap() {

			global $shortcode_tags;
			$cjaddons_shortcodes = array();
			if( is_array( $shortcode_tags ) && ! empty( $shortcode_tags ) ) {
				foreach( $shortcode_tags as $shortcode_key => $shortcode ) {
					if( strpos( $shortcode_key, 'cjaddons' ) === 0 ) {
						$shortcode_info = (array) $shortcode[0];
						$cjaddons_shortcodes[ $shortcode_key . '_shortcode' ] = $shortcode_info['defaults'];
					}
				}
			}
			if( isset( $cjaddons_shortcodes['cjaddons_ui_block_shortcode'] ) ) {
				unset( $cjaddons_shortcodes['cjaddons_ui_block_shortcode'] );
			}

			if( is_array( $cjaddons_shortcodes ) ) {
				foreach( $cjaddons_shortcodes as $key => $shortcode ) {

					$params = array();
					$hidden_default_content = (isset( $shortcode['info']['default_content_type'] ) && $shortcode['info']['default_content_type'] == 'hidden') ? true : false;

					if( ! $shortcode['info']['single'] && ! $hidden_default_content ) {
						$params[] = array(
							"type" => "textarea_html",
							"holder" => "div",
							"class" => "",
							"heading" => __( "Content", "cssjockey-add-ons" ),
							"param_name" => "content", // Important: Only one textarea_html param per content element allowed and it should have "content" as a "param_name"
							"value" => $shortcode['info']['default_content'],
							"description" => ''
						);
					}

					foreach( $shortcode['options'] as $o_key => $option ) {
						$field_type = $option['type'];
						$field_value = (is_array( $option['options'] ) && ! empty( $option['options'] )) ? array_keys( $option['options'] ) : $option['default'];
						if( in_array( $option['type'], $this->helpers->inputTextFieldTypes() ) ) {
							$field_type = 'textfield';
						}
						if( $option['type'] == 'textarea' ) {
							$field_type = 'textarea';
						}
						if( $option['type'] == 'file' ) {
							$field_type = 'attach_image';
						}
						if( $option['type'] == 'files' ) {
							$field_type = 'attach_images';
						}
						if( $option['type'] == 'color' ) {
							$field_type = 'colorpicker';
						}
						if( in_array( $option['type'], array('checkbox', 'checkbox-inline', 'radio', 'radio-inline') ) ) {
							$field_type = 'dropdown';
						}
						$params[] = array(
							'type' => $field_type,
							'heading' => $option['label'],
							'param_name' => $option['id'],
							'description' => $option['info'],
							'value' => $field_value,
						);
					}

					$settings = array(

						'icon' => $this->helpers->root_url . '/assets/cssjockey/images/icon.svg',
						// icon

						'name' => $shortcode['info']['name'],
						// shortcode name

						'base' => $shortcode['info']['tag'],
						// shortcode base [cjaddons_ui_block]

						'category' => __( 'CSSJockey Addons', 'cssjockey-add-ons' ),
						// param category tab in add elements view

						'description' => $shortcode['info']['description'],
						// element description in add elements view

						'show_settings_on_create' => true,
						// don't show params window after adding

						'weight' => - 5,
						// Depends on ordering in list, Higher weight first

						'js_view' => $shortcode['info']['tag'] . '_js_view',
						// JS View name for backend. Can be used to override or add some logic for shortcodes in backend (cloning/rendering/deleting/editing).

						'params' => $params
					);

					vc_map( $settings );
				}
			}
		}

	}

	cjaddons_vc_integration::getInstance();
}