<?php
if( ! class_exists( 'cjaddons_plugin_action_links' ) ) {
	class cjaddons_plugin_action_links {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			if( $this->helpers->itemInfo( 'item_type' ) == 'plugin' ) {
				add_filter( 'plugin_action_links_' . plugin_basename( $this->helpers->root_dir . '/init.php' ), array($this, 'pluginActionLinks') );
			}
		}

		public function pluginActionLinks( $links ) {
			$links[] = '<a href="' . esc_url( $this->helpers->callbackUrl( 'config', 'core-welcome', 'cjaddons' ) ) . '">' . __( 'Settings', 'cssjockey-add-ons' ) . '</a>';
			// cjaddons-install-addons
			$links[] = '<a href="' . esc_url( admin_url('plugins.php?page=cjaddons-install-addons') ) . '">' . __( 'Addons', 'cssjockey-add-ons' ) . '</a>';

			return $links;
		}

	}

	cjaddons_plugin_action_links::getInstance();
}