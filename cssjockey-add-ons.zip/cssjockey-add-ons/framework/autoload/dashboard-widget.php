<?php
if( ! class_exists( 'cjaddons_dashboard_widget' ) ) {
	class cjaddons_dashboard_widget {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			if( $this->helpers->itemInfo( 'item_type' ) != 'theme' ) {
				add_action( 'wp_dashboard_setup', array($this, 'addDashboardWidget') );
				add_action( 'wp_ajax_save_notifications', array($this, 'saveNotifications'), 99 );
				add_action( 'admin_notices', array($this, 'connectWithUs'), 99 );
			}
		}

		public function connectWithUs() {
			if( current_user_can( 'manage_options' ) ) {
				$facebook_url = 'https://facebook.com/cssjockey.fb';
				$twitter_url = 'https://twitter.com/cssjockey';
				$message = sprintf( __( 'Connect via <a href="%s" target="_blank">Facebook</a> and  <a href="%s" target="_blank">Twitter</a> to stay updated and suggest new features.', 'cssjockey-add-ons' ), $facebook_url, $twitter_url );
				$title = $this->helpers->itemInfo( 'item_name' ) . ' ~ ' . __( 'Stay up-to-date!', 'cssjockey-add-ons' );
				$this->helpers->adminNotice( 'cjaddons_connect_with_us', 'success', $message, $title, true );
			}
		}

		public function addDashboardWidget() {
			$title = '<span class="cssjockey-ui"><i class="icon-cssjockey cj-color-cj-red cj-mr-10"></i>CSSJockey Add-ons</span>';
			if( current_user_can( 'manage_options' ) ) {
				wp_add_dashboard_widget( 'cjaddons_dashboard_widget', $title, array($this, 'renderDashboardWidget') );
			}
		}

		public function renderDashboardWidget() {
			global $cjaddons_item_vars;
			ob_start();
			require_once $this->helpers->root_dir . '/framework/html/dashboard-widget.php';
			echo ob_get_clean();
		}

		public function saveNotifications() {
			$option_name = $_POST['key'];
			$option_value = (is_array( $_POST['value'] )) ? serialize( $_POST['value'] ) : $_POST['value'];
			set_transient( $option_name, $option_value, (60 * 60 * 10) );
			echo get_transient( $option_name );
			wp_die();
		}

	}
	// cjaddons_dashboard_widget::getInstance();
}