<?php
if( ! class_exists( 'cjaddons_rest_product_info' ) ) {
	class cjaddons_rest_product_info {

		public $helpers, $module_dir, $routes, $api_url;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			$this->api_url = rest_url( 'cjaddons' ) . '/';
			$this->routes = array(
				'core-product-info' => array(
					'endpoint' => 'product-info',
					'name' => __( 'Product Info', 'cssjockey-add-ons' ),
					'description' => __( 'Returns product info.', 'cssjockey-add-ons' ),
					'methods' => array(
						'get' => array($this, 'productInfo'), // callback function
					),
					'permissions' => function () {
						return true;
						// return current_user_can( 'manage_options' );
					},
				),
				'core-locale' => array(
					'endpoint' => 'locale',
					'name' => __( 'Localization Strings', 'cssjockey-add-ons' ),
					'description' => __( 'Returns localization strings used in this product.', 'cssjockey-add-ons' ),
					'methods' => array(
						'get' => array($this, 'locale'), // callback function
					),
					'permissions' => function () {
						return true;
						// return current_user_can( 'manage_options' );
					},
				),
				'core-product-settings' => array(
					'endpoint' => 'product-settings',
					'name' => __( 'Product Settings', 'cssjockey-add-ons' ),
					'description' => __( 'Returns product settings.', 'cssjockey-add-ons' ),
					'methods' => array(
						'get' => array($this, 'productSettings'), // callback function
					),
					'permissions' => function () {
						return current_user_can( 'manage_options' );
					},
				),
				'core-get-wp-option' => array(
					'endpoint' => 'get-wp-option',
					'name' => __( 'Get WordPress Option', 'cssjockey-add-ons' ),
					'description' => __( 'Returns WordPress option by key', 'cssjockey-add-ons' ),
					'methods' => array(
						'post' => array($this, 'wpGetOption'), // callback function
					),
					'permissions' => function () {
						return true;
					},
				),
				'core-get-cjaddons-option' => array(
					'endpoint' => 'get-cjaddons-option',
					'name' => __( 'Get CSSJockey Addons Option', 'cssjockey-add-ons' ),
					'description' => __( 'Returns CSSJockey Addons option by key', 'cssjockey-add-ons' ),
					'methods' => array(
						'post' => array($this, 'cjaddonsOption'), // callback function
					),
					'permissions' => function ( $request ) {
						return true;
					},
				),
				'core-get-current-user' => array(
					'endpoint' => 'current-user/get',
					'name' => __( 'Current user public data', 'cssjockey-add-ons' ),
					'description' => __( 'Returns current user public data by auth token', 'cssjockey-add-ons' ),
					'methods' => array(
						'get' => array($this, 'currentUserPublicData'), // callback function
					),
					'permissions' => function ( $request ) {
						$api_user_info = $this->helpers->getApiUserInfo( $request );
						if( ! empty( $api_user_info ) ) {
							return true;
						}
					},
				),
				'core-user/login' => array(
					'endpoint' => 'user/login',
					'name' => __( 'Login', 'cssjockey-add-ons' ),
					'description' => __( 'Login a user and returns basic user data.', 'cssjockey-add-ons' ),
					'methods' => array(
						'post' => array($this, 'doLogin'), // callback function
					),
					'permissions' => function ( $request ) {
						return true;
					},
				),
				'core-update-current-user' => array(
					'endpoint' => 'current-user/update',
					'name' => __( 'Update current user data', 'cssjockey-add-ons' ),
					'description' => __( 'Updates current user data by auth token', 'cssjockey-add-ons' ),
					'methods' => array(
						'post' => array($this, 'currentUserUpdateData'), // callback function
					),
					'permissions' => function ( $request ) {
						$api_user_info = $this->helpers->getApiUserInfo( $request );
						if( ! empty( $api_user_info ) ) {
							return true;
						}
					},
				),
				'core-get-posts' => array(
					'endpoint' => 'posts/get',
					'name' => __( 'Get Posts', 'cssjockey-add-ons' ),
					'description' => '',
					'methods' => array(
						'post' => array($this, 'getPosts'), // callback function
					),
					'permissions' => function ( $request ) {
						return true;
					},
				),
				'core-get-taxonomies' => array(
					'endpoint' => 'terms/get',
					'name' => __( 'Get Terms', 'cssjockey-add-ons' ),
					'description' => '',
					'methods' => array(
						'post' => array($this, 'getTerms'), // callback function
					),
					'permissions' => function ( $request ) {
						return true;
					},
				)
			);
			add_filter( 'cjaddons_register_api_route', array($this, 'registerRoute') );
		}

		public function registerRoute( $routes ) {
			$routes = array_merge( $routes, $this->routes );

			return $routes;
		}

		/**
		 * @apiName          GetProductInfo
		 * @apiDescription   Get product information with all installed addons.
		 * @api              {get} /product-info 01. Product information
		 * @apiSampleRequest /product-info
		 * @apiVersion       1.0.0
		 * @apiGroup         Core
		 */
		public function productInfo( $request ) {
			$data = $this->helpers->itemInfo();
			$data['installed_addons'] = $this->helpers->item_vars['module_info'];

			return $this->helpers->apiResponse( $request, $data );
		}

		/**
		 * @apiName          Localization Strings
		 * @apiDescription   Get localization strings for product and all modules.
		 * @api              {get} /locale 02. Localization Strings
		 * @apiSampleRequest /locale
		 * @apiVersion       1.0.0
		 * @apiGroup         Core
		 * @apiPermission    [public]
		 */
		public function locale( $request ) {
			return $this->helpers->apiResponse( $request, $this->helpers->item_vars['locale'] );
		}

		/**
		 * @apiName          Product Settings
		 * @apiDescription   Get saved strings under product settings pages in WordPress admin.
		 * @api              {get} /product-settings 03. Product Settings
		 * @apiSampleRequest /product-settings
		 * @apiVersion       1.0.0
		 * @apiGroup         Core
		 * @apiPermission    Current user can: [manage_options]
		 * @apiHeader (Authorization) {String} X-Authorization-Token User meta key "X-Authorization".
		 */
		public function productSettings( $request ) {

			return $this->helpers->apiResponse( $request, $this->helpers->saved_options );
		}

		public function wpGetOption( $request ) {
			$key = $request->get_params( 'option_name' );
			$data = get_option( $key['option_name'] );

			return $this->helpers->apiResponse( $request, $data );
		}

		public function cjaddonsOption( $request ) {
			$key = $request->get_params( 'option_name' );
			$data = $this->helpers->savedOption( $key['option_name'] );

			return $this->helpers->apiResponse( $request, $data );
		}

		public function currentUserPublicData( $request ) {
			global $wpdb;
			$key = $request->get_header( 'X-Authorization' );
			$user_info = $this->helpers->getUserByToken( $key );

			$data = array(
				'ID' => $user_info['ID'],
				'user_login' => $user_info['user_login'],
				'user_email' => $user_info['user_email'],
				'first_name' => $user_info['first_name'],
				'last_name' => $user_info['last_name'],
				'display_name' => $user_info['display_name'],
				'default_avatar' => $user_info['default_avatar'],
				'gravatar_avatar' => $user_info['gravatar'],
				'user_avatar' => $user_info['user_avatar'],
				'gravatar' => $user_info['gravatar'],
				'nickname' => $user_info['nickname'],
				'description' => $user_info['description'],
				'user_registered' => $user_info['user_registered'],
				'user_url' => $user_info['user_url'],
				'posts_link_url' => $user_info['posts_link_url'],
			);

			$data['social_profiles'] = false;
			$social_profiles_table = $wpdb->prefix . 'cjaddons_social_profiles';
			if( $wpdb->get_var( "SHOW TABLES LIKE '$social_profiles_table'" ) == $social_profiles_table ) {
				$social_profiles = $wpdb->get_results( "SELECT * FROM $social_profiles_table WHERE user_id = '{$user_info['ID']}'", 'ARRAY_A' );
				if( ! empty( $social_profiles ) ) {
					$data['social_profiles'] = array();
					foreach( $social_profiles as $key => $profile ) {
						$data['social_profiles'][ $profile['provider'] ] = $profile;
					}
				}
			}

			return $this->helpers->apiResponse( $request, $data );
		}

		public function currentUserUpdateData( $request ) {
			global $wpdb;
			$key = $request->get_header( 'X-Authorization' );
			$user_info = $this->helpers->getUserByToken( $key );
			if( ! empty( $user_info ) ) {
				foreach( $request->get_params() as $key => $value ) {
					$user_info[ $key ] = $value;
				}
				$this->helpers->updateUserInfo( $user_info['ID'], $user_info );
				$user_info = $this->helpers->userInfo( $user_info['ID'] );
			}
			$data = array(
				'ID' => $user_info['ID'],
				'user_login' => $user_info['user_login'],
				'user_email' => $user_info['user_email'],
				'first_name' => $user_info['first_name'],
				'last_name' => $user_info['last_name'],
				'display_name' => $user_info['display_name'],
				'default_avatar' => $user_info['default_avatar'],
				'gravatar_avatar' => $user_info['gravatar'],
				'user_avatar' => $user_info['user_avatar'],
				'nickname' => $user_info['nickname'],
				'description' => $user_info['description'],
				'user_registered' => $user_info['user_registered'],
				'user_url' => $user_info['user_url'],
				'posts_link_url' => $user_info['posts_link_url'],
			);

			$data['social_profiles'] = false;
			$social_profiles_table = $wpdb->prefix . 'cjaddons_social_profiles';
			if( $wpdb->get_var( "SHOW TABLES LIKE '$social_profiles_table'" ) == $social_profiles_table ) {
				$social_profiles = $wpdb->get_results( "SELECT * FROM $social_profiles_table WHERE user_id = '{$user_info['ID']}'", 'ARRAY_A' );
				if( ! empty( $social_profiles ) ) {
					$data['social_profiles'] = array();
					foreach( $social_profiles as $key => $profile ) {
						$data['social_profiles'][ $profile['provider'] ] = $profile;
					}
				}
			}

			return $this->helpers->apiResponse( $request, $data );
		}

		public function doLogin( $request ) {
			$post_data = $request->get_params();
			$return = array();
			$errors = array();

			if( ! isset( $post_data['user_login'] ) ) {
				$errors['user_login'] = __( 'You must enter your username or email address.', 'cssjockey-add-ons' );
			}

			if( $post_data['user_login'] == '' ) {
				$errors['user_login'] = __( 'You must enter your username or email address.', 'cssjockey-add-ons' );
			}

			if( ! isset( $post_data['user_pass'] ) ) {
				$errors['user_pass'] = __( 'You must enter your password.', 'cssjockey-add-ons' );
			}

			if( $post_data['user_pass'] == '' ) {
				$errors['user_pass'] = __( 'You must enter your password.', 'cssjockey-add-ons' );
			}

			$user_info = $this->helpers->userInfo( $post_data['user_login'] );

			if( empty( $user_info ) ) {
				$errors['user_login'] = __( 'Invalid username or email address.', 'cssjockey-add-ons' );
				$errors['user_pass'] = __( 'Invalid username or email address.', 'cssjockey-add-ons' );
			}

			$authenticate = wp_authenticate( $user_info['user_login'], $post_data['user_pass'] );
			if( is_wp_error( $authenticate ) ) {
				$error_message = $authenticate->get_error_message();
				$errors['user_pass'] = str_replace( '<a ', '<a target="_blank" ', $error_message );
			}

			if( ! empty( $errors ) ) {
				return $this->helpers->apiError( $request, 403, $errors, 403, $errors );
			} else {
				$login_status = $this->helpers->login( $post_data['user_login'], $post_data['user_pass'] );
				if( ! $login_status ) {
					$errors[] = __( 'Invalid username or password.', 'cssjockey-add-ons' );

					return $this->helpers->apiError( $request, 200, $errors, 200, $errors );
				} else {
					$user_info = $this->helpers->userInfo( $post_data['user_login'] );
					$data = array(
						'ID' => $user_info['ID'],
						'user_login' => $user_info['user_login'],
						'user_email' => $user_info['user_email'],
						'first_name' => $user_info['first_name'],
						'last_name' => $user_info['last_name'],
						'display_name' => $user_info['display_name'],
						'default_avatar' => $user_info['default_avatar'],
						'gravatar_avatar' => $user_info['gravatar'],
						'gravatar' => $user_info['gravatar'],
						'nickname' => $user_info['nickname'],
						'description' => $user_info['description'],
						'user_registered' => $user_info['user_registered'],
						'user_url' => $user_info['user_url'],
						'posts_link_url' => $user_info['posts_link_url'],
						'access_token' => $user_info['access_token'],
					);

					return $this->helpers->apiResponse( $request, $data );
				}
			}
		}

		public function getPosts( $request ) {
			$args = $request->get_params();
			$required_args = array('query_vars', 'fields');
			$errors = array();
			foreach( $required_args as $r_key => $r_value ) {
				if( ! isset( $args[ $r_value ] ) ) {
					$errors[ $r_value ] = sprintf( __( 'Missing required variables: %s', 'cssjockey-add-ons' ), $r_value );
				}
			}

			if( ! empty( $errors ) ) {
				return $this->helpers->apiError( $request, 403, $errors, 403, $args );
			}

			$posts = get_posts( $args['query_vars'] );
			$return = array();
			if( ! empty( $posts ) ) {
				foreach( $posts as $key => $post ) {
					$post_info = $this->helpers->postInfo( $post->ID );
					foreach( $args['fields'] as $field_key => $field_id ) {
						$return[ $post->ID ][ $field_id ] = (isset( $post_info[ $field_id ] )) ? $post_info[ $field_id ] : '';
					}
				}
			}

			return $this->helpers->apiResponse( $request, $return );
		}

		public function getTerms( $request ) {
			$post_data = $request->get_params();
			$return = array();
			$taxonomy = $post_data['taxonomy'];
			$args = $post_data['args'];

			$required_args = array('taxonomy', 'args');
			$errors = array();
			foreach( $required_args as $r_key => $r_value ) {
				if( ! isset( $post_data[ $r_value ] ) ) {
					$errors[ $r_value ] = sprintf( __( 'Missing required variables: %s', 'cssjockey-add-ons' ), $r_value );
				}
			}
			if( ! empty( $errors ) ) {
				return $this->helpers->apiError( $request, 403, $errors, 403, $args );
			}
			$terms = get_terms( $taxonomy, $args );
			$return = $terms;
			return $this->helpers->apiResponse( $request, $return );
		}

	}

	cjaddons_rest_product_info::getInstance();
}