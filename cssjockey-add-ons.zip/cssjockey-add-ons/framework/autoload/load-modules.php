<?php
if( ! class_exists( 'cjaddons_load_modules' ) ) {
	class cjaddons_load_modules {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			$this->loadModules();
			$this->loadShortcodes();
			add_action( 'admin_notices', array($this, 'checkDependencies') );
		}

		public function loadModules() {
			$active_addons = $this->helpers->activeAddons();

			$module_init_paths = array();
			$api_route_paths = array();

			$modules_dir = $this->helpers->root_dir . '/modules/';
			if( is_dir( $modules_dir ) ) {
				$module_dirs = preg_grep( '/^([^.])/', scandir( $modules_dir ) );
				foreach( $module_dirs as $key => $module ) {
					if( ! is_file( $module ) && is_dir( $modules_dir . $module ) ) {
						$module_file_path = $modules_dir . $module . '/init.php';
						if( file_exists( $module_file_path ) ) {
							if( in_array( $module, $active_addons ) ) {
								$module_init_paths[ $module ] = $modules_dir . $module . '/init.php';
								// rest api routes
								$rest_api_dir = $modules_dir . $module . '/api-routes/';
								if( is_dir( $rest_api_dir ) ) {
									$api_route_files = preg_grep( '/^([^.])/', scandir( $rest_api_dir ) );
									foreach( $api_route_files as $api_file_key => $api_route_file ) {
										$api_route_file = $rest_api_dir . $api_route_file;
										if( file_exists( $api_route_file ) && ! is_dir( $api_route_file ) ) {
											$api_route_paths[] = $api_route_file;
										}
									}
								}
							}
						}
					}
				}
			}

			$plugins_path = trailingslashit( WP_PLUGIN_DIR );
			$plugins_dirs = preg_grep( '/^([^.])/', scandir( $plugins_path ) );
			foreach( $plugins_dirs as $p_key => $plugin_name ) {
				if( is_dir( $plugins_path . $plugin_name ) && file_exists( $plugins_path . $plugin_name . '/cssjockey-addon.php' ) ) {
					if( in_array( $plugin_name, $active_addons ) ) {
						$module_init_paths[ $plugin_name ] = $plugins_path . $plugin_name . '/init.php';
						// rest api routes
						$rest_api_dir = $plugins_path . $plugin_name . '/api-routes/';
						if( is_dir( $rest_api_dir ) ) {
							$api_route_files = preg_grep( '/^([^.])/', scandir( $rest_api_dir ) );
							foreach( $api_route_files as $api_file_key => $api_route_file ) {
								$api_route_file = $rest_api_dir . $api_route_file;
								if( file_exists( $api_route_file ) && ! is_dir( $api_route_file ) ) {
									$api_route_paths[] = $api_route_file;
								}
							}
						}
					}
				}
			}

			$installed_versions = get_option( 'cjaddons_upgrades', array() );
			if( ! empty( $module_init_paths ) ) {
				foreach( $module_init_paths as $plugin_name => $init_path ) {
					require_once $init_path;
					$module_info = $this->helpers->moduleInfo( $plugin_name );
					$installed_versions[ $plugin_name ] = $module_info['module_version'];
					update_option( 'cjaddons_installed_versions', $installed_versions );
				}
			}

			if( ! empty( $api_route_paths ) ) {
				foreach( $api_route_paths as $plugin_name => $api_path ) {
					require_once $api_path;
				}
			}
		}

		public function checkDependencies() {
			global $cjaddons_item_vars;
			$active_addons = $this->helpers->activeAddons();
			$missing_dependencies = array();
			$addons_ready = array();
			$folder_names = array();
			foreach( $active_addons as $key => $active_addon ) {
				if( isset( $cjaddons_item_vars['module_info'][ $active_addon ] ) ) {
					$addons_ready[ $key ] = 1;
					delete_option( 'cjaddons-' . $key . '-dependent-on' );
					$module_name = $cjaddons_item_vars['module_info'][ $active_addon ]['module_name'];
					$dependencies = $cjaddons_item_vars['module_info'][ $active_addon ]['dependencies'];

					$addon_info = $cjaddons_item_vars['module_info'][ $active_addon ];
					if( basename( $addon_info['module_path'] ) !== $addon_info['module_id'] ) {
						$folder_names[] = $addon_info;
					}

					if( ! empty( $dependencies ) ) {
						foreach( $dependencies as $k => $c ) {
							if( class_exists( $c ) ) {
								$class_instance = $c::getInstance();
								update_option( 'cjaddons-' . basename( $class_instance->module_dir ) . '-dependent-on', $cjaddons_item_vars['module_info'][ $active_addon ] );
							}
							if( ! class_exists( $c ) ) {
								$addons_ready[ $key ] = 0;
								$missing_dependencies[ $module_name ][ $c ] = '<span>' . $this->helpers->ucWords( $c, array('cjaddons_', '_', '-') ) . '</span>';
							}
						}
					}
				}
			}

			update_option( 'cjaddons_ready', $addons_ready );

			if( count( $missing_dependencies ) > 0 ) {
				foreach( $missing_dependencies as $k => $m ) {
					$addon_name = $k;
					$message = '';
					$message .= __( 'Requires following add-ons, please install and activate.', 'cssjockey-add-ons' );
					$message .= '<br><b>' . implode( ', ', $m ) . '</b><br>';
					$folder_name = 'addon-' . sanitize_title( $k );
					$message .= sprintf( __( 'Zip files for these add-ons can be found in <b>%s/plugins</b> folder. <br>You can also download these add-ons from <a target="_blank" href="%s">our website</a> using %s license key.', 'cssjockey-add-ons' ), $folder_name, $this->helpers->itemInfo( 'author_url' ), $k );
					$this->helpers->adminNotice( 'cjaddons-missing-dependencies', 'error', $message, $addon_name, false );
				}
			}

			if( count( $folder_names ) > 0 ) {
				foreach( $folder_names as $key => $value ) {
					$message = sprintf( __( 'Plugin folder name should be <b>%s</b> instead of <b>%s</b>', 'cssjockey-add-ons' ), $value['module_id'], basename( $value['module_path'] ) );
					$this->helpers->adminNotice( 'cjaddons-folder-issue', 'error', $message, $value['module_name'], false );
				}
			}
		}

		public function loadShortcodes() {

			$framework_features = $this->helpers->savedOption( 'core_features', array() );
			if( ! in_array( 'shortcodes', $framework_features ) ) {
				return false;
			}

			$shortcodes_path = $this->helpers->root_dir . '/shortcodes/';
			$dirs = preg_grep( '/^([^.])/', scandir( $shortcodes_path ) );
			if( is_array( $dirs ) ) {
				foreach( $dirs as $key => $shortcode_dir ) {
					if( is_dir( $shortcodes_path . $shortcode_dir ) ) {
						$file_path = $shortcodes_path . $shortcode_dir . '/init.php';
						if( file_exists( $file_path ) ) {
							require_once $file_path;
						}
					}
				}
			}
		}
	}

	cjaddons_load_modules::getInstance();
}