(function () {
    tinymce.create('tinymce.plugins.cssjockey_shortcodes_btn', {
        init: function (ed, url) {
            ed.addButton('cssjockey_shortcodes_btn', {
                title: 'CSSJockey Shortcodes',
                cmd: 'cssjockey_shortcodes_btn_command',
                image: url + '/icon.png'
            });
            ed.addCommand('cssjockey_shortcodes_btn_command', function () {
                jQuery(document).ready(function ($) {
                    $('.cj-shortcode-settings-iframe iframe').attr('src', '');
                    $('.cj-shortcode-blocks').show(0);
                    $('#cj-shortcode-ui').removeClass('cj-hidden');
                    $('.cj-material-panel .cj-thumb').each(function () {
                        var $el = $(this);
                        var bg_image = $el.data('background-image');
                        $el.attr('style', 'background-image: url("' + bg_image + '");');
                    });
                    var listener = function (e) {
                        var eventName = e.data[0];
                        var data = e.data[1];
                        switch (eventName) {
                            case 'shortcodeSettingsLoaded':
                                break;
                            case 'closeShortcodesPanel':
                                $('.cj-shortcode-settings-iframe iframe').attr('src', '');
                                $('.cj-shortcode-blocks').slideDown();
                                $('#cj-shortcode-ui').removeClass('cj-hidden');
                                break;
                            case 'shortcodeTag':
                                var obj = JSON.parse(data);
                                ed.execCommand('mceInsertContent', false, obj.shortcode_string);

                                $('.cj-shortcode-settings-iframe iframe').attr('src', '');
                                $('#cj-shortcode-ui').addClass('cj-hidden');

                                window.removeEventListener('message', listener, false);
                                return false;
                                break;
                        }
                    };
                    window.removeEventListener('message', listener, false);
                    window.addEventListener('message', listener, false);

                });
            });
        },
    });
    // Register plugin
    tinymce.PluginManager.add('cssjockey_shortcodes_btn', tinymce.plugins.cssjockey_shortcodes_btn);
})();
