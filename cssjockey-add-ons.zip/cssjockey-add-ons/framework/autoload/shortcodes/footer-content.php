<?php
$cssjockey_shortcodes = $this->shortcodesArray();
$cssjockey_components = get_posts( array(
	'posts_per_page' => - 1,
	'post_type' => 'cj-ui-blocks',
	'post_status' => 'publish',
) );
?>
<div class="cssjockey-ui">
    <div id="cj-shortcode-ui" class="cj-hidden">
        <div class="cj-header">
            <ul>
                <li><a class="cj-pl-15 cj-pr-15" href="<?php echo $this->helpers->itemInfo( 'author_url' ) ?>" target="_blank"><i class="icon-cssjockey cj-color-primary-invert"></i></a></li>
                <li class="cj-show-shortcodes cj-hidden"><a class="cj-pl-15 cj-pr-15" href="#"><?php _e( 'Shortcodes', 'cssjockey-add-ons' ) ?></a></li>
                <li class="cj-is-hidden-mobile cj-search-input"><input type="search" class="cj-quick-search" placeholder="<?php _e( 'Search..', 'cssjockey-add-ons' ) ?>" value=""></li>
                <li class="cj-is-pulled-right"><a class="cj-close-shortcodes-panel" href="#"><i class="fa fa-times"></i></a></li>
                <li class="cj-is-hidden-mobile cj-is-pulled-right"><a href="<?php echo $this->helpers->itemInfo( 'docs_url' ); ?>" target="_blank"><i class="fa fa-question"></i></a></li>
            </ul>
        </div>

        <div class="cj-builder">
            <div class="cj-shortcodes-list">
                <div class="cj-shortcode-blocks">
                    <div class="cj-columns cj-is-multiline">
						<?php
						if( is_array( $cssjockey_shortcodes ) && ! empty( $cssjockey_shortcodes ) ) {
							foreach( $cssjockey_shortcodes as $shortcode_tag => $shortcode_info ) {
								if( isset( $shortcode_info['info'] ) ) {
									$url = $this->helpers->callbackUrl( 'config', 'core-shortcode-iframe', 'cjaddons', true ) . 'shortcode=' . $shortcode_tag;
									?>
                                    <div class="cj-column cj-is-3-widescreen cj-is-4-desktop cj-is-half-tablet cj-is-full-mobile cj-quick-searchable">
                                        <div class="cj-box cj-material-panel">
                                            <div class="cj-thumb" data-background-image="<?php echo $shortcode_info['info']['screenshot'] ?>"></div>
                                            <div class="cj-entry">
                                                <a href="#" data-iframe-url="<?php echo $url; ?>" class="cj-button cj-is-success cj-btn-plus cj-load-shortcode-options-iframe">
                                                    <span class="cj-icon"><i class="fa fa-plus"></i></span>
                                                </a>
                                                <h3 class="cj-fs-16 cj-m-0">
													<?php echo $shortcode_info['info']['name']; ?>
                                                    <span class="cj-ml-10 cj-fs-14 cj-color-success">(<?php echo $shortcode_info['info']['group']; ?>)</span>
                                                </h3>
                                                <!--<div class="pt-5 opacity-50">
														<?php /*echo '[' . $shortcode_info['info']['tag'] . ']'; */ ?>
                                                    </div>-->
                                                <div class="cj-pt-5"><?php echo $this->helpers->trimChars( $shortcode_info['info']['description'], 120, '...' ) ?></div>
                                            </div>
                                        </div>
                                    </div>
								<?php } ?>
							<?php } ?>
						<?php } ?>
                    </div>
                </div>
                <div class="cj-shortcode-settings-iframe">
                    <iframe src="" frameborder="0"></iframe>
                </div>
            </div>
        </div>

    </div>
</div>