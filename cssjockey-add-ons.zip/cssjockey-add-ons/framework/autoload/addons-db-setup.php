<?php
if( ! class_exists( 'cjaddons_db_setup' ) ) {
	class cjaddons_db_setup {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'init', array($this, 'dbSetup'), 1 );
			add_action( 'admin_init', array($this, 'syncOptions'), 2 );
			add_action( 'admin_init', array($this, 'syncDatabaseOptions') );
		}

		public function dbSetup() {
			global $wpdb;
			// delete_option( "cjaddons_db_version" );
			$charset_collate = $wpdb->get_charset_collate();
			$installed_ver = get_option( "cjaddons_db_version" );
			$migrations_installed = 0;
			$migrations = $this->helpers->item_vars['migrations'];
			$options_table = $wpdb->prefix . $this->helpers->itemInfo( 'options_table' );
			if( $wpdb->get_var( "SHOW TABLES LIKE '$options_table'" ) != $options_table ) {
				$options_table_name = str_replace( $wpdb->prefix, '', $options_table );
				$query = (isset( $migrations[ $options_table_name ] )) ? $migrations[ $options_table_name ] : '';
				if( $query != '' ) {
					$query = str_replace( '%TABLE_NAME%', $wpdb->prefix . $options_table_name, $query );
					$query = str_replace( '%CHARSET_COLLATE%', $charset_collate, $query );
					$wpdb->query( $query );
				}
			}

			if( ! empty( $migrations ) ) {
				foreach( $migrations as $table => $query ) {
					$table_name = $wpdb->prefix . $table;
					if( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) == $table_name ) {
						$migrations_installed += 1;
					}
				}
			}
			if( $migrations_installed != count( $migrations ) ) {
				$installed_ver = 0;
				delete_option( "cjaddons_db_version" );
			}
			if( ! $installed_ver && is_array( $this->helpers->saved_options ) && empty( $this->helpers->saved_options ) ) {
				$installed_ver = 0;
				delete_option( "cjaddons_db_version" );
			}

			if( $installed_ver != cjaddons_version ) {
				if( ! function_exists( 'wp_should_upgrade_global_tables' ) ) {
					require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
				}
				if( isset( $this->helpers->item_vars['migrations'] ) && is_array( $this->helpers->item_vars['migrations'] ) && $migrations_installed != count( $migrations ) ) {
					foreach( $this->helpers->item_vars['migrations'] as $key => $sql ) {
						$query = $sql;
						$query = str_replace( '%TABLE_NAME%', $wpdb->prefix . $key, $query );
						$query = str_replace( '%CHARSET_COLLATE%', $charset_collate, $query );
						$wpdb->query( $query );
					}
					$this->syncOptions();
					update_option( 'cjaddons_db_version', cjaddons_version );
				}
			}
		}

		public function syncOptions() {
			global $wpdb;
			$options_table = $this->helpers->itemInfo( 'options_table' );
			$options_table_name = $wpdb->prefix . $options_table;
			$default_options = $this->helpers->getDefaultOptions();
			$default_options_keys = array_keys( $default_options );
			$default_options_count = count( $default_options_keys );
			$saved_table_options = $wpdb->get_results( "SELECT * FROM $options_table_name", 'ARRAY_A' );
			$saved_options_keys = array_keys( $saved_table_options );
			$saved_options_count = count( $saved_options_keys );
			if( $default_options_count != $saved_options_count ) {
				update_option( 'cjaddons_saved_options', $saved_table_options );
				$wpdb->query( "TRUNCATE TABLE {$options_table_name}" );
				$synced_options = get_option( 'cjaddons_saved_options', true );
				foreach( $default_options as $d_key => $d_value ) {
					$this->helpers->addOption( $d_key, $d_value );
				}
				foreach( array_values( $synced_options ) as $s_key => $s_value ) {
					if( isset( $default_options[ $s_value['option_name'] ] ) ) {
						$this->helpers->updateOption( $s_value['option_name'], $s_value['option_value'] );
					}
				}
				$all_cjaddons_options = get_option( 'cjaddons_all_options' );
				if( is_array( $all_cjaddons_options ) && ! empty( $all_cjaddons_options ) ) {
					foreach( $all_cjaddons_options as $a_key => $a_value ) {
						if( isset( $default_options[ $a_key ] ) ) {
							$this->helpers->updateOption( $a_key, $a_value );
						}
					}
				}
				$saved_table_options = $wpdb->get_results( "SELECT * FROM $options_table_name", 'ARRAY_A' );
				update_option( 'cjaddons_saved_options', $saved_table_options );
			}
		}

		public function syncDatabaseOptions() {
			if( isset( $_GET['cjaddons-sync-db'] ) ) {
				if( wp_verify_nonce( $_GET['cjaddons-sync-db'], 'cjaddons-sync-db-options' ) ) {
					delete_option( "cjaddons_db_version" );
					$ref_url = explode( '&cjaddons-sync-db', $this->helpers->currentUrl() );
					wp_redirect( $ref_url[0] );
					exit;
				}
			}
		}

	}

	cjaddons_db_setup::getInstance();
}