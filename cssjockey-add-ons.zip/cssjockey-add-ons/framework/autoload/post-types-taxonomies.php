<?php
if( ! class_exists( 'cjaddons_register_post_types_taxonomies' ) ) {
	class cjaddons_register_post_types_taxonomies {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'init', array($this, 'registerPostTypes') );
			add_action( 'init', array($this, 'registerTaxonomies') );
			add_action( 'init', array($this, 'registerNavMenus') );
			add_action( 'wp_loaded', function () {
				$taxonomies = get_taxonomies();
				$post_types = get_post_types();
				$save = array();
				foreach($post_types as $key => $value){
					$save[$key] = get_post_type_object($key);
				}
				update_option( 'cjaddons_taxonomies', $taxonomies );
				update_option( 'cjaddons_post_types', $save );
			} );
		}

		public function registerPostTypes() {
			$post_types = $this->helpers->itemVars( 'post_types' );
			if( is_array( $post_types ) && ! empty( $post_types ) ) {
				foreach( $post_types as $key => $post_type ) {
					if( ! empty( $post_type ) && isset( $post_type['labels'] ) ) {
						$labels = '';
						$labels = $post_type['labels'];
						$args = array(
							'labels' => $labels,
							'public' => $post_type['args']['public'],
							'publicly_queryable' => $post_type['args']['publicly_queryable'],
							'show_ui' => $post_type['args']['show_ui'],
							'show_in_menu' => $post_type['args']['show_in_menu'],
							'query_var' => $post_type['args']['query_var'],
							'rewrite' => $post_type['args']['rewrite'],
							'capability_type' => $post_type['args']['capability_type'],
							'has_archive' => $post_type['args']['has_archive'],
							'hierarchical' => $post_type['args']['hierarchical'],
							'menu_position' => $post_type['args']['menu_position'],
							'supports' => $post_type['args']['supports'],
							'menu_icon' => $post_type['args']['menu_icon'],
							'taxonomies' => $post_type['args']['taxonomies'],
						);
						register_post_type( $key, $args );
					}
				}
			}
		}

		public function registerTaxonomies() {

			$custom_taxonomies = $this->helpers->itemVars( 'taxonomies' );
			if( is_array( $custom_taxonomies ) && ! empty( $custom_taxonomies ) ) {
				foreach( $custom_taxonomies as $key => $taxonomy ) {
					if( ! empty( $taxonomy ) ) {
						$labels = '';
						$labels = $taxonomy['labels'];
						$args = array(
							'hierarchical' => $taxonomy['args']['hierarchical'],
							'labels' => $labels,
							'show_ui' => $taxonomy['args']['show_ui'],
							'show_admin_column' => $taxonomy['args']['show_admin_column'],
							'query_var' => $taxonomy['args']['query_var'],
							'rewrite' => $taxonomy['args']['rewrite'],
						);
						register_taxonomy( $key, $taxonomy['post_types'], $args );
					}
				}
			}
		}

		public function registerNavMenus() {
			$nav_menus = $this->helpers->itemVars( 'nav_menus' );
			if( is_array( $nav_menus ) ) {
				foreach( $nav_menus as $key => $nav_menu ) {
					register_nav_menus( $nav_menu );
				}
			}
		}

	}

	cjaddons_register_post_types_taxonomies::getInstance();
}