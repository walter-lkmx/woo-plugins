<?php
if( ! class_exists( 'cjaddons_admin_notices_setup' ) ) {
	class cjaddons_admin_notices_setup {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'admin_notices', array($this, 'coreAdminNotices') );
			add_action( 'wp_ajax_cjaddons_close_admin_notice', array($this, 'ajaxCloseAdminNotice') );
			add_action( 'admin_notices', array($this, 'adminNotices') );
		}

		public function adminNotices() {
			$framework_version = $this->helpers->itemInfo( 'item_version' );
			$file_path = sprintf( '%s/framework/autoload/admin-notices/version-%s.php', $this->helpers->root_dir, $framework_version );
			if( file_exists( $file_path ) ) {
				require_once $file_path;
			}
		}

		public function coreAdminNotices() {
			do_action( 'cjaddons_admin_notices' );
		}

		public function ajaxCloseAdminNotice() {
			$post_data = $_POST['post_data'];
			$notice_id = $post_data['notice_id'];
			$closed_notices = get_option( 'cjaddons_admin_notices' );
			if( ! $closed_notices ) {
				$data[ $notice_id ] = $notice_id;
				update_option( 'cjaddons_admin_notices', $data );
			} else {
				$closed_notices[ $notice_id ] = $notice_id;
				update_option( 'cjaddons_admin_notices', $closed_notices );
			}
			echo 'success';
			wp_die();
		}

	}

	cjaddons_admin_notices_setup::getInstance();
}