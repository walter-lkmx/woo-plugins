<?php

use Leafo\ScssPhp\Compiler;

if( ! class_exists( 'cjaddons_core_sass' ) ) {
	class cjaddons_core_sass {

		public $helpers, $ui_base_css_path, $helpers_css_path;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			$this->ui_base_css_path = $this->helpers->upload_path . '/cssjockey-ui/ui-base.min.css';
			$this->helpers_css_path = $this->helpers->upload_path . '/cssjockey-ui/helpers.min.css';
			add_action( 'admin_notices', array($this, 'checkDirs') );
			add_action( 'admin_init', array($this, 'compileCoreSass') );
			add_action( 'template_redirect', array($this, 'compileSassTest'), 1 );
		}

		public function compileSassTest() {

			if( isset( $_GET['scss-test'] ) && $_GET['scss-test'] == 1 ) {
				$scss_content = '@import "ui-base";';
				echo $this->helpers->compileSass( $scss_content );
				die();
			}
		}

		public function checkDirs() {
			if( ! is_writable( $this->helpers->upload_path ) ) {
				$content = sprintf( __( 'Folder <b>%s</b> is <span class="color-danger text-bold">NOT</span> writable. <a href="%s" target="_blank">Click here</a> to learn more about the fix.', 'cssjockey-add-ons' ), $this->helpers->upload_path, 'https://codex.wordpress.org/Changing_File_Permissions' );
				$message = '<span class="cssjockey-ui">' . $content . '</span>';
				echo $this->helpers->adminNotice( 'cjaddons_core_sas_files', 'error', $message, __( 'CSSJockey Add-Ons', 'cssjockey-add-ons' ), true );
			}
		}

		public function compileCoreSass() {
			if( ! is_writable( $this->helpers->upload_path ) ) {
				return false;
			}
			if( is_writable( $this->helpers->upload_path ) && ! is_dir( $this->helpers->upload_path . '/cssjockey-ui' ) ) {
				$this->helpers->createDirectory( $this->helpers->upload_path . '/cssjockey-ui' );
				$this->helpers->createDirectory( $this->helpers->upload_path . '/cssjockey-add-ons' );
				$this->helpers->putFileContents( $this->helpers->upload_path . '/cssjockey-ui/index.php', '<?php // Silence is golden' );
			}

			if( is_writable( $this->helpers->upload_path ) ) {
				if( file_exists( $this->ui_base_css_path ) ) {
					// $this->helpers->deleteFile( $this->ui_base_css_path );
				}
				$scss_content = '';
				$helpers_scss_content = '';
				$saved_sass_variables = $this->helpers->getOption( 'core_sass_variables' );

				if( ! is_array( $saved_sass_variables ) ) {
					$sass_user_variables = $this->helpers->userSassVariables();
					$save_variables = array();
					foreach( $sass_user_variables as $sass_var_key => $sass_var_value ) {
						$save_variables[ $sass_var_key ] = $sass_var_value['default'];
					}
					$this->helpers->updateOption( 'core_sass_variables', $save_variables );
					$saved_sass_variables = $this->helpers->getOption( 'core_sass_variables' );
				}

				if( is_array( $saved_sass_variables ) && ! empty( $saved_sass_variables ) ) {
					foreach( $saved_sass_variables as $key => $value ) {
						if( is_numeric( $value ) ) {
							$value = $value . 'px';
						}
						$scss_content .= '$' . $key . ':  ' . $value . ' !default;' . "\n";
						$helpers_scss_content .= '$' . $key . ':  ' . $value . ' !default;' . "\n";
					}
				}

				if( ! file_exists( $this->ui_base_css_path ) ) {
					$scss_content .= '@import "ui-base";';
					$ui_sass_content = $this->helpers->compileSass( $scss_content );
					$this->helpers->putFileContents( $this->ui_base_css_path, $ui_sass_content );
				}

				if( ! file_exists( $this->helpers_css_path ) ) {
					$helpers_scss_content .= '@import "helpers";';
					$helpers_css = $this->helpers->compileSass( $helpers_scss_content );
					$this->helpers->putFileContents( $this->helpers_css_path, $helpers_css );
				}
			}

			// report errors to admin
			if( current_user_can( 'manage_options' ) ) {
				$admin_message = array();
				if( ! file_exists( $this->ui_base_css_path ) ) {
					$admin_message[] = sprintf( __( 'Unable to create <b>%s</b>.', 'cssjockey-add-ons' ), $this->ui_base_css_path );
				}
				if( ! file_exists( $this->helpers_css_path ) ) {
					$admin_message[] = sprintf( __( 'Unable to create <b>%s</b>.', 'cssjockey-add-ons' ), $this->helpers_css_path );
				}

				if( ! empty( $admin_message ) ) {
					$admin_message[] = sprintf( __( '<a href="%s">Click here for more details.</a>', 'cssjockey-add-ons' ), $this->helpers->callbackUrl( 'config', 'core-sass' ) );
					$this->helpers->adminNotice( 'sass-config', 'error', implode( '<br>', $admin_message ), $this->helpers->itemInfo( 'item_name' ), false );
				}
			}
		}

	}

	cjaddons_core_sass::getInstance();
}