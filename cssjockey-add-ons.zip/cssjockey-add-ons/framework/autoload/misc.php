<?php
if( ! class_exists( 'cjaddons_misc_functions' ) ) {
	class cjaddons_misc_functions {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_filter( 'the_content', array($this, 'fixShortcodes') );
			add_action( 'wp_head', array($this, 'redirect') );

			// shortcode <br> fix

			// remove_filter( 'the_content', 'wpautop' );
			// add_filter( 'the_content', 'wpautop' , 99);
		}

		public function fixShortcodes( $content ) {
			$array = array(
				'<p>[' => '[',
				']</p>' => ']',
				']<br />' => ']',
				']<br>' => ']'
			);

			$content = strtr( $content, $array );

			return $content;
		}

		public function redirect() {
			if( isset( $_GET['cjaddons-goto'] ) && $_GET['cjaddons-goto'] != '' ) {
				$link = urldecode( $_GET['cjaddons-goto'] );
				wp_redirect( $link );
				die();
			}
		}

	}

	cjaddons_misc_functions::getInstance();
}
