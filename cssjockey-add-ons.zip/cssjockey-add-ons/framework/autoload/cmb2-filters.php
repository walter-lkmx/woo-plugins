<?php
add_filter( 'cmb2_show_on', 'cjaddons_cmb_show_on_meta_value', 10, 2 );
function cjaddons_cmb_show_on_meta_value( $display, $meta_box ) {

	if( ! isset( $meta_box['show_on']['meta_key'] ) ) {
		return $display;
	}

	$post_id = 0;

	// If we're showing it based on ID, get the current ID
	if( isset( $_GET['post'] ) ) {
		$post_id = $_GET['post'];
	} elseif( isset( $_POST['post_ID'] ) ) {
		$post_id = $_POST['post_ID'];
	}

	if( ! $post_id ) {
		return $display;
	}

	$value = get_post_meta( $post_id, $meta_box['show_on']['meta_key'], true );

	if( empty( $meta_box['show_on']['meta_value'] ) ) {
		return (bool) $value;
	}

	return $value == $meta_box['show_on']['meta_value'];
}