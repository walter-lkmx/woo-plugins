<?php
if( ! class_exists( 'cjaddons_ui_blocks_setup' ) ) {
	class cjaddons_ui_blocks_setup {
		private static $instance;
		public $helpers;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'wp_ajax_get_ui_blocks_by_type', array($this, 'getUiBlocksByType') );
			add_action( 'template_redirect', array($this, 'showUiBlockSelectorPanel'), 1 );
		}

		public function showUiBlockSelectorPanel() {
			if( isset( $_GET['cjaddons-show-ui-blocks-selector'] ) && $_GET['cjaddons-show-ui-blocks-selector'] == 1 ) {

				require_once 'html/ui-block-selector.php';
				die();
			}
		}

		public function getUiBlocksByType() {
			$return = array();
			$posts_per_page = 12;
			$offset = (int) $_POST['page'] * $posts_per_page;
			if( $_POST['type'] == 'saved' ) {
				$return = array();
				$total_blocks = wp_count_posts( 'cj-ui-blocks' );
				$args = array(
					'posts_per_page' => $posts_per_page,
					'offset' => $offset,
					'paged' => (isset( $_POST['page'] ) && $_POST['page'] > 0) ? $_POST['page'] : '',
					'post_type' => 'cj-ui-blocks',
					'post_status' => 'publish',
					'orderby' => 'post_date',
					'order' => 'DESC',
				);
				if( isset( $_POST['search'] ) && $_POST['search'] != '' ) {
					$args['s'] = $_POST['search'];
				}

				$saved_blocks = array();
				$the_query = new WP_Query( $args );
				if( $the_query->have_posts() ) {
					while( $the_query->have_posts() ) {
						$the_query->the_post();
						global $post;
						$saved_blocks[] = $post;
					}
					wp_reset_postdata();
				}

				if( is_array( $saved_blocks ) && ! empty( $saved_blocks ) ) {
					foreach( $saved_blocks as $key => $block ) {
						$class_name = get_post_meta( $block->ID, '_component_class_name', true );
						if( class_exists( $class_name ) ) {
							$class_instance = $class_name::getInstance();
							$class_info = $class_instance->info();
							$return[] = array(
								'total' => (int) $total_blocks->publish,
								'type' => $_POST['type'],
								'class_name' => $class_name,
								'block_id' => $block->ID,
								'group' => $class_info['group'],
								'group_name' => ucwords( str_replace( array('-', '_'), ' ', $class_info['group'] ) ),
								'name' => $block->post_title,
								'description' => $class_info['description'],
								'screenshot' => $class_info['screenshot'],
							);
						}
					}
				}
				echo json_encode( $return );
				die();
			}

			if( $_POST['type'] == 'get-more' ) {
				$url = 'https://cssjockey.com/wp-json/cjaddons/addon-cssjockey/get-ui-blocks';
				$query = $_POST;
				$result = $this->helpers->wpRemotePost( $url, $query, array(), 'all' );
				if( isset( $result['response'] ) && isset( $result['response']['code'] ) && $result['response']['code'] == 200 ) {
					$result = (array) json_decode( $result['body'] );
					$result = (array) $result['data'];
					foreach( $result as $key => $block ) {
						$return[] = array(
							'total' => $block->total,
							'type' => $_POST['type'],
							'class_name' => '',
							'block_id' => '',
							'group' => $block->price_format,
							'group_name' => $block->price_format,
							'name' => $block->name,
							'description' => $this->helpers->trimChars( $block->description, 80, '...' ),
							'screenshot' => $block->screenshot,
							'download_url' => $block->download_url,
						);
					}
				}
				echo json_encode( $return );
				die();
			}
		}

	}

	cjaddons_ui_blocks_setup::getInstance();
}