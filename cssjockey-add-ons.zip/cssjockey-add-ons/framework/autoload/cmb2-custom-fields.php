<?php

if( ! class_exists( 'cjaddons_cmb2_custom_fields' ) ) {
	class cjaddons_cmb2_custom_fields {
		private static $instance;
		public $helpers;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_filter( 'cmb2_render_address', array($this, 'addressFieldWithMap'), 10, 5 );
			add_action( 'save_post', array($this, 'saveGoogleMapsApiKey') );
		}

		public function addressFieldWithMap( $field, $value, $object_id, $object_type, $field_type ) {
			// make sure we specify each part of the value we need.
			$value = wp_parse_args( $value, array(
				'address_line_1' => '',
				'address_line_2' => '',
				'city' => '',
				'state' => '',
				'country' => '',
				'zip' => '',
				'lat' => '',
				'lng' => '',
			) );
			$google_maps_api_key = get_option( 'cjaddons_google_maps_api_key' );
			include "cmb2-fields-html/address-with-map.php";
			if( $google_maps_api_key ) {
				require_once 'cmb2-fields-html/google-maps-js.php';
			}
			echo $field_type->_desc( true );
		}

		public function saveGoogleMapsApiKey() {
			if( isset( $_POST['cjaddons_google_maps_api_key'] ) && $_POST['cjaddons_google_maps_api_key'] != '' ) {
				update_option( 'cjaddons_google_maps_api_key', $_POST['cjaddons_google_maps_api_key'] );
			}
		}

	}

	cjaddons_cmb2_custom_fields::getInstance();
}