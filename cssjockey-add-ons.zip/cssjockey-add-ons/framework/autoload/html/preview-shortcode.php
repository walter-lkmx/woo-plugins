<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if( is_singular() && pings_open( get_queried_object() ) ) : ?>
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'cssjockey-ui' ) ?> style="background: #f7f7f7;">


<div class="cj-box cj-m-30">
	<?php
	$class_name = $_GET['cjaddons-preview-shortcode'] . '_shortcode';
	if( ! class_exists( $class_name ) ) {
		echo $this->helpers->alert( 'warning', 'Invalid shortcode tag', '', false );
	}
	if( class_exists( $class_name ) ) {
		$class_instance = $class_name::getInstance();
		$shortcode_defaults = $class_instance->defaults();
		$shortcode_options = $shortcode_defaults['options'];

		$shortcode_content = 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget.';
		if( isset( $_POST['default_content'] ) ) {
			$shortcode_content = $_POST['default_content'];
		}

		$shortcode_options_string = array();
		if( is_array( $shortcode_options ) ) {
			foreach( $shortcode_options as $options_key => $options_value ) {
				$shortcode_options_string[] = ' ' . $options_value['id'] . '=' . '"' . esc_attr( $options_value['default'] ) . '"';
			}
		}

		if( isset( $_POST['cjaddons_shortcode_tag'] ) ) {
			$post_data = $_POST;
			unset( $post_data['cjaddons_shortcode_tag'] );
			$shortcode_options_string = array();
			$atts = array();
			if( is_array( $post_data ) && ! empty( $post_data ) ) {
				foreach( $post_data as $key => $value ) {
					if( $key !== 'default_content' ) {
						$shortcode_options_string[] = ' ' . $key . '="' . esc_attr( $value ) . '"';
					}
				}
			}

			foreach( $shortcode_options as $option_key => $option_value ) {
				$shortcode_options[ $option_key ] = $option_value;
				$shortcode_options[ $option_key ]['default_value'] = $option_value['default'];
				$shortcode_options[ $option_key ]['default'] = $post_data[ $option_value['id'] ];
			}

			$shortcode_tag = stripcslashes( $_POST['cjaddons_shortcode_tag'] );
		}

		$shortcode_tag = '';
		$shortcode_tag .= '[';
		$shortcode_tag .= $shortcode_defaults['info']['tag'];
		$shortcode_tag .= implode( '', $shortcode_options_string );
		$shortcode_tag .= ']';
		if( ! $shortcode_defaults['info']['single'] ) {
			$shortcode_tag .= $shortcode_content;
			$shortcode_tag .= '[/' . $shortcode_defaults['info']['tag'] . ']';
		}
		echo do_shortcode( $shortcode_tag );

		?>
        <hr class="cj-mb-20">
        <form action="" method="post">
            <div class="cj-field">
                <p class="cj-control">
                    <textarea class="cj-textarea" name="cjaddons_shortcode_tag" cols="30" rows="3"><?php echo $shortcode_tag; ?></textarea>
                </p>
            </div>
            <div class="cj-field cj-mt-10">
                <p class="cj-control">
                    <button type="submit" class="cj-button cj-is-primary"><?php _e( 'Update', 'cssjockey-add-ons' ) ?></button>
                    <button data-clipboard-text='<?php echo $shortcode_tag; ?>' class="cj-button cj-ml-10"><span class="cj-icon cj-is-small"><i class="fa fa-copy"></i></span></button>
                </p>
            </div>
            <h2 class="cj-title"><?php _e( 'Shortcode Options:', 'cssjockey-add-ons' ) ?></h2>
            <hr class="cj-mt-10 cj-mb-0">
			<?php
			if( is_array( $shortcode_options ) ) {
				foreach( $shortcode_options as $options_key => $options_value ) {
					$options_string = (is_array( $options_value['options'] ) && ! empty( $options_value['options'] )) ? implode( '<br>', array_keys( $options_value['options'] ) ) : '';
					?>
                    <table class="cj-table cj-mb-30">
                        <thead>
                        <tr>
                            <th colspan="2" class="cj-fs-18" style="background: #F7F7F7;">
								<?php echo $options_value['id']; ?> :
                                <div class="cj-text-normal cj-opacity-50"><?php echo $options_value['info']; ?></div>
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td colspan="2" style="padding: 10px 10px 0px 10px; background: #ededed;">
								<?php
								$form_option = $options_value;
								unset( $form_option['label'] );
								unset( $form_option['info'] );
								echo $this->helpers->renderFrontendForm( array($form_option) );
								?>
                            </td>
                        </tr>
                        <tr>
                            <td width="150px"><span class="cj-is-pulled-right">:</span><?php _e( 'default', 'cssjockey-add-ons' ) ?></td>
                            <td>
								<?php
								if( isset( $options_value['default_value'] ) && $options_value['default_value'] != '' ) {
									echo $options_value['default_value'];
								} elseif( isset( $options_value['default'] ) && $options_value['default'] != '' ) {
									echo $options_value['default'];
								} else {
									echo '<i class="cj-opacity-50">(blank)</i>';
								}
								?>
                            </td>
                        </tr>
						<?php if( $options_string !== '' ) { ?>
                            <tr>
                                <td width="150px"><span class="cj-is-pulled-right">:</span><?php _e( 'options', 'cssjockey-add-ons' ) ?></td>
                                <td>
                                    <div style="max-height: 200px; overflow: hidden; overflow-y: scroll;">
										<?php echo $options_string; ?>
                                    </div>
                                </td>
                            </tr>
						<?php } ?>
                        </tbody>
                    </table>
					<?php
				}
			}
			?>
            <hr>
			<?php
			if( ! $shortcode_defaults['info']['single'] ) {
				$default_content = 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget.';
				if( isset( $_POST['default_content'] ) ) {
					$default_content = $_POST['default_content'];
				}
				echo $this->helpers->renderAdminForm( array(
					array(
						'id' => 'default_content',
						'type' => 'wysiwyg',
						'label' => 'Default Content',
						'info' => '',
						'default' => $default_content,
						'options' => '', // array in case of dropdown, checkbox and radio buttons
					)
				) );
			}
			?>
        </form>
	<?php } ?>

</div>

<div class="cj-end-html"></div>
<?php wp_footer(); ?>
<script>
    jQuery(document).ready(function ($) {
        $('div.cj-end-html').nextAll('div').hide();
    });
</script>
</body>
</html>