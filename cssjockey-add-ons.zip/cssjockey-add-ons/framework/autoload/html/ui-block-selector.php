<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if( is_singular() && pings_open( get_queried_object() ) ) : ?>
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<?php wp_head(); ?>
    <style>
        html {
            margin: 0 !important;
            padding: 0 !important;
        }
        body {
            background-color: #f1f1f1 !important;
            margin: 0 !important;
            padding: 0 !important;
            font-size: 14px;
        }
        #wpadminbar {
            display: none;
        }
        body:before,
        body:after {
            display: none !important;
        }
    </style>
    <script src="<?php echo $this->helpers->root_url.'/framework/lib/iframe.min.js' ?>"></script>
</head>
<body <?php body_class() ?>>
<div class="cssjockey-ui">
    <div id="cj-vue-ui-block-selector">
        <cjaddons-ui-block-selector></cjaddons-ui-block-selector>
    </div>
</div>
<?php wp_footer(); ?>
</body>
</html>