<?php
if( ! class_exists( 'cjaddons_admin_wp_footer_setup' ) ) {
	class cjaddons_admin_wp_footer_setup {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'admin_footer', array($this, 'hideMainMenu'), 1, 1 );
			add_action( 'wp_footer', array($this, 'previewShortcode') );
			add_action( 'wp_footer', array($this, 'globalWpFooter') );
			add_action( 'wp_head', array($this, 'globalWpHead') );
		}

		public function hideMainMenu() {

			// google maps api key
			$google_maps_api_key = $this->helpers->savedOption('core_google_maps_key');
			if($google_maps_api_key !== ''){
				echo '<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?libraries=places&libraries=places&key='.$google_maps_api_key.'" async defer></script>';
			}

			ob_start();
			require_once $this->helpers->root_dir.'/framework/html/admin-footer.php';
			echo ob_get_clean();
		}

		public function globalWpFooter() {
			ob_start();
			require_once $this->helpers->root_dir.'/framework/html/wp-footer.php';
			echo ob_get_clean();
		}

		public function globalWpHead() {
			// google maps api key
			$google_maps_api_key = $this->helpers->savedOption('core_google_maps_key');
			if($google_maps_api_key !== ''){
				echo '<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?libraries=places&libraries=places&key='.$google_maps_api_key.'" async defer></script>';
			}
		}

		public function previewShortcode() {
			if( isset( $_GET['cj-shortcode-preview'] ) && $_GET['cj-shortcode-preview'] == 1 && isset( $_GET['iframe'] ) && $_GET['iframe'] == 1 && isset( $_GET['shortcode'] ) && $_GET['shortcode'] != '' ) {
				require_once $this->helpers->root_dir . '/framework/shortcode-generator/preview.php';
				die();
			}
		}

	}

	cjaddons_admin_wp_footer_setup::getInstance();
}