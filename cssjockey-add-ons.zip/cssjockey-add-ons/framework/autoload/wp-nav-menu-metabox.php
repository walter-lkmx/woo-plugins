<?php
if( ! class_exists( 'cjaddons_wp_nav_menu_metabox' ) ) {
	class cjaddons_wp_nav_menu_metabox {
		private static $instance;
		public $helpers;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'admin_init', array($this, 'navMenuMetaBox'), 99999 );
		}

		public function navMenuMetaBox() {
			add_meta_box(
				'cjaddons_nav_menus_metabox',
				'CSSJockey Add-ons',
				array($this, 'navMenusMetaBoxUi'),
				'nav-menus',
				'side',
				'high'
			);
		}

		public function navMenusMetaBoxUi() {

			$nav_menus = array();
			$menus = apply_filters( 'cjaddons_nav_menu_metabox_links', $nav_menus );

			if( empty( $menus ) ) {
				echo __( 'No items.', 'cssjockey-add-ons' );
			}
			?>
            <div id="cjaddons-wp-nav-menu-links" class="posttypediv" style="padding: 0; margin-top: -25px;">
                <div id="tabs-panel-cjaddons-wp-nav-menus" class="tabs-panel tabs-panel-active" style="border: none; padding: 0;">
                    <ul id="cjaddons-wp-nav-menus-checklist" class="categorychecklist form-no-clear" style="margin-top: 0; margin-bottom: 0; padding-bottom: 10px;">
						<?php
						$count = 10000000;
						foreach( $menus as $key => $menu ) {
							if( $menu['type'] == 'cjaddons-metabox-heading' ) {
								echo '<p style="margin-bottom: 5px;"><strong>' . $menu['label'] . '</strong></p>';
							} else {
								$count --;
								?>
                                <li>
                                    <label class="menu-item-title">
                                        <input type="checkbox" class="menu-item-checkbox" name="menu-item[<?php echo $count; ?>][menu-item-object-id]" value="<?php echo $count; ?>"> <?php echo $menu['label'] ?>
                                    </label>
                                    <input type="hidden" class="menu-item-type" name="menu-item[<?php echo $count; ?>][menu-item-type]" value="<?php echo $menu['type'] ?>">
                                    <input type="hidden" class="menu-item-title" name="menu-item[<?php echo $count; ?>][menu-item-title]" value="<?php echo $menu['title'] ?>">
                                    <input type="hidden" class="menu-item-url" name="menu-item[<?php echo $count; ?>][menu-item-url]" value="<?php echo $menu['url'] ?>">
                                    <input type="hidden" class="menu-item-classes" name="menu-item[<?php echo $count; ?>][menu-item-classes]" value="<?php echo $menu['classes'] ?>">
                                </li>
							<?php }
						} ?>
                    </ul>
                </div>
                <p class="button-controls" style="margin-top: 0; padding-top: 15px; border-top: 1px solid #dddddd;">
                    <span class="list-controls">
        				<a href="/wordpress/wp-admin/nav-menus.php?page-tab=all&amp;selectall=1#cjaddons-wp-nav-menu-links" class="select-all">Select All</a>
        			</span>
                    <span class="add-to-menu">
        				<input type="submit" class="button-secondary submit-add-to-menu right" value="Add to Menu" name="add-post-type-menu-item" id="submit-cjaddons-wp-nav-menu-links">
        				<span class="spinner"></span>
        			</span>
                </p>
            </div>
		<?php }

	}

	cjaddons_wp_nav_menu_metabox::getInstance();
}