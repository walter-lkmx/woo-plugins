<?php

if( ! class_exists( 'cjaddons_setup_components' ) ) {
	class cjaddons_setup_components {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'load-post.php', array($this, 'metaboxInit') );
			add_action( 'load-post-new.php', array($this, 'metaboxInit') );
			add_action( 'wp_ajax_attach_component', array($this, 'attachComponent') );
			add_action( 'wp_ajax_detach_component', array($this, 'detachComponent') );
			add_action( 'wp_ajax_create_component', array($this, 'createComponent') );
			add_action( 'template_redirect', array($this, 'previewBlock') );

			add_filter( 'post_row_actions', array($this, 'editPostAdminLinks'), 10, 2 );
			add_action( 'admin_init', array($this, 'cloneUiBlock') );

			add_action( 'wp_ajax_nopriv_cjaddons_components_css', array($this, 'componentsCss'), 10 );
			add_action( 'wp_ajax_cjaddons_components_css', array($this, 'componentsCss'), 10 );
			add_action( 'wp_ajax_nopriv_cjaddons_components_js', array($this, 'componentsJs'), 10 );
			add_action( 'wp_ajax_cjaddons_components_js', array($this, 'componentsJs'), 10 );
			add_action( 'wp_footer', array($this, 'enqueueUiBlockAssets'), 99999 );

			add_action( 'wp_ajax_cjaddons_get_component_info', array($this, 'getComponentInfo'), 10 );

			add_action( 'the_content', array($this, 'frontendUiBlocksPanel'), 10 );
			add_action( 'wp_ajax_cjaddons_get_ui_blocks', array($this, 'frontendGetUiBlocks') );
			add_action( 'wp_ajax_cjaddons_frontend_add_ui_block', array($this, 'frontendAddUiBlock') );
			add_action( 'wp_ajax_cjaddons_frontend_delete_ui_block', array($this, 'frontendDeleteUiBlock') );
			add_action( 'wp_ajax_cjaddons_frontend_sort_ui_block', array($this, 'frontendSortUiBlock') );

			add_action( 'plugins_loaded', array($this, 'includeComponents') );
			add_action( 'cjaddons_core_sass_updated', array($this, 'coreSassUpdated') );
			add_action( 'wp_enqueue_scripts', array($this, 'removeThemeAssets'), 99 );
		}

		public function coreSassUpdated() {
			global $wpdb;
			$blocks = $wpdb->get_results( "SELECT * from $wpdb->posts WHERE post_type = 'cj-ui-blocks' AND post_status = 'publish'" );
			foreach( $blocks as $key => $block ) {
				update_post_meta( $block->ID, '_cjaddons_compile_sass', 'yes' );
			}
		}

		public function includeComponents() {
			$wp_content_ui_blocks_dir = $this->helpers->upload_path . '/cssjockey-add-ons/ui-blocks/';
			if( is_dir( $wp_content_ui_blocks_dir ) ) {
				$dirs = preg_grep( '/^([^.])/', scandir( $wp_content_ui_blocks_dir ) );
				foreach( $dirs as $key => $dir_name ) {
					$file_path = $wp_content_ui_blocks_dir . $dir_name . '/init.php';
					if( is_file( $file_path ) && file_exists( $file_path ) ) {
						require($file_path);
					}
				}
			}
		}

		public function componentsCss() {
			ob_start();
			require_once $this->helpers->root_dir . '/framework/autoload/components/ui-blocks.css.php';
			echo ob_get_clean();
			die();
		}

		public function componentsJs() {
			ob_start();
			require_once $this->helpers->root_dir . '/framework/autoload/components/ui-blocks.js.php';
			echo ob_get_clean();
			die();
		}

		public function enqueueUiBlockAssets() {
			$block_ids = array();
			if( is_singular() ) {
				global $post;
				$post_info = $this->helpers->postInfo( $post->ID );
				if( is_array( $post_info ) && ! empty( $post_info ) ) {
					if( isset( $post_info['cjaddons_ui_blocks_above'] ) ) {
						$blocks_above = explode( ',', $post_info['cjaddons_ui_blocks_above'] );
						foreach( $blocks_above as $key => $block_id ) {
							$block_ids[ $block_id ] = $block_id;
						}
					}
					if( isset( $post_info['cjaddons_ui_blocks_below'] ) ) {
						$blocks_below = explode( ',', $post_info['cjaddons_ui_blocks_below'] );
						foreach( $blocks_below as $key => $block_id ) {
							$block_ids[ $block_id ] = $block_id;
						}
					}
				}
			}
			$block_ids_array = apply_filters( 'cjaddons_ui_block_assets', $block_ids );

			$params = base64_encode( ABSPATH );

			$item_version = sha1( implode( '', $block_ids_array ) );
			if( $this->helpers->isLocal() ) {
				$item_version = time();
			}

			$css_file_path = $this->helpers->root_url . '/framework/autoload/components/ui-blocks.css.php';
			$js_file_path = $this->helpers->root_url . '/framework/autoload/components/ui-blocks.js.php';

			echo '<link rel="stylesheet" href="' . $css_file_path . '?params=' . $params . '&blocks=' . implode( '|', $block_ids_array ) . '&ver=' . $item_version . '" media="all" />';
			echo '<script type="text/javascript" src="' . $js_file_path . '?params=' . $params . '&blocks=' . implode( '|', $block_ids_array ) . '&ver=' . $item_version . '"></script>';
		}

		public function metaboxInit() {
			add_action( 'add_meta_boxes', array($this, 'addUiBlockMetaBox') );
			add_action( 'save_post', array($this, 'saveBlockSettings') );
		}

		public function saveBlockSettings( $post_id ) {
			// Check if our nonce is set.
			if( ! isset( $_POST['cjaddons_ui_block_metabox_nonce'] ) ) {
				return $post_id;
			}
			$nonce = $_POST['cjaddons_ui_block_metabox_nonce'];
			// Verify that the nonce is valid.
			if( ! wp_verify_nonce( $nonce, 'cjaddons_ui_block_metabox' ) ) {
				return $post_id;
			}
			/*
			 * If this is an autosave, our form has not been submitted,
			 * so we don't want to do anything.
			 */
			if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				return $post_id;
			}

			// Check the user's permissions.
			if( 'page' == $_POST['post_type'] ) {
				if( ! current_user_can( 'edit_page', $post_id ) ) {
					return $post_id;
				}
			} else {
				if( ! current_user_can( 'edit_post', $post_id ) ) {
					return $post_id;
				}
			}
			$this->helpers->updateUiBlockSettings( $post_id, $_POST );
		}

		public function addUiBlockMetaBox( $post_type ) {
			// Limit meta box to certain post types.
			if( $post_type != 'cj-ui-blocks' ) {
				return;
			}
			add_meta_box(
				'cj-ui-blocks-metabox',
				'<span class="cssjockey-ui"><i class="icon-cssjockey cj-color-cj-red  cj-color-primary cj-mr-10"></i> ' . __( 'UI Block Builder', 'cssjockey-add-ons' ) . ' </span>',
				array($this, 'renderUiBlockMetabox'),
				'cj-ui-blocks',
				'normal',
				'high'
			);
			$post_id = get_the_ID();
			$class_name = get_post_meta( $post_id, '_component_class_name', true );
			if( $class_name != '' && class_exists( $class_name ) ) {
				add_meta_box(
					'cj-ui-block-shortcode-metabox',
					'<span class="cssjockey-ui"><i class="icon-cssjockey cj-color-cj-red cj-mr-10"></i> ' . __( 'UI Block Settings', 'cssjockey-add-ons' ) . ' </span>',
					array($this, 'renderUiBlockShortcodeMetabox'),
					'cj-ui-blocks',
					'normal',
					'low'
				);
			}
		}

		public function renderUiBlockMetabox( $post ) {
			// Add an nonce field so we can check for it later.
			wp_nonce_field( 'cjaddons_ui_block_metabox', 'cjaddons_ui_block_metabox_nonce' );
			// Use get_post_meta to retrieve an existing value from the database.
			$value = get_post_meta( $post->ID, '_my_meta_value_key', true );

			ob_start();
			require_once 'components/index.php';
			echo ob_get_clean();
		}

		public function renderUiBlockShortcodeMetabox( $post ) {
			$block_info = $this->helpers->postInfo( $post->ID );
			$class_name = $block_info['_component_class_name'];
			if( class_exists( $class_name ) ) {
				$shortcode_content = (string) "[cjaddons_ui_block block_id='" . $post->ID . "']";
				$class_instance = $class_name::getInstance();
				$component_options = $class_instance->info['options'];
				$block_class_info = $class_instance->info();
				$block_location = str_replace( ABSPATH, '/', $block_class_info['path'] );
				$form_fields = array(
					array(
						'id' => '_shortcode',
						'type' => 'text-readonly',
						'suffix' => '<span data-clipboard-text="' . $shortcode_content . '" class="cj-icon cj-is-small"><i class="fa fa-copy"></i></span>',
						'label' => __( 'Shortcode', 'cssjockey-add-ons' ),
						'info' => '<p class="cj-mb-10">' . __( 'You can use this shortcode on any page, post or text widget.', 'cssjockey-add-ons' ) .
						          '<br>' . sprintf( __( '<b>UI BLock Location:</b><br><pre>%s</pre>', 'cssjockey-add-ons' ), $block_location ) .
						          '</p>',
						'default' => $shortcode_content,
						'options' => '', // array in case of dropdown, checkbox and radio buttons
					)
				);
				if( is_array( $component_options ) && ! empty( $component_options ) ) {
					foreach( $component_options as $key => $form_field ) {
						$default_value = get_post_meta( $post->ID, $form_field['id'], true );
						if( gettype( $default_value ) == 'object' ) {
							$default_value = (array) $default_value;
						}
						$form_fields[ $form_field['id'] ] = $form_field;
						$form_fields[ $form_field['id'] ]['default'] = $default_value;
						if( $form_field['type'] == 'group' ) {
							$form_fields[ $form_field['id'] ]['default'] = $default_value['selected_value'];
							if( is_array( $default_value['items'] ) && ! empty( $default_value['items'] ) ) {
								foreach( $default_value['items'] as $item_key => $item_value ) {
									foreach( $item_value as $i_key => $i_value ) {
										$form_fields[ $form_field['id'] ]['items'][ $item_key ][ $i_key ]['default'] = $i_value;
									}
								}
							}
						}
					}
				}

				$form_fields['_default_options_heading'] = array(
					'id' => '_default_options_heading',
					'type' => 'sub-heading',
					'label' => '',
					'info' => '',
					'params' => array(),
					'default' => __( 'Additional Settings', 'cssjockey-add-ons' ),
					'options' => '', // array in case of dropdown, checkbox and radio buttons
				);
				$form_fields['_content_above'] = array(
					'id' => '_content_above',
					'type' => 'textarea',
					'label' => __( 'Content above', 'cssjockey-add-ons' ),
					'info' => __( 'You can add any valid HTML or text here and this will be displayed above this UI block.', 'cssjockey-add-ons' ),
					'params' => array(),
					'default' => (isset( $block_info['_content_above'] )) ? $block_info['_content_above'] : '',
					'options' => '', // array in case of dropdown, checkbox and radio buttons
				);
				$form_fields['_content_below'] = array(
					'id' => '_content_below',
					'type' => 'textarea',
					'label' => __( 'Content below', 'cssjockey-add-ons' ),
					'info' => __( 'You can add any valid HTML or text here and this will be displayed below this UI block.', 'cssjockey-add-ons' ),
					'params' => array(),
					'default' => (isset( $block_info['_content_below'] )) ? $block_info['_content_below'] : '',
					'options' => '', // array in case of dropdown, checkbox and radio buttons
				);
				$form_fields['_margin'] = array(
					'id' => '_margin',
					'type' => 'spacing',
					'label' => __( 'Margin', 'cssjockey-add-ons' ),
					'info' => __( 'This content will be displayed below this UI block.', 'cssjockey-add-ons' ),
					'params' => array(),
					'default' => (isset( $block_info['_margin'] )) ? $block_info['_margin'] : '',
					'options' => '', // array in case of dropdown, checkbox and radio buttons
				);
				$form_fields['_padding'] = array(
					'id' => '_padding',
					'type' => 'spacing',
					'label' => __( 'Padding', 'cssjockey-add-ons' ),
					'info' => __( 'This content will be displayed below this UI block.', 'cssjockey-add-ons' ),
					'params' => array(),
					'default' => (isset( $block_info['_padding'] )) ? $block_info['_padding'] : '',
					'options' => '', // array in case of dropdown, checkbox and radio buttons
				);
				$form_fields['_custom_css_code'] = array(
					'id' => '_custom_css_code',
					'type' => 'code-css',
					'label' => __( 'Custom CSS', 'cssjockey-add-ons' ),
					'info' => __( 'You can specify custom css code for this block.', 'cssjockey-add-ons' ) . '<br><code>.cjaddons-ui-block-' . $block_info['ID'] . '{...}</code>',
					'params' => array(
						'placeholder' => '.cjaddons-ui-block-' . $block_info['ID'] . '{
	background-color: #222222;
	color: #ffffff;
}'
					),
					'default' => (isset( $block_info['_custom_css_code'] )) ? $block_info['_custom_css_code'] : '',
					'options' => '', // array in case of dropdown, checkbox and radio buttons
				);

				echo '<style type="text/css">#cj-ui-block-shortcode-metabox .inside{padding: 0 !important; margin-top: 0;} .cssjockey-ui .cj-admin-form{border:none;}</style>';
				echo '<div class="cssjockey-ui">';
				echo '<div class="cj-admin-form">';
				echo $this->helpers->renderAdminForm( $form_fields );
				echo '</div>';
				echo '</div>';
			}
		}

		public function attachComponent() {
			if( isset( $_POST['post_id'] ) && $_POST['post_id'] != '' && isset( $_POST['class_name'] ) && $_POST['class_name'] != '' ) {
				$post_info = $this->helpers->postInfo( $_POST['post_id'] );
				update_post_meta( $_POST['post_id'], '_component_class_name', $_POST['class_name'] );
				$post_data = array(
					'ID' => $_POST['post_id'],
					'post_status' => 'publish',
				);
				if( $post_info['post_title'] == 'Auto Draft' ) {
					$component_name = $_POST['class_name'];
					$component_name = str_replace( 'cjaddons_', '', $component_name );
					$component_name = str_replace( '_', ' ', $component_name );
					$post_data['post_title'] = 'New Block ~ ' . ucwords( $component_name );
				}
				wp_update_post( $post_data );
				$class_instance = $_POST['class_name']::getInstance();
				if( is_array( $class_instance->info['options'] ) && ! empty( $class_instance->info['options'] ) ) {
					$component_settings = array();
					foreach( $class_instance->info['options'] as $key => $value ) {
						$component_settings[ $value['id'] ] = $value['default'];
					}
					update_post_meta( $_POST['post_id'], '_component_settings', $component_settings );
				}

				ob_start();
				require_once $class_instance->info( 'path' ) . '/style.scss';
				$sass = ob_get_clean();
				$component_css = $this->helpers->compileSass( $sass );
				update_post_meta( $_POST['post_id'], '_component_css', $component_css );

				ob_start();
				require_once $class_instance->info( 'path' ) . '/script.min.js';
				$component_js = ob_get_clean();
				update_post_meta( $_POST['post_id'], '_component_js', $component_js );

				$post_info = $this->helpers->postInfo( $_POST['post_id'] );
				$post_info['post_edit_url'] = admin_url( 'post.php?post=' . $post_info['ID'] . '&action=edit' );
				echo json_encode( $post_info );
			}
			die();
		}

		public function detachComponent() {
			if( isset( $_POST['post_id'] ) && $_POST['post_id'] != '' ) {
				delete_post_meta( $_POST['post_id'], '_component_class_name' );
				delete_post_meta( $_POST['post_id'], '_component_settings' );
				delete_post_meta( $_POST['post_id'], '_component_css' );
				delete_post_meta( $_POST['post_id'], '_component_js' );
				echo json_encode( $this->helpers->postInfo( $_POST['post_id'] ) );
			}
			die();
		}

		public function createComponent() {
			$saved_block_info = $this->helpers->postInfo( $_POST['block_id'] );
			$class_name = $saved_block_info['_component_class_name'];
			$class = $class_name::getInstance();
			$component_info = $class->info();
			$post_title = $_POST['post_title'];
			$post_data = array(
				'post_title' => $post_title,
				'post_type' => 'cj-ui-blocks',
				'post_status' => 'publish',
			);
			$block_id = wp_insert_post( $post_data );
			update_post_meta( $block_id, '_component_class_name', $component_info['class'] );
			$component_options = $component_info['options'];
			if( is_array( $component_options ) && ! empty( $component_options ) ) {
				foreach( $component_options as $key => $component_option ) {
					update_post_meta( $block_id, $component_option['id'], $component_option['default'] );
				}
			}
			$component_settings = array();
			foreach( $component_options as $key => $value ) {
				$component_settings[ $value['id'] ] = $value['default'];
			}
			update_post_meta( $block_id, '_component_settings', $component_settings );
			if( isset( $component_info['module_info']['module_id'] ) ) {
				update_post_meta( $block_id, '_module_id', $component_info['module_info']['module_id'] );
			}
			ob_start();
			include $component_info['path'] . '/style.scss';
			$sass = ob_get_clean();
			$component_css = $this->helpers->compileSass( $sass );
			update_post_meta( $block_id, '_component_css', $component_css );
			ob_start();
			include $component_info['path'] . '/script.min.js';
			$component_js = ob_get_clean();
			update_post_meta( $block_id, '_component_js', $component_js );

			$new_block_info = $this->helpers->postInfo( $block_id );

			$return = array(
				'class_name' => $class_name,
				'block_id' => $new_block_info['ID'],
				'group' => $component_info['group'],
				'group_name' => ucwords( str_replace( array('-', '_'), ' ', $component_info['group'] ) ),
				'name' => $new_block_info['post_title'],
				'description' => $new_block_info['post_excerpt'],
				'screenshot' => $component_info['screenshot'],
			);

			echo json_encode( $return );

			die();
		}

		public function previewBlock() {
			if( isset( $_GET['cjaddons-preview-ui-block'] ) && $_GET['cjaddons-preview-ui-block'] != '' ) {
				show_admin_bar( false );
				require 'components/preview/header.php';
				require 'components/preview/index.php';
				require 'components/preview/footer.php';
				die();
			}
		}

		public function removeThemeAssets() {
			if( isset( $_GET['cjaddons-disable-theme-assets'] ) && $_GET['cjaddons-disable-theme-assets'] == '1' ) {
				global $wp_styles, $wp_scripts;
				if( isset( $wp_styles->registered ) && ! empty( $wp_styles->registered ) ) {
					foreach( $wp_styles->registered as $key => $value ) {
						if( preg_match( '(wp-content/themes)', $value->src ) && ! preg_match( '(cjaddons|cssjockey|imagination)', $value->handle ) ) {
							wp_deregister_style( $value->handle );
							wp_dequeue_style( $value->handle );
						}
					}
				}
				if( isset( $wp_scripts->registered ) && ! empty( $wp_scripts->registered ) ) {
					foreach( $wp_scripts->registered as $key => $value ) {
						if( preg_match( '(wp-content/themes)', $value->src ) && ! preg_match( '(cjaddons|cssjockey|imagination)', $value->handle ) ) {
							wp_deregister_script( $value->handle );
							wp_dequeue_script( $value->handle );
						}
					}
				}
			}
		}

		public function getComponentInfo() {
			$class_name = get_post_meta( $_POST['block_id'], '_component_class_name', true );
			$class = $class_name::getInstance();
			$class_info = $class->info();
			if( is_array( $class_info ) && isset( $class_info['screenshot'] ) ) {
				echo $class_info['screenshot'];
			} else {
				echo 'not-found';
			}
			die();
		}

		public function frontendUiBlocksPanel( $content ) {
			$button_above_content = '';
			$button_below_content = '';
			$blocks_above_shortcodes = '';
			$blocks_below_shortcodes = '';
			if( is_singular() ) {
				$queried_object = get_queried_object();
				$blocks_above = get_post_meta( $queried_object->ID, 'cjaddons_ui_blocks_above', true );
				$blocks_below = get_post_meta( $queried_object->ID, 'cjaddons_ui_blocks_below', true );
				if( $blocks_above != '' ) {
					$blocks_above = explode( ',', $blocks_above );
				}
				if( $blocks_below != '' ) {
					$blocks_below = explode( ',', $blocks_below );
				}

				if( is_array( $blocks_above ) && ! empty( $blocks_above ) ) {
					foreach( $blocks_above as $sort_key => $block_above_id ) {
						$sort_arrows = '';
						if( in_array( $sort_key + 1, array_keys( $blocks_above ) ) ) {
							$sort_arrows = 'up|down';
						}
						if( ! in_array( $sort_key + 1, array_keys( $blocks_above ) ) ) {
							$sort_arrows = 'up';
						}
						if( $sort_key == 0 ) {
							$sort_arrows = 'down';
						}
						$blocks_above_shortcodes .= '[cjaddons_ui_block placement="above" sort_arrows="' . $sort_arrows . '" sort_id="' . $sort_key . '" block_id="' . $block_above_id . '"]';
					}
				}
				if( is_array( $blocks_below ) && ! empty( $blocks_below ) ) {
					foreach( $blocks_below as $sort_key => $block_below_id ) {
						$sort_arrows = '';
						if( in_array( $sort_key + 1, array_keys( $blocks_below ) ) ) {
							$sort_arrows = 'up|down';
						}
						if( ! in_array( $sort_key + 1, array_keys( $blocks_below ) ) ) {
							$sort_arrows = 'up';
						}
						if( $sort_key == 0 ) {
							$sort_arrows = 'down';
						}
						$blocks_below_shortcodes .= '[cjaddons_ui_block placement="below" sort_arrows="' . $sort_arrows . '" sort_id="' . $sort_key . '" block_id="' . $block_below_id . '"]';
					}
				}

				if( isset( $queried_object->ID ) && isset( $_GET['cjaddons-action'] ) && $_GET['cjaddons-action'] == 'cj-show-frontend-ui-blocks-editor' ) {

					if( $content == '' ) {
						$content = '<span class="cssjockey-ui"><div class="cj-p-15 cj-text-center"><p>' . sprintf( __( 'Content for this %s will be displayed here.', 'cssjockey-add-ons' ), $queried_object->post_type ) . '</p></div></span>';
					}
					$blocks_panel_url = $this->helpers->queryString( site_url() ) . 'cjaddons-show-ui-blocks-selector=1&cjaddons-disable-theme-assets=1';
					$button_above_content .= '<div class="cssjockey-addons-ui-blocks-panel">';
					$button_above_content .= '<vue-frontend-ui-blocks frame-url="' . $blocks_panel_url . '&placement=above" placement="above" post-id="' . $queried_object->ID . '"></vue-frontend-ui-blocks>';
					$button_below_content .= '<vue-frontend-ui-blocks frame-url="' . $blocks_panel_url . '&placement=below" placement="below" post-id="' . $queried_object->ID . '"></vue-frontend-ui-blocks>';
					$button_below_content .= '</div>';

					return $blocks_above_shortcodes . $button_above_content . $content . $blocks_below_shortcodes . $button_below_content;
				}
			}
			$frontend_editor_link = '';

			if( current_user_can( 'publish_posts' ) && ! isset( $_GET['cjaddons-action'] ) ) {
				if( $blocks_above_shortcodes != '' || $blocks_below_shortcodes != '' ) {
					$show_editor_url = $this->helpers->currentUrl( false, true ) . 'cjaddons-action=cj-show-frontend-ui-blocks-editor';
					$frontend_editor_link = '<div class="cssjockey-ui"><a href="' . $show_editor_url . '" class="cj-button cj-mt-20 cj-mb-20 cj-is-small cj-bg-cj-red cj-color-white cj-no-borders">' . __( 'Manage UI Blocks', 'cssjockey-add-ons' ) . '</a></div>';
				}
			}

			return $blocks_above_shortcodes . $content . $blocks_below_shortcodes . $frontend_editor_link;
		}

		public function frontendGetUiBlocks() {
			$return = array();
			if( $_POST['type'] != 'saved' ) {
				$ui_blocks = $this->helpers->componentsArray();
				foreach( $ui_blocks as $class_name => $ui_block ) {
					$return[ $class_name ] = $ui_block->info;
					$return[ $class_name ]['group_name'] = ucwords( str_replace( array('-', '_'), ' ', $ui_block->info['group'] ) );
					$return[ $class_name ]['search_filters'] = json_encode( $ui_block->info );
				}
				echo json_encode( $return );
				die();
			}
			if( $_POST['type'] == 'saved' ) {
				$ui_blocks = get_posts( array(
					'post_type' => 'cj-ui-blocks',
					'posts_per_page' => - 1,
					'post_status' => 'publish',
				) );
				if( ! empty( $ui_blocks ) ) {
					foreach( $ui_blocks as $key => $ui_block ) {
						$ui_block_info = $this->helpers->postInfo( $ui_block->ID );
						$class_name = get_post_meta( $ui_block->ID, '_component_class_name', true );
						$class = $class_name::getInstance();
						$class_info = $class->info();
						$return[ $ui_block_info['ID'] ] = $class_info;
						$return[ $ui_block_info['ID'] ]['group_name'] = ucwords( str_replace( array('-', '_'), ' ', $class_info['group'] ) );
						$return[ $ui_block_info['ID'] ]['search_filters'] = json_encode( $class_info );
						$return[ $ui_block_info['ID'] ]['ID'] = $ui_block_info['ID'];
					}
					echo json_encode( $return );
					die();
				}
			}
			die();
		}

		public function frontendAddUiBlock() {
			$post_id = $_POST['post_id'];
			$block_id = $_POST['block_id'];
			$placement = $_POST['placement'];
			$option_name = 'cjaddons_ui_blocks_' . $placement;
			if( $block_id == 'new' ) {
				$ui_block_info = $this->helpers->componentsArray( $_POST['block_class_name'] );
				$component_info = $ui_block_info->info;
				$component_info['name'] = (isset( $_POST['post_title'] ) && $_POST['post_title'] != '') ? $_POST['post_title'] : $ui_block_info->info->name;
				$block_id = $this->helpers->autoCreateUiBlock( $component_info, true );
			}
			$post_blocks = get_post_meta( $post_id, $option_name, true );
			if( $post_blocks == '' ) {
				$post_blocks = $block_id;
			} else {
				$post_blocks = $post_blocks . ',' . $block_id;
			}
			update_post_meta( $post_id, $option_name, $post_blocks );
			echo 'success';
			die();
		}

		public function frontendDeleteUiBlock() {
			$post_id = $_POST['data']['postId'];
			$sort_id = $_POST['data']['sortId'];
			$placement = $_POST['data']['placement'];
			$option_name = 'cjaddons_ui_blocks_' . $placement;
			$block_ids = get_post_meta( $post_id, $option_name, true );
			$block_ids = explode( ',', $block_ids );
			unset( $block_ids[ $sort_id ] );
			update_post_meta( $post_id, $option_name, implode( ',', $block_ids ) );
			echo 'success';
			die();
		}

		public function frontendSortUiBlock() {
			$post_id = $_POST['data']['postId'];
			$sort_id = $_POST['data']['sortId'];
			$placement = $_POST['data']['placement'];
			$option_name = 'cjaddons_ui_blocks_' . $placement;
			$block_ids = get_post_meta( $post_id, $option_name, true );
			$blocks_array = explode( ',', $block_ids );
			if( $_POST['data']['move'] == 'down' ) {
				$new_array = array();
				$new_array[ $sort_id ] = $blocks_array[ $sort_id + 1 ];
				$new_array[ $sort_id + 1 ] = $blocks_array[ $sort_id ];
				unset( $blocks_array[ $sort_id ] );
				unset( $blocks_array[ $sort_id + 1 ] );
				$save_array = $new_array + $blocks_array;
				ksort( $save_array );
				update_post_meta( $post_id, $option_name, implode( ',', $save_array ) );
				echo 'success';
				die();
			}
			if( $_POST['data']['move'] == 'up' ) {
				$new_array = array();
				$new_array[ $sort_id ] = $blocks_array[ $sort_id - 1 ];
				$new_array[ $sort_id - 1 ] = $blocks_array[ $sort_id ];
				unset( $blocks_array[ $sort_id ] );
				unset( $blocks_array[ $sort_id - 1 ] );
				$save_array = $new_array + $blocks_array;
				ksort( $save_array );
				update_post_meta( $post_id, $option_name, implode( ',', $save_array ) );
				echo 'success';
				die();
			}
		}

		public function editPostAdminLinks( $actions, $post ) {
			if( $post->post_type == 'cj-ui-blocks' ) {
				$clone_url = admin_url( 'edit.php?post_type=cj-ui-blocks&cjaddons_action=clone-ui-block&block_id=' . $post->ID );
				$preview_url = site_url( '?cjaddons-preview-ui-block=' . $post->ID );
				$actions['cjaddons-clone-ui-block'] = '<a href="' . $clone_url . '" title="' . esc_attr__( 'Clone', 'cssjockey-add-ons' ) . '">' . esc_html__( 'Clone', 'cssjockey-add-ons' ) . '</a>';
				$actions['cjaddons-preview-ui-block'] = '<a href="' . $preview_url . '" target="_blank" title="' . esc_attr__( 'Preview', 'cssjockey-add-ons' ) . '">' . esc_html__( 'Preview', 'cssjockey-add-ons' ) . '</a>';
			}

			return $actions;
		}

		public function cloneUiBlock() {
			if( isset( $_GET['cjaddons_action'] ) && $_GET['cjaddons_action'] == 'clone-ui-block' && isset( $_GET['block_id'] ) && $_GET['block_id'] != '' ) {
				$post_info = $this->helpers->postInfo( $_GET['block_id'] );
				unset( $post_info['ID'] );
				unset( $post_info['post_name'] );
				unset( $post_info['post_date'] );
				unset( $post_info['post_date_gmt'] );
				unset( $post_info['post_modified'] );
				unset( $post_info['post_modified_gmt'] );
				$post_info['post_title'] = $post_info['post_title'] . ' - ' . __( 'Cloned', 'cssjockey-add-ons' );
				$new_block_id = wp_insert_post( $post_info );
				$this->helpers->updatePostInfo( $new_block_id, $post_info );
				$location = admin_url( 'edit.php?post_type=cj-ui-blocks' );
				wp_redirect( $location );
				die();
			}
		}

	}

	cjaddons_setup_components::getInstance();
}