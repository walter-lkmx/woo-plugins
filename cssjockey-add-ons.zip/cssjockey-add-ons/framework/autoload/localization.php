<?php
if( ! class_exists( 'cjaddons_localization_support' ) ) {
	class cjaddons_localization_support {

		public $helpers, $theme_dir;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->theme_dir = get_stylesheet_directory();
			$this->theme_url = get_stylesheet_directory_uri();
			$this->helpers = cjaddons_helpers::getInstance();
			if( $this->helpers->itemInfo( 'item_type' ) == 'plugin' ) {
				add_action( 'init', array($this, 'pluginLocalization') );
			}
			if( $this->helpers->itemInfo( 'item_type' ) == 'theme' ) {
				$lang_path = $this->theme_dir . '/languages/';
				load_theme_textdomain( $this->helpers->itemInfo( 'text_domain' ), $lang_path );
			}
		}

		public function pluginLocalization() {
			$domain = basename( $this->helpers->root_dir );
			$locale = apply_filters( 'plugin_locale', get_locale(), $domain );
			$lang_path = $this->helpers->root_dir . '/languages/';
			$mo_path = $lang_path . $domain . '-' . $locale . '.mo';
			load_textdomain( $domain, $mo_path );
			load_plugin_textdomain( $domain, false, $lang_path );
		}

	}

	cjaddons_localization_support::getInstance();
}