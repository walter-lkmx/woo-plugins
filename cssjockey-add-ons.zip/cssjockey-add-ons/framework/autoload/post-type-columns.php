<?php

if( ! class_exists( 'cjaddons_ui_blocks_columns' ) ) {
	class cjaddons_ui_blocks_columns {
		private static $instance;
		public $helpers;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_filter( 'manage_cj-ui-blocks_posts_columns', array($this, 'customColumns'), 10, 1 );
			add_action( 'manage_cj-ui-blocks_posts_custom_column', array($this, 'customColumnsContent'), 10, 2 );
			add_action( 'admin_footer', array($this, 'columnStyle') );
		}

		public function customColumns( $columns ) {
			$return = array();
			foreach( $columns as $key => $column ) {
				$return[ $key ] = $column;
				if( $key == 'cb' ) {
					$return['cjaddons_ui_block_screenshot'] = __( 'Screenshot', 'cssjockey-add-ons' );
				}
				if( $key == 'title' ) {
					$return['cjaddons_ui_block_shortcode'] = __( 'Shortcode', 'cssjockey-add-ons' );
				}
			}

			return $return;
		}

		public function customColumnsContent( $column, $post_id ) {
			$helpers = cjaddons_helpers::getInstance();
			$post_info = $helpers->postInfo( $post_id );
			$class_name = get_post_meta( $post_id, '_component_class_name', true );
			if( ! class_exists( $class_name ) ) {
				switch( $column ) {
					case 'cjaddons_ui_block_screenshot':
						echo '<span style="color:red;">' . __( 'REMOVED', 'cssjockey-add-ons' ) . '</span>';
						break;
					case 'cjaddons_ui_block_shortcode':
						echo '<span style="color:red;">' . __( 'REMOVED', 'cssjockey-add-ons' ) . '</span>';
						break;
				}
			} else {
				$class = $class_name::getInstance();
				$class_info = $class->info();
				switch( $column ) {
					case 'cjaddons_ui_block_screenshot':
						if( isset( $class_info ) && isset( $class_info['screenshot'] ) ) {
							echo '<img src="' . $class_info['screenshot'] . '" width="100%" />';
						} else {
							echo '<div style="text-align: center;">' . __( 'UI Component<br>Not Assigned', 'cssjockey-add-ons' ) . '</div>';
						}
						break;
					case 'cjaddons_ui_block_shortcode':
						if( $post_info['post_type'] == 'cj-ui-blocks' && isset( $post_info['_component_class_name'] ) && ! class_exists( $post_info['_component_class_name'] ) ) {
							$addon_dir_name = basename( dirname( dirname( $class_info['path'] ) ) );
							echo '<span class="cssjockey-ui"><span class="cj-color-danger">' . sprintf( __( '<b>Error:</b><br> %s not found.', 'cssjockey-add-ons' ), $addon_dir_name ) . '</span></span>';
						} else {
							echo '<span class="cssjockey-ui"><code class="cj-inline-block cj-fs-14 cj-p-5 cj-mt-5" style="line-height: 1;">[cjaddons_ui_block block_id=\'' . $post_info['ID'] . '\']</code><span data-clipboard-text="[cjaddons_ui_block block_id=\'' . $post_info['ID'] . '\']" data-clipboard-confirmation="<i class=\'fa fa-check color-green\'></i>" class="cj-ml-10 cj-mt-10 cj-icon cj-is-small"><i class="fa fa-copy"></i></span></span>';
						}
						break;
				}
			}
		}

		public function columnStyle() {
			global $current_screen;
			if( $current_screen->id == 'edit-cj-ui-blocks' ) {
				echo '<style>.column-cjaddons_ui_block_screenshot{width: 120px;} .column-cjaddons_ui_block_screenshot img{max-width: 100%;}</style>';
			}
		}
	}

	cjaddons_ui_blocks_columns::getInstance();
}
