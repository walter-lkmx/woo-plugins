<?php
$block_id = $_GET['cjaddons-preview-ui-block'];
$block_info = $this->helpers->postInfo( $block_id );
$class_name = get_post_meta( $block_id, '_component_class_name', true );
$class_instance = $class_name::getInstance();
echo '<div class="cj-uib-preview-content">';
$class_instance->render( $block_info );
echo '<div>';

