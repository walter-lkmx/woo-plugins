<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if( is_singular() && pings_open( get_queried_object() ) ) : ?>
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<?php wp_head(); ?>
</head>
<body <?php body_class() ?>>
<!--<div class="cj-uib-settings-form-loading">
    <i class="fa fa-spinner fa-spin"></i>
</div>-->
<style>
    html {
        margin: 0 !important;
        padding: 0 !important;
    }

    body {
        background-color: #ffffff !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    body:before,
    body:after {
        display: none !important;
    }

    .cj-uib-settings-form-loading {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 3;
        background: #ffffff;
        color: #d8d8d8;
        text-align: center;
    }

    .cj-uib-settings-form-loading i.fa-spin {
        display: inline-block;
        margin-top: 100px;
        font-size: 60px;
    }
</style>