<div class="cj-end-html"></div>
<?php wp_footer(); ?>
<script>
    jQuery(document).ready(function ($) {
        $('div.cj-end-html').nextAll('div').hide();
    });
</script>
<script src="<?php echo $this->helpers->root_url . '/framework/lib/iframe.min.js' ?>"></script>
<style>
    html, body {
        margin-top: 0 !important;
    }

    .cj-uib-preview-content {
        position: relative;
        z-index: 2;
    }

    .cj-frame-loading {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        color: #fff;
        background-color: rgba(0, 0, 0, 0.5);
    }
</style>
</body>
</html>
