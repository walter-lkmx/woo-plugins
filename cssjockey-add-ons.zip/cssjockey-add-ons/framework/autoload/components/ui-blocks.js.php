<?php
$root_dir = base64_decode($_GET['params']);
if(!file_exists($root_dir . '/wp-load.php')){
	echo '/* document root not defined */';
	return false;
}
require_once $root_dir . '/wp-load.php';
$helpers = cjaddons_helpers::getInstance();
$print = '';
if( isset( $_GET['blocks'] ) && $_GET['blocks'] != '' ) {
	$blocks = explode( '|', $_GET['blocks'] );
	foreach( $blocks as $key => $block_id ) {
		$class_name = get_post_meta( $block_id, '_component_class_name', true );
		ob_start();
		if( gettype( $class_name ) === 'string' ) {
			$class = $class_name::getInstance();
			$class_info = $class->info();
			if( file_exists( $class_info['path'] . '/script.min.js' ) ) {
				require_once $class_info['path'] . '/script.min.js';
			}
		}
		$print .= ob_get_clean();
	}
}
if( ! $helpers->isLocal() ) {
	$expires = 60 * 60 * 24; // how long to cache in secs..
	header( "Pragma: public" );
	header( "Cache-Control: maxage=" . $expires );
	header( 'Expires: ' . gmdate( 'D, d M Y H:i:s', time() + $expires ) . ' GMT' );
}
header( "Content-type: text/javascript;" );
echo $print;