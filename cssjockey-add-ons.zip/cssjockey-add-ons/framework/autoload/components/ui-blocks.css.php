<?php
$root_dir = base64_decode($_GET['params']);
if(!file_exists($root_dir . '/wp-load.php')){
	echo '/* document root not defined */';
	return false;
}
require_once $root_dir . '/wp-load.php';
$helpers = cjaddons_helpers::getInstance();
$print = '.cjaddons-ui-block{
	opacity: 1 !important;
    filter: alpha(opacity=100) !important;
}';
if( isset( $_GET['blocks'] ) && $_GET['blocks'] != '' ) {
	$blocks = explode( '|', $_GET['blocks'] );
	if(is_array($blocks) && !empty($blocks)){
		foreach( $blocks as $key => $block_id ) {
			$class_name = get_post_meta($block_id, '_component_class_name', true);
			if(gettype($class_name) === 'string'){
				$class = $class_name::getInstance();
				$class_info = $class->info();
				if(file_exists($class_info['path'] . '/style.scss')){
				if($helpers->isLocal()){
						ob_start();
						require_once $class_info['path'] . '/style.scss';
						$sass = ob_get_clean();
						$print .= $helpers->compileSass( $sass );
				}else{
					$block_css = get_post_meta($block_id, '_component_css', true);
					if($block_css != ''){
						$print .= $block_css;
					}
				}
				}
			}
		}
	}
}
if(!$helpers->isLocal()){
	$expires = 60 * 60 * 24;
	header( "Pragma: public" );
	header( "Cache-Control: maxage=" . $expires );
	header( 'Expires: ' . gmdate( 'D, d M Y H:i:s', time() + $expires ) . ' GMT' );
}
header("Content-type: text/css; charset: UTF-8");
echo $print;