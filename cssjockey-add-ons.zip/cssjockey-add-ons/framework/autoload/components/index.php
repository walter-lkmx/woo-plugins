<div class="cssjockey-ui">
	<?php
	$cssjockey_components = $this->helpers->componentsArray();
	if( empty( $cssjockey_components ) ) {
		echo '<div class="cj-m-15 cj-notification cj-is-warning">' . sprintf( __( '<p><b>No UI Blocks found.</b></p>Visit <a href="%s" target="_blank">our website</a> to download our free and premium add-ons to get UI Blocks for your website.', 'cssjockey-add-ons' ), $this->helpers->itemInfo( 'author_url' ) ) . '</div>';

		return;
	}
	$block_class = get_post_meta( $post->ID, '_component_class_name', true );
	?>
	<?php if( $block_class == '' ) { ?>
        <iframe src="<?php echo site_url( '?cjaddons-show-ui-blocks-selector=1&cjaddons-disable-theme-assets=1&run=cjaddons-attach-new-ui-block&post_id=' . $post->ID ) ?>" width="100%" height="1000px" frameborder="0"></iframe>
	<?php } ?>

	<?php if( $block_class != '' && class_exists( $block_class ) ) { ?>
        <div class="cj-header">
            <ul>
                <li><a href="#cj-ui-block-shortcode-metabox" data-scroll-to="#cj-ui-block-shortcode-metabox"><i class="fa fa-cog"></i></a></li>
                <!--<li><a href="#" class="show-ui-block-preview" data-iframe-src="<?php /*echo $this->helpers->queryString( site_url() ) . 'cjaddons-preview-ui-block=' . $post->ID */ ?>"><i class="fa fa-eye"></i></a></li>-->
                <li><a href="#" class="cj-preview-television" data-iframe-src="<?php echo $this->helpers->queryString( site_url() ) . 'cjaddons-preview-ui-block=' . $post->ID ?>"><i class="fa fa-television"></i></a></li>
                <li><a href="#" class="cj-preview-desktop" data-iframe-src="<?php echo $this->helpers->queryString( site_url() ) . 'cjaddons-preview-ui-block=' . $post->ID ?>"><i class="fa fa-laptop"></i></a></li>
                <li><a href="#" class="cj-preview-tablet" data-iframe-src="<?php echo $this->helpers->queryString( site_url() ) . 'cjaddons-preview-ui-block=' . $post->ID ?>"><i class="fa fa-tablet"></i></a></li>
                <li><a href="#" class="cj-preview-mobile" data-iframe-src="<?php echo $this->helpers->queryString( site_url() ) . 'cjaddons-preview-ui-block=' . $post->ID ?>"><i class="fa fa-mobile"></i></a></li>
                <li><a href="#" class="cj-preview-refresh" data-iframe-src="<?php echo $this->helpers->queryString( site_url() ) . 'cjaddons-preview-ui-block=' . $post->ID ?>"><i class="fa fa-refresh"></i></a></li>
                <li><a href="<?php echo $this->helpers->queryString( site_url() ) . 'cjaddons-preview-ui-block=' . $post->ID ?>" target="_blank"><i class="fa fa-external-link"></i></a></li>
                <li class="cj-is-pulled-right">
                    <a data-id="<?php echo $post->ID ?>" href="#" class="cj-detach-component" data-confirm="<?php _e( "Are you sure?\nThis will detach the UI block.", 'cssjockey-add-ons' ) ?>">
                        <i class="fa fa-times"></i>
                    </a>
                </li>
            </ul>
        </div>
        <div class="cj-uib-iframe-container">
            <iframe class="cjaddons-iframe-resize" id="cj-ui-block-iframe" width="100%" src="<?php echo $this->helpers->queryString( site_url() ) . 'cjaddons-preview-ui-block=' . $post->ID ?>" frameborder="0"></iframe>
        </div>
	<?php } ?>
</div>

<script type="text/javascript">
    jQuery(document).ready(function ($) {
        var attachComponent = function (post_id, class_name) {
            let data = {
                action: 'attach_component',
                post_id: post_id,
                class_name: class_name,
            };
            $.post(ajaxurl, data, function (response) {
                let obj = JSON.parse(response);
                if (obj.post_edit_url !== undefined) {
                    window.location.href = obj.post_edit_url;
                    return false;
                }
            });
        };

        let listener = function (e) {
            let eventName = e.data[0];
            let data = e.data[1];
            switch (eventName) {
                case 'block_info':
                    let location = JSON.parse('{"' + decodeURI(data.location).replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g, '":"') + '"}');
                    if (location.run === 'cjaddons-attach-new-ui-block') {
                        attachComponent(location.post_id, data.block.class_name);
                        console.log(location.post_id);
                        console.log(data.block.class_name);
                    }
                    break;
                case 'close_panel':
                    window.location.href = '<?php echo admin_url('edit.php?post_type=cj-ui-blocks') ?>';
                    break;
            }
            return false;
        };
        window.removeEventListener('message', listener, false);
        window.addEventListener('message', listener, false);

    });
</script>