<div class="cssjockey-ui">
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=<?php echo $google_maps_api_key ?>"></script>
</div>