<div class="cssjockey-ui">
    <div class="cj-mb-10">
        <p><label for="cjaddons_google_maps_api_key"><?php _e( 'Google Maps API Key', 'cssjockey-add-ons' ) ?></label></p>
		<?php echo $field_type->input( array(
			'name' => 'cjaddons_google_maps_api_key',
			'id' => 'cjaddons_google_maps_api_key',
			'value' => $google_maps_api_key,
			'class' => 'input',
			'desc' => '',
		) ); ?>
        <div class="cj-info cj-mt-10 cj-color-danger"><?php _e( 'Please specify Google Maps API Key.', 'cssjockey-add-ons' ) ?></div>
    </div>
</div>