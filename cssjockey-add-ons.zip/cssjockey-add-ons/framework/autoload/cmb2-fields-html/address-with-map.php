<?php
$container_id = str_replace( '_', '-', 'address-field' . sanitize_title( $field_type->_id() ) );
$saved_values = $value;
$address_field_errors = array(
	'google-not-defined' => __( 'Unable to load google maps api.', 'cssjockey-add-ons' )
);
?>
<div id="<?php echo $container_id; ?>" class="cssjockey-ui cj-relative" v-cloak>
    <div class="cj-pr-100">
        <div class="cj-columns cj-is-multiline cj-is-mobile cj-is-gapless">
            <div class="cj-column cj-is-12">
                <div v-if="error" class="cj-notification cj-is-danger">
                    {{ error }}
                </div>
                <div class="cj-field find-address">
                    <p class="cj-control cj-has-icon cj-has-icon-right" :class="{'cj-is-loading' : searching_address}">
                        <input type="text" class="cj-input cj-is-medium cj-mb-0" v-model="search_address" @keyup="searchAddresses" placeholder="<?php _e( 'Search address..', 'cssjockey-add-ons' ) ?>"/>
                        <span v-if="!searching_address" class="cj-icon"><i class="fa fa-map-marker"></i></span>
                    </p>
                </div>
                <div class="address-list" v-if="addresses.length > 0">
                    <div class="address-list-item" v-for="address in addresses">
                        <a @click="setAddress(address)" v-if="address.address" class="cj-is-pulled-right"><span class="cj-icon cj-is-small cj-color-success"><i class="fa fa-check"></i></span></a>
                        <span v-if="!address.address"><?php _e( 'No address found.', 'cssjockey-add-ons' ) ?></span>
                        {{ address.address }}
                    </div>
                </div>
            </div>
            <div class="cj-column cj-is-6 cmb2-address-fields">
                <div class="cj-pr-50">
                    <div class="cj-address-fields">
                        <div class="cj-mb-10">
                            <p><label for="<?php echo $field_type->_id( '_address_line_1' ); ?>"><?php _e( 'Address Line 1', 'cssjockey-add-ons' ) ?></label></p>
							<?php echo $field_type->input( array(
								'name' => $field_type->_name( '[address_line_1]' ),
								'id' => $field_type->_id( '_address_line_1' ),
								'value' => $value['address_line_1'],
								'class' => 'input',
								'v-model' => 'selected_address.address_line_1',
								'desc' => '',
							) ); ?>
                        </div>
                        <div class="cj-mb-10">
                            <p><label for="<?php echo $field_type->_id( '_address_line_2' ); ?>'"><?php _e( 'Address Line 2', 'cssjockey-add-ons' ) ?></label></p>
							<?php echo $field_type->input( array(
								'name' => $field_type->_name( '[address_line_2]' ),
								'id' => $field_type->_id( '_address_line_2' ),
								'value' => $value['address_line_2'],
								'class' => 'input',
								'v-model' => 'selected_address.address_line_2',
								'desc' => '',
							) ); ?>
                        </div>
                        <div class="cj-mb-10">
                            <p><label for="<?php echo $field_type->_id( '_city' ); ?>'"><?php _e( 'City', 'cssjockey-add-ons' ) ?></label></p>
							<?php echo $field_type->input( array(
								'name' => $field_type->_name( '[city]' ),
								'id' => $field_type->_id( '_city' ),
								'value' => $value['city'],
								'v-model' => 'selected_address.city',
								'class' => 'input',
								'desc' => '',
							) ); ?>
                        </div>
                        <div class="cj-mb-10">
                            <p><label for="<?php echo $field_type->_id( '_state' ); ?>'"><?php _e( 'State', 'cssjockey-add-ons' ) ?></label></p>
							<?php echo $field_type->input( array(
								'name' => $field_type->_name( '[state]' ),
								'id' => $field_type->_id( '_state' ),
								'value' => $value['state'],
								'v-model' => 'selected_address.state',
								'class' => 'input',
								'desc' => '',
							) ); ?>
                        </div>
                        <div class="cj-mb-10">
                            <p><label for="<?php echo $field_type->_id( '_country' ); ?>'"><?php _e( 'Country', 'cssjockey-add-ons' ) ?></label></p>
							<?php echo $field_type->input( array(
								'name' => $field_type->_name( '[country]' ),
								'id' => $field_type->_id( '_country' ),
								'value' => $value['country'],
								'v-model' => 'selected_address.country',
								'class' => 'input',
								'desc' => '',
							) ); ?>
                        </div>
                        <div class="cj-mb-0">
                            <p><label for="<?php echo $field_type->_id( '_zip' ); ?>'"><?php _e( 'Postal / Zip Code', 'cssjockey-add-ons' ) ?></label></p>
                            <div class="cj-field">
                                <p class="cj-control">
									<?php echo $field_type->input( array(
										'name' => $field_type->_name( '[zip]' ),
										'id' => $field_type->_id( '_zip' ),
										'value' => $value['zip'],
										'v-model' => 'selected_address.zip',
										'class' => 'input',
										'desc' => '',
									) ); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="cj-column cj-is-6">
                <div class="cj-map-fields">
                    <div class="cj-clearfix">
                        <div class="cj-one_half cj-mb-10">
                            <div class="cj-mb-10">
                                <p><label for="<?php echo $field_type->_id( '_lat' ); ?>"><?php _e( 'Latitude', 'cssjockey-add-ons' ) ?></label></p>
								<?php echo $field_type->input( array(
									'name' => $field_type->_name( '[lat]' ),
									'id' => $field_type->_id( '_lat' ),
									'value' => $value['lat'],
									'v-model' => 'selected_address.lat',
									'class' => 'input',
									'desc' => '',
								) ); ?>
                            </div>
                        </div>
                        <div class="cj-one_half cj-last cj-mb-10">
                            <div class="cj-mb-10">
                                <p><label for="<?php echo $field_type->_id( '_lat' ); ?>"><?php _e( 'Longitude', 'cssjockey-add-ons' ) ?></label></p>
								<?php echo $field_type->input( array(
									'name' => $field_type->_name( '[lng]' ),
									'id' => $field_type->_id( '_lng' ),
									'value' => $value['lng'],
									'v-model' => 'selected_address.lng',
									'class' => 'input',
									'desc' => '',
								) ); ?>
                            </div>
                        </div>
                    </div>

					<?php if( ! $google_maps_api_key ) { ?>
						<?php require_once 'google-maps-api-key.php'; ?>
					<?php } else { ?>
                        <div class="cj-map">
                            <div id="<?php echo $container_id ?>-map"></div>
                        </div>
					<?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>
<br class="cj-clear">

<style>
    .find-address {
        background-color: #f7f7f7;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #DDDDDD;
    }

    .cmb2-metabox .cmb-td .find-address p {
        margin-bottom: 0 !important;
    }

    .cmb2-address-fields input[type="text"] {
        width: 100%;
    }

    .address-list .address-list-item {
        background-color: #f7f7f7;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #DDDDDD;
    }

    #<?php echo $container_id ?>-map {
        box-sizing: border-box;
        border: 6px solid #DDDDDD;
        height: 345px;
        width: 100%;
    }
</style>

<script type="text/javascript">
    jQuery(document).ready(function ($) {
        Vue.http.options.emulateJSON = true;
        Vue.http.options.emulateHTTP = true;
        new Vue({
            el: '#<?php echo $container_id; ?>',
            data: {
                google_maps_api_key: '<?php echo $google_maps_api_key; ?>',
                error: null,
                timeout: null,
                searching_address: 0,
                search_address: '',
                no_address_found: 0,
                addresses: [],
                selected_address: {
                    address_line_1: '<?php echo $saved_values['address_line_1']; ?>',
                    address_line_2: '<?php echo $saved_values['address_line_2']; ?>',
                    city: '<?php echo $saved_values['city']; ?>',
                    state: '<?php echo $saved_values['state']; ?>',
                    country: '<?php echo $saved_values['country']; ?>',
                    zip: '<?php echo $saved_values['zip']; ?>',
                    lat: parseFloat('<?php echo ($saved_values['lat'] != '') ? $saved_values['lat'] : 0; ?>'),
                    lng: parseFloat('<?php echo ($saved_values['lng'] != '') ? $saved_values['lng'] : 0; ?>'),
                },
                map: '',
                map_center: '',
                map_marker: '',
            },
            mounted: function () {
                var instance = this;
                setTimeout(function () {
                    instance.showMap();
                }, 2500);
            },
            methods: {
                searchAddresses: function () {
                    var instance = this;
                    instance.searching_address = 1;
                    clearTimeout(instance.timeout);
                    instance.timeout = setTimeout(function () {
                        instance.$http.post(ajaxurl, {
                            action: 'get_google_addresses',
                            term: instance.search_address,
                        }).then(function (result) {
                            instance.searching_address = 0;
                            instance.addresses = result.body;
                        }, function (error) {
                            instance.searching_address = 0;
                            console.log(error);
                        });
                    }, 1500);
                },
                getAddressByLatLng: function (lat, lng) {
                    var instance = this;
                    instance.searching_address = 1;
                    instance.timeout = setTimeout(function () {
                        instance.$http.post(ajaxurl, {
                            action: 'get_google_addresses_by_lat_lng',
                            lat: lat,
                            lng: lng,
                        }).then(function (result) {
                            instance.searching_address = 0;
                            instance.addresses = result.body;
                        }, function (error) {
                            console.log(error);
                        });
                    }, 1500);
                },
                setAddress: function (address) {
                    var instance = this;
                    instance.selected_address.address_line_1 = address.address_line_1;
                    instance.selected_address.address_line_2 = address.address_line_2;
                    instance.selected_address.city = address.city;
                    instance.selected_address.state = address.state;
                    instance.selected_address.country = address.country;
                    instance.selected_address.zip = address.zipcode;
                    instance.selected_address.lat = parseFloat(address.latlng.lat);
                    instance.selected_address.lng = parseFloat(address.latlng.lng);
                    instance.addresses = [];
                    setTimeout(function () {
                        instance.showMap();
                    }, 1000);
                },
                showMap: function () {
                    var instance = this;

                    if (!instance.selected_address.lat) {
                        return;
                    }

                    if (typeof google === 'undefined') {
                        instance.error = '<?php echo $address_field_errors['google-not-defined'] ?>';
                        return;
                    }
                    instance.map_center = {lat: instance.selected_address.lat, lng: instance.selected_address.lng};
                    instance.map = new google.maps.Map(document.getElementById('<?php echo $container_id ?>-map'), {
                        zoom: 19,
                    });
                    instance.map.panTo(instance.map_center);
                    instance.marker = new google.maps.Marker({
                        position: instance.map_center,
                        map: instance.map,
                        draggable: true,
                        animation: google.maps.Animation.DROP,
                    });
                    google.maps.event.addListener(instance.marker, 'dragend', function (event) {
                        instance.selected_address.lat = this.getPosition().lat();
                        instance.selected_address.lng = this.getPosition().lng();
                        let location = new google.maps.LatLng(instance.selected_address.lat, instance.selected_address.lng);
                        instance.map.panTo(location);
                        instance.getAddressByLatLng(instance.selected_address.lat, instance.selected_address.lng);
                    });
                }
            }
        });
    });

</script>