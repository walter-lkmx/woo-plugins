<?php
if( ! class_exists( 'cjaddons_global_ajax_support' ) ) {
	class cjaddons_global_ajax_support {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'wp_ajax_nopriv_get_google_addresses', array($this, 'getGoogleAddresses') );
			add_action( 'wp_ajax_get_google_addresses', array($this, 'getGoogleAddresses') );
			add_action( 'wp_ajax_nopriv_get_google_addresses_by_lat_lng', array($this, 'getGoogleAddressesByLatLng') );
			add_action( 'wp_ajax_get_google_addresses_by_lat_lng', array($this, 'getGoogleAddressesByLatLng') );
			add_action( 'wp_ajax_nopriv_vue_upload_user_avatar', array($this, 'vueUploadUserAvatar') );
			add_action( 'wp_ajax_vue_upload_user_avatar', array($this, 'vueUploadUserAvatar') );
			add_action( 'wp_ajax_nopriv_vue_upload_file', array($this, 'vueUploadFiles') );
			add_action( 'wp_ajax_vue_upload_file', array($this, 'vueUploadFiles') );
			add_action( 'wp_ajax_vue_upload_ui_block', array($this, 'vueUploadUiBlock') );
			add_action( 'wp_ajax_vue_upload_addon', array($this, 'vueUploadAddon') );

			add_action( 'wp_ajax_nopriv_cjaddons_query_posts', array($this, 'queryPostsCallback') );
			add_action( 'wp_ajax_cjaddons_query_posts', array($this, 'queryPostsCallback') );

			add_action( 'wp_ajax_nopriv_cjaddons_query_users', array($this, 'queryUsersCallback') );
			add_action( 'wp_ajax_cjaddons_query_users', array($this, 'queryUsersCallback') );

			add_action( 'wp_ajax_cjaddons_dismiss_admin_notice', array($this, 'dismissAdminNotice') );

			add_action( 'wp_ajax_update_license_key', array($this, 'updateAddonsLicenseKeys') );
		}

		public function updateAddonsLicenseKeys() {
			$module_id = $_POST['item_id'];
			if( $_POST['license_key'] != '' ) {
				update_option( 'cjaddons_license_' . $module_id, $_POST['license_key'] );
			} else {
				delete_option( 'cjaddons_license_' . $module_id );
			}
			echo json_encode( array('success' => 'done') );
			wp_die();
		}

		public function dismissAdminNotice() {
			$id = $_POST['id'];
			$current_user = wp_get_current_user();
			$dismissed_notices = get_user_meta( $current_user->ID, 'cjaddons_dismissed_notices', true );
			if( ! is_array( $dismissed_notices ) ) {
				$dismissed_notices = array();
			}
			$dismissed_notices[ $id ] = $id;
			update_user_meta( $current_user->ID, 'cjaddons_dismissed_notices', $dismissed_notices );
			die();
		}

		public function getGoogleAddresses() {
			$string = $_REQUEST['term'];
			$addresses = $this->helpers->getAddressFromGoogle( $string, $_REQUEST['filter'] );
			$return[] = array('address' => __( 'No address found.', 'cssjockey-add-ons' ));
			if( ! empty( $addresses ) ) {
				$return = array();
				foreach( $addresses as $key => $value ) {
					$return[] = $value;
				}
			}
			echo json_encode( $return );
			die();
		}

		public function getGoogleAddressesByLatLng() {
			$addresses = $this->helpers->getAddressByCoords( $_REQUEST['lat'], $_REQUEST['lng'] );
			$return[] = __( 'No address found.', 'cssjockey-add-ons' );
			if( ! empty( $addresses ) ) {
				$return = array();
				foreach( $addresses as $key => $value ) {
					$return[] = $value;
				}
			}
			echo json_encode( $return );
			die();
		}

		public function getAddressByPostalCode() {
			$address = $this->helpers->getAddressesByPostcode( $_POST['zip'] );
			$return = array();
			if( is_array( $address ) ) {
				$return = $address;
			} else {
				$return = array();
			}
			echo json_encode( $return );
			die();
		}

		public function vueUploadUserAvatar() {
			$return = array();

			// check if square
			list($width, $height) = getimagesize($_FILES['file']['tmp_name']);

			if($width !== $height){
				$return['errors'] = __('You must upload an image with same width and height.', 'cssjockey-add-ons');
				echo json_encode($return);
				die();
			}

			/*if( is_user_logged_in() && ! wp_verify_nonce( $_POST['_wp_nonce'], 'vue-upload-avatar' ) ) {
				$return['error'] = __( 'You are not allowed to perform this action.', 'cssjockey-add-ons' );
				echo json_encode( $return );
				die();
			}*/
			$upload_dir = $this->helpers->upload_path . '/cssjockey-add-ons/user-avatars';

			add_filter( 'upload_dir', function ( $upload ) {
				$upload['subdir'] = '/user-avatars/';
				$upload['path'] = $upload['basedir'] . '/cssjockey-add-ons/user-avatars';
				$upload['url'] = $upload['baseurl'] . '/cssjockey-add-ons/user-avatars';

				return $upload;
			} );

			$allowed_file_types = null;
			$mime_types = array();
			$allowed_file_mime_types = (isset( $_POST['allowed_file_types'] )) ? explode( ',', $_POST['allowed_file_types'] ) : null;
			if( is_array( $allowed_file_mime_types ) ) {
				foreach( $allowed_file_mime_types as $key => $mime_type ) {
					$mime_types = explode( '/', $mime_type )[0];
				}
			}
			$allowed_file_types = implode( ',', $mime_types );
			$upload_data = $this->helpers->uploadFile( $_FILES['file'], null, null, $allowed_file_types, null, 'guid', $upload_dir );
			if( is_array( $upload_data ) ) {
				$return['errors'] = $upload_data['errors'];
			} else {
				$return['success'] = $upload_data;
			}
			echo json_encode( $return );

			die();
		}

		public function vueUploadFiles() {
			if( ! isset( $_POST['delete_file'] ) ) {
				$return = array();
				if( ! wp_verify_nonce( $_POST['_wp_nonce'], 'vue-upload-avatar' ) ) {
					$return['error'] = __( 'You are not allowed to perform this action.', 'cssjockey-add-ons' );
					die();
				}
				$upload_dir = $this->helpers->upload_path . '/cssjockey-add-ons/files';
				add_filter( 'upload_dir', function ( $upload ) {
					$upload['subdir'] = '/files/';
					$upload['path'] = $upload['basedir'] . '/cssjockey-add-ons/files';
					$upload['url'] = $upload['baseurl'] . '/cssjockey-add-ons/files';

					return $upload;
				} );

				$allowed_file_types = null;
				$mime_types = array();
				$allowed_file_mime_types = (isset( $_POST['allowed_file_types'] )) ? explode( ',', $_POST['allowed_file_types'] ) : null;
				if( is_array( $allowed_file_mime_types ) ) {
					foreach( $allowed_file_mime_types as $key => $mime_type ) {
						$mime_types = explode( '/', $mime_type )[0];
					}
				}
				$allowed_file_types = implode( ',', $mime_types );
				$upload_data = $this->helpers->uploadFile( $_FILES['file'], null, null, $allowed_file_types, null, 'guid', $upload_dir );
				if( is_array( $upload_data ) ) {
					$return['errors'] = $upload_data['errors'];
				} else {
					$return['success'] = $upload_data;
				}
				echo json_encode( $return );

				die();
			}
			if( isset( $_POST['delete_file'] ) ) {
				$file_url = $_POST['delete_file'];
				$file_path = str_replace( $this->helpers->root_url, $this->helpers->root_dir, $file_url );
				$this->helpers->deleteFile( $file_path );
				$return['success'] = $_POST['delete_file'];
				echo json_encode( $return );
				die();
			}
		}

		public function vueUploadUiBlock() {
			global $wpdb;
			$upload_dir = $this->helpers->upload_path . '/cssjockey-add-ons/ui-blocks';
			$source = $_FILES['file'];
			$destination = trailingslashit( $upload_dir );
			$file_name = str_replace( '.zip', '', $source['name'] );

			$blocks = $wpdb->get_results( "SELECT * FROM $wpdb->postmeta WHERE meta_key = '_component_info' AND meta_value LIKE '%{$file_name}%'" );
			if( is_array( $blocks ) ) {
				foreach( $blocks as $key => $block ) {
					update_post_meta( $block->post_id, '_cjaddons_compile_sass', 'yes' );
				}
			}

			$extension = pathinfo( $source['name'], PATHINFO_EXTENSION );
			if( $extension !== 'zip' ) {
				echo json_encode( array('errors' => __( 'Invalid file type.', 'cssjockey-add-ons' )) );
				die();
			}
			if( is_dir( $destination . $file_name ) ) {
				$this->helpers->deleteDirectory( $destination . $file_name );
			}
			$response = $this->helpers->unzipFile( $source['tmp_name'], $destination . $file_name );
			if( is_array( $response ) && ! empty( $response ) ) {
				echo json_encode( array('errors' => implode( '<br>', $response )) );
			} else {
				$upload_dir_msg = explode( 'wp-content', $upload_dir );
				echo json_encode( array('success' => sprintf( __( 'UI BLock Uploaded to <br>%s.', 'cssjockey-add-ons' ), 'wp-content' . $upload_dir_msg[1] . '/' . $file_name )) );
			}
			die();
		}

		public function vueUploadAddon() {
			global $wpdb;
			$upload_dir = WP_PLUGIN_DIR;
			$source = $_FILES['file'];
			$destination = trailingslashit( $upload_dir );
			$file_name = str_replace( '.zip', '', $source['name'] );

			$extension = pathinfo( $source['name'], PATHINFO_EXTENSION );
			if( $extension !== 'zip' ) {
				echo json_encode( array('errors' => __( 'Invalid file type.', 'cssjockey-add-ons' )) );
				die();
			}
			if( is_dir( $destination . $file_name ) ) {
				$this->helpers->deleteDirectory( $destination . $file_name );
			}
			$response = $this->helpers->unzipFile( $source['tmp_name'], $destination );
			if( is_array( $response ) && ! empty( $response ) ) {
				echo json_encode( array('errors' => implode( '<br>', $response )) );
			} else {
				$upload_dir_msg = explode( 'wp-content', $upload_dir );
				echo json_encode( array('success' => __( 'Addon uploaded successfully!', 'cssjockey-add-ons' )) );
			}
			die();
		}

		public function queryPostsCallback() {
			$query_args = (isset( $_REQUEST['args'] ) && is_array( $_REQUEST['args'] )) ? $_REQUEST['args'] : array();
			$return = array();
			$query_args['paged'] = (isset( $query_args['paged'] )) ? $query_args['paged'] : 1;
			$the_query = new WP_Query( $query_args );
			$count = - 1;
			$posts = array();
			if( $the_query->have_posts() ) {
				$count = - 1;
				while( $the_query->have_posts() ) {
					$count ++;
					$the_query->the_post();
					global $post;
					$post_info = $this->helpers->postInfo( $post->ID );
					$post_info['sort_order'] = strtotime( $post_info['post_date'] );
					$posts[ $count ] = $post_info;
				}
				if( is_array( $posts ) && ! empty( $posts ) ) {
					$return['posts'] = $posts;
					$return['post_count'] = $the_query->post_count;
					$return['total_posts'] = (int) $the_query->found_posts;

					$return['pagination'] = array();
					// pagination data
					$total_pages = $the_query->max_num_pages;
					$current_page = (int) $the_query->query['paged'];
					$next_page = $the_query->query['paged'] + 1;
					$previous_page = $the_query->query['paged'] - 1;
					if( $next_page > $total_pages ) {
						$next_page = null;
					}
					if( $previous_page <= 0 ) {
						$previous_page = null;
					}
					$return['pagination']['total_pages'] = $total_pages;
					$return['pagination']['current_page'] = $current_page;
					$return['pagination']['next_page'] = $next_page;
					$return['pagination']['previous_page'] = $previous_page;
					$return = apply_filters( 'modify_cjaddons_query_posts', $return );
				} else {
					$return = array();
				}
				wp_reset_postdata();
			} else {
				$return = array();
			}
			echo json_encode( $return );
			die();
		}

		public function queryUsersCallback() {
			$users = get_users( $_POST );
			$return = array();
			if( ! empty( $users ) ) {
				foreach( $users as $key => $user ) {
					$user_info = $this->helpers->userInfo( $user->ID );
					$return[] = $user_info;
				}
			}
			echo json_encode( $return );
			die();
		}

	}

	cjaddons_global_ajax_support::getInstance();
}