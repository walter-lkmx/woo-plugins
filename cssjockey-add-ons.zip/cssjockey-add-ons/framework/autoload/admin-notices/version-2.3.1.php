<?php
$sass_variables_url = $this->helpers->callbackUrl( 'config', 'core-sass' );
$title = sprintf( __( '%s - Upgrade Notice', 'cssjockey-add-ons' ), $this->helpers->itemInfo( 'item_name' ) );
$message[] = 'We have changed all css classes and used <code>cj-</code> as a prefix to avoid conflicts with other themes and plugins.';
$message[] = 'You must update the <a href="' . $sass_variables_url . '" target="_blank">SASS variables</a> and clear your website cache if you use any cache plugins.';
$message[] = 'If you are using our <b>WP Form Builder</b> Add-on, then you must update the column size for the fields and use <code>cj-</code> as prefix for all button classes under form settings.';
$message[] = '<p style="margin-bottom: 0 !important;">We use <a href="http://bulma.io/" target="_blank">bulma css framework</a> so you can use any classes available with this framework.</p>';

$file_name = str_replace( '.php', '', basename( __FILE__ ) );
$notice_id = 'cjaddons-notice-' . sanitize_title( $file_name );
echo $this->helpers->adminNotice( $notice_id, 'warning', implode( '<br>', $message ), $title, true );