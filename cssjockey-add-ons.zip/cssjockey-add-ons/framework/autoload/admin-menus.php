<?php
if( ! class_exists( 'cjaddons_admin_menus' ) ) {
	class cjaddons_admin_menus {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'admin_menu', array($this, 'adminMenu') );
			add_action( 'admin_bar_menu', array($this, 'addonsAdminBarMenus'), 1000 );
		}

		public function adminMenu() {
			global $menu, $submenu;
			$item_info = $this->helpers->itemVars( 'info' );
			$icon_url = $this->helpers->root_url . '/assets/cssjockey/images/icon.svg';
			add_menu_page( $item_info['page_title'], $item_info['menu_title'], 'manage_options', $item_info['page_slug'], array($this, 'adminMenuPage'), $icon_url );

			// Updates available count
			$upgrades_available = (array) get_option( 'cjaddons_upgrades_available', array() );
			$count = count( $upgrades_available );

			if( $count > 0 ) {
				foreach( $menu as $key => $value ) {
					if( $menu[ $key ][2] == 'cjaddons' ) {
						$menu[ $key ][0] .= '<span class="update-plugins count-' . $count . '"><span class="update-count">' . $count . '</span></span>';
					}
				}
			}

			// Notification Count
			$admin_menu_notification_count = 0;
			$admin_menu_notification_count = apply_filters( 'cjaddons_admin_menu_notification_count', $admin_menu_notification_count );
			if( $admin_menu_notification_count > 0 ) {
				foreach( $menu as $key => $value ) {
					if( $menu[ $key ][2] == $item_info['page_slug'] ) {
						$menu[ $key ][0] .= ' <span class="update-plugins count-1"><span class="update-count">' . $admin_menu_notification_count . '</span></span>';
					}
				}
			}

			add_submenu_page( 'edit.php?post_type=cj-ui-blocks', __( 'Import UI Blocks', 'cssjockey-add-ons' ), __( 'Import', 'cssjockey-add-ons' ), 'manage_options', 'cjaddons-upload-ui-blocks', array($this, 'uploadUiBlocksPage') );
			add_submenu_page( 'edit.php?post_type=cj-ui-blocks', __( 'Check for Updates', 'cssjockey-add-ons' ), __( 'Updates', 'cssjockey-add-ons' ), 'manage_options', 'cjaddons-update-ui-blocks', array($this, 'updatesUiBlocksPage') );
		}

		public function adminMenuPage() {
			require_once $this->helpers->root_dir . '/framework/html/admin-page.php';
		}

		public function getAddonsPage() {
			require_once $this->helpers->root_dir . '/framework/html/admin-submenu-page.php';
		}

		public function uploadUiBlocksPage() {
			$url = $this->helpers->callbackUrl( 'config', 'upload-ui-blocks', 'cjaddons' );
			wp_redirect( $url );
			die();
		}

		public function updatesUiBlocksPage() {
			$url = $this->helpers->callbackUrl( 'config', 'upgrades-ui-blocks', 'cjaddons' );
			wp_redirect( $url );
			die();
		}

		public function showUpdatesPage() {
			$url = $this->helpers->queryString( $this->helpers->callbackUrl( 'config', 'core-download-updates', 'cjaddons' ) );
			wp_redirect( $url );
			die();
		}

		public function addonsAdminBarMenus() {
			if( ! current_user_can( 'manage_options' ) ) {
				return false;
			}
			global $wp_admin_bar;
			$title = 'CSSJockey';
			$wp_admin_bar->add_menu( array('id' => 'cjaddons', 'title' => $title, 'href' => $this->helpers->callbackUrl( 'config', 'core-welcome', 'cjaddons' )) );
			$wp_admin_bar->add_menu( array('parent' => 'cjaddons', 'id' => 'cjaddons-menu-core', 'title' => __( 'Home', 'cssjockey-add-ons' ), 'href' => $this->helpers->callbackUrl( 'config', 'core-welcome', 'cjaddons' )) );
			$wp_admin_bar->add_menu( array('parent' => 'cjaddons-menu-core', 'id' => 'cjaddons-menu-core-info', 'title' => __( 'Info & Add-ons', 'cssjockey-add-ons' ), 'href' => $this->helpers->callbackUrl( 'config', 'core-welcome', 'cjaddons' )) );
			$wp_admin_bar->add_menu( array('parent' => 'cjaddons-menu-core', 'id' => 'cjaddons-menu-core-global-config', 'title' => __( 'Global Settings', 'cssjockey-add-ons' ), 'href' => $this->helpers->callbackUrl( 'config', 'core-global-config', 'cjaddons' )) );
			$wp_admin_bar->add_menu( array('parent' => 'cjaddons-menu-core', 'id' => 'cjaddons-menu-core-sass', 'title' => __( 'UI Style Variables', 'cssjockey-add-ons' ), 'href' => $this->helpers->callbackUrl( 'config', 'core-sass', 'cjaddons' )) );
			$wp_admin_bar->add_menu( array('parent' => 'cjaddons-menu-core', 'id' => 'cjaddons-menu-core-shortcodes', 'title' => __( 'Shortcodes', 'cssjockey-add-ons' ), 'href' => $this->helpers->callbackUrl( 'config', 'core-shortcodes', 'cjaddons' )) );
			$wp_admin_bar->add_menu( array('parent' => 'cjaddons-menu-core', 'id' => 'cjaddons-menu-core-backup', 'title' => __( 'Backup & Restore', 'cssjockey-add-ons' ), 'href' => $this->helpers->callbackUrl( 'config', 'core-backup', 'cjaddons' )) );
			$wp_admin_bar->add_menu( array('parent' => 'cjaddons-menu-core', 'id' => 'cjaddons-menu-core-uninstall', 'title' => __( 'Uninstall', 'cssjockey-add-ons' ), 'href' => $this->helpers->callbackUrl( 'config', 'core-uninstall', 'cjaddons' )) );
			$installed_addons = $this->helpers->activeAddons();
			if( is_array( $installed_addons ) && ! empty( $installed_addons ) ) {
				foreach( $installed_addons as $key => $value ) {
					if( strstr( $key, 'addon-' ) ) {
						$module_info = $this->helpers->moduleInfo( $key );
						if( is_array( $module_info ) && ! empty( $module_info ) && isset( $module_info['module_name'] ) ) {
							$url = $this->helpers->callbackUrl( $key, 'info', 'cjaddons-' . $key );
							$wp_admin_bar->add_menu( array('parent' => 'cjaddons', 'id' => 'menu-' . $key, 'title' => $module_info['module_name'], 'href' => $url) );

							$sub_menus = (isset( $this->helpers->item_vars['admin_menu'][ $module_info['module_id'] ] )) ? $this->helpers->item_vars['admin_menu'][ $module_info['module_id'] ] : '';
							if( is_array( $sub_menus ) && ! empty( $sub_menus ) ) {
								foreach( $sub_menus as $sub_menu_key => $sub_menu ) {
									if( ! is_array( $sub_menu ) ) {
										$sub_menu_url = $this->helpers->callbackUrl( $key, $sub_menu_key, 'cjaddons-' . $key );
										$wp_admin_bar->add_menu( array('parent' => 'menu-' . $key, 'id' => 'sub-menu-' . $sub_menu_key, 'title' => $sub_menu, 'href' => $sub_menu_url) );
									}
									if( is_array( $sub_menu ) && ! empty( $sub_menu ) ) {
										$sub_menu_callback_back = array_keys( $sub_menu['items'] )[0];
										$sub_menu_url = $this->helpers->callbackUrl( $key, $sub_menu_callback_back, 'cjaddons-' . $key );
										$sub_menu_id = 'sub-menu-' . sanitize_title( $sub_menu['label'] );
										$wp_admin_bar->add_menu( array('parent' => 'menu-' . $key, 'id' => 'sub-menu-' . sanitize_title( $sub_menu['label'] ), 'title' => $sub_menu['label'], 'href' => $sub_menu_url) );
										if( is_array( $sub_menu['items'] ) && ! empty( $sub_menu['items'] ) ) {
											foreach( $sub_menu['items'] as $sub_menu_item_key => $sub_menu_item_value ) {
												$sub_menu_url = $this->helpers->callbackUrl( $module_info['module_id'], $sub_menu_item_key, 'cjaddons-' . $module_info['module_id'] );
												$wp_admin_bar->add_menu( array('parent' => $sub_menu_id, 'id' => 'sub-menu-' . $sub_menu_item_key, 'title' => $sub_menu_item_value, 'href' => $sub_menu_url) );
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

	}

	cjaddons_admin_menus::getInstance();
}