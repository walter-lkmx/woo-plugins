<?php
if( ! class_exists( 'cjaddons_ui_block_shortcode' ) ) {
	class cjaddons_ui_block_shortcode {

		public $defaults, $helpers, $render_forms, $textdomain, $shortcode_tag;
		private static $instance;

		public function defaults() {
			$ui_blocks = [];
			$ui_blocks_query = get_posts( [
				'posts_per_page' => -1,
				'post_type' => 'cj-ui-blocks',
				'post_status' => 'publish',
				'order_by' => 'post_title',
				'order' => 'ASC',
			] );
			if( ! empty( $ui_blocks_query ) ) {
				foreach( $ui_blocks_query as $key => $form_post ) {
					$ui_blocks[ $form_post->ID ] = $form_post->post_title;
				}
			}
			$defaults['info'] = array(
				'single' => true,
				'tag' => $this->shortcode_tag,
				'name' => esc_attr__( 'UI Block', $this->textdomain ),
				'description' => esc_attr__( 'This shortcode will render selected UI block.', $this->textdomain ),
				'screenshot' => 'https://cssjockey.com/cjaddons-media/graphics/cssjockey-add-ons/ui-block-shortcode-thumb.png',
				'default_content' => '',
				'group' => 'cjaddons',
				'textdomain' => 'cjaddons',
				'item_name' => $this->helpers->itemInfo( 'item_name' ),
			);
			$defaults['options'] = array(
				array(
					'type' => 'dropdown',
					'id' => 'block_id',
					'label' => __( 'Select UI Block', 'cssjockey-add-ons' ),
					'info' => '',
					'default' => '',
					'params' => array('class' => 'show-component-screenshot'),
					'options' => $ui_blocks, // array in case of dropdown, checkbox and radio buttons
				),
			);

			return $defaults;
		}

		public static function getInstance() {

			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->shortcode_tag = str_replace( '_shortcode', '', get_class( $this ) );
			add_shortcode( $this->shortcode_tag, array($this, 'run') );
			$this->helpers = cjaddons_helpers::getInstance();
			$this->textdomain = $this->helpers->itemInfo( 'text_domain' );
			$this->defaults = $this->defaults();

			add_action( 'template_redirect', array($this, 'previewShortcode'), 1 );
		}

		public function getScreenshotUrl() {

			$screen_shot_url = null;
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.svg';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.png';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.jpg';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}

			return $screen_shot_url;
		}

		public function run( $atts, $content = null ) {

			$defaults = array();
			$shortcode_params = $this->defaults();
			foreach( $shortcode_params['options'] as $key => $param ) {
				$default_key = str_replace( '-', '_', $param['id'] );
				$default_value = (is_array( $param['default'] )) ? implode( '|', $param['default'] ) : $param['default'];
				$defaults[ $default_key ] = $default_value;
			}
			$instance = shortcode_atts( $defaults, $atts );
			$output = '';

			if($instance['block_id'] == '' && current_user_can('manage_options')){
				$output = $this->helpers->alert('warning', __('You must specify <b>block_id</b> to render the UI Block.', 'cssjockey-add-ons'), '' , false);
			}

			ob_start();
			$block_info = $this->helpers->postInfo( $instance['block_id'] );

			if( isset( $block_info['_component_class_name'] ) ) {
				$class_name = $block_info['_component_class_name'];
				$block_info['_shortcode_atts'] = $atts;
				if( class_exists( $class_name ) ) {
					$class_instance = $class_name::getInstance();
					$class_instance->render( $block_info );
					$output .= ob_get_clean();
					$output = apply_filters( 'cjaddons_shortcode_before_output', $output, $shortcode_params );
					$output = apply_filters( 'cjaddons_shortcode_after_output', $output, $shortcode_params );
				}
			}

			return $output;
		}

		public function previewShortcode() {
			if( isset( $_GET['cjaddons-preview-shortcode'] ) && $_GET['cjaddons-preview-shortcode'] != '' ) {
				require_once 'html/preview-shortcode.php';
				die();
			}
		}

	}

	cjaddons_ui_block_shortcode::getInstance();
}