<?php
if( ! class_exists( 'cjaddons_enqueue_admin_scripts' ) ) {
	class cjaddons_enqueue_admin_scripts {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'admin_enqueue_scripts', array($this, 'adminEnqueueScripts') );
		}

		public function adminEnqueueScripts() {
			global $cjaddons_item_vars;
			$assets_url = $this->helpers->root_url;
			$assets_dir = $this->helpers->root_dir;

			$item_version = ($this->helpers->isLocal()) ? time() : $this->helpers->itemInfo( 'item_version' );

			wp_register_style( 'cjaddons-cssjockey-font', $this->helpers->root_url . '/framework/lib/cssjockey-font/style.css', array(), $item_version, 'all' );
			wp_enqueue_style( 'cjaddons-cssjockey-font' );

			wp_enqueue_script( 'media-upload' );
			wp_enqueue_media();

			$handle = 'cssjockey-external-font-awesome';
			wp_enqueue_style( $handle, $this->helpers->root_url . '/framework/lib/font-awesome/css/font-awesome.min.css', array(), $item_version, 'all' );

			$external_sources = array();
			if( isset( $cjaddons_item_vars['external_libraries_backend'] ) && ! empty( $cjaddons_item_vars['external_libraries_backend'] ) ) {
				foreach( $cjaddons_item_vars['external_libraries_backend'] as $module => $files ) {
					if( is_array( $files ) && ! empty( $files ) ) {
						foreach( $files as $f_key => $f_path ) {
							if( is_array( $f_path ) ) {
								$file_slug = sanitize_title( basename( $f_path[0] ) );
								$external_sources[ $file_slug ] = $f_path[0];
							} else {
								$file_slug = sanitize_title( basename( $f_path ) );
								$external_sources[ $file_slug ] = $f_path;
							}
						}
					}
				}
				if( ! empty( $external_sources ) ) {
					foreach( $external_sources as $e_key => $e_file ) {
						$url = '';
						$dependencies = array();
						if( ! is_array( $e_file ) ) {
							$url = $e_file;
						}
						if( is_array( $e_file ) ) {
							$url = $e_file[0];
							$dependencies = $e_file[1];
						}

						if( strstr( $e_file, '//fonts.googleapis.com/css' ) ) {
							$handle = 'cjaddons-external-' . $e_key;
							wp_enqueue_style( $handle, $url, $dependencies, $item_version, 'all' );
						}
						if( substr( $url, - 4, 4 ) == '.css' ) {
							$handle = 'cjaddons-external-' . $e_key;
							wp_enqueue_style( $handle, $url, $dependencies, $item_version, 'all' );
						}
						if( substr( $url, - 3, 3 ) == '.js' ) {
							$handle = 'cjaddons-external-' . $e_key;
							wp_enqueue_script( $handle, $url, $dependencies, $item_version, true );
						}
					}
				}
			}

			if( file_exists( $assets_dir . '/assets/backend/vendor.min.css' ) ) {
				wp_register_style( 'cssjockey-backend-vendors', $assets_url . '/assets/backend/vendor.min.css', false, $item_version );
				wp_enqueue_style( 'cssjockey-backend-vendors' );
			}

			$vendor_dir = $assets_dir . '/assets/backend/vendor';
			$dirs = preg_grep( '/^([^.])/', scandir( $vendor_dir ) );
			foreach( $dirs as $key => $file ) {
				$file_path = $vendor_dir . '/' . $file;
				if( ! is_dir( $file_path ) && strpos( $file, '.js' ) > 0 && file_exists( $file_path ) ) {
					$file_url = str_replace( $assets_dir, $assets_url, $file_path );
					$file_id = strtolower( sanitize_title( $file ) );
					$in_footer = true;
					if( strstr( $file, 'vue' ) ) {
						$in_footer = false;
					}
					wp_register_script( 'cssjockey-backend-vendor-' . $file_id, $file_url, array('jquery', 'jquery-ui-autocomplete', 'jquery-ui-datepicker'), $item_version, $in_footer );
					if( file_exists( $file_path ) ) {
						wp_enqueue_script( 'cssjockey-backend-vendor-' . $file_id );
					}
				}
			}

			$vendor_dir = $assets_dir . '/assets/backend/vendor';
			$dirs = preg_grep( '/^([^.])/', scandir( $vendor_dir ) );
			if( is_array( $dirs ) && ! empty( $dirs ) ) {
				foreach( $dirs as $key => $file ) {
					$file_path = $vendor_dir . '/' . $file;
					if( ! is_dir( $file_path ) && strpos( $file, '.css' ) > 0 && file_exists( $file_path ) ) {
						$file_url = str_replace( $assets_dir, $assets_url, $file_path );
						$file_id = strtolower( sanitize_title( $file ) );
						wp_register_style( 'cssjockey-backend-vendor-' . $file_id, $file_url, false, $item_version, 'all' );
						if( file_exists( $file_path ) ) {
							wp_enqueue_style( 'cssjockey-backend-vendor-' . $file_id );
						}
					}
				}
			}

			if( file_exists( $assets_dir . '/assets/backend/helpers.min.css' ) ) {
				wp_register_style( 'cssjockey-backend-helpers', $assets_url . '/assets/backend/helpers.min.css', false, $item_version );
				wp_enqueue_style( 'cssjockey-backend-helpers' );
			}

			if( file_exists( $assets_dir . '/assets/backend/backend.min.css' ) ) {
				wp_register_style( 'cjaddons-backend-framework', $assets_url . '/assets/backend/backend.min.css', false, $item_version );
				wp_enqueue_style( 'cjaddons-backend-framework' );
			}

			if( file_exists( $assets_dir . '/assets/backend/backend.min.js' ) ) {
				wp_register_script( 'cjaddons-backend-framework', $assets_url . '/assets/backend/backend.min.js', array('jquery-ui-datepicker'), $item_version, true );
				$localize_admin_script = $this->helpers->localizeScripts();
				$localize_admin_script['options'] = $this->helpers->saved_options;
				wp_enqueue_script( 'cjaddons-backend-framework' );
				wp_localize_script( 'cjaddons-backend-framework', 'localize', $localize_admin_script );
			}
		}

	}

	cjaddons_enqueue_admin_scripts::getInstance();
}