<?php
if( ! class_exists( 'cjaddons_enqueue_frontend_scripts' ) ) {
	class cjaddons_enqueue_frontend_scripts {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'wp_enqueue_scripts', array($this, 'frontendEnqueueScripts'), 99 );
			add_action( 'wp_enqueue_scripts', array($this, 'frontendEnqueueScriptsCombined'), 9999 );
			add_filter( 'clean_url', array($this, 'addAsyncLoadCombinedScripts'), 99999, 1 );

			add_action( 'wp_head', array($this, 'thirdPartyScripts') );
		}

		public function thirdPartyScripts() {
			$google_recaptcha = $this->helpers->reCaptcha();
			if( $google_recaptcha ) {
				echo $google_recaptcha->getScript();
			}
		}

		public function addAsyncLoadCombinedScripts( $url ) {
			if( strpos( $url, 'combined-scripts' ) !== false ) {
				$url = str_replace( 'combined-scripts.php', "combined-scripts.php' async='async", $url );

				return $url;
			}

			return $url;
		}

		public function frontendEnqueueScriptsCombined() {

			if( $this->helpers->savedOption( 'core_combine_assets' ) !== 'yes' ) {
				return false;
			}
			global $wp_styles, $wp_scripts;
			$item_version = ($this->helpers->isLocal()) ? time() : $this->helpers->itemInfo( 'item_version' );
			$styles = array_keys( $wp_styles->registered );
			$exclude_styles = array(
				'cjaddons-external-font-awesome'
			);
			$combined_styles = array();
			if( is_array( $styles ) && ! empty( $styles ) ) {
				foreach( $styles as $key => $style ) {
					if( strpos( $style, 'cjaddons' ) === 0 && $style !== 'cjaddons-ui-blocks-css' && ! in_array( $style, $exclude_styles ) ) {
						$combined_styles[] = $wp_styles->registered[ $style ]->src;
					}
				}
				update_option( 'cjaddons_combined_styles', $combined_styles );
				$file_url = $this->helpers->root_url . '/combined-styles.php';
				wp_enqueue_style( 'cjaddons-combined-css', $file_url, array(), $item_version, 'all' );
			}

			$scripts = array_keys( $wp_scripts->registered );
			$exclude_scripts = array();
			$combined_scripts = array();
			if( is_array( $scripts ) && ! empty( $scripts ) ) {
				foreach( $scripts as $key => $script ) {
					if( strpos( $script, 'cjaddons' ) === 0 && $script !== 'cjaddons-ui-blocks-js' && ! in_array( $script, $exclude_scripts ) ) {
						$combined_scripts[] = $wp_scripts->registered[ $script ]->src;
					}
				}
				update_option( 'cjaddons_combined_scripts', $combined_scripts );
				$file_url = $this->helpers->root_url . '/combined-scripts.php';
				$localize_script = $this->helpers->localizeScripts();
				wp_enqueue_script( 'cjaddons-combined-js', $file_url, array('jquery', 'jquery-ui-datepicker', 'jquery-ui-sortable'), $item_version, true );
				wp_localize_script( 'cjaddons-combined-js', 'localize', $localize_script );
			}
		}

		public function frontendEnqueueScripts() {
			global $cjaddons_item_vars;
			$assets_url = $this->helpers->root_url;
			$assets_dir = $this->helpers->root_dir;

			$combine_assets = $this->helpers->savedOption( 'core_combine_assets' );
			$item_version = ($this->helpers->isLocal()) ? time() : $this->helpers->itemInfo( 'item_version' );
			wp_register_style( 'cjaddons-external-font-awesome', $this->helpers->root_url . '/framework/lib/font-awesome/css/font-awesome.min.css', array(), $item_version, 'all' );
			wp_enqueue_style( 'cjaddons-external-font-awesome' );

			wp_register_style( 'cjaddons-cssjockey-font', $this->helpers->root_url . '/framework/lib/cssjockey-font/style.css', array(), $item_version, 'all' );
			wp_enqueue_style( 'cjaddons-cssjockey-font' );

			$core_sass_variables = $this->helpers->savedOption( 'core_sass_variables' );
			$google_fonts = array();
			$google_fonts_array = $this->helpers->getGoogleFonts();
			foreach( $core_sass_variables as $key => $value ) {
				if( strstr( $key, 'family' ) ) {
					if( in_array( $value, $google_fonts_array ) ) {
						$google_fonts[ $value ] = 'https://fonts.googleapis.com/css?family=' . urlencode( $value );
					}
				}
			}
			if( ! empty( $google_fonts ) ) {
				foreach( $google_fonts as $key => $url ) {
					if( $combine_assets !== 'yes' ) {
						wp_enqueue_style( 'cjaddons-external-' . sanitize_title( $key ), $url, array(), $item_version, 'all' );
					}
				}
			}

			$external_sources = array();
			if( isset( $cjaddons_item_vars['external_libraries_frontend'] ) && ! empty( $cjaddons_item_vars['external_libraries_frontend'] ) ) {
				foreach( $cjaddons_item_vars['external_libraries_frontend'] as $module => $files ) {
					if( is_array( $files ) && ! empty( $files ) ) {
						foreach( $files as $f_key => $f_path ) {
							if( is_array( $f_path ) ) {
								$file_slug = sanitize_title( basename( $f_path[0] ) );
								$external_sources[ $file_slug ] = $f_path[0];
							} else {
								$file_slug = sanitize_title( basename( $f_path ) );
								$external_sources[ $file_slug ] = $f_path;
							}
						}
					}
				}
				if( ! empty( $external_sources ) ) {
					foreach( $external_sources as $e_key => $e_file ) {
						$url = '';
						$dependencies = array();
						if( ! is_array( $e_file ) ) {
							$url = $e_file;
						}
						if( is_array( $e_file ) ) {
							$url = $e_file[0];
							$dependencies = $e_file[1];
						}

						if( strstr( $e_file, '//fonts.googleapis.com/css' ) ) {
							$handle = 'cjaddons-external-' . $e_key;
							if( $combine_assets !== 'yes' ) {
								wp_enqueue_style( $handle, $url, $dependencies, $item_version, 'all' );
							}
						}
						if( substr( $url, - 4, 4 ) == '.css' ) {
							$handle = 'cjaddons-external-' . $e_key;
							if( $combine_assets !== 'yes' ) {
								wp_enqueue_style( $handle, $url, $dependencies, $item_version, 'all' );
							}
						}
						if( substr( $url, - 3, 3 ) == '.js' ) {
							if( $combine_assets !== 'yes' ) {
								$handle = 'cjaddons-external-' . $e_key;
								wp_enqueue_script( $handle, $url, $dependencies, $item_version, true );
							}
						}
					}
				}
			}

			$vendor_dir = $assets_dir . '/assets/frontend/vendor';
			if( is_dir( $vendor_dir ) ) {
				$dirs = preg_grep( '/^([^.])/', scandir( $vendor_dir ) );
				foreach( $dirs as $key => $file ) {
					$file_path = $vendor_dir . '/' . $file;
					if( ! is_dir( $file_path ) && strpos( $file, '.js' ) > 0 && file_exists( $file_path ) ) {
						$file_url = str_replace( $assets_dir, $assets_url, $file_path );
						$file_id = strtolower( sanitize_title( $file ) );
						if( file_exists( $file_path ) ) {
							wp_register_script( 'cjaddons-frontend-' . $file_id, $file_url, array('jquery', 'jquery-ui-datepicker', 'jquery-ui-sortable'), $item_version, false );
							if( $combine_assets !== 'yes' ) {
								wp_enqueue_script( 'cjaddons-frontend-' . $file_id );
							}
						}
					}
				}
			}

			$vendor_dir = $assets_dir . '/assets/frontend/vendor';
			if( is_dir( $vendor_dir ) ) {
				$dirs = preg_grep( '/^([^.])/', scandir( $vendor_dir ) );
				foreach( $dirs as $key => $file ) {
					$file_path = $vendor_dir . '/' . $file;
					if( ! is_dir( $file_path ) && strpos( $file, '.css' ) > 0 && file_exists( $file_path ) ) {
						$file_url = str_replace( $assets_dir, $assets_url, $file_path );
						$file_id = strtolower( sanitize_title( $file ) );
						wp_register_style( 'cjaddons-frontend-vendor-' . $file_id, $file_url, false, $item_version, 'all' );
						if( file_exists( $file_path ) ) {
							if( $combine_assets !== 'yes' ) {
								wp_enqueue_style( 'cjaddons-frontend-vendor-' . $file_id );
							}
						}
					}
				}
			}

			$upload_dir = $this->helpers->upload_dir['basedir'];
			$custom_ui_sass_file = $upload_dir . '/cssjockey-ui/ui-base.min.css';
			$custom_helpers_file = $upload_dir . '/cssjockey-ui/helpers.min.css';

			if( file_exists( $custom_ui_sass_file ) ) {
				wp_register_style( 'cjaddons-core-sass', str_replace( ABSPATH, site_url('/'), $custom_ui_sass_file ), false, $item_version . time() );
				if( $combine_assets !== 'yes' ) {
					wp_enqueue_style( 'cjaddons-core-sass' );
				}
			} else {
				$custom_ui_sass_file = $this->helpers->root_dir . '/assets/frontend/ui-base-core.css';
				wp_register_style( 'cjaddons-core-sass', str_replace( ABSPATH, site_url('/'), $custom_ui_sass_file ), false, $item_version . time() );
				if( $combine_assets !== 'yes' ) {
					wp_enqueue_style( 'cjaddons-core-sass' );
				}
			}

			if( file_exists( $custom_helpers_file ) ) {
				wp_register_style( 'cjaddons-core-helpers', str_replace( ABSPATH, site_url('/'), $custom_helpers_file ), false, $item_version . time() );
				if( $combine_assets !== 'yes' ) {
					wp_enqueue_style( 'cjaddons-core-helpers' );
				}
			} else if( file_exists( $assets_dir . '/assets/frontend/helpers.min.css' ) ) {
				wp_register_style( 'cjaddons-core-helpers', $assets_url . '/assets/frontend/helpers.min.css', false, $item_version );
				if( $combine_assets !== 'yes' ) {
					wp_enqueue_style( 'cjaddons-core-helpers' );
				}
			}

			if( file_exists( $assets_dir . '/assets/frontend/frontend.min.css' ) ) {
				wp_register_style( 'cjaddons-frontend-framework', $assets_url . '/assets/frontend/frontend.min.css', false, $item_version );
				if( $combine_assets !== 'yes' ) {
					wp_enqueue_style( 'cjaddons-frontend-framework' );
				}
			}

			if( file_exists( $assets_dir . '/assets/frontend/cssjockey-core.min.css' ) ) {
				wp_register_style( 'cjaddons-frontend-framework', $assets_url . '/assets/frontend/cssjockey-core.min.css', false, $item_version );
				if( $combine_assets !== 'yes' ) {
					wp_enqueue_style( 'cjaddons-frontend-framework' );
				}
			}

			wp_register_script( 'cjaddons-frontend-framework', $assets_url . '/assets/frontend/frontend.min.js', array('jquery', 'jquery-ui-autocomplete', 'jquery-ui-datepicker', 'jquery-ui-draggable'), $item_version, true );
			if( file_exists( $assets_dir . '/assets/frontend/frontend.min.js' ) ) {
				if( $combine_assets !== 'yes' ) {
					$localize_admin_script = $this->helpers->localizeScripts();
					wp_enqueue_script( 'cjaddons-frontend-framework' );
					wp_localize_script( 'cjaddons-frontend-framework', 'localize', $localize_admin_script );
				}
			}

			wp_register_script( 'cjaddons-frontend-framework', $assets_url . '/assets/frontend/cssjockey-core.min.js', array('jquery-ui-datepicker'), $item_version, true );
			if( file_exists( $assets_dir . '/assets/frontend/cssjockey-core.min.js' ) ) {
				if( $combine_assets !== 'yes' ) {
					$localize_admin_script = $this->helpers->localizeScripts();
					wp_enqueue_script( 'cjaddons-frontend-framework' );
					wp_localize_script( 'cjaddons-frontend-framework', 'localize', $localize_admin_script );
				}
			}
		}

	}

	cjaddons_enqueue_frontend_scripts::getInstance();
}