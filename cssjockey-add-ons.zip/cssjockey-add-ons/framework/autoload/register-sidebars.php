<?php
if( ! class_exists( 'cjaddons_sidebars_support' ) ) {
	class cjaddons_sidebars_support {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'widgets_init', array($this, 'registerSidebars') );
		}

		public function registerSidebars() {
			global $cjaddons_item_vars;
			if( isset( $cjaddons_item_vars['sidebars'] ) && is_array( $cjaddons_item_vars['sidebars'] ) && ! empty( $cjaddons_item_vars['sidebars'] ) ) {
				foreach( $cjaddons_item_vars['sidebars'] as $module_name => $sidebars ) {
					foreach( $sidebars as $key => $sidebar ) {
						$sidebar['class'] = $sidebar['class'] . ' cjaddons-sidebar';
						$dynamic_sidebar['before_widget'] = '<li id="%1$s" class="cj-widget widget %2$s">';
						$dynamic_sidebar['after_widget'] = '</li>';
						$dynamic_sidebar['before_title'] = '<h2 class="widgettitle">';
						$dynamic_sidebar['after_title'] = '</h2>';
						register_sidebar( $sidebar );
					}
				}
			}

			$dynamic_sidebars = $this->helpers->getOption( 'core_dynamic_sidebars', array() );
			if( is_array( $dynamic_sidebars ) && ! empty( $dynamic_sidebars ) ) {
				foreach( $dynamic_sidebars as $key => $dynamic_sidebar ) {
					if( $key != '' ) {
						$dynamic_sidebar['class'] = $dynamic_sidebar['class'] . ' cjaddons-sidebar';
						$dynamic_sidebar['before_widget'] = '<li id="%1$s" class="cj-widget widget %2$s">';
						$dynamic_sidebar['after_widget'] = '</li>';
						$dynamic_sidebar['before_title'] = '<h2 class="widgettitle">';
						$dynamic_sidebar['after_title'] = '</h2>';

						register_sidebar( $dynamic_sidebar );
					}
				}
			}
		}

	}

	cjaddons_sidebars_support::getInstance();
}