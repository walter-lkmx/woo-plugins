<?php
if( ! class_exists( 'cjaddons_frontend_mods' ) ) {
	class cjaddons_frontend_mods {
		public $helpers;
		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'init', array($this, 'init') );
		}

		public function init() {
			add_filter( 'body_class', array($this, 'bodyClass') );
		}

		public function bodyClass( $classes ) {
			if( is_user_logged_in() ) {
				$new_classes['logged-in'] = 'logged-in';
			} else {
				$new_classes['logged-out'] = 'logged-out';
			}

			return array_merge( $classes, $new_classes );
		}

	}

	cjaddons_frontend_mods::getInstance();
}