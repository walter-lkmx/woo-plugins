<?php
if( ! class_exists( 'cjaddons_admin_pointers' ) ) {
	class cjaddons_admin_pointers {
		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_action( 'admin_enqueue_scripts', array($this, 'loadPointers'), 1000 );
			add_filter( 'cjaddons_admin_pointers-dashboard', array($this, 'registerPointerDashboardWidget') );
		}

		public function registerPointerDashboardWidget( $pointers ) {
			$content = '<span class="cssjockey-ui">';
			$content .= '<p><b>Thank you for using CSSJockey Add-ons.</b></p>';
			$content .= sprintf('<p>CSSJockey Add-ons is our base framework plugin, that embeds the common functionality of our various <a target="_blank" href="%s">FREE</a> and <a target="_blank" href="%s">PREMIUM</a> add-ons to use common resources.</p>', 'https://cssjockey.com/freebie-type/add-on/', 'https://cssjockey.com/product-type/add-on/');
			$content .= '<span>';
			$pointers['cjaddons-core-dashboard-widget'] = array(
				'target' => '#cjaddons_dashboard_widget',
				'options' => array(
					'content' => sprintf( '<h3> %s </h3> <p> %s </p>',
						__( 'Activate your license!', 'cssjockey-add-ons' ),
						$content
					),
					'position' => array('edge' => 'left', 'align' => 'top')
				)
			);

			return $pointers;
		}

		public function loadPointers() {
			// Don't run on WP < 3.3
			if( get_bloginfo( 'version' ) < '3.3' ) {
				return;
			}

			$screen = get_current_screen();
			$screen_id = $screen->id;

			// Get pointers for this screen
			$pointers = apply_filters( 'cjaddons_admin_pointers-' . $screen_id, array() );

			if( ! $pointers || ! is_array( $pointers ) ) {
				return;
			}

			// Get dismissed pointers
			$dismissed = explode( ',', (string) get_user_meta( get_current_user_id(), 'dismissed_wp_pointers', true ) );
			$valid_pointers = array();

			// Check pointers and remove dismissed ones.
			foreach( $pointers as $pointer_id => $pointer ) {
				// Sanity check
				if( in_array( $pointer_id, $dismissed ) || empty( $pointer ) || empty( $pointer_id ) || empty( $pointer['target'] ) || empty( $pointer['options'] ) ) {
					continue;
				}
				$pointer['pointer_id'] = $pointer_id;
				// Add the pointer to $valid_pointers array
				$valid_pointers['pointers'][] = $pointer;
			}

			if( empty( $valid_pointers ) ) {
				return;
			}

			// Add pointers style to queue.
			wp_enqueue_style( 'wp-pointer' );

			// Add pointers script to queue. Add custom script.
			$script_url = $this->helpers->root_url . '/framework/autoload/pointers/pointer.js';
			wp_enqueue_script( 'cjaddons-admin-pointer', $script_url, array('wp-pointer') );

			// Add pointer options to script.
			wp_localize_script( 'cjaddons-admin-pointer', 'cjaddonsPointer', $valid_pointers );
		}

	}

	cjaddons_admin_pointers::getInstance();
}