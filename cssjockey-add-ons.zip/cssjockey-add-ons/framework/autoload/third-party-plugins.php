<?php
if( ! class_exists( 'cjaddons_third_party_plugins' ) ) {
	class cjaddons_third_party_plugins {

		public $helpers;

		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			// add_action( 'tgmpa_register', array($this, 'installPlugins') );
		}

		public function installPlugins() {
			$plugins_array = $this->helpers->itemVars( 'install_plugins' );
			$config = $this->helpers->itemVars( 'tgmpa_config' );
			$plugins = [];
			if( is_array( $plugins_array ) ) {
				foreach( $plugins_array as $key => $plugin ) {
					tgmpa( $plugin, $config );
				}
			}
		}

	}

	// cjaddons_third_party_plugins::getInstance();
}