<?php
if( ! class_exists( 'cjaddons_check_upgrades' ) ) {
	class cjaddons_check_upgrades {
		private static $instance;
		public $helpers;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			add_filter( 'pre_set_site_transient_update_plugins', array($this, 'checkForUpgrades') );
			if( ! defined( 'cjaddons_disable_updates' ) ) {
				add_action( 'admin_notices', array($this, 'activationMessage') );
			}
		}

		function checkForUpgrades( $transient ) {
			$url = $this->helpers->itemInfo( 'author_url' ) . 'download/upgrades.php';
			$installed_products = get_option( 'cjaddons_installed_versions' );
			$response = $this->helpers->wpRemotePost( $url, $installed_products, array(), 'full' );
			if(!isset( $response->errors ) && $response['response']['code'] == 200 ) {
				if( $response['body'] != '' ) {
					$data = json_decode( $response['body'] );
					$data = (array) $data;
					update_option( 'cjaddons_upgrades_available', $data );
				}
				if( $response['body'] == '' ) {
					update_option( 'cjaddons_upgrades_available', array() );
				}
			}
			return $transient;
		}

		public function activationMessage() {
			global $cjaddons_item_vars;

			$activation_required_array = $cjaddons_item_vars['locale']['activation_required'];
			if( ! empty( $activation_required_array ) ) {
				$activation_required = array();
				foreach( $activation_required_array as $key => $value ) {
					$activation_required[] = '<b>' . $value['module_name'] . '</b>';
				}

				$message = sprintf( __( 'You must activate your license for following products: <br>%s', 'cssjockey-add-ons' ), implode( ', ', $activation_required ) );
				$message .= '<br>';
				$message .= sprintf( __( '<a href="%s">Click here</a> to activate.', 'cssjockey-add-ons' ), $this->helpers->callbackUrl( 'config', 'core-welcome', 'cjaddons' ) );
				$this->helpers->adminNotice( 'cjaddons_activation_required', 'error', $message, __( 'Activation Required', 'cssjockey-add-ons' ), false );
			}
		}

	}

	cjaddons_check_upgrades::getInstance();
}