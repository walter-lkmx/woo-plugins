<div class="cssjockey-ui">
	<div id="cjaddons-global-modal" class="cj-modal">
		<div class="cj-modal-background"></div>
		<div class="cj-modal-content cj-width-100 cj-m-20">
			<div class="cj-box cj-p-0" style="overflow-y: scroll;">
				<div class="cj-dynamic-content"></div>
			</div>
		</div>
	</div>
</div>