<?php
global $wp_roles, $wp_registered_sidebars, $wpdb;
$field_html = array();
$text_fields = $this->inputTextFieldTypes();
$select_fields = $this->selectFields();

if( ! isset( $option['options'] ) ) {
	$option['options'] = array();
}
$form_field_id = '';
if( isset( $option['id'] ) ) {
	$form_field_id = $this->cleanString( $option['id'] );
	if( strstr( $option['id'], '~' ) ) {
		$option['id'] = explode( '~', $option['id'] )[1];
	}
}
if( ! isset( $option['params'] ) ) {
	$option['params'] = array();
}
if( isset( $option['params'] ) && ! is_array( $option['params'] ) ) {
	$option['params'] = array();
}
if( ! isset( $option['params']['class'] ) ) {
	$option['params']['class'] = '';
}

if( isset( $option['params']['class'] ) && is_array( $option['params']['class'] ) ) {
	$option['params']['class'] = implode( ' ', $option['params']['class'] );
}

if( in_array( $option['type'], $text_fields ) ) {
	$option['params']['class'] = (isset( $option['params']['class'] ) && $option['params']['class'] !== '') ? $option['params']['class'] . ' cj-input' : 'cj-input';
}
if( in_array( $option['type'], $select_fields ) ) {
	$option['params']['class'] = (isset( $option['params']['class'] ) && $option['params']['class'] !== '') ? $option['params']['class'] . ' selectize' : 'selectize';
}
if( $option['type'] == 'textarea' ) {
	$option['params']['class'] = $option['params']['class'] . ' cj-textarea';
}

$params = '';
if( is_array( $option['params'] ) && ! empty( $option['params'] ) ) {
	foreach( $option['params'] as $attribute => $attr_value ) {
		$class_value = esc_textarea( strip_tags( $attr_value ) );
		$class_value = str_replace( ' ', '-space-', $class_value );
		$class_value = str_replace( array('space-', '-space', '-space-'), ' ', $class_value );
		$class_value = str_replace( array('- ', ' -'), ' ', $class_value );
		$params .= ' ' . $attribute . '="' . trim( $class_value ) . '"';
	}
}

$option['default'] = (isset( $option['default'] ) && $option['default'] != '') ? $option['default'] : '';

if( gettype( $option['default'] ) == 'object' ) {
	$option['default'] = (array) $option['default'];
}

if( in_array( $option['type'], $text_fields ) ) {
	$option['default'] = ( ! is_array( $option['default'] )) ? esc_html( $option['default'] ) : $option['default'];
}

if( $option['type'] == 'admin-heading' ) {
	$heading_text = ($option['default'] != '') ? $option['default'] : $option['label'];
	$field_html[] = '<div class="cj-main-heading">';

	if( isset( $option['search_form'] ) && $option['search_form'] == 1 ) {
		$field_html[] = '<div class="cj-is-pulled-right" style="margin-top: -3px;"><p class="cj-control cj-mb-0 cj-has-icon cj-has-icon-right inline-block"><input type="search" class="cj-quick-search cj-input" style="padding: 2px 15px; width: 200px;" placeholder="' . __( 'Search..', 'cssjockey-add-ons' ) . '"><span class="cj-icon cj-is-small"><i class="cj-mr-10 fa fa-search"></i></span></p></div>';
	}

	$field_html[] = '<h2>' . html_entity_decode( $heading_text ) . '</h2>';
	$field_html[] = '<div class="cj-help">' . $option['info'] . '</div>';
	$field_html[] = '</div>';
}
if( $option['type'] == 'admin-info-full' ) {
	$heading_text = ($option['default'] != '') ? $option['default'] : $option['label'];
	$field_html[] = '<div class="cj-field cj-p-15">';
	if( $option['label'] != '' ) {
		$field_html[] = '<span class="cj-label">' . $option['label'] . '</span>';
	}
	$field_html[] = '<div class="cj-help">' . html_entity_decode( $option['default'] ) . '</div>';
	$field_html[] = '</div>';
}
if( $option['type'] == 'heading' ) {
	$field_html[] = '<h2>' . $option['label'] . '</h2>';
}
if( $option['type'] == 'sub-heading' ) {
	$field_html[] = '<h2>' . $option['label'] . '</h2>';
}
if( $option['type'] == 'info' ) {
	$field_html[] = '<div class="cj-info">' . html_entity_decode( $option['default'] ) . '</div>';
}
if( $option['type'] == 'text' ) {
	$field_html[] = '<input id="' . $form_field_id . '" name="' . $option['id'] . '" type="text" value="' . $option['default'] . '" ' . $params . ' />';
}
if( $option['type'] == 'html' ) {
	$field_html[] = html_entity_decode( html_entity_decode( $option['default'] ) );
}
if( $option['type'] == 'text-readonly' ) {
	$field_html[] = '<input id="' . $form_field_id . '" name="' . $option['id'] . '" type="text" value="' . $option['default'] . '" ' . $params . ' readonly />';
}
if( $option['type'] == 'text-disabled' ) {
	$field_html[] = '<input id="' . $form_field_id . '" name="' . $option['id'] . '" type="text" value="' . $option['default'] . '" ' . $params . ' disabled />';
}
if( $option['type'] == 'number' ) {
	$field_html[] = '<input id="' . $form_field_id . '" name="' . $option['id'] . '" type="number" value="' . $option['default'] . '" ' . $params . ' />';
}
if( $option['type'] == 'email' ) {
	$field_html[] = '<input id="' . $form_field_id . '" name="' . $option['id'] . '" type="email" value="' . $option['default'] . '" ' . $params . ' />';
}
if( $option['type'] == 'url' ) {
	$field_html[] = '<input id="' . $form_field_id . '" name="' . $option['id'] . '" type="url" value="' . $option['default'] . '" ' . $params . ' />';
}
if( $option['type'] == 'password' ) {
	$field_html[] = '<input id="' . $form_field_id . '" name="' . $option['id'] . '" type="password" value="' . $option['default'] . '" ' . $params . ' />';
}
if( $option['type'] == 'date' ) {
	$field_html[] = '<input data-input-type="date" id="' . $form_field_id . '" name="' . $option['id'] . '" type="text" value="' . $option['default'] . '" ' . $params . ' />';
}
if( $option['type'] == 'date-range' ) {
	$from = (isset( $option['default']['from'] )) ? $option['default']['from'] : '';
	$to = (isset( $option['default']['to'] )) ? $option['default']['to'] : '';
	$field_html[] = '<div class="cj-columns cj-is-multiline" style="border-top: 0;">';
	$field_html[] = '<div class="cj-column cj-is-6"><input data-input-type="date-range-from" id="' . $form_field_id . '-from" name="' . $option['id'] . '[from]" type="text" value="' . $from . '" class="cj-input" placeholder="' . __( 'Select Start Date', 'cssjockey-add-ons' ) . '" /></div>';
	$field_html[] = '<div class="cj-column cj-is-6"><input data-input-type="date-range-to" id="' . $form_field_id . '-to" name="' . $option['id'] . '[to]" type="text" value="' . $to . '" class="cj-input" placeholder="' . __( 'Select End Date', 'cssjockey-add-ons' ) . '" /></div>';
	$field_html[] = '</div>';
}
if( $option['type'] == 'date-time' ) {
	$field_html[] = '<input data-input-type="date-time" id="' . $form_field_id . '" name="' . $option['id'] . '" type="text" value="' . $option['default'] . '" ' . $params . ' />';
}
if( $option['type'] == 'time' ) {
	$field_html[] = '<input data-input-type="time" id="' . $form_field_id . '" name="' . $option['id'] . '" type="text" value="' . $option['default'] . '" ' . $params . ' />';
}
if( $option['type'] == 'color' ) {
	$default_value = ($option['default'] != '') ? $option['default'] : __( 'inherit', 'cssjockey-add-ons' );
	$field_html[] = '<input data-input-type="color" id="' . $form_field_id . '" name="' . $option['id'] . '" type="text" value="' . $option['default'] . '" ' . $params . ' /><span style="position: relative; top: 0px; height:30px;" class="cj-button cj-hex-color-container cj-br-0"><span class="cj-hex-color" data-clipboard-text="' . $default_value . '" data-clipboard-confirmation="' . __( 'Copied', 'cssjockey-add-ons' ) . '">' . $default_value . '</span></span>';
}
if( $option['type'] == 'hidden' ) {
	$field_html[] = '<input id="' . $form_field_id . '" name="' . $option['id'] . '" type="hidden" value="' . $option['default'] . '" ' . $params . ' />';
}
if( $option['type'] == 'textarea' ) {
	$field_html[] = '<textarea spellcheck="false" autocapitalize="off" id="' . $form_field_id . '" name="' . $option['id'] . '" ' . $params . '>' . $option['default'] . '</textarea>';
}
if( $option['type'] == 'select' && isset( $option['options'] ) ) {
	if( isset( $option['options'] ) && is_array( $option['options'] ) && ! empty( $option['options'] ) ) {
		$opts = '';
		$opts = '<option value=""></option>';
		foreach( $option['options'] as $opt => $val ) {
			if( $option['default'] != '' && $opt == $option['default'] ) {
				$opts .= '<option selected value="' . $opt . '">' . $val . '</option>';
			} else {
				$opts .= '<option value="' . $opt . '">' . $val . '</option>';
			}
		}
		$use_form_options = (isset( $option['select_options_from'] )) ? 1 : 0;
		$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-load-child-dropdown="' . $use_form_options . '" ' . $params . '>';
		$field_html[] = $opts;
		$field_html[] = '</select>';
	} else {
		if( current_user_can( 'manage_options' ) ) {
			$field_html[] = $this->alert( 'warning', __( 'Options for this field are not specified, please review field settings.', 'cssjockey-add-ons' ) );
		}
	}
}
if( $option['type'] == 'font-family' ) {
	$default_fonts['Arial'] = 'Arial';
	$default_fonts['Helvetica'] = 'Helvetica';
	$default_fonts['Times New Roman'] = 'Times New Roman';
	$default_fonts['Times'] = 'Times';
	$default_fonts['Courier New'] = 'Courier New';
	$default_fonts['Courier'] = 'Courier';
	$default_fonts['Verdana'] = 'Verdana';
	$default_fonts['Georgia'] = 'Georgia';
	$default_fonts['Palatino'] = 'Palatino';
	$default_fonts['Garamond'] = 'Garamond';
	$default_fonts['Bookman'] = 'Bookman';
	$default_fonts['Comic Sans MS'] = 'Comic Sans MS';
	$default_fonts['Trebuchet MS'] = 'Trebuchet MS';
	$default_fonts['Arial Black'] = 'Arial Black';
	$default_fonts['Impact'] = 'Impact';

	$google_fonts = $this->getGoogleFonts();

	if( is_array( $default_fonts ) && is_array( $google_fonts ) ) {
		$option['options'] = array_merge( $default_fonts, $google_fonts );
	}

	$opts = '<option value="inherit">inherit</option>';
	foreach( $option['options'] as $opt => $val ) {
		if( $option['default'] != '' && $opt == $option['default'] ) {
			$opts .= '<option selected value="' . $opt . '">' . $val . '</option>';
		} else {
			$opts .= '<option value="' . $opt . '">' . $val . '</option>';
		}
	}
	$use_form_options = (isset( $option['select_options_from'] )) ? 1 : 0;
	$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-load-child-dropdown="' . $use_form_options . '" data-tags="true" class="selectize">';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'select-raw' && isset( $option['options'] ) ) {
	if( isset( $option['options'] ) && is_array( $option['options'] ) ) {
		$opts = '';
		$opts = '<option value=""></option>';
		foreach( $option['options'] as $opt => $val ) {
			if( $option['default'] != '' && $opt == $option['default'] ) {
				$opts .= '<option selected value="' . $opt . '">' . $val . '</option>';
			} else {
				$opts .= '<option value="' . $opt . '">' . $val . '</option>';
			}
		}
		$use_form_options = (isset( $option['select_options_from'] )) ? 1 : 0;
		$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-load-child-dropdown="' . $use_form_options . '" ' . $params . '>';
		$field_html[] = $opts;
		$field_html[] = '</select>';
	} else {
		if( current_user_can( 'manage_options' ) ) {
			$field_html[] = $this->alert( 'warning', __( 'Options for this field are not specified, please review field settings.', 'cssjockey-add-ons' ) );
		}
	}
}
if( $option['type'] == 'dropdown' ) {
	if( isset( $option['options'] ) && is_array( $option['options'] ) && ! empty( $option['options'] ) ) {
		$opts = '';
		$opts = '<option value=""></option>';
		if( ! empty( $option['options'] ) ) {
			foreach( $option['options'] as $opt => $val ) {
				if( $option['default'] != '' && $opt == $option['default'] ) {
					$opts .= '<option selected value="' . $opt . '">' . $val . '</option>';
				} else {
					$opts .= '<option value="' . $opt . '">' . $val . '</option>';
				}
			}
		}
		$use_form_options = (isset( $option['select_options_from'] )) ? 1 : 0;
		$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-load-child-dropdown="' . $use_form_options . '" data-tags="true" ' . $params . '>';
		$field_html[] = $opts;
		$field_html[] = '</select>';
	} else {
		if( current_user_can( 'manage_options' ) ) {
			$field_html[] = $this->alert( 'warning', __( 'Options for this field are not specified, please review field settings.', 'cssjockey-add-ons' ) );
		}
	}
}
if( $option['type'] == 'multi-dropdown' ) {
	if( isset( $option['options'] ) && is_array( $option['options'] ) && ! empty( $option['options'] ) ) {
		$opts = '';
		$opts = '<option value=""></option>';
		if( ! empty( $option['options'] ) ) {
			foreach( $option['options'] as $opt => $val ) {
				if( $option['default'] != '' && in_array( $opt, $option['default'] ) ) {
					$opts .= '<option selected value="' . $opt . '">' . $val . '</option>';
				} else {
					$opts .= '<option value="' . $opt . '">' . $val . '</option>';
				}
			}
		}
		$use_form_options = (isset( $option['select_options_from'] )) ? 1 : 0;
		$field_html[] = '<select multiple id="' . $form_field_id . '" name="' . $option['id'] . '[]" data-load-child-dropdown="' . $use_form_options . '" data-tags="true" ' . $params . '>';
		$field_html[] = $opts;
		$field_html[] = '</select>';
	} else {
		if( current_user_can( 'manage_options' ) ) {
			$field_html[] = $this->alert( 'warning', __( 'Options for this field are not specified, please review field settings.', 'cssjockey-add-ons' ) );
		}
	}
}
if( $option['type'] == 'checkbox' || $option['type'] == 'checkbox-inline' ) {
	$option['options'] = (isset( $option['select-options-from-raw'] )) ? $option['select-options-from-raw'] : $option['options'];
	if( isset( $option['options'] ) && is_array( $option['options'] ) && ! empty( $option['options'] ) ) {
		$opts = '';
		$inline_class = 'cj-' . $option['type'];
		if( isset( $option['options'] ) && is_array( $option['options'] ) ) {
			foreach( $option['options'] as $opt => $val ) {
				if( is_array( $option['default'] ) && in_array( $opt, $option['default'] ) ) {
					$opts .= '<label class="cj-checkbox ' . $inline_class . '"><input checked name="' . $option['id'] . '[]" type="checkbox" value="' . $opt . '"> &nbsp; <span class="cj-relative" style="top:1px;">' . $val . '</span></label>';
				} else {
					$opts .= '<label class="cj-checkbox ' . $inline_class . '"><input name="' . $option['id'] . '[]" type="checkbox" value="' . $opt . '"> &nbsp; <span class="cj-relative" style="top:1px;">' . $val . '</span></label>';
				}
			}
		}
		$field_html[] = $opts;
	} else {
		if( current_user_can( 'manage_options' ) ) {
			$field_html[] = $this->alert( 'warning', __( 'Options for this field are not specified.', 'cssjockey-add-ons' ) );
		}
	}
}
if( $option['type'] == 'radio' || $option['type'] == 'radio-inline' ) {
	$option['options'] = (isset( $option['select-options-from-raw'] )) ? $option['select-options-from-raw'] : $option['options'];
	if( isset( $option['options'] ) && is_array( $option['options'] ) && ! empty( $option['options'] ) ) {
		$opts = '';
		$inline_class = 'cj-' . $option['type'];
		foreach( $option['options'] as $opt => $val ) {
			if( $option['default'] !== '' && $option['default'] == $opt ) {
				$opts .= '<label class="cj-radio ' . $inline_class . '"><input checked name="' . $option['id'] . '" type="radio" value="' . $opt . '"> &nbsp; <span class="cj-relative" style="top:1px;">' . $val . '</span></label>';
			} else {
				$opts .= '<label class="cj-radio ' . $inline_class . '"><input name="' . $option['id'] . '" type="radio" value="' . $opt . '"> &nbsp; <span class="cj-relative" style="top:1px;">' . $val . '</span></label>';
			}
		}
		$field_html[] = $opts;
	} else {
		if( current_user_can( 'manage_options' ) ) {
			$field_html[] = $this->alert( 'warning', __( 'Options for this field are not specified.', 'cssjockey-add-ons' ) );
		}
	}
}
if( $option['type'] == 'user' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$options = get_users( array('orderby' => 'display_name') );
	foreach( $options as $opt => $val ) {
		if( $val->ID == $option['default'] ) {
			$opts .= '<option selected value="' . $val->ID . '">' . $val->display_name . ' (' . $val->user_email . ')</option>';
		} else {
			$opts .= '<option value="' . $val->ID . '">' . $val->display_name . ' (' . $val->user_email . ')</option>';
		}
	}
	$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'users' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$options = get_users( array('orderby' => 'display_name') );
	foreach( $options as $opt => $val ) {
		if( is_array( $option['default'] ) && in_array( $val->ID, $option['default'] ) ) {
			$opts .= '<option selected value="' . $val->ID . '">' . $val->display_name . ' (' . $val->user_email . ')</option>';
		} else {
			$opts .= '<option value="' . $val->ID . '">' . $val->display_name . ' (' . $val->user_email . ')</option>';
		}
	}
	$field_html[] = '<select multiple id="' . $form_field_id . '" name="' . $option['id'] . '[]" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'role' ) {
	$opts = '';
	$opts = '<option value="default">' . esc_attr__( 'None | Default', 'cssjockey-add-ons' ) . '</option>';
	$options = $wp_roles->role_names;
	foreach( $options as $opt => $val ) {
		if( $opt == $option['default'] ) {
			$opts .= '<option selected value="' . $opt . '">' . $val . '</option>';
		} else {
			$opts .= '<option value="' . $opt . '">' . $val . '</option>';
		}
	}
	$visitor_selected = ($option['default'] == 'visitor') ? 'selected' : '';
	$opts .= '<option ' . $visitor_selected . ' value="visitor">' . esc_attr__( 'Visitor', 'cssjockey-add-ons' ) . '</option>';
	$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'roles' ) {
	$options = $wp_roles->role_names;
	if( is_array( $option['default'] ) && in_array( 'everyone', $option['default'] ) ) {
		$opts = '<option selected value="everyone">' . __( 'All Roles', 'cssjockey-add-ons' ) . '</option>';
	} else {
		$opts = '<option value="everyone">' . __( 'All Roles', 'cssjockey-add-ons' ) . '</option>';
	}

	foreach( $options as $opt => $val ) {
		if( is_array( $option['default'] ) && in_array( $opt, $option['default'] ) ) {
			$opts .= '<option selected value="' . $opt . '">' . $val . '</option>';
		} else {
			$opts .= '<option value="' . $opt . '">' . $val . '</option>';
		}
	}
	$visitor_selected = (is_array( $option['default'] ) && in_array( 'visitor', $option['default'] )) ? 'selected' : '';
	$opts .= '<option ' . $visitor_selected . ' value="visitor">' . esc_attr__( 'Visitor', 'cssjockey-add-ons' ) . '</option>';
	$field_html[] = '<select multiple id="' . $form_field_id . '" name="' . $option['id'] . '[]" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'page' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$options = get_pages( array('sort_column' => 'post_title', 'sort_order' => 'ASC', 'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => '10000') );
	foreach( $options as $opt => $val ) {
		if( $val->ID == $option['default'] ) {
			$opts .= '<option selected value="' . $val->ID . '">' . $val->post_title . '</option>';
		} else {
			$opts .= '<option value="' . $val->ID . '">' . $val->post_title . '</option>';
		}
	}
	$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'pages' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$options = get_pages( array('sort_column' => 'post_title', 'sort_order' => 'ASC', 'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => '10000') );
	foreach( $options as $opt => $val ) {
		if( is_array( $option['default'] ) && in_array( $val->ID, $option['default'] ) ) {
			$opts .= '<option selected value="' . $val->ID . '">' . $val->post_title . '</option>';
		} else {
			$opts .= '<option value="' . $val->ID . '">' . $val->post_title . '</option>';
		}
	}
	$field_html[] = '<select multiple id="' . $form_field_id . '" name="' . $option['id'] . '[]" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'post' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$options = get_posts( array('sort_column' => 'post_title', 'sort_order' => 'ASC', 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => '10000') );
	foreach( $options as $opt => $val ) {
		if( $val->ID == $option['default'] ) {
			$opts .= '<option selected value="' . $val->ID . '">' . $val->post_title . '</option>';
		} else {
			$opts .= '<option value="' . $val->ID . '">' . $val->post_title . '</option>';
		}
	}
	$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'posts' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$options = get_posts( array('sort_column' => 'post_title', 'sort_order' => 'ASC', 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => '10000') );
	foreach( $options as $opt => $val ) {
		if( is_array( $option['default'] ) && in_array( $val->ID, $option['default'] ) ) {
			$opts .= '<option selected value="' . $val->ID . '">' . $val->post_title . '</option>';
		} else {
			$opts .= '<option value="' . $val->ID . '">' . $val->post_title . '</option>';
		}
	}
	$field_html[] = '<select multiple id="' . $form_field_id . '" name="' . $option['id'] . '[]" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'post-type' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$options = get_post_types();
	if( isset( $option['exclude'] ) && is_array( $option['exclude'] ) && ! empty( $option['exclude'] ) ) {
		foreach( $option['exclude'] as $exclude_key => $exclude_value ) {
			unset( $options[ $exclude_value ] );
		}
	}
	foreach( $options as $opt => $val ) {
		if( $opt == $option['default'] ) {
			$opts .= '<option selected value="' . $opt . '">' . $val . '</option>';
		} else {
			$opts .= '<option value="' . $opt . '">' . $val . '</option>';
		}
	}
	$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'post-types' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$options = get_post_types();
	if( isset( $option['exclude'] ) && is_array( $option['exclude'] ) && ! empty( $option['exclude'] ) ) {
		foreach( $option['exclude'] as $exclude_key => $exclude_value ) {
			unset( $options[ $exclude_value ] );
		}
	}
	foreach( $options as $opt => $val ) {
		if( is_array( $option['default'] ) && in_array( $opt, $option['default'] ) ) {
			$opts .= '<option selected value="' . $opt . '">' . $val . '</option>';
		} else {
			$opts .= '<option value="' . $opt . '">' . $val . '</option>';
		}
	}
	$field_html[] = '<select multiple id="' . $form_field_id . '" name="' . $option['id'] . '[]" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'category' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$options = get_categories( array('type' => 'post', 'orderby' => 'name', 'order' => 'ASC', 'hide_empty' => 0, 'taxonomy' => 'category', 'number' => 10000) );
	foreach( $options as $opt => $val ) {
		if( $val->slug == $option['default'] ) {
			$opts .= '<option selected value="' . $val->slug . '">' . $val->name . '</option>';
		} else {
			$opts .= '<option value="' . $val->slug . '">' . $val->name . '</option>';
		}
	}
	$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'categories' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$options = get_categories( array('type' => 'post', 'orderby' => 'name', 'order' => 'ASC', 'hide_empty' => 0, 'taxonomy' => 'category', 'number' => 10000) );
	foreach( $options as $opt => $val ) {
		if( is_array( $option['default'] ) && in_array( $val->slug, $option['default'] ) ) {
			$opts .= '<option selected value="' . $val->slug . '">' . $val->name . '</option>';
		} else {
			$opts .= '<option value="' . $val->slug . '">' . $val->name . '</option>';
		}
	}
	$field_html[] = '<select multiple id="' . $form_field_id . '" name="' . $option['id'] . '[]" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'taxonomy' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$taxonomies = get_taxonomies();
	$exclude_taxonomies = array('category', 'post_tag', 'nav_menu', 'link_category', 'post_format');
	$terms = '';
	$taxonomy_array = array();
	foreach( $taxonomies as $key => $taxonomy ) {
		if( ! in_array( $key, $exclude_taxonomies ) ) {
			$taxonomy_array[] = $key;
		}
	}
	$options = get_terms( $taxonomy_array, array('orderby' => 'name', 'hide_empty' => false) );

	if( is_array( $options ) ) {
		foreach( $options as $opt => $val ) {
			$t_val = $val->slug . '~~~~' . $val->taxonomy;
			if( $t_val == $option['default'] ) {
				$opts .= '<option selected value="' . $t_val . '">' . $val->name . ' (' . $val->taxonomy . ')</option>';
			} else {
				$opts .= '<option value="' . $t_val . '">' . $val->name . ' (' . $val->taxonomy . ')</option>';
			}
		}
	}

	$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'taxonomies' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$taxonomies = get_taxonomies();
	$exclude_taxonomies = array('category', 'post_tag', 'nav_menu', 'link_category', 'post_format');
	$terms = '';
	$taxonomy_array = array();
	foreach( $taxonomies as $key => $taxonomy ) {
		if( ! in_array( $key, $exclude_taxonomies ) ) {
			$taxonomy_array[] = $key;
		}
	}
	$options = get_terms( $taxonomy_array, array('orderby' => 'name', 'hide_empty' => false) );

	if( is_array( $options ) ) {
		foreach( $options as $opt => $val ) {
			$t_val = $val->slug . '~~~~' . $val->taxonomy;
			if( in_array( $t_val, $option['default'] ) ) {
				$opts .= '<option selected value="' . $t_val . '">' . $val->name . ' (' . $val->taxonomy . ')</option>';
			} else {
				$opts .= '<option value="' . $t_val . '">' . $val->name . ' (' . $val->taxonomy . ')</option>';
			}
		}
	}
	$field_html[] = '<select multiple id="' . $form_field_id . '" name="' . $option['id'] . '[]" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'taxonomy-terms' || $option['type'] == 'taxonomy_terms' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$taxonomies = get_taxonomies();
	$exclude_taxonomies = array('nav_menu', 'link_category', 'post_format');
	$get_terms_params = array('orderby' => 'name', 'hide_empty' => false);
	if( isset( $option['get_terms_params'] ) && is_array( $option['get_terms_params'] ) && ! empty( $option['get_terms_params'] ) ) {
		foreach( $option['get_terms_params'] as $p_key => $p_value ) {
			$get_terms_params[ $p_key ] = $p_value;
		}
	}
	$terms = '';
	$taxonomy_array = array();
	foreach( $taxonomies as $tax_key => $taxonomy ) {
		if( ! in_array( $tax_key, $exclude_taxonomies ) ) {
			$taxonomy_array[] = $tax_key;
		}
	}
	$term_opts = get_terms( $taxonomy_array, $get_terms_params );

	if( is_array( $term_opts ) ) {
		foreach( $term_opts as $opt => $val ) {
			$t_val = $val->slug . '@' . $val->taxonomy;
			if( $t_val == $option['default'] ) {
				$opts .= '<option selected value="' . $t_val . '">' . $val->name . ' (' . $val->taxonomy . ')</option>';
			} else {
				$opts .= '<option value="' . $t_val . '">' . $val->name . ' (' . $val->taxonomy . ')</option>';
			}
		}
	}

	$field_html[] = '<div class="form-taxonomy">';
	$field_html[] = '<div class="cj-form-field">';
	$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
	$field_html[] = '</div>';
	$field_html[] = '</div>';
}
if( $option['type'] == 'tag' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$options = get_tags();
	foreach( $options as $opt => $val ) {
		if( $val->slug == $option['default'] ) {
			$opts .= '<option selected value="' . $val->slug . '">' . $val->name . '</option>';
		} else {
			$opts .= '<option value="' . $val->slug . '">' . $val->name . '</option>';
		}
	}

	$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'tags' ) {
	$opts = '';
	$opts = '<option value=""></option>';
	$options = get_tags();
	foreach( $options as $opt => $val ) {
		if( is_array( $option['default'] ) && in_array( $val->slug, $option['default'] ) ) {
			$opts .= '<option selected value="' . $val->slug . '">' . $val->name . '</option>';
		} else {
			$opts .= '<option value="' . $val->slug . '">' . $val->name . '</option>';
		}
	}
	$field_html[] = '<select  id="' . $form_field_id . '" name="' . $option['id'] . '" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'code-css' ) {
	$field_html[] = '<textarea data-code="code-css" id="' . $form_field_id . '" name="' . $option['id'] . '" ' . $params . '>' . $option['default'] . '</textarea>';
}
if( $option['type'] == 'code-html' ) {
	$field_html[] = '<textarea data-code="code-html" id="' . $form_field_id . '" name="' . $option['id'] . '" ' . $params . '>' . html_entity_decode( $option['default'] ) . '</textarea>';
}
if( $option['type'] == 'code-js' ) {
	$field_html[] = '<textarea data-code="code-js" id="' . $form_field_id . '" name="' . $option['id'] . '" ' . $params . '>' . $option['default'] . '</textarea>';
}
if( $option['type'] == 'wysiwyg' ) {
	$editor_id = $form_field_id;
	$editor_settings = array(
		'wpautop' => false,
		'media_buttons' => true,
		'textarea_name' => $option['id'],
		'textarea_rows' => 7,
		'teeny' => false,
	);
	if( isset( $option['editor_settings'] ) && is_array( $option['editor_settings'] ) ) {
		foreach( $option['editor_settings'] as $e_key => $e_value ) {
			$editor_settings[ $e_key ] = $e_value;
		}
	}
	ob_start();
	$content = html_entity_decode( $option['default'] );
	wp_editor( $content, $editor_id, $editor_settings );
	$editor_panel = ob_get_clean();
	$field_html[] = '<div id="wysiwyg-' . $form_field_id . '" class="cj-wysiwyg">' . $editor_panel . '</div>';
}
if( $option['type'] == 'wysiwyg-tiny' ) {
	$editor_id = str_replace( '-', '', str_replace( '_', '', strtolower( $option['id'] ) ) );
	$editor_settings = array(
		'wpautop' => false,
		'media_buttons' => true,
		'textarea_name' => $option['id'],
		'textarea_rows' => 7,
		'teeny' => true,
	);
	if( isset( $option['editor_settings'] ) && is_array( $option['editor_settings'] ) ) {
		foreach( $option['editor_settings'] as $e_key => $e_value ) {
			$editor_settings[ $e_key ] = $e_value;
		}
	}
	ob_start();
	$content = html_entity_decode( $option['default'] );
	wp_editor( $content, $editor_id, $editor_settings );
	$editor_panel = ob_get_clean();
	$field_html[] = '<div class="cj-wysiwyg">' . $editor_panel . '</div>';
}
if( $option['type'] == 'file' || $option['type'] == 'files' ) {
	$multiple_files = (isset( $option['type'] ) && $option['type'] == 'files') ? true : false;
	$multiple = ($multiple_files) ? true : false;
	$button_text = (isset( $option['type'] ) && $option['type'] == 'files') ? __( 'Select Files', 'cssjockey-add-ons' ) : __( 'Select File', 'cssjockey-add-ons' );
	$field_html[] = '<div class="cj-form-file">';
	$field_html[] = '<div class="cj-form-field ">';
	$field_html[] = '<label data-multiple="' . $multiple_files . '" for="' . $option['id'] . '" data-selector-id="' . sanitize_title( $option['id'] ) . '" class="cj-upload-files">';
	$field_html[] = '<span class="cj-button"><span class="cj-icon cj-is-small cj-mr-10"><i class="fa fa-file"></i></span>' . __( 'Select File', 'cssjockey-add-ons' ) . '</span>';
	//$field_html[] = '<input type="file" name="' . $option['id'] . '" value="" ' . $multiple . ' class="opacity-0" >';
	$field_html[] = '</label>';
	$field_html[] = '</div>';

	$field_html[] = '<div class="uploaded-file">';
	$field_html[] = '<ul id="filelist-' . sanitize_title( $option['id'] ) . '" data-id="' . $form_field_id . '" class="cj-file-list">';
	if( $option['type'] == 'files' && is_array( $option['default'] ) ) {
		foreach( $option['default'] as $i_key => $img_url ) {
			if( $img_url != '' ) {
				$field_html[] = '<li>
						<div class="cj-image-object cj-cover" style="background-image: url(' . $img_url . ')"></div>
                        <input type="hidden" name="' . $option['id'] . '[]" value="' . $img_url . '">
                        <a class="cj-remove-file cj-delete cj-is-small" href="#"></a>
                        <div class="cj-overlay cj-opacity-90"></div>
                        </li>';
			}
		}
	}
	if( $option['type'] == 'file' ) {
		$img_url = $option['default'];
		if( $img_url != '' && ! is_array( $img_url ) ) {
			$field_html[] = '<li>
						<div class="cj-image-object cj-cover" style="background-image: url(' . $img_url . ')"></div>
                        <input type="hidden" name="' . $option['id'] . '" value="' . $img_url . '">
                        <a class="cj-remove-file cj-delete cj-is-small" href="#"></a><div class="cj-overlay cj-opacity-90"></div>
                        </li>';
		}
	}
	$field_html[] = '</ul>';

	$field_html[] = '</div>';
	$field_html[] = '</div>';
}
if( $option['type'] == 'dropzone' ) {
	$field_html[] = '<div class="cj-dropzone" id="dropzone-' . $form_field_id . '">';
	$field_html[] = 'click here to upload';
	$field_html[] = '</div>';
}
if( $option['type'] == 'user_avatar' ) {
	$option['default'] = ($option['default'] == '') ? $this->default_avatar_url : $option['default'];
	$option['default_avatar_url'] = $this->default_avatar_url;
	$option['upload_button_text'] = __( 'Upload image', 'cssjockey-add-ons' );
	$unique_string = $this->uniqueString();
	$field_html[] = '<div id="cj-user-avatar-form-field-' . $unique_string . '" v-cloak class="cj-user-avatar-form-field"><vue-user-avatar is_user_logged_in="' . is_user_logged_in() . '" option_data=\'[' . json_encode( $option ) . ']\'></vue-user-avatar></div>';
}
if( $option['type'] == 'vue-file-upload' ) {
	$option['upload_button_text'] = __( 'Select File(s)', 'cssjockey-add-ons' );
	$field_html[] = '<div v-cloak class="file-upload vue-file-upload"><vue-file-upload is_user_logged_in="' . is_user_logged_in() . '" option_data=\'[' . json_encode( $option ) . ']\'></vue-file-upload></div>';
}
if( $option['type'] == 'file-raw' ) {
	$field_html[] = '<div class="cj-form-file-raw">';
	$field_html[] = '<div class="cj-form-field">';
	$field_html[] = '<label for="' . $form_field_id . '">';
	$field_html[] = '<span class="cj-button"><span class="cj-icon cj-is-small cj-mr-10"><i class="fa fa-file"></i></span>' . __( 'Select File', 'cssjockey-add-ons' ) . '</span>';
	$field_html[] = '<input id="' . $form_field_id . '" name="' . $option['id'] . '" type="file" value="' . $option['default'] . '" ' . $params . ' style="display:none;" />';
	$field_html[] = '</label> <div class="cj-inline-block cj-ml-10 cj-pt-10 cj-selected-filename"></div>';
	$field_html[] = '</div>';
	$field_html[] = '</div>';
}
if( $option['type'] == 'sortable' ) {
	$sortables = '';
	if( is_array( $option['default'] ) ) {
		foreach( $option['default'] as $key => $value ) {
			$sortables .= '<li>';
			$sortables .= '<span class="text-bold">' . $value . '</span>';
			$sortables .= '<i class="fa fa-sort cj-is-pulled-right opacity-50"></i>';
			$sortables .= '<input id="' . $form_field_id . '" name="' . $option['id'] . '[' . $key . ']" type="hidden" value="' . $option['default'][ $key ] . '" />';
			$sortables .= '</li>';
		}
	}

	$field_html[] = '<ul class="cj-sortable">';
	$field_html[] = $sortables;
	$field_html[] = '</ul>';
}
if( $option['type'] == 'repeatable' ) {
	$field_html[] = '<div class="cj-form-repeatable">';
	$field_html[] = '<div class="cj-form-field cj-repeatable">';
	$default_options = (is_array( $option['default'] )) ? $option['default'] : array(__( 'Some value', 'cssjockey-add-ons' ));
	if( is_array( $default_options ) ) {
		$field_html[] = '<div id="' . $form_field_id . '-options" class="cj-sortable">';
		foreach( $default_options as $o_key => $o_value ) {
			$o_value = esc_textarea( $o_value );
			$default_placeholder = (isset( $option['default_placeholders'] ) && isset( $option['default_placeholders'][ $o_key ] )) ? $option['default_placeholders'][ $o_key ] : '';
			$field_html[] = '<div class="cj-repeatable-field">';
			$field_html[] = '<input id="' . $form_field_id . '" name="' . $option['id'] . '[' . $o_key . ']" type="text" value="' . $o_value . '" placeholder="' . $default_placeholder . '" class="" />';
			$field_html[] = '<span class="cj-input-group-addon cj-pointer" data-option-id="' . $form_field_id . '">';
			if( ! isset( $option['disable_new'] ) ) {
				$field_html[] = '<span class="cj-remove-repeatable-option" data-msg-not-allowed="' . __( 'Not Allowed!', 'cssjockey-add-ons' ) . '"><i class="fa fa-minus cj-color-danger"></i></span>';
			}
			$field_html[] = '</span>';
			$field_html[] = '</div>';
		}
		$field_html[] = '</div>';
	}
	$field_html[] = '</div>';
	$field_html[] = '</div>';
	if( ! isset( $option['disable_new'] ) ) {
		$field_html[] = '<a class="cj-button cj-is-success cj-mt-10 cj-mb-10 cj-add-repeatable" data-id="' . $option['id'] . '"><i class="fa fa-plus"></i></a>';
	}
}
if( $option['type'] == 'css-styles' ) {
	ob_start();
	require 'parts/admin-form-css-styles.php';
	$field_html[] = ob_get_clean();
}
if( $option['type'] == 'css-shorthand' ) {
	$field_html[] = '<div class="cj-columns cj-is-gapless">';
	$field_html[] = '<div class="cj-column"><p class="cj-control cj-mr-5"><label class="fs-12 pt-0">' . __( 'Top', 'cssjockey-add-ons' ) . '</label><input style="min-width: 100px; " type="text" name="' . $option['id'] . '[top]" class="cj-input cj-is-small" placeholder="' . $option['params']['placeholder'] . '" /></p></div>';
	$field_html[] = '<div class="cj-column"><p class="cj-control cj-mr-5"><label class="fs-12 pt-0">' . __( 'Right', 'cssjockey-add-ons' ) . '</label><input style="min-width: 100px; " type="text" name="' . $option['id'] . '[right]" class="cj-input cj-is-small" placeholder="' . $option['params']['placeholder'] . '" /></p></div>';
	$field_html[] = '<div class="cj-column"><p class="cj-control cj-mr-5"><label class="fs-12 pt-0">' . __( 'Left', 'cssjockey-add-ons' ) . '</label><input style="min-width: 100px; " type="text" name="' . $option['id'] . '[left]" class="cj-input cj-is-small" placeholder="' . $option['params']['placeholder'] . '" /></p></div>';
	$field_html[] = '<div class="cj-column"><p class="cj-control cj-mr-5"><label class="fs-12 pt-0">' . __( 'Bottom', 'cssjockey-add-ons' ) . '</label><input style="min-width: 100px; " type="text" name="' . $option['id'] . '[bottom]" class="cj-input cj-is-small" placeholder="' . $option['params']['placeholder'] . '" /></p></div>';
	$field_html[] = '</div>';
}

if( $option['type'] == 'google_recaptcha' || $option['type'] == 'google-recaptcha' ) {
	$recaptcha = $this->reCaptcha();
	if( $recaptcha ) {
		$field_html[] = $recaptcha->getHtml();
	}
}

if( $option['type'] == 'min-max' ) {
	$min_value = (isset( $option['default']['min'] )) ? stripcslashes( htmlentities( $option['default']['min'] ) ) : '';
	$max_value = (isset( $option['default']['max'] )) ? stripcslashes( htmlentities( $option['default']['max'] ) ) : '';
	// params
	$min_params = '';
	$max_params = '';
	if( ! isset( $option['min_params'] ) || empty( $option['min_params'] ) ) {
		$option['min_params']['placeholder'] = __( 'Min', 'cssjockey-add-ons' );
	}
	if( ! isset( $option['max_params'] ) || empty( $option['max_params'] ) ) {
		$option['max_params']['placeholder'] = __( 'Max', 'cssjockey-add-ons' );
	}
	if( isset( $option['min_params'] ) && is_array( $option['min_params'] ) && ! empty( $option['min_params'] ) ) {
		foreach( $option['min_params'] as $attribute => $param_value ) {
			$min_params .= $attribute . '="' . $param_value . '" ';
		}
	}
	if( isset( $option['max_params'] ) && is_array( $option['max_params'] ) && ! empty( $option['max_params'] ) ) {
		foreach( $option['max_params'] as $attribute => $param_value ) {
			$max_params .= $attribute . '="' . $param_value . '" ';
		}
	}

	$min_container_class = 'cj-one_half';
	$max_container_class = 'cj-one_half cj-last';
	$required = (isset( $option['validation_rules'] ) && $option['validation_rules']['required'] == 'yes') ? 'required' : '';
	// options
	$opts = '';
	$options['options'] = array_filter( $option['options'] );
	if( is_array( $option['options'] ) && ! empty( $options['options'] ) ) {
		$min_container_class = 'cj-one_third';
		$max_container_class = 'cj-one_third';
		$opts .= '<p class="cj-control cj-mb-0">';
		$opts .= '<select name="' . $option['id'] . '[type]" class="selectize" ' . $required . ' >';
		foreach( $option['options'] as $o_key => $o_value ) {
			if( isset( $option['default']['type'] ) && $option['default']['type'] == $o_key ) {
				$opts .= '<option selected value="' . $o_key . '">' . $o_value . '</option>';
			} else {
				$opts .= '<option value="' . $o_key . '">' . $o_value . '</option>';
			}
		}
		$opts .= '</select>';
		$opts .= '</p>';
	}

	$field_html[] = '<div class="cj-clearfix">';
	$field_html[] = '<div class="cj-one_third cj-mb-0"><p class="cj-control cj-mb-0"><input id="' . $form_field_id . '" name="' . $option['id'] . '[min]" type="text" value="' . $min_value . '" ' . $min_params . ' class="cj-input" ' . $required . ' /></p></div>';
	$field_html[] = '<div class="cj-one_third cj-mb-0"><p class="cj-control cj-mb-0"><input id="' . $form_field_id . '" name="' . $option['id'] . '[max]" type="text" value="' . $max_value . '" ' . $max_params . ' class="cj-input" ' . $required . ' /></p></div>';
	$field_html[] = '<div class="cj-one_third cj-mb-0 cj-last">' . $opts . '</div>';
	$field_html[] = '</div>';
}

if( $option['type'] == 'google-address' ) {
	$filter = (isset( $option['filter'] )) ? $option['filter'] : '';
	$field_html[] = '<div class="cj-google-addresses-autocomplete" data-filter="' . $filter . '">';
	$field_html[] = '<input id="' . $form_field_id . '" name="' . $option['id'] . '" ' . $params . ' type="text" value="' . $option['default'] . '" />';
	$field_html[] = '</div>';
	$maps_key = $this->savedOption( 'core_google_maps_key' );
	if( $maps_key == '' && current_user_can( 'manage_options' ) ) {
		$field_html[] = '<div class="cj-notification cj-is-warning cj-mt-10 cj-mb-0">';
		$field_html[] = __( 'Google maps API key is not specified in Global Settings page.', 'cssjockey-add-ons' );
		$field_html[] = '</div>';
	}
}

if( $option['type'] == 'auto-complete' ) {

	$settings_array = array(
		'url' => admin_url( 'admin-ajax.php' ) . '?action=<span class="cj-color-danger">REGISTERED_ACTION</span>',
		'post_data' => array(
			'search' => '*<span class="cj-color-danger">input_query</span>*',
		),
		'key_field' => 'key_field',
		'value_field' => 'value_field',
		'search_field' => 'search_field',
	);

	if( ! isset( $option['settings'] ) ) {
		echo '<div class="cj-notification cj-is-danger">' . __( 'Settings for this field is not defined.', 'cssjockey-add-ons' ) . '</div>';
		echo '<pre class="cj-mb-20">';
		print_r( $settings_array );
		echo '</pre>';
	}

	$url = (isset( $option['settings'] ) && isset( $option['settings']['url'] )) ? $option['settings']['url'] : '';
	$post_data = (isset( $option['settings'] ) && isset( $option['settings']['post_data'] )) ? json_encode( $option['settings']['post_data'] ) : '';
	$key_field = (isset( $option['settings'] ) && isset( $option['settings']['key_field'] )) ? $option['settings']['key_field'] : '';
	$value_field = (isset( $option['settings'] ) && isset( $option['settings']['value_field'] )) ? $option['settings']['value_field'] : '';
	$search_field = (isset( $option['settings'] ) && isset( $option['settings']['search_field'] )) ? $option['settings']['search_field'] : '';
	$field_html[] = '<div class="cjaddons-auto-complete" data-url="' . $url . '" data-post-data=\'' . $post_data . '\' data-key-field="' . $key_field . '" data-value-field="' . $value_field . '" data-search-field="' . $search_field . '">';
	$field_html[] = '<input id="' . $form_field_id . '" name="' . $option['id'] . '" type="text" value="' . $option['default'] . '" autocomplete="off" />';
	$field_html[] = '</div>';
}

if( $option['type'] == 'group' && is_array( $option['items'] ) ) {
	$opts = '';
	if( ! isset( $option['options_disable_blank'] ) ) {
		$opts = '<option value=""></option>';
	}
	foreach( $option['options'] as $opt => $val ) {
		if( $option['default'] != '' && $opt == $option['default'] ) {
			$opts .= '<option selected value="' . $opt . '">' . $val . '</option>';
		} else {
			$opts .= '<option value="' . $opt . '">' . $val . '</option>';
		}
	}

	$field_html[] = '<div class="cj-form-dropdown">';
	$field_html[] = '<div class="cj-form-field cj-has-group-items" data-group-name=' . $option['group'] . '>';
	$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '[selected_value]" data-tags="true" class="selectize">';
	$field_html[] = $opts;
	$field_html[] = '</select>';
	$field_html[] = '<div class="cj-help">' . $option['info'] . '</div>';
	$field_html[] = '</div>';
	$field_html[] = '</div>';

	$group_options = $this->compileGroupItems( $option );

	if( ! empty( $group_options ) ) {
		$field_html[] = '<div class="group-fields">';
		foreach( $group_options as $g_key => $g_option ) {
			$field_html[] = '<div class="cj-field ' . $g_option['container_class'] . '">';
			$field_html[] = '<label class="cj-label">' . $g_option['label'] . '</label>';
			$field_html[] = '<p class="cj-control">';
			$field_html[] = $this->formField( $g_option );
			$field_html[] = '</p>';
			if( isset( $g_option['info'] ) ) {
				$field_html[] = '<div class="cj-help">' . $g_option['info'] . '</div>';
			}
			$field_html[] = '</div>';
		}
		$field_html[] = '</div>';
	}
}
if( $option['type'] == 'button-with-icon' ) {

	if( ! is_array( $option['default'] ) ) {
		$option['default'] = array();
	}
	$option['default']['text'] = (isset( $option['default']['text'] )) ? $option['default']['text'] : '';
	$option['default']['icon'] = (isset( $option['default']['icon'] )) ? $option['default']['icon'] : '';
	$option['default']['align'] = (isset( $option['default']['align'] )) ? $option['default']['align'] : '';
	$option['params']['placeholder'] = (isset( $option['params']['placeholder'] )) ? $option['params']['placeholder'] : '';

	$custom_url = (isset($option['default']['custom_url'])) ? $option['default']['custom_url'] : '';

	$fa_array = $this->fontAwesomeIconsArray();
	$pe_icons_array = $this->arrays( 'social-icons' );
	$icons_array = array_merge( $pe_icons_array, $fa_array );

	$icons = '<option value="">' . __( 'Select Icon', 'cssjockey-add-ons' ) . '</option>';
	foreach( $icons_array as $o_key => $o_value ) {
		if( $o_key == $option['default']['icon'] ) {
			$icons .= '<option selected value="' . $o_key . '">' . $o_value . '</option>';
		} else {
			$icons .= '<option value="' . $o_key . '">' . $o_value . '</option>';
		}
	}

	$align_array = array(
		'left' => __( 'Left', 'cssjockey-add-ons' ),
		'right' => __( 'Right', 'cssjockey-add-ons' ),
	);
	$icon_alignment = '<option value="">' . __( 'Align', 'cssjockey-add-ons' ) . '</option>';
	foreach( $align_array as $a_key => $a_value ) {
		if( $a_key == $option['default']['align'] ) {
			$icon_alignment .= '<option selected value="' . $a_key . '">' . $a_value . '</option>';
		} else {
			$icon_alignment .= '<option value="' . $a_key . '">' . $a_value . '</option>';
		}
	}

	$button_class_array = array(
		'cj-is-small' => __( 'Small', 'cssjockey-add-ons' ),
		'cj-is-medium' => __( 'Medium', 'cssjockey-add-ons' ),
		'cj-is-large' => __( 'Large', 'cssjockey-add-ons' ),
	);
	$button_class = '<option value="">' . __( 'Button size', 'cssjockey-add-ons' ) . '</option>';
	foreach( $button_class_array as $c_key => $c_value ) {
		if( isset( $option['default']['size'] ) && $c_key == $option['default']['size'] ) {
			$button_class .= '<option selected value="' . $c_key . '">' . $c_value . '</option>';
		} else {
			$button_class .= '<option value="' . $c_key . '">' . $c_value . '</option>';
		}
	}

	$field_html[] = <<<EOD
	<div class="cj-clearfix">
	<div class="cj-one_fourth cj-mb-0 cj-field">
	<label class="cj-label">Button Text</label>
	<p class="cj-control cj-mb-0 cj-is-expanded">
    	<input name="{$option['id']}[text]" class="cj-input" type="text" value="{$option['default']['text']}" placeholder="{$option['params']['placeholder']}">
  	</p>
	</div>
  	<div class="cj-one_fourth cj-mb-0 cj-field">
  	<label class="cj-label">Select an icon</label>
  	<p class="cj-control cj-mb-0">
    	<select class="selectize" name="{$option['id']}[icon]" style="width: 100%">
            {$icons}
        </select>
  	</p>
  	</div>
  	<div class="cj-one_fourth cj-mb-0 cj-field">
  	<label class="cj-label">Align icon to</label>
  	<p class="cj-control cj-mb-0">
    	<select class="selectize" name="{$option['id']}[align]">
            {$icon_alignment}
        </select>
  	</p>
	</div>
	<div class="cj-one_fourth cj-mb-0 cj-last cj-field">
  	<label class="cj-label">Button size</label>
  	<p class="cj-control cj-mb-0">
    	<select class="selectize" name="{$option['id']}[size]">
            {$button_class}
        </select>
  	</p>
	</div>
</div>
<div class="cj-mt-10">
	<input name="{$option['id']}[custom_url]" value="{$custom_url}" type="text" placeholder="or specify custom button image url." class="cj-input" />
</div>
EOD;
}
if( $option['type'] == 'screenshot' ) {
	$screenshots = $option['options'];
	if( is_array( $screenshots ) && ! empty( $screenshots ) ) {
		$field_html[] = '<div class="cj-columns cj-is-multiline cj-is-mobile" style="border:none">';
		foreach( $screenshots as $s_key => $screenshot_url ) {
			$checked = ($option['default'] == $s_key) ? 'checked' : '';
			$active_class = ($option['default'] == $s_key) ? 'cj-is-active' : '';
			$field_html[] = '<div class="cj-column cj-exclude-full cj-is-4-widescreen cj-is-4-desktop cj-is-6-tablet cj-is-6-mobile cj-pt-15 cj-pb-0">';
			$field_html[] = '<label class="' . $active_class . '">';
			$field_html[] = '<input type="radio" name="' . $option['id'] . '" value="' . $s_key . '" ' . $checked . '>';
			$field_html[] = '<img src="' . $screenshot_url . '" />';
			$field_html[] = '</label>';
			$field_html[] = '</div>';
		}
		$field_html[] = '</div><!-- cj-columns -->';
	}
}
if( $option['type'] == 'font-styles' ) {
	ob_start();
	include 'admin-form-font-styles.php';
	$field_html[] = ob_get_clean();
}
if( $option['type'] == 'gradient' ) {
	$color_1 = (isset( $option['default']['color-1'] )) ? $option['default']['color-1'] : '#139cec';
	$color_2 = (isset( $option['default']['color-2'] )) ? $option['default']['color-2'] : '#c3325f';
	$angle = (isset( $option['default']['angle'] )) ? $option['default']['angle'] : '45deg';
	$field_html[] = '<div class="cj-clearfix">';
	$field_html[] = '<div class="cj-mb-5">';
	$field_html[] = '<input data-input-type="color" id="' . $form_field_id . '" name="' . $option['id'] . '[color-1]" type="text" value="' . $color_1 . '"  /> &nbsp;';
	$field_html[] = '<input data-input-type="color" id="' . $form_field_id . '" name="' . $option['id'] . '[color-2]" type="text" value="' . $color_2 . '"  /> &nbsp;';
	$field_html[] = '<input id="' . $form_field_id . '" name="' . $option['id'] . '[angle]" type="text" value="' . $angle . '" placeholder="' . __( 'Angle e.g. 90deg or -45deg', 'cssjockey-add-ons' ) . '" class="cj-input cj-mb-0" style="width: 100px; height:30px;" /> &nbsp;';
	$field_html[] = '</div>';
	$field_html[] = '<div class="">';

	$field_html[] = '</div>';
	$field_html[] = '</div>';
}
if( $option['type'] == 'nav_menu' || $option['type'] == 'nav-menu' ) {

	$nav_menus = get_terms( array(
		'taxonomy' => 'nav_menu',
		'hide_empty' => false,
	) );
	$option['options'] = array();
	if( ! empty( $nav_menus ) ) {
		foreach( $nav_menus as $menu => $menu_term ) {
			$option['options'][ $menu_term->slug ] = $menu_term->name;
		}
	}
	$opts = '';
	$opts = '<option value=""></option>';
	if( ! empty( $option['options'] ) ) {
		foreach( $option['options'] as $opt => $val ) {
			if( $option['default'] != '' && $opt == $option['default'] ) {
				$opts .= '<option selected value="' . $opt . '">' . $val . '</option>';
			} else {
				$opts .= '<option value="' . $opt . '">' . $val . '</option>';
			}
		}
	}
	$use_form_options = (isset( $option['select_options_from'] )) ? 1 : 0;
	$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-load-child-dropdown="' . $use_form_options . '" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}
if( $option['type'] == 'sidebar' ) {
	$sidebars = $wp_registered_sidebars;
	$option['options'] = array();
	if( ! empty( $sidebars ) ) {
		foreach( $sidebars as $sidebar_id => $sidebar ) {
			$option['options'][ $sidebar_id ] = $sidebar['name'];
		}
	}
	$opts = '';
	$opts = '<option value=""></option>';
	if( ! empty( $option['options'] ) ) {
		foreach( $option['options'] as $opt => $val ) {
			if( $option['default'] != '' && $opt == $option['default'] ) {
				$opts .= '<option selected value="' . $opt . '">' . $val . '</option>';
			} else {
				$opts .= '<option value="' . $opt . '">' . $val . '</option>';
			}
		}
	}
	$use_form_options = (isset( $option['select_options_from'] )) ? 1 : 0;
	$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-load-child-dropdown="' . $use_form_options . '" data-tags="true" ' . $params . '>';
	$field_html[] = $opts;
	$field_html[] = '</select>';
}

if( $option['type'] == 'user-meta-key-value' ) {
	$user_meta_keys_array = $wpdb->get_results( "SELECT distinct meta_key FROM $wpdb->usermeta" );
	$meta_keys_array = array();
	foreach( $user_meta_keys_array as $key => $value ) {
		$meta_keys_array[ $value->meta_key ] = $value->meta_key;
	}

	$meta_keys_field = array(
		'id' => $option['id'] . '[meta_key]',
		'type' => 'dropdown',
		'label' => '',
		'params' => array(
			'placeholder' => __( 'Select meta key', 'cssjockey-add-ons' ),
			'class' => 'selectize',
		),
		'default' => (isset( $option['default']['meta_key'] )) ? $option['default']['meta_key'] : '',
		'options' => $meta_keys_array,
	);
	$meta_value_field = array(
		'id' => $option['id'] . '[meta_value]',
		'type' => 'text',
		'label' => '',
		'params' => array(
			'placeholder' => __( 'Specify meta value', 'cssjockey-add-ons' )
		),
		'default' => (isset( $option['default']['meta_value'] )) ? $option['default']['meta_value'] : '',
		'options' => '',
	);

	$field_html[] = '<div class="meta-key-dropdown mb-10">';
	$field_html[] = $this->formField( $meta_keys_field );
	$field_html[] = '</div>';
	$field_html[] = '<div class="meta-value-textbox">';
	$field_html[] = $this->formField( $meta_value_field );
	$field_html[] = '</div>';
}

if( $option['type'] == 'post-meta-key-value' ) {
	$post_meta_keys_array = $wpdb->get_results( "SELECT distinct meta_key FROM $wpdb->postmeta" );
	$meta_keys_array = array();
	foreach( $post_meta_keys_array as $key => $value ) {
		$meta_keys_array[ $value->meta_key ] = $value->meta_key;
	}
	$meta_keys_field = array(
		'id' => $option['id'] . '[meta_key]',
		'type' => 'dropdown',
		'label' => '',
		'params' => array(
			'placeholder' => __( 'Select meta key', 'cssjockey-add-ons' ),
			'class' => 'selectize',
		),
		'default' => (isset( $option['default']['meta_key'] )) ? $option['default']['meta_key'] : '',
		'options' => $meta_keys_array,
	);
	$meta_value_field = array(
		'id' => $option['id'] . '[meta_value]',
		'type' => 'text',
		'label' => '',
		'params' => array(
			'placeholder' => __( 'Specify meta value', 'cssjockey-add-ons' )
		),
		'default' => (isset( $option['default']['meta_value'] )) ? $option['default']['meta_value'] : '',
		'options' => '',
	);

	$field_html[] = '<div class="meta-key-dropdown mb-10">';
	$field_html[] = $this->formField( $meta_keys_field );
	$field_html[] = '</div>';
	$field_html[] = '<div class="meta-value-textbox">';
	$field_html[] = $this->formField( $meta_value_field );
	$field_html[] = '</div>';
}

if( $option['type'] == 'spacing' ) {
	$top = (isset( $option['default']['top'] )) ? $option['default']['top'] : '';
	$right = (isset( $option['default']['right'] )) ? $option['default']['right'] : '';
	$bottom = (isset( $option['default']['bottom'] )) ? $option['default']['bottom'] : '';
	$left = (isset( $option['default']['left'] )) ? $option['default']['left'] : '';

	$field_html[] = '<div class="cj-field cj-is-grouped">';
	$field_html[] = '<p class="cj-control"><input name="' . $option['id'] . '[top]" value="' . $top . '" type="text" class="cj-input" placeholder="' . __( 'Top e.g. 20px', 'cssjockey-add-ons' ) . '" /></p>';
	$field_html[] = '<p class="cj-control"><input name="' . $option['id'] . '[right]" value="' . $right . '" type="text" class="cj-input" placeholder="' . __( 'Right e.g. 20px', 'cssjockey-add-ons' ) . '" /></p>';
	$field_html[] = '<p class="cj-control"><input name="' . $option['id'] . '[bottom]" value="' . $bottom . '" type="text" class="cj-input" placeholder="' . __( 'Bottom e.g. 20px', 'cssjockey-add-ons' ) . '" /></p>';
	$field_html[] = '<p class="cj-control"><input name="' . $option['id'] . '[left]" value="' . $left . '" type="text" class="cj-input" placeholder="' . __( 'Left e.g. 20px', 'cssjockey-add-ons' ) . '" /></p>';
	$field_html[] = '</div>';
}

if( $option['type'] == 'icon' ) {
	$option['options'] = $this->fontAwesomeIconsArray();
	if( isset( $option['options'] ) && is_array( $option['options'] ) && ! empty( $option['options'] ) ) {
		$opts = '';
		$opts = '<option value=""></option>';
		if( ! empty( $option['options'] ) ) {
			foreach( $option['options'] as $opt => $val ) {
				if( $option['default'] != '' && $opt == $option['default'] ) {
					$opts .= '<option selected value="' . $opt . '">' . $val . '</option>';
				} else {
					$opts .= '<option value="' . $opt . '">' . $val . '</option>';
				}
			}
		}
		$use_form_options = (isset( $option['select_options_from'] )) ? 1 : 0;
		$field_html[] = '<select id="' . $form_field_id . '" name="' . $option['id'] . '" data-load-child-dropdown="' . $use_form_options . '" data-tags="true" ' . $params . '>';
		$field_html[] = $opts;
		$field_html[] = '</select>';
	} else {
		if( current_user_can( 'manage_options' ) ) {
			$field_html[] = $this->alert( 'warning', __( 'Options for this field are not specified, please review field settings.', 'cssjockey-add-ons' ) );
		}
	}
}

if( $option['type'] == 'submit' ) {
	$field_html[] = (isset( $option['prefix'] )) ? '' . $option['prefix'] : '';
	$field_html[] = '<button name="' . $option['id'] . '" type="submit"  ' . $params . ' >' . $option['default'] . '</button>';
	$field_html[] = (isset( $option['suffix'] )) ? '' . $option['suffix'] : '';
}

echo implode( '', $field_html );