<?php
global $wp_roles;
if( isset( $form_options['form_id'] ) ) {
	$form_id = $form_options['form_id']['default'];
	$form_info = $this->postInfo( $form_id );
}

if( is_array( $form_options ) && ! empty( $form_options ) ) {
	echo '<div class="cj-columns cj-is-multiline">';
	foreach( $form_options as $key => $option ) {
		$form_field_id = $this->cleanString( $option['id'] );
		$show_control_p = 1;
		$include_control = 1;
		$show_label = 1;
		$show_info = 1;
		$field_error = 0;
		$control_class = '';
		$field_class = '';
		$field_type_class = 'field-' . sanitize_title( str_replace( '_', '-', $option['type'] ) );
		$container_class = (isset( $option['container_class'] )) ? $option['container_class'] : 'cj-column cj-is-full';
		$help_text = (isset( $option['info'] ) && $option['info'] != '') ? '<div class="cj-help">' . html_entity_decode( $option['info'] ) . '</div>' : '';
		if( $option['type'] == 'hidden' ) {
			$container_class = 'cj-hidden';
		}
		$input_icon = '';
		if( isset( $option['has_icon'] ) && $option['has_icon'] && $option['has_icon'] != '' ) {
			$control_class .= 'cj-has-icon';
			$input_icon = '<span class="cj-icon"><i class="' . $option['has_icon'] . '"></i></span>';
		}

		if( $option['type'] == 'file' && $option['id'] == 'user_avatar' ) {
			$option['type'] = 'user_avatar';
			$show_label = 0;
			$help_text = '';
			$option['_wp_nonce'] = wp_create_nonce( 'vue-upload-avatar' );
		}
		if( in_array( $option['type'], $this->selectFields() ) ) {
			$option['type'] = 'select';
			$option['params']['class'] = 'selectize';
			$show_control_p = 0;
		}
		if( $option['type'] == 'heading' ) {
			$show_label = 0;
		}
		if( $option['type'] == 'color' ) {
			$field_class = 'text-color';
		}
		if( $option['type'] == 'file' || $option['type'] == 'files' ) {
			$option['type'] = 'vue-file-upload';
			$option['_wp_nonce'] = wp_create_nonce( 'vue-upload-avatar' );
		}

		if( $option['type'] == 'wysiwyg' ) {
			$option['editor_settings'] = array(
				'wpautop' => false,
				'media_buttons' => false,
				'textarea_rows' => 10,
				'teeny' => true,
				'drag_drop_upload' => true,
				'tinymce' => array(
					'resize' => false,
					'statusbar' => false,
				)
			);
		}
		if( isset( $option['label'] ) && $option['label'] == '' ) {
			$show_label = 0;
		}
		if( $option['type'] == 'html' ) {
			$include_control = 0;
			$show_label = 0;
		}
		if( $option['type'] == 'min-max' ) {
			$include_control = 0;
		}
		if( isset( $option['control_class'] ) && $option['control_class'] != '' ) {
			$control_class = $option['control_class'];
		}

		if( isset( $option['params']['required'] ) ) {
			$option['label'] = $option['label'] . ' <span class="cj-color-danger cj-fs-14">*</span>';
		}

		?>
        <div id="container-<?php echo $form_field_id; ?>" class="<?php echo $container_class; ?>">
			<?php if( $show_label == 1 && isset($option['label']) && $option['label'] !== '' ) { ?> <label class="cj-label" for="<?php echo $form_field_id; ?>"><?php echo $option['label']; ?></label> <?php } ?>
			<?php if( ! $field_error ) { ?>
                <div class="cj-field <?php echo $field_class; ?> <?php echo $field_type_class; ?>">
					<?php if($include_control){ ?>
				<?php if($show_control_p){ ?><p class="cj-control <?php echo $control_class ?>"><?php } ?>
						<?php } ?>
						<?php echo $this->formField( $option ); ?>
						<?php echo $input_icon; ?>
						<?php if($include_control){ ?>
						<?php if($show_control_p){ ?></p><?php } ?>
				<?php } ?>
                </div>
			<?php } ?>
			<?php if( $field_error ) {
				echo $this->alert( 'warning', $field_error );
			} ?>
			<?php echo $help_text; ?>
        </div><!-- /container -->
		<?php
	}
	echo '</div> <!-- /columns -->';
}