<?php
global $cjaddons_options, $cjaddons_item_vars;

if( ! isset( $_GET['callback'] ) ) {
	wp_redirect( $this->helpers->callbackUrl() );
	exit;
}

$callback = explode( '~', $_GET['callback'] );
if( $callback[0] == '' && $_GET['page'] == 'cjaddons' ) {
	wp_redirect( $this->helpers->callbackUrl() );
	exit;
}

$module_vars = $this->helpers->itemVars( 'module_info' );
$current_module_info = array();

if( isset( $module_vars[ $callback[0] ] ) ) {
	$current_module_info = $module_vars[ $callback[0] ];
}

if( ! empty( $current_module_info ) ) {
	$module_dir_name = basename( $current_module_info['module_path'] );
	$url = $this->helpers->callbackUrl( $module_dir_name, $callback[1], 'cjaddons-' . $module_dir_name );
	// wp_redirect($url);
	die();
}

$core_modules = ['config'];
if( is_array( $module_vars ) ) {
	foreach( $module_vars as $module_var_key => $module_var ) {
		if( $module_vars[ $module_var_key ]['core'] ) {
			$core_modules[] = $module_var_key;
		}
	}
}

function cjaddons_render_menu_items( $p_key, $m_key, $menu ) {
	$helpers = cjaddons_helpers::getInstance();
	$menu_link = ( ! is_array( $menu )) ? $helpers->callbackUrl( $p_key, $m_key ) : '#';
	$display[] = '<li>';
	$display[] = '<a href="' . $menu_link . '">';
	$display[] = (isset( $menu['label'] )) ? $menu['label'] : $menu;
	if( isset( $menu['items'] ) && is_array( $menu['items'] ) && ! empty( $menu['items'] ) ) {
		$display[] = '<span class="cj-icon cj-ml-5 cj-is-small"><i class="fa fa-caret-down"></i></span>';
	}
	$display[] = '</a>';
	if( isset( $menu['items'] ) && is_array( $menu['items'] ) ) {
		$display[] = '<ul>';
		foreach( $menu['items'] as $s_key => $s_menu ) {
			$display[] = '<li>';
			$display[] = '<a href="' . $helpers->callbackUrl( $p_key, $s_key ) . '">';
			$display[] = $s_menu;
			$display[] = '</a>';
			$display[] = '</li>';
		}
		$display[] = '</ul>';
	}
	$display[] = '</li>';

	return implode( '', $display );
}

$file_path = ($callback[0] == 'config') ? $this->helpers->root_dir . "/framework/admin-pages/{$callback[1]}.php" : $module_vars[ $callback[0] ]['module_path'] . "/admin-pages/{$callback[1]}.php";

$admin_page_file = $file_path;

$option_files = $this->helpers->itemVars( 'option_files' );
$render_admin_form = isset( $option_files[ $callback[0] ] ) ? true : false;
$show_form_message = '';
if( isset( $_POST['save_admin_options'] ) ) {
	if( check_admin_referer( sha1( $this->helpers->itemInfo( 'item_id' ) ) ) ) {
		if( file_exists( $admin_page_file ) ) {
			$this->helpers->saveOptionsToSync( $_POST );
			if( isset( $cjaddons_options[ $callback[1] ] ) ) {
				$options = $cjaddons_options[ $callback[1] ];
				foreach( $options as $o_key => $opt ) {
					$opt_value = (isset( $_POST[ $opt['id'] ] )) ? $_POST[ $opt['id'] ] : '';
					$this->helpers->updateOption( $opt['id'], $opt_value );
				}
			}
		}
		$location = $this->helpers->queryString( $this->helpers->callbackUrl( $callback[0], $callback[1] ) ) . 'cjaddons-msg=saved';
		wp_redirect( $location );
		wp_die();
	} else {
		$location = $this->helpers->queryString( $this->helpers->callbackUrl( $callback[0], $callback[1] ) ) . 'cjaddons-msg=invalid-nonce';
		wp_redirect( $location );
		wp_die();
	}
}
if( isset( $_GET['cjaddons-msg'] ) && $_GET['cjaddons-msg'] == 'saved' ) {
	$show_form_message = $this->helpers->alert( 'success', esc_attr__( 'Options saved successfully.', 'cssjockey-add-ons' ) );
}
if( isset( $_GET['cjaddons-msg'] ) && $_GET['cjaddons-msg'] == 'invalid-nonce' ) {
	$show_form_message = $this->helpers->alert( 'danger', esc_attr__( 'Options cannot be saved.', 'cssjockey-add-ons' ) );
}
?>
<div class="wrap">

    <h1 class="breadcrumb">
        <a href="<?php echo $this->helpers->callbackUrl( 'config', 'core-welcome', 'cssjockey-add-ons' ); ?>" style="text-decoration: none !important; color: #222222 !important;"><?php echo $this->helpers->itemInfo( 'item_name' ); ?></a>
        <span class="cssjockey-ui"><?php echo ( ! empty( $current_module_info )) ? ' &raquo; <span class="opacity-50">' . $current_module_info['module_name'] . '</span>' : ''; ?></span>
    </h1>
    <div class="cssjockey-ui">
        <section>
            <section class="cj-main-menu">
                <ul>
					<?php
					$admin_menus = $this->helpers->itemVars( 'admin_menu' );
					foreach( $admin_menus as $p_key => $menus ):
						if( in_array( $callback[0], $core_modules ) && in_array( $p_key, $core_modules ) ) {
							foreach( $menus as $m_key => $menu ):
								echo cjaddons_render_menu_items( $p_key, $m_key, $menu );
							endforeach;
						}
						if( ! in_array( $callback[0], $core_modules ) && $p_key == 'config' ) {
							foreach( $menus as $m_key => $menu ):
								echo cjaddons_render_menu_items( $p_key, $m_key, $menu );
							endforeach;
						}
						if( ! in_array( $callback[0], $core_modules ) && $p_key != 'config' && ! empty( $current_module_info ) && $p_key == $callback[0] ) {
							foreach( $menus as $m_key => $menu ):
								echo cjaddons_render_menu_items( $p_key, $m_key, $menu );
							endforeach;
						}

					endforeach;
					?>
                    <li class="cj-right">
                        <a href="#"><i class="fa fa-life-ring cj-mr-5"></i> <?php _e( 'Help & Support', 'cssjockey-add-ons' ) ?></a>
                        <ul>
                            <li class="cj-hidden"><a href="<?php echo $this->helpers->queryString( $this->helpers->callbackUrl() ) . 'cjaddons_assistant=restart'; ?>"><i class="fa fa-magic cj-mr-5"></i> <?php _e( 'Setup Assistant', 'cssjockey-add-ons' ) ?></a></li>
                            <li><a target="_blank" href="<?php echo $this->helpers->itemInfo( 'docs_url' ); ?>"><i class="fa fa-book cj-mr-5"></i> <?php _e( 'Documentation', 'cssjockey-add-ons' ) ?></a></li>
                            <li><a target="_blank" href="<?php echo $this->helpers->itemInfo( 'support_url' ); ?>"><i class="fa fa-ticket cj-mr-5"></i> <?php _e( 'Support Tickets', 'cssjockey-add-ons' ) ?></a></li>
                            <li><a target="_blank" href="<?php echo $this->helpers->itemInfo( 'customization_url' ); ?>"><i class="fa fa-file-code-o cj-mr-5"></i> <?php _e( 'Customization', 'cssjockey-add-ons' ) ?></a></li>
                            <li><a target="_blank" href="<?php echo $this->helpers->itemInfo( 'hire_us_url' ); ?>"><i class="fa fa-user-plus cj-mr-5"></i> <?php _e( 'Hire Us', 'cssjockey-add-ons' ) ?></a></li>
                        </ul>
                    </li>
					<?php
					if( isset( $cjaddons_item_vars['module_info'] ) && ! empty( $cjaddons_item_vars['module_info'] ) && is_array( $cjaddons_item_vars['module_info'] ) ) {
						echo '<li class="cj-is-pulled-right">';
						echo '<a href="#">' . __( 'Installed Add-ons', 'cssjockey-add-ons' ) . '<span class="cj-icon cj-ml-5 cj-is-small"><i class="fa fa-caret-down"></i></span></a>';
						echo '<ul>';
						foreach( $cjaddons_item_vars['module_info'] as $m_key => $m_value ) {
							$module_url = $this->helpers->callbackUrl( $m_value['module_id'], 'info', 'cjaddons-' . $m_value['module_id'] );
							echo '<li><a href="' . $module_url . '">' . $m_value['module_name'] . '</a></li>';
						}
						echo '</ul>';
						echo '</li>';
					}
					?>
                </ul>
            </section><!-- main-menu -->

            <section id="cj-admin-content">
				<?php
				if( file_exists( $admin_page_file ) ):
					if( isset( $cjaddons_options[ $callback[1] ] ) ) {
						$saved_options = $this->helpers->saved_options;
						$exclude = [
							'info',
							'info-full',
							'heading',
							'sub-heading',
							'css-styles',
						];
						foreach( $cjaddons_options[ $callback[1] ] as $key => $option ) {
							if( ! in_array( $option['type'], $exclude ) ) {
								$cjaddons_options[ $callback[1] ][ $key ]['default'] = $saved_options[ $option['id'] ];
								if( $option['type'] == 'page' && $saved_options[ $option['id'] ] != '' ) {
									$cjaddons_options[ $callback[1] ][ $key ]['label'] = $option['label'] . '<p class="text-normal"><a href="' . get_permalink( $saved_options[ $option['id'] ] ) . '" target="_blank">' . __( 'View Page', 'cssjockey-add-ons' ) . '</a></p>';
								}
								if( $option['type'] == 'post' && $saved_options[ $option['id'] ] != '' ) {
									$cjaddons_options[ $callback[1] ][ $key ]['label'] = $option['label'] . '<p class="text-normal"><a href="' . get_permalink( $saved_options[ $option['id'] ] ) . '" target="_blank">' . __( 'View Post', 'cssjockey-add-ons' ) . '</a></p>';
								}

								if( $option['type'] == 'group' && $saved_options[ $option['id'] ] != '' ) {
									$group_saved_values = $saved_options[ $option['id'] ];
									if( isset( $group_saved_values['selected_value'] ) && $group_saved_values['selected_value'] != '' ) {
										$cjaddons_options[ $callback[1] ][ $key ]['default'] = $group_saved_values['selected_value'];
										foreach( $cjaddons_options[ $callback[1] ][ $key ]['items'] as $item_key => $item_value ) {
											foreach( $item_value as $ik => $iv ) {
												if( isset( $group_saved_values['items'][ $item_key ][ $iv['id'] ] ) && $group_saved_values['items'][ $item_key ][ $iv['id'] ] != '' ) {
													$default_value = $group_saved_values['items'][ $item_key ][ $iv['id'] ];
													$cjaddons_options[ $callback[1] ][ $key ]['items'][ $item_key ][ $ik ]['default'] = $default_value;
												}
											}
										}
									}
								}
							}
						}
						$cjaddons_options[ $callback[1] ]['submit'] = array(
							'type' => 'submit',
							'id' => 'save_admin_options',
							'label' => '',
							'label_suffix' => '',
							'info' => '',
							'params' => array('class' => 'cj-button cj-is-primary cj-is-medium'),
							'suffix' => '',
							'default' => esc_attr__( 'Save Settings', 'cssjockey-add-ons' ),
							'options' => '', // array in case of dropdown, checkbox and radio buttons
						);
						echo $show_form_message;
						echo '<form class="cj-options-form" action="" method="post">';
						echo wp_nonce_field( sha1( $this->helpers->itemInfo( 'item_id' ) ) );
						echo $this->helpers->renderAdminForm( $cjaddons_options[ $callback[1] ] );
						echo '</form>';
					} else {
						require_once($admin_page_file);
					}
				endif;
				?>
				<?php if( ! file_exists( $admin_page_file ) ):
					$path = str_replace( $this->helpers->root_dir, '', $admin_page_file );
					?>
                    <div class="cj-notification cj-is-danger">
						<?php echo sprintf( __('<b>File not found:</b><br>%s', 'cssjockey-add-ons'), $path ); ?>
                    </div>
				<?php endif; ?>
            </section>
        </section>

    </div>

</div>
