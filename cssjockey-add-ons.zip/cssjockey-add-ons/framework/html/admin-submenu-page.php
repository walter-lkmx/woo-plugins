<?php
global $cjaddons_options, $cjaddons_item_vars;

if( isset( $_GET['page'] ) && $_GET['page'] == 'cjaddons-get-addons' ) {
	$url = $this->helpers->callbackUrl( 'config', 'get-addons', 'cjaddons' );
	wp_redirect( $url );
	die();
}

$addon_dir = basename( $this->helpers->module_dir );
$module_info = $this->helpers->moduleInfo( $addon_dir );
$admin_menus = $this->helpers->itemVars( 'admin_menu' );
$callback = (isset( $_GET['callback'] )) ? explode( '~', $_GET['callback'] ) : '';
if( $callback == '' && $_GET['page'] != 'cjaddons' ) {
	wp_redirect( $this->helpers->callbackUrl( $addon_dir, 'info', 'cjaddons-' . $addon_dir ) );
	exit();
}
if( isset( $callback[1] ) ) {
	$admin_page_file = $this->helpers->module_dir . '/admin-pages/' . $callback[1] . '.php';
} else {
	$admin_page_file = '';
}
$show_form_message = '';

if( isset( $_POST['save_admin_options'] ) ) {
    if( check_admin_referer( sha1( $this->helpers->itemInfo( 'item_id' ) ) ) ) {
		if( file_exists( $admin_page_file ) ) {
			$this->helpers->saveOptionsToSync($_POST);
			if( isset( $cjaddons_options[ $callback[1] ] ) ) {
				$options = $cjaddons_options[ $callback[1] ];
				foreach( $options as $o_key => $opt ) {
					$opt_value = (isset( $_POST[ $opt['id'] ] ) && $_POST[ $opt['id'] ] != '') ? $_POST[ $opt['id'] ] : '';
					$this->helpers->updateOption( $opt['id'], $opt_value );
				}
			}
		}
		$location = $this->helpers->queryString( $this->helpers->callbackUrl( $callback[0], $callback[1] ) ) . 'cjaddons-msg=saved';
		wp_redirect( $location );
		wp_die();
	} else {
		$location = $this->helpers->queryString( $this->helpers->callbackUrl( $callback[0], $callback[1] ) ) . 'cjaddons-msg=invalid-nonce';
		wp_redirect( $location );
		wp_die();
	}
}
if( isset( $_GET['cjaddons-msg'] ) && $_GET['cjaddons-msg'] == 'saved' ) {
	$show_form_message = $this->helpers->alert( 'success', esc_attr__( 'Options saved successfully.', 'cssjockey-add-ons' ) );
}
if( isset( $_GET['cjaddons-msg'] ) && $_GET['cjaddons-msg'] == 'invalid-nonce' ) {
	$show_form_message = $this->helpers->alert( 'danger', esc_attr__( 'Options cannot be saved.', 'cssjockey-add-ons' ) );
}

?>
<div class="wrap">
    <h1>
        <a href="<?php echo $this->helpers->callbackUrl( 'config', 'core-welcome', 'cjaddons' ); ?>" style="text-decoration: none !important; color: #222222 !important;"><?php echo $this->helpers->itemInfo( 'item_name' ); ?></a>
        <span class="cssjockey-ui"><?php echo ( ! empty( $module_info )) ? ' &raquo; <span class="cj-opacity-50">' . $module_info['module_name'] . '</span>' : ''; ?></span>
    </h1>

    <div class="cssjockey-ui">
        <section class="cj-main-menu">
            <nav>
                <ul>
					<?php
					if( ! empty( $admin_menus ) ) {
						foreach( $admin_menus as $a_key => $a_value ) {
							if( $a_key == 'config' ) {
								foreach( $a_value as $key => $value ) {
									if( $key == 'core-welcome' && ! is_array( $value ) ) {
										echo '<li><a href="' . $this->helpers->callbackUrl( 'config', 'core-welcome', 'cjaddons' ) . '">' . $value . '</a></li>';
									}
									if( is_array( $value ) && isset( $value['items'] ) && is_array( $value['items'] ) ) {
										echo '<li>';
										echo '<a href="#">' . $value['label'] . '<span class="cj-icon cj-ml-5 cj-is-small"><i class="fa fa-caret-down"></i></span></a>';
										if( ! empty( $value['items'] ) ) {
											echo '<ul>';
											foreach( $value['items'] as $s_key => $s_value ) {
												echo '<li><a href="' . $this->helpers->callbackUrl( 'config', $s_key, 'cjaddons' ) . '">' . $s_value . '</a></li>';
											}
											echo '</ul>';
										}
										echo '</li>';
									}
								}
							}
							if( $a_key == $addon_dir ) {
								foreach( $a_value as $key => $value ) {
									if( ! isset( $value['items'] ) ) {
										echo '<li><a href="' . $this->helpers->callbackUrl( $addon_dir, $key, 'cjaddons-' . $a_key ) . '">' . $value . '</a></li>';
									}
									if( is_array( $value ) && isset( $value['items'] ) && is_array( $value['items'] ) ) {
										echo '<li>';
										echo '<a href="#">' . $value['label'] . '<span class="cj-icon cj-ml-5 cj-is-small"><i class="fa fa-caret-down"></i></span></a>';
										if( ! empty( $value['items'] ) ) {
											echo '<ul>';
											foreach( $value['items'] as $s_key => $s_value ) {
												echo '<li><a href="' . $this->helpers->callbackUrl( $addon_dir, $s_key, 'cjaddons-' . $a_key ) . '">' . $s_value . '</a></li>';
											}
											echo '</ul>';
										}
										echo '</li>';
									}
								}
							}
						}
					}
					?>
                    <li class="cj-right">
                        <a href="#"><i class="fa fa-life-ring cj-mr-5"></i> <?php _e( 'Help & Support', 'cssjockey-add-ons' ) ?></a>
                        <ul>
                            <li class="cj-hidden"><a href="<?php echo $this->helpers->queryString( $this->helpers->callbackUrl() ) . 'cjaddons_assistant=restart'; ?>"><i class="fa fa-magic cj-mr-5"></i> <?php _e( 'Setup Assistant', 'cssjockey-add-ons' ) ?></a></li>
                            <li><a target="_blank" href="<?php echo $this->helpers->itemInfo( 'docs_url' ); ?>"><i class="fa fa-book cj-mr-5"></i> <?php _e( 'Documentation', 'cssjockey-add-ons' ) ?></a></li>
                            <li><a target="_blank" href="<?php echo $this->helpers->itemInfo( 'support_url' ); ?>"><i class="fa fa-ticket cj-mr-5"></i> <?php _e( 'Support Tickets', 'cssjockey-add-ons' ) ?></a></li>
                            <li><a target="_blank" href="<?php echo $this->helpers->itemInfo( 'customization_url' ); ?>"><i class="fa fa-file-code-o cj-mr-5"></i> <?php _e( 'Customization', 'cssjockey-add-ons' ) ?></a></li>
                            <li><a target="_blank" href="<?php echo $this->helpers->itemInfo( 'hire_us_url' ); ?>"><i class="fa fa-user-plus cj-mr-5"></i> <?php _e( 'Hire Us', 'cssjockey-add-ons' ) ?></a></li>
                        </ul>
                    </li>
	                <?php
	                if( isset( $cjaddons_item_vars['module_info'] ) && ! empty( $cjaddons_item_vars['module_info'] ) && is_array( $cjaddons_item_vars['module_info'] ) ) {
		                echo '<li class="cj-is-pulled-right">';
		                echo '<a href="#">'.__('Installed Add-ons', 'cssjockey-add-ons').'<span class="cj-icon cj-ml-5 cj-is-small"><i class="fa fa-caret-down"></i></span></a>';
		                echo '<ul>';
		                foreach($cjaddons_item_vars['module_info'] as $m_key => $m_value){
			                $module_url = $this->helpers->callbackUrl($m_value['module_id'], 'info', 'cjaddons-'.$m_value['module_id']);
			                echo '<li><a href="'.$module_url.'">'.$m_value['module_name'].'</a></li>';
		                }
		                echo '</ul>';
		                echo '</li>';
	                }
	                ?>
                </ul>
            </nav>
        </section>

        <section id="cj-admin-content">
			<?php
			if( file_exists( $admin_page_file ) ):
				if( isset( $cjaddons_options[ $callback[1] ] ) ) {
					$saved_options = $this->helpers->saved_options;
					$exclude = [
						'info',
						'info-full',
						'heading',
						'sub-heading',
						'css-styles',
					];
					foreach( $cjaddons_options[ $callback[1] ] as $key => $option ) {
						if( ! in_array( $option['type'], $exclude ) ) {

							$cjaddons_options[ $callback[1] ][ $key ]['default'] = (!is_array($saved_options[ $option['id'] ])) ? html_entity_decode($saved_options[ $option['id'] ]) : $saved_options[ $option['id'] ];
							if( $option['type'] == 'page' && $saved_options[ $option['id'] ] != '' ) {
								$cjaddons_options[ $callback[1] ][ $key ]['label'] = $option['label'] . '<p class="cj-text-normal"><a href="' . get_permalink( $saved_options[ $option['id'] ] ) . '" target="_blank">' . __( 'View Page', 'cssjockey-add-ons' ) . '</a></p>';
							}
							if( $option['type'] == 'post' && $saved_options[ $option['id'] ] != '' ) {
								$cjaddons_options[ $callback[1] ][ $key ]['label'] = $option['label'] . '<p class="cj-text-normal"><a href="' . get_permalink( $saved_options[ $option['id'] ] ) . '" target="_blank">' . __( 'View Post', 'cssjockey-add-ons' ) . '</a></p>';
							}

							if( $option['type'] == 'group' && $saved_options[ $option['id'] ] != '' ) {
								$group_saved_values = $saved_options[ $option['id'] ];
								if( isset( $group_saved_values['selected_value'] ) && $group_saved_values['selected_value'] != '' ) {
									$cjaddons_options[ $callback[1] ][ $key ]['default'] = $group_saved_values['selected_value'];
									foreach( $cjaddons_options[ $callback[1] ][ $key ]['items'] as $item_key => $item_value ) {
										foreach( $item_value as $ik => $iv ) {
											if( isset( $group_saved_values['items'][ $item_key ][ $iv['id'] ] ) && $group_saved_values['items'][ $item_key ][ $iv['id'] ] != '' ) {
												$default_value = $group_saved_values['items'][ $item_key ][ $iv['id'] ];
												$cjaddons_options[ $callback[1] ][ $key ]['items'][ $item_key ][ $ik ]['default'] = $default_value;
											}else{
												$cjaddons_options[ $callback[1] ][ $key ]['items'][ $item_key ][ $ik ]['default'] = '';
                                            }
										}
									}
								}
							}
						}
					}
					$cjaddons_options[ $callback[1] ]['submit'] = array(
						'type' => 'submit',
						'id' => 'save_admin_options',
						'label' => '',
						'label_suffix' => '',
						'info' => '',
						'suffix' => '',
						'params' => '',
						'default' => esc_attr__( 'Save Settings', 'cssjockey-add-ons' ),
						'options' => '', // array in case of dropdown, checkbox and radio buttons
					);
					echo $show_form_message;
					echo '<form class="cj-options-form" action="" method="post">';
					echo wp_nonce_field( sha1( $this->helpers->itemInfo( 'item_id' ) ) );
					echo $this->helpers->renderAdminForm( $cjaddons_options[ $callback[1] ], true );
					echo '</form>';
				} else {
					require_once($admin_page_file);
				}
			endif;
			?>
			<?php if( ! file_exists( $admin_page_file ) ):
				$path = str_replace( $this->helpers->root_dir, '', $admin_page_file );
                ?>
                <div class="cj-notification cj-is-danger">
	                <?php echo sprintf( __('<b>File not found:</b><br>%s', 'cssjockey-add-ons'), $path ); ?>
                </div>
			<?php endif; ?>
        </section>
    </div>

</div>
