<?php
$text_style_options = array(
	array(
		'type' => 'color',
		'id' => $option['id'] . '[color]',
		'label' => __( 'Text Color', 'cssjockey-add-ons' ),
		'default' => '#666666',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'number',
		'id' => $option['id'] . '[font-size]',
		'label' => __( 'Font Size', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => 'px',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'number',
		'id' => $option['id'] . '[line-height]',
		'label' => __( 'Line Height', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => 'px',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . '[font-weight]',
		'label' => __( 'Font Weight', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => '',
		'options' => $this->arrays( 'font-weight' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . '[font-style]',
		'label' => __( 'Font Style', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => '',
		'options' => $this->arrays( 'font-style' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . '[text-decoration]',
		'label' => __( 'Text Decoration', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => '',
		'options' => $this->arrays( 'text-decoration' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . '[font-variant]',
		'label' => __( 'Font Variant', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => '',
		'options' => $this->arrays( 'font-variant' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . '[text-transform]',
		'label' => __( 'Text Transform', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => '',
		'options' => $this->arrays( 'text-transform' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . '[font-family]',
		'label' => __( 'Font Family', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => '',
		'options' => $this->getGoogleFonts(), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . '[text-align]',
		'label' => __( 'Text Align', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => '',
		'options' => $this->arrays( 'text-align' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'number',
		'id' => $option['id'] . '[text-indent]',
		'label' => __( 'Text Indent', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => 'px',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'number',
		'id' => $option['id'] . '[letter-spacing]',
		'label' => __( 'Letter Spacing', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => 'px',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'number',
		'id' => $option['id'] . '[word-spacing]',
		'label' => __( 'Word Spacing', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => 'px',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . '[white-space]',
		'label' => __( 'White Space', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => '',
		'options' => $this->arrays( 'white-space' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'text',
		'id' => $option['id'] . '[text-shadow]',
		'label' => __( 'Text Shadow', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
);
$decoration_style_options = array(
	array(
		'type' => 'color',
		'id' => $option['id'] . 'background-color',
		'label' => __( 'Background Color', 'cssjockey-add-ons' ),
		'default' => 'none',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'files',
		'id' => $option['id'] . 'background-image',
		'label' => __( 'Background Image', 'cssjockey-add-ons' ),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . 'background-position',
		'label' => __( 'Background Position', 'cssjockey-add-ons' ),
		'default' => '',
		'options' => $this->arrays( 'background-position' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . 'background-repeat',
		'label' => __( 'Background Repeat', 'cssjockey-add-ons' ),
		'default' => '',
		'options' => $this->arrays( 'background-repeat' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . 'background-size',
		'label' => __( 'Background Size', 'cssjockey-add-ons' ),
		'default' => '',
		'options' => $this->arrays( 'background-size' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . 'background-attachment',
		'label' => __( 'Background Size', 'cssjockey-add-ons' ),
		'default' => '',
		'options' => $this->arrays( 'background-attachment' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'text',
		'id' => $option['id'] . 'box-shadow',
		'label' => __( 'Box Shadow', 'cssjockey-add-ons' ),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'text',
		'id' => $option['id'] . 'opacity',
		'label' => __( 'Opacity', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => '%',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'css-shorthand',
		'id' => $option['id'] . 'border',
		'label' => __( 'Borders', 'cssjockey-add-ons' ),
		'default' => '',
		'suffix' => '',
		'params' => array('placeholder' => '1px solid #ddd'),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
);
$layout_style_options = array(
	array(
		'type' => 'css-shorthand',
		'id' => $option['id'] . 'margin',
		'label' => __( 'Margin', 'cssjockey-add-ons' ),
		'params' => array('placeholder' => '10px'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'css-shorthand',
		'id' => $option['id'] . 'padding',
		'label' => __( 'Padding', 'cssjockey-add-ons' ),
		'params' => array('placeholder' => '10px'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . 'position',
		'label' => __( 'Position', 'cssjockey-add-ons' ),
		'default' => '',
		'options' => $this->arrays( 'position' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'css-shorthand',
		'id' => $option['id'] . 'position',
		'label' => __( 'Position #', 'cssjockey-add-ons' ),
		'params' => array('placeholder' => 'px or auto'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'number',
		'id' => $option['id'] . 'width',
		'label' => __( 'Width', 'cssjockey-add-ons' ),
		'suffix' => 'px',
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'number',
		'id' => $option['id'] . 'height',
		'label' => __( 'Height', 'cssjockey-add-ons' ),
		'suffix' => 'px',
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . 'display',
		'label' => __( 'Display', 'cssjockey-add-ons' ),
		'suffix' => 'px',
		'default' => '',
		'options' => $this->arrays( 'display' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . 'float',
		'label' => __( 'Float', 'cssjockey-add-ons' ),
		'suffix' => '',
		'default' => '',
		'options' => $this->arrays( 'float' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . 'clear',
		'label' => __( 'Clear', 'cssjockey-add-ons' ),
		'suffix' => '',
		'default' => '',
		'options' => $this->arrays( 'clear' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . 'visibility',
		'label' => __( 'Visibility', 'cssjockey-add-ons' ),
		'suffix' => '',
		'default' => '',
		'options' => $this->arrays( 'visibility' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . 'overflow',
		'label' => __( 'Overflow', 'cssjockey-add-ons' ),
		'suffix' => '',
		'default' => '',
		'options' => $this->arrays( 'overflow' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . 'overflow-x',
		'label' => __( 'Overflow X', 'cssjockey-add-ons' ),
		'suffix' => '',
		'default' => '',
		'options' => $this->arrays( 'overflow' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'select',
		'id' => $option['id'] . 'overflow-y',
		'label' => __( 'Overflow Y', 'cssjockey-add-ons' ),
		'suffix' => '',
		'default' => '',
		'options' => $this->arrays( 'overflow' ), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'number',
		'id' => $option['id'] . 'z-index',
		'label' => __( 'Z-Index', 'cssjockey-add-ons' ),
		'suffix' => '',
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
);
$custom_style_options = array(
	array(
		'type' => 'code-css',
		'id' => $option['id'] . 'custom_css',
		'label' => __( 'Custom CSS', 'cssjockey-add-ons' ),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'text',
		'id' => $option['id'] . 'custom_classes',
		'label' => __( 'Custom CSS Classes', 'cssjockey-add-ons' ),
		'params' => array('placeholder' => 'classname, classname ...'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
);
?>

<a data-toggle="class" data-classes="cj-is-active" data-target="#cj-css-styles-<?php echo $form_field_id; ?>" class="cj-button cj-is-info"><i class="fa fa-css3 cj-mr-5"></i> <?php _e( 'CSS Styles', 'cssjockey-add-ons' ) ?></a>


<div id="cj-css-styles-<?php echo $form_field_id; ?>" class="cj-modal">
    <div data-toggle="class" data-classes="cj-is-active" data-target="#cj-css-styles-<?php echo $form_field_id; ?>" class="cj-modal-background"></div>
    <div class="cj-modal-card cj-width-50">
        <header class="cj-modal-card-head">
            <p class="cj-modal-card-title"><?php _e('CSS Styles', 'cssjockey-add-ons') ?></p>
            <button data-toggle="class" data-classes="cj-is-active" data-target="#cj-css-styles-<?php echo $form_field_id; ?>" class="cj-delete"></button>
        </header>
        <section class="cj-modal-card-body cj-p-0">
            <div class="cj-content">
                <div class="">
                    <div class="cj-field cj-has-addons cj-m-0">
                        <p class="cj-control cj-m-0">
                            <a data-toggle="element" data-target=".text-styles" class="cj-button cj-is-info cj-no-borders cj-is-active">
                                <span class="cj-icon cj-is-small"><i class="fa fa-align-left"></i></span><span><?php _e( 'Text Styles', 'cssjockey-add-ons' ) ?></span>
                            </a>
                            <a data-toggle="element" data-target=".decoration-styles" class="cj-button cj-is-info cj-no-borders">
                                <span class="cj-icon cj-is-small"><i class="fa fa-paint-brush"></i></span><span><?php _e( 'Decoration', 'cssjockey-add-ons' ) ?></span>
                            </a>
                            <a data-toggle="element" data-target=".layout-styles" class="cj-button cj-is-info cj-no-borders">
                                <span class="cj-icon cj-is-small"><i class="fa fa-columns"></i></span><span><?php _e( 'Layout', 'cssjockey-add-ons' ) ?></span>
                            </a>
                            <a data-toggle="element" data-target=".custom-css" class="cj-button cj-is-info cj-no-borders">
                                <span class="cj-icon cj-is-small"><i class="fa fa-code"></i></span><span><?php _e( 'Custom CSS', 'cssjockey-add-ons' ) ?></span>
                            </a>
                        </p>
                    </div>
                </div>

                <div class="cj-toggle-group">
                    <div class="text-styles cj-is-active">
				        <?php echo $this->renderAdminForm( $text_style_options ); ?>
                    </div>
                    <div class="decoration-styles">
				        <?php echo $this->renderAdminForm( $decoration_style_options ); ?>
                    </div>
                    <div class="layout-styles">
				        <?php echo $this->renderAdminForm( $layout_style_options ); ?>
                    </div>
                    <div class="custom-css">
				        <?php echo $this->renderAdminForm( $custom_style_options ); ?>
                    </div>
                </div>


            </div>
        </section>
    </div>
</div>