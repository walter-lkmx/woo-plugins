<?php
global $cjaddons_item_vars;
?>
<?php if( isset( $cjaddons_item_vars['module_info'] ) && is_array( $cjaddons_item_vars['module_info'] ) && ! empty( $cjaddons_item_vars['module_info'] ) ) { ?>
    <style type="text/css">
        ul#adminmenu li.toplevel_page_cjaddons ul.wp-submenu li.wp-first-item {
            display: none !important;
        }
    </style>
<?php } ?>

<div class="cssjockey-ui">
    <div id="cjaddons-global-modal" class="cj-modal">
        <div class="cj-modal-background"></div>
        <div class="cj-modal-content cj-width-100 cj-m-20">
            <div class="cj-box cj-p-0" style="overflow-y: scroll;">
                <div class="cj-dynamic-content"></div>
            </div>
        </div>
    </div>
</div>