<div class="cssjockey-ui">
	<?php
	// delete_transient( 'cjaddons_notifications' );
	$notifications = get_transient( 'cjaddons_notifications' );
	$notifications = (is_serialized( $notifications )) ? unserialize( $notifications ) : $notifications;
	if( is_array( $notifications ) ) {
		$items = json_encode( $notifications );
	} else {
		$items = '';
	}
	if( isset( $_GET['cssjockey-username'] ) && $_GET['cssjockey-username'] == 'reset' ) {
		delete_option( 'cssjockey_username' );
		wp_redirect( admin_url() );
		exit;
	}
	if( isset( $_POST['update_cssjockey_username'] ) ) {

		if( $_POST['cssjockey_username'] == '' ) {
			echo $this->helpers->alert( 'danger cj-mb-0', __( 'You must provide username or email address.', 'cssjockey-add-ons' ), '', false );
		} else {
			$url = $this->helpers->itemInfo( 'author_url' ) . '/io/api/?check_username=' . $_POST['cssjockey_username'];
			$result = $this->helpers->wpRemoteGet( $url );
			$result = json_decode( $result );
			if( isset( $result->error ) ) {
				echo $this->helpers->alert( 'danger cj-mb-0', $result->error, '', false );
			}
			if( isset( $result->success ) ) {
				update_option( 'cssjockey_username', $_POST['cssjockey_username'] );
				wp_redirect( admin_url() );
				exit;
			}
		}
	}
	$cssjockey_username = get_option( 'cssjockey_username' );
	?>
    <div id="cssjockey-dashboard-widget" v-cloak>
        <div class="cj-modules-installed">
            <div class="cj-p-10 cj-welcome-message cj-hidden">
                <p class="cj-fs-14">Thank you for using CSSJockey Add-ons.</p>
                <p>
                    CSSJockey Add-ons is our base framework plugin, that embeds the common functionality of our various <a target="_blank" class="cj-color-warning" href="<?php echo $this->helpers->itemInfo( 'author_url' ) ?>freebie-type/add-on">FREE</a> and
                    <a target="_blank" class="cj-color-warning" href="<?php echo $this->helpers->itemInfo( 'author_url' ) ?>product-type/add-on">PREMIUM</a> add-ons to use common resources.
                </p>
            </div>

			<?php if( ! $cssjockey_username || $cssjockey_username == '' ) { ?>
                <form action="" method="post" class="cj-p-15" style="border-bottom: 1px solid #ededed;">
                    <p class="cj-pb-0">
						<?php echo sprintf( __( 'Enter your <a href="%s" class="color-cj-red" target="_blank">CSSJockey.com</a> username or email address to activate support and license for your free and premium addons.', 'cssjockey-add-ons' ), $this->helpers->itemInfo( 'author_url' ) . 'account' ) ?>
                    </p>
                    <label class="cj-inline-block cj-mb-5 cj-text-bold-removed">CSSJockey username or email address</label>
                    <div class="cj-field cj-has-addons">
                        <p class="cj-control cj-is-expanded">
                            <input name="cssjockey_username" type="text" class="cj-input" placeholder="<?php echo __( 'Username or email address', 'cssjockey-add-ons' ) ?>"/>
                        </p>
                        <p class="cj-control">
                            <button name="update_cssjockey_username" type="submit" class="cj-button cj-is-success"><?php echo __( 'Submit', 'cssjockey-add-ons' ); ?></button>
                        </p>
                    </div>
                </form>
			<?php } else { ?>
                <p class="cj-p-15 cj-mb-0" style="border-bottom: 1px solid #ededed; background-color: #f7f7f7;">
                    <a href="<?php echo $this->helpers->queryString( admin_url() ) . 'cssjockey-username=reset' ?>" class="cj-is-pulled-right cj-color-cj-red"><?php _e( 'Reset', 'cssjockey-add-ons' ) ?></a>
					<?php echo sprintf( __( 'CSSJockey account: <b>%s</b>', 'cssjockey-add-ons' ), $cssjockey_username ) ?>
                </p>
				<?php if( ! empty( $cjaddons_item_vars['module_info'] ) ) { ?>
					<?php foreach( $cjaddons_item_vars['module_info'] as $key => $module_info ) {

						$placeholder_text = __( 'License key', 'cssjockey-add-ons' );
						if( $module_info['envato_id'] != '' && $module_info['envato_id'] != 'NA' ) {
							$placeholder_text = __( 'Envato purchase code', 'cssjockey-add-ons' );
						}
						if( $module_info['envato_id'] == '' || $module_info['envato_id'] == 'NA' ) {
							$placeholder_text = __( 'CSSJockey license key', 'cssjockey-add-ons' );
						}
						$vue_module_data = array(
							'slug' => $key,
							'info' => $module_info,
							//'is_local' => $this->helpers->isLocal(),
							'is_local' => 0,
							'is_dependent' => get_option( 'cjaddons-' . $key . '-dependent-on' ),
							'license_key' => get_option( 'cjaddons_license_' . $module_info['item_id'], false ),
							'core_upgrades_url' => admin_url( 'update-core.php' ),
							'settings_url' => $this->helpers->callbackUrl( $key, 'info', 'cjaddons-' . $key ),
							'text' => array(
								'module_version' => sprintf( __( 'Version %s', 'cssjockey-add-ons' ), $module_info['module_version'] ),
								'license_key_placeholder' => $placeholder_text,
								'btn_text' => __( 'Activate', 'cssjockey-add-ons' ),
								'reset' => __( 'Reset', 'cssjockey-add-ons' ),
								'is_local' => __( 'You will be asked to activate the license on a web server.', 'cssjockey-add-ons' ),
								'is_client' => __( 'Please contact CSSJockey Team for upgrades.', 'cssjockey-add-ons' ),
							),
						);
						$module_data = $this->helpers->jsonEncode( $vue_module_data );
						echo '<module-info cssjockey_username="' . $cssjockey_username . '" module_data="[' . $module_data . ']"></module-info>';
						?>
					<?php } ?>
				<?php } else {
					echo '<div class="cj-p-15">' . sprintf( __( 'No active add-ons found. <a target="_blank" href="%s">Get Add-ons</a>', 'cssjockey-add-ons' ), $this->helpers->itemInfo( 'addons_url' ) ) . '</div>';
				} ?>
			<?php } ?>
        </div>

        <div class="cj-copyright">
            <a target="_blank" class="cj-color-dark cj-is-pulled-right cj-opacity-80" href="https://wordpress.org/support/plugin/cssjockey-add-ons/reviews/"><i class="fa fa-thumbs-up"></i></a>
            <a href="<?php echo $this->helpers->itemInfo( 'docs_url' ) ?>" target="_blank"><?php _e( 'Documentation', 'cssjockey-add-ons' ) ?></a><span class="cj-p-5 cj-opacity-50">|</span>
            <a href="<?php echo $this->helpers->itemInfo( 'support_url' ) ?>" target="_blank"><?php _e( 'Support', 'cssjockey-add-ons' ) ?></a><span class="cj-p-5 cj-opacity-50">|</span>
            <a href="<?php echo admin_url( 'admin.php?page=cjaddons-get-addons' ) ?>"><?php _e( 'Get more add-ons', 'cssjockey-add-ons' ) ?></a>
        </div>

    </div>

</div>