<?php
global $wpdb;

$blocks = $wpdb->get_results( "SELECT * FROM $wpdb->posts WHERE post_type = 'cj-ui-blocks' AND post_status = 'publish'" );

$fields = array();

$fields['heading'] = array(
	'id' => 'heading',
	'type' => 'heading',
	'label' => '',
	'default' => __( 'UI Block Updates', 'cssjockey-add-ons' ),
	'search_form' => 0,
	'options' => '', // array in case of dropdown, checkbox and radio buttons
);

$blocks_array = array();
foreach( $blocks as $key => $block ) {
	$block_class_name = get_post_meta( $block->ID, '_component_class_name', true );
	if( $block_class_name != '' && class_exists( $block_class_name ) ) {
		$class_instance = $block_class_name::getInstance();
		if( isset( $class_instance->version ) ) {
			$block_name = $class_instance->info( 'name' );
			$block_version = $class_instance->version;
			$block_slug = basename( $class_instance->component_dir );
			$blocks_array[ $block_slug ] = $block_version;
			$fields[ $block_slug ] = array(
				'id' => $block_slug,
				'type' => 'info',
				'label' => $block->post_title . '<br><span class="cj-text-normal cj-fs-12 cj-opacity-50">(' . $block_name . ')</span>',
				'info' => '',
				'default' => sprintf( __( 'Installed: Version %s', 'cssjockey-add-ons' ), $block_version ),
				'options' => '', // array in case of dropdown, checkbox and radio buttons
			);
		}
	}
}



$field_keys = array_keys( $fields );

$upgrades_url = $this->helpers->itemInfo( 'author_url' ) . '/download/upgrades.php';
$upgrades_response = $this->helpers->wpRemotePost( $upgrades_url, $blocks_array, array(), 'all' );

$upgrades_available = array();
if( isset( $upgrades_response['response']['code'] ) && $upgrades_response['response']['code'] == 200 ) {
	$upgrades_available = $upgrades_response['body'];
	if( $upgrades_available !== '' ) {
		$upgrades_available = (array) json_decode( $upgrades_available );
	}
}

foreach( $blocks_array as $key => $value ) {
	if( ! isset( $upgrades_available[ $key ] ) ) {
		unset( $fields[ $key ] );
	} else {
		$download_url = $this->helpers->queryString( $this->helpers->itemInfo( 'author_url' ) ) . 'get-product-by-slug=' . $key;
		$fields[ $key ]['default'] = $fields[ $key ]['default'] . '<br>' . sprintf( __( '<span class="cj-color-success">Version %s is available to download.</span> <a target="_blank" href="%s">Download</a>', 'cssjockey-add-ons' ), $upgrades_available[ $key ], $download_url );
	}
}

echo $this->helpers->renderAdminForm( $fields );

