<?php
$helpers = cjaddons_helpers::getInstance();
$form_fields = array();
$success_message = '';
$block_info = $helpers->postInfo( $_GET['block-id'] );
$class_name = $block_info['_component_class_name'];
$class_instance = $class_name::getInstance();
$block_settings = array();
if( isset( $_POST['update_block_settings'] ) ) {
    $helpers->updateUiBlockSettings($_GET['block-id'], $_POST);
	$block_info = $helpers->postInfo( $_GET['block-id'] );
	?>
    <script>
        jQuery(document).ready(function () {
            var $parent_document = window.parent.document;
            $($parent_document).find('#cjaddons-global-modal').removeClass('cj-is-active');
            $($parent_document).find('#cjaddons-global-modal').find('.dynamic-content').html('');
        });
    </script>
	<?php
}

$component_options = $class_instance->info['options'];

$form_fields['heading'] = array(
	'id' => 'block-settings-heading',
	'type' => 'sub-heading',
	'label' => '',
	'info' => '',
	'default' => '<a class="cj-delete cj-is-pulled-right cj-close-iframe"></a>'.$block_info['post_title'],
	'options' => '', // array in case of dropdown, checkbox and radio buttons
);


foreach( $component_options as $key => $form_field ) {
	$form_fields[ $form_field['id'] ] = $form_field;
}

$form_fields['_default_options_heading'] = array(
	'id' => '_default_options_heading',
	'type' => 'sub-heading',
	'label' => '',
	'info' => '',
	'params' => array(),
	'default' => __( 'Additional Settings', 'cssjockey-add-ons' ),
	'options' => '', // array in case of dropdown, checkbox and radio buttons
);
$form_fields['_content_above'] = array(
	'id' => '_content_above',
	'type' => 'textarea',
	'label' => __( 'Content above', 'cssjockey-add-ons' ),
	'info' => __( 'You can add any valid HTML or text here and this will be displayed above this UI block.', 'cssjockey-add-ons' ),
	'params' => array(),
	'default' => (isset($block_info['_content_above'])) ? $block_info['_content_above'] : '',
	'options' => '', // array in case of dropdown, checkbox and radio buttons
);
$form_fields['_content_below'] = array(
	'id' => '_content_below',
	'type' => 'textarea',
	'label' => __( 'Content below', 'cssjockey-add-ons' ),
	'info' => __( 'You can add any valid HTML or text here and this will be displayed below this UI block.', 'cssjockey-add-ons' ),
	'params' => array(),
	'default' => (isset($block_info['_content_below'])) ? $block_info['_content_below'] : '',
	'options' => '', // array in case of dropdown, checkbox and radio buttons
);
$form_fields['_margin'] = array(
	'id' => '_margin',
	'type' => 'spacing',
	'label' => __( 'Margin', 'cssjockey-add-ons' ),
	'info' => __( 'This content will be displayed below this UI block.', 'cssjockey-add-ons' ),
	'params' => array(),
	'default' => (isset($block_info['_margin'])) ? $block_info['_margin'] : '',
	'options' => '', // array in case of dropdown, checkbox and radio buttons
);
$form_fields['_padding'] = array(
	'id' => '_padding',
	'type' => 'spacing',
	'label' => __( 'Padding', 'cssjockey-add-ons' ),
	'info' => __( 'This content will be displayed below this UI block.', 'cssjockey-add-ons' ),
	'params' => array(),
	'default' => (isset($block_info['_padding'])) ? $block_info['_padding'] : '',
	'options' => '', // array in case of dropdown, checkbox and radio buttons
);
$form_fields['_custom_css_code'] = array(
	'id' => '_custom_css_code',
	'type' => 'code-css',
	'label' => __( 'Custom CSS', 'cssjockey-add-ons' ),
	'info' => __('You can specify custom css code for this block.', 'cssjockey-add-ons').'<br><code>.cjaddons-ui-block-'.$block_info['ID'].'{...}</code>',
	'params' => array(
		'placeholder' => '.cjaddons-ui-block-'.$block_info['ID'].'{
	background-color: #222222;
	color: #ffffff;
}'
	),
	'default' => (isset($block_info['_custom_css_code'])) ? $block_info['_custom_css_code'] : '',
	'options' => '', // array in case of dropdown, checkbox and radio buttons
);


$form_fields['submit'] = array(
	'id' => 'update_block_settings',
	'type' => 'submit',
	'label' => '',
	'info' => '',
	'suffix' => '<a href="#" class="cj-button cj-close-iframe cj-ml-10">' . __( 'Cancel', 'cssjockey-add-ons' ) . '</a>',
	'default' => __( 'Update Block Settings', 'cssjockey-add-ons' ),
	'options' => '', // array in case of dropdown, checkbox and radio buttons
);

?>
<div class="cj-scroll">
    <div class="cj-uib-settings-form-loading">
        <i class="fa fa-spinner fa-spin"></i>
    </div>
    <form action="<?php echo $helpers->currentUrl(); ?>" method="post" id="cj-shortcode-form">
		<?php
		$component_settings = $block_info['_component_settings'];
		foreach( $form_fields as $key => $form_field ) {
			$form_fields[ $key ]['default'] = (isset( $component_settings[ $form_field['id'] ] )) ? $component_settings[ $form_field['id'] ] : $form_field['default'];
		}
		?>
		<?php echo $success_message; ?>
		<?php echo $helpers->renderAdminForm( $form_fields ); ?>
    </form>
</div>
<style>
    #wpadminbar,
    #wpfooter,
    #adminmenuback,
    .cssjockey-ui .cj-main-menu,
    .cssjockey-ui h1,
    #cj-admin-content #cj-shortcode-generator,
    #adminmenuwrap {
        display: none !important;
    }
    #cj-admin-content{
        margin: 0 !important;
    }

    .wrap {
        margin: 0 !important;
    }

    #wpcontent {
        padding: 0 !important;
        margin: 0 !important;
    }

    .cssjockey-ui .cj-admin-form .info {
        padding-left: 0 !important;
    }

    #cj-shortcode-form.cj-mt-30 {
        margin-top: 0 !important;
    }

    .cj-notification {
        margin-bottom: 0 !important;
    }

    html {
        margin-top: 0 !important;
        padding-top: 0 !important;
        height: 100%;
    }

    body {
        overflow: hidden;
        overflow-y: scroll;
    }

    #cj-shortcode-form {
        overflow-y: scroll;
        z-index: 1;
    }

    body {
        background: #ffffff !important;
    }

    h1.breadcrumb {
        display: none !important;
    }

    .cj-admin-form {
        border: 0 !important;
    }

    .cj-uib-settings-form-loading {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 2;
        background: #ffffff;
        color: #d8d8d8;
        text-align: center;
    }

    .cj-uib-settings-form-loading i.fa-spin {
        display: inline-block;
        margin-top: 100px;
        font-size: 60px;
    }

</style>
<script>
    var $ = jQuery;
    $(document).ready(function () {
        $('.cj-close-iframe').on('click', function () {
            var $parent_document = window.parent.document;
            $($parent_document).find('#cjaddons-global-modal').removeClass('cj-is-active');
            $($parent_document).find('#cjaddons-global-modal').find('.dynamic-content').html('');
            return false;
        });

    });
    $(window).load(function () {
        $('.cj-uib-settings-form-loading').fadeOut();
    });
</script>