<?php
$upload_dir = $this->helpers->upload_dir['basedir'];
if( is_writable( $upload_dir ) ) {
	$upload_dir_path = str_replace(ABSPATH, '/', $upload_dir);
	$message = sprintf(__('<h2>Click or Drag and Drop UI Block ZIP file here.</h2><p>UI blocks will be saved in <br>%s</p>', 'cssjockey-add-ons'), $upload_dir_path.'/cssjockey-add-ons/ui-blocks/');
	echo '<div id="cjaddons_upload_ui_block"><upload-ui-block message="'.$message.'"></upload-ui-block></div>';
} else {
	$message = sprintf( __( 'Upload directory is NOT writable, please fix directory permissions and refresh this page.<br>%s', 'cssjockey-add-ons' ), $upload_dir );
	echo $this->helpers->alert( 'danger', $message );
}