<?php
global $cjaddons_options;
$file_name = str_replace( '.php', '', basename( __FILE__ ) );

$core_features_array = array(
	'shortcodes' => __('Shortcodes', 'lang-cjaddons'),
	'ui-blocks-editor' => __('UI Blocks Editor', 'lang-cjaddons'),
);

$cjaddons_options[ $file_name ] = array(
	array(
		'type' => 'heading',
		'id' => 'core_global_config_heading',
		'label' => '',
		'info' => '',
		'default' => __( 'Global Settings', 'cssjockey-add-ons' ),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'roles',
		'id' => 'core_admin_bar',
		'label' => __( 'Disable Admin Bar for', 'cssjockey-add-ons' ),
		'info' => __( 'You can choose to disable admin bar for specified roles.', 'cssjockey-add-ons' ),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'dropdown',
		'id' => 'core_combine_assets',
		'label' => __( 'Combine CSS/JS files', 'cssjockey-add-ons' ),
		'info' => __( 'If Yes, then all css and js files required for the framework and installed add-ons will be combined into one file.', 'cssjockey-add-ons' ),
		'default' => 'no',
		'options' => $this->arrays('yes-no'), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'multi-dropdown',
		'id' => 'core_features',
		'label' => __( 'Framework Features', 'cssjockey-add-ons' ),
		'info' => __( 'Select framework features you would like to use on this website.', 'cssjockey-add-ons' ),
		'default' => array('shortcodes', 'ui-blocks-editor'),
		'options' => $core_features_array, // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'sub-heading',
		'id' => 'core_google_maps_heading',
		'label' => '',
		'info' => '',
		'default' => __('Global Maps', 'cssjockey-add-ons'),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'text',
		'id' => 'core_google_maps_key',
		'label' => __('API Key', 'cssjockey-add-ons'),
		'info' => '',
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'sub-heading',
		'id' => 'core_google_recaptcha_heading',
		'label' => '',
		'info' => '',
		'default' => __('Global reCaptcha', 'cssjockey-add-ons'),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'text',
		'id' => 'core_google_recaptcha_site_key',
		'label' => __('Site Key', 'cssjockey-add-ons'),
		'info' => sprintf(__('<a href="%s" tabindex="-1" target="_blank">Click here</a> to get reCaptcha keys.', 'cssjockey-add-ons'), 'https://www.google.com/recaptcha/intro/'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'text',
		'id' => 'core_google_recaptcha_site_secret',
		'label' => __('Site Secret', 'cssjockey-add-ons'),
		'info' => sprintf(__('<a href="%s" tabindex="-1" target="_blank">Click here</a> to get reCaptcha keys.', 'cssjockey-add-ons'), 'https://www.google.com/recaptcha/intro/'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'id' => 'core_google_recaptcha_theme',
		'type' => 'dropdown',
		'label' => __( 'Theme', 'cssjockey-add-ons' ),
		'info' => 'Select reCAPTCHA theme',
		'default' => 'light',
		'options' => array('light' => __( 'Light', 'cssjockey-add-ons' ), 'dark' => __( 'Dark', 'cssjockey-add-ons' )), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'id' => 'core_google_recaptcha_language',
		'type' => 'text',
		'label' => __( 'Language', 'cssjockey-add-ons' ),
		'info' => sprintf( __( 'Specify language, <a href="%s" target="_blank">Click here</a> for language options.', 'cssjockey-add-ons' ), 'https://developers.google.com/recaptcha/docs/language' ),
		'default' => 'en',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
);
