<?php
$framework_features = $this->helpers->savedOption( 'core_features', array() );
if( ! in_array( 'shortcodes', $framework_features ) ) {
    $link = $this->helpers->callbackUrl('config', 'core-global-config', 'cjaddons');
    $message = sprintf(__('Shortcodes are currently disabled, <a href="%s" class="cj-color-warning">Click here</a> to enable shortcodes under Framework features section.', 'lang-cjaddons'), $link);
    echo $this->helpers->alert('info', $message, '', false);
	return false;
}


global $shortcode_tags;
$cjaddons_shortcodes = array();
if( is_array( $shortcode_tags ) && ! empty( $shortcode_tags ) ) {
	foreach( $shortcode_tags as $shortcode_key => $shortcode ) {
		if( strpos( $shortcode_key, 'cjaddons' ) === 0 ) {
			$shortcode_info = (array) $shortcode[0];
			$cjaddons_shortcodes[ $shortcode_key . '_shortcode' ] = $shortcode_info['defaults'];
		}
	}
}
?>
<div class="cj-columns cj-is-multiline cj-is-mobile">
    <div class="cj-column cj-is-3-widescreen cj-is-3-desktop cj-is-12-tablet cj-is-12-mobile">
        <div class="cj-box">
            <aside class="cj-menu">
                <p class="cj-menu-label">
					<?php _e( 'Shortcodes', 'cssjockey-add-ons' ) ?>
                </p>
                <ul class="cj-menu-list cj-shortcodes-list">
					<?php
					if( ! empty( $cjaddons_shortcodes ) ) {
						$count = 0;
						foreach( $cjaddons_shortcodes as $class_name => $shortcode ) {
							$count ++;
							$active_class = ($count == 1) ? 'cj-is-active' : '';
							echo '<li><a href="#shortcode_' . $class_name . '" class="' . $active_class . '">' . $shortcode['info']['name'] . '</a></li>';
						}
					}
					?>
                </ul>
            </aside>
        </div>
    </div>
    <div class="cj-column cj-is-9-widescreen cj-is-9-desktop cj-is-12-tablet cj-is-12-mobile">
		<?php
		if( ! empty( $cjaddons_shortcodes ) ) {
			$count = 0;
			foreach( $cjaddons_shortcodes as $class_name => $shortcode ) {
				$count ++;
				$active_class = ($count == 1) ? 'cj-is-active' : '';
				$shortcode_options = $shortcode['options'];
				$shortcode_options_string = array();
				if( is_array( $shortcode_options ) ) {
					foreach( $shortcode_options as $options_key => $options_value ) {
						$shortcode_options_string[] = ' ' . $options_value['id'] . '=' . '"' . $options_value['default'] . '"';
					}
				}
				$shortcode_tag = '';
				$shortcode_tag .= '[';
				$shortcode_tag .= $shortcode['info']['tag'];
				$shortcode_tag .= implode( '', $shortcode_options_string );
				$shortcode_tag .= ']';
				if( ! $shortcode['info']['single'] ) {
					$shortcode_tag .= __( '..content goes here..', 'cssjockey-add-ons' );
					$shortcode_tag .= '[/' . $shortcode['info']['tag'] . ']';
				}
				?>
                <div id="<?php echo 'shortcode_' . $class_name; ?>" class="cj-box cj-shortcode-box <?php echo $active_class; ?>">
                    <div class="cj-content">
                        <h1 class="cj-m-0"><?php echo $shortcode['info']['name']; ?></h1>
                        <p class="cj-mt-5"><?php echo $shortcode['info']['description']; ?></p>
                        <hr class="cj-mt-10 cj-mb-20">
                        <div class="cj-clearfix">
                            <div class="cj-is-pulled-right">
                            <a class="cj-ml-10 cj-button cj-br-4 cj-is-primary" data-clipboard-text='<?php echo $shortcode_tag; ?>'><span class="cj-icon cj-is-small"><i class="fa fa-copy"></i></span></a>
                            <a target="_blank" href="<?php echo $this->helpers->queryString(site_url()).'cjaddons-preview-shortcode='.$shortcode['info']['tag']; ?>" class="cj-ml-5 cj-button cj-br-4"><span class="cj-icon cj-is-small"><i class="fa fa-eye"></i></span></a>
                            </div>
                            <pre><?php echo $shortcode_tag; ?></pre>
                        </div>
                        <hr class="cj-mt-10 cj-mb-20">
						<?php
						if( is_array( $shortcode_options ) ) {
							foreach( $shortcode_options as $options_key => $options_value ) {
								$options_string = (is_array( $options_value['options'] ) && ! empty( $options_value['options'] )) ? implode( '<br>', array_keys( $options_value['options'] ) ) : '';
								?>
                                <table class="cj-table cj-mb-30">
                                    <thead>
                                    <tr>
                                        <th colspan="2" class="cj-fs-18">
											<?php echo $options_value['id']; ?> :
                                            <div class="cj-text-normal cj-opacity-50"><?php echo $options_value['info']; ?></div>
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td width="150px"><span class="cj-is-pulled-right">:</span><?php _e( 'default', 'cssjockey-add-ons' ) ?></td>
                                        <td><?php echo ($options_value['default'] != '') ? $options_value['default'] : '<i class="cj-opacity-50">(blank)</i>' ?></td>
                                    </tr>
									<?php if( $options_string !== '' ) { ?>
                                        <tr>
                                            <td width="150px"><span class="cj-is-pulled-right">:</span><?php _e( 'options', 'cssjockey-add-ons' ) ?></td>
                                            <td>
                                                <div style="max-height: 200px; overflow: hidden; overflow-y: scroll;">
													<?php echo $options_string; ?>
                                                </div>
                                            </td>
                                        </tr>
									<?php } ?>
                                    </tbody>
                                </table>

								<?php
							}
						}
						?>

                    </div>
                </div>
				<?php
			}
		}
		?>

    </div>
</div>
<style type="text/css">
    .cj-shortcodes-list a,
    .cj-shortcodes-list a:active,
    .cj-shortcodes-list a:visited,
    .cj-shortcodes-list a:focus {
        box-shadow: none !important;
        border: none !important;
    }

    .cj-shortcode-box {
        display: none !important;
    }

    .cj-shortcode-box.cj-is-active {
        display: block !important;
    }
</style>
<script type="text/javascript">
    jQuery(document).ready(function ($) {
        $('.cj-shortcodes-list a').on('click', function () {
            var $el = $(this);
            var $target = $($(this).attr('href'));
            $('.cj-shortcodes-list a').removeClass('cj-is-active');
            $el.addClass('cj-is-active');
            $('.cj-shortcode-box').removeClass('cj-is-active');
            $target.addClass('cj-is-active');
            return false;
        });
    });
</script>