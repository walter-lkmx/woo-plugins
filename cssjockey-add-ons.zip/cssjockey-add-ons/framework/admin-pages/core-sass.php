<?php
$helpers = cjaddons_helpers::getInstance();

$upload_dir = wp_upload_dir();
$upload_dir = $upload_dir['basedir'];
$upload_dir_path = str_replace(ABSPATH, '', $upload_dir);
$upload_dir_path = $upload_dir;

$core_saved_file = $upload_dir . '/cssjockey-ui/ui-base.min.css';
$helpers_saved_file = $upload_dir . '/cssjockey-ui/helpers.min.css';

// save options and redirect to compiler
if( isset( $_POST['save_stylesheets'] ) ) {
	unset( $_POST['save_stylesheets'] );
	$helpers->updateOption( 'core_sass_variables', $_POST );
	$compiler_url = $helpers->queryString( $helpers->callbackUrl( 'config', 'core-sass' ) ) . 'cjaddons_action=save-core-css';
	wp_redirect( $compiler_url );
	exit;
}

if( isset( $_GET['cjaddons_action'] ) && $_GET['cjaddons_action'] == 'save-core-css' ) {
	$scss_content = '';
	$helpers_scss_content = '';
	$scss_content .= '@import "ui-base";';
	$ui_css_content = $this->helpers->compileSass( $scss_content );
	$helpers->putFileContents( $core_saved_file, $ui_css_content );

	$helpers_scss_content .= '@import "helpers";';
	$helpers_css_content = $this->helpers->compileSass( $helpers_scss_content );
	$helpers->putFileContents( $helpers_saved_file, $helpers_css_content );
	do_action( 'cjaddons_core_sass_updated' );
	if( isset( $_GET['redirect'] ) ) {
		wp_redirect( $_GET['redirect'] );
		exit;
	} else {
		wp_redirect( $helpers->callbackUrl( 'config', 'core-sass' ) );
		exit;
	}
}
?>
<div class="cssjockey-ui">
	<?php ob_start() ?>
    <div class="cj-sass-environment-message">
        <!-- wp-content test -->
		<?php if( is_writable( $upload_dir ) ) {
			/* create folder if not exists */
			$helpers->createDirectory( $upload_dir . '/cssjockey-ui' );
			?>
            <p class="cj-m-0 cj-mb-10 cj-color-success"><i class="fa fa-check cj-mr-5"></i> <?php echo sprintf(__( 'Folder <b>%s</b> is writable.', 'cssjockey-add-ons' ), $upload_dir_path) ?></p>
		<?php } ?>
		<?php if( ! is_writable( $upload_dir ) ) { ?>
            <p class="cj-m-0 cj-mb-10 cj-color-danger"><i class="fa fa-times cj-mr-5"></i> <?php echo sprintf(__( 'Folder <b>%s</b> is NOT writable.', 'cssjockey-add-ons' ), $upload_dir_path) ?></p>
		<?php } ?>

        <!-- cssjockey-ui test -->
		<?php if( is_dir( $upload_dir . '/cssjockey-ui' ) ) { ?>
            <p class="cj-m-0 cj-mb-10 cj-color-success"><i class="fa fa-check cj-mr-5"></i> <?php echo sprintf(__( 'Folder <b>%s/cssjockey-ui</b> created and is writable.', 'cssjockey-add-ons' ), $upload_dir_path) ?></p>
		<?php } ?>
		<?php if( ! is_dir( $upload_dir . '/cssjockey-ui' ) ) { ?>
            <p class="cj-m-0 cj-mb-10 cj-color-danger"><i class="fa fa-times cj-mr-5"></i> <?php echo sprintf(__( 'Folder <b>%s/cssjockey-ui</b> not found and is not writable.', 'cssjockey-add-ons' ), $upload_dir_path) ?></p>
		<?php } ?>

        <!-- cssjockey-bootstrap test -->
		<?php if( file_exists( $core_saved_file ) ) { ?>
            <p class="cj-m-0 cj-mb-10 cj-color-success"><i class="fa fa-check cj-mr-5"></i> <?php echo sprintf(__( 'Folder <b>%s/cssjockey-ui/ui-base.min.css</b> found, you can update variables to customize the interface.', 'cssjockey-add-ons' ), $upload_dir_path) ?></p>
		<?php } ?>
		<?php if( ! file_exists( $core_saved_file ) ) { ?>
            <p class="cj-m-0 cj-mb-10 cj-color-danger"><i class="fa fa-times cj-mr-5"></i> <?php echo sprintf(__( 'Folder <b>%s/cssjockey-ui/ui-base.min.css</b> not found, please save settings to resolve this issue.', 'cssjockey-add-ons' ), $upload_dir_path) ?></p>
		<?php } ?>

        <!-- cssjockey-helpers test -->
		<?php if( file_exists( $helpers_saved_file ) ) { ?>
            <p class="cj-m-0 cj-mb-10 cj-color-success"><i class="fa fa-check cj-mr-5"></i> <?php echo sprintf(__( 'Folder <b>%s/cssjockey-ui/helpers.min.css</b> found, you can update variables to customize the interface.', 'cssjockey-add-ons' ), $upload_dir_path) ?></p>
		<?php } ?>
		<?php if( ! file_exists( $helpers_saved_file ) ) { ?>
            <p class="cj-m-0 cj-mb-10 cj-color-danger"><i class="fa fa-times cj-mr-5"></i> <?php echo sprintf(__( 'Folder <b>%s/cssjockey-ui/helpers.min.css</b> not found, please save settings to resolve this issue.', 'cssjockey-add-ons' ), $upload_dir_path) ?></p>
		<?php } ?>
    </div>
	<?php $tests = ob_get_clean(); ?>

	<?php
	$info_fields = array(
		array(
			'id' => 'environment-heading',
			'label' => '',
			'type' => 'sub-heading',
			'search-form' => false,
			'default' => __( 'Environment Tests', 'cssjockey-add-ons' ),
			'options' => '', // array in case of dropdown, checkbox and radio buttons
		),
		array(
			'id' => 'environment-info',
			'label' => '',
			'type' => 'info-full',
			'default' => $tests,
			'options' => '', // array in case of dropdown, checkbox and radio buttons
		)
	);

	echo '<div class="cj-mb-30">';
	echo $this->helpers->renderAdminForm( $info_fields );
	echo '</div>';

	$last_updated = '';
	if( file_exists( $core_saved_file ) ) {
		$saved_timestamp = date( "F d Y H:i A.", filemtime( $core_saved_file ) );
		$saved_timestamp = $helpers->wpDate( filemtime( $core_saved_file ), 'date-time', true );
		$last_updated = sprintf( __( 'Last updated at: <span class="cj-color-info">%s</span>', 'cssjockey-add-ons' ), $saved_timestamp );
	}

	$form_fields['colors-heading'] = array(
		'id' => 'colors-heading',
		'type' => 'heading',
		'label' => __( 'Global Styles', 'cssjockey-add-ons' ),
		'info' => $last_updated,
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	);
	$saved_value = $helpers->getOption( 'core_sass_variables' );
	$sass_default_variables = $helpers->userSassVariables();
	foreach( $sass_default_variables as $key => $value ) {
		$default_value = (isset( $saved_value[ $key ] )) ? $saved_value[ $key ] : $value;
		if(isset($default_value['default'])){
		    $default_value = $default_value['default'];
        }
		$default_value = str_replace( 'px', '', $default_value );
		$form_fields[ $key ] = $value;
		$form_fields[ $key ]['default'] = $default_value;
	}
	$form_fields['save_stylesheets'] = array(
		'id' => 'save_stylesheets',
		'type' => 'submit',
		'label' => '',
		'info' => '',
		'default' => __( 'Update Variables', 'cssjockey-add-ons' ),
		'suffix' => '<div class="cj-block cj-mt-10 cj-mb-10 cj-color-danger cj-text-italic">' . __( 'It may take some time to compile SCSS files, please be patient.', 'cssjockey-add-ons' ) . '</div>',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	);
	?>

    <form action="" method="post">
		<?php echo $helpers->renderAdminForm( $form_fields ); ?>
    </form>

</div>