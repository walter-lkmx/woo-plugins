<!-- TODO: Complete get addons page. -->
<p>Get addons</p>