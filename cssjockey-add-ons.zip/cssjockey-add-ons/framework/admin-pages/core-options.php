<?php
global $cjaddons_options;
$file_name = str_replace('.php', '', basename(__FILE__));
$cjaddons_options[$file_name] = array(
    array(
        'type' => 'text',
        'id' => 'core_license_key',
        'label' => '',
        'info' => '',
        'default' => '',
        'options' => '', // array in case of dropdown, checkbox and radio buttons
    ),
	array(
        'type' => 'text',
        'id' => 'core_license_data',
        'label' => '',
        'info' => '',
        'default' => '',
        'options' => '', // array in case of dropdown, checkbox and radio buttons
    ),
    array(
        'type' => 'hidden',
        'id' => 'core_sass_variables',
        'label' => '',
        'info' => '',
        'default' => array(
	        'body-size' => '16',
	        'family-headings' => 'Montserrat',
	        'family-primary' => 'Montserrat',
	        'family-code' => 'Source Code Pro',
	        'dark' => '#222222',
	        'dark-invert' => '#ffffff',
	        'light' => '#ffffff',
	        'light-invert' => '#222222',
	        'primary' => '#337ab7',
	        'primary-invert' => '#ffffff',
	        'success' => '#5cb85c',
	        'success-invert' => '#ffffff',
	        'danger' => '#d9534f',
	        'danger-invert' => '#ffffff',
	        'info' => '#5bc0de',
	        'info-invert' => '#ffffff',
	        'warning' => '#f0ad4e',
	        'warning-invert' => '#ffffff',
	        'radius' => '3',
	        'radius-small' => '2',
	        'radius-large' => '5',
	        'input-radius' => '2',
        ),
        'options' => '', // array in case of dropdown, checkbox and radio buttons
    ),
    array(
        'type' => 'hidden',
        'id' => 'core_rest_api_routes',
        'label' => '',
        'info' => '',
        'default' => '',
        'options' => '', // array in case of dropdown, checkbox and radio buttons
    ),
	array(
		'type' => 'textarea',
		'id' => 'core_dynamic_sidebars',
		'label' => '',
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	)
);