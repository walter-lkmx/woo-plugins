<?php
global $cjaddons_item_vars;
$cjaddons_item_info = $this->helpers->itemInfo();

$addons_message = '<p>CSSJockey Add-ons is a base plugin which allows you to install our various free and premium add-ons to enable different functionality for your WordPress website. The main goal of this plugin is to utilize the common resources and reduce the server load and make it easy to use any of our add-ons based on your requirements.</p>
<p>Our add-ons are child plugins which may have only one single file to enable a few features, or a combination of many PHP, CSS and JS files to enable a fully functional Job Portal or ERP for your WordPress website and will use the common resources and setup provided by our base framework.</p>';

$cjaddons_core_welcome = array(
	array(
		'type' => 'heading',
		'id' => 'item-info',
		'label' => $cjaddons_item_info['item_name'],
		'info' => '',
		'suffix' => '',
		'search_form' => 0,
		'prefix' => '',
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'info',
		'id' => 'item-version',
		'label' => __( 'Framework', 'cssjockey-add-ons' ),
		'label_suffix' => sprintf( __( 'Version %s', 'cssjockey-add-ons' ), $cjaddons_item_info['item_version'] ),
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'default' => sprintf( __( '%s<a target="_blank" href="%s">Documentation</a> | <a target="_blank" href="%s">Help & Support</a>', 'cssjockey-add-ons' ), $addons_message, $cjaddons_item_info['docs_url'], $cjaddons_item_info['support_url'] ),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
);

if( $this->helpers->itemInfo( 'rest_api' ) ) {
	$api_docs_link = $this->helpers->root_url . '/docs/rest-api/';
	$cjaddons_core_welcome['rest-api-heading'] = array(
		'type' => 'sub-heading',
		'id' => 'rest-api-heading',
		'label' => esc_attr__( 'REST API', 'cssjockey-add-ons' ),
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	);
	$cjaddons_core_welcome['rest-api-url'] = array(
		'type' => 'info',
		'id' => 'rest-api-url',
		'label' => esc_attr__( 'Base Url', 'cssjockey-add-ons' ),
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'default' => '<span class="cj-color-info cj-copy-content" data-clipboard-text="' . $this->helpers->apiUrl() . '">' . $this->helpers->apiUrl() . '</span>',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	);
	$cjaddons_core_welcome['rest-api-docs'] = array(
		'type' => 'info',
		'id' => 'rest-api-docs',
		'label' => esc_attr__( 'Documentation', 'cssjockey-add-ons' ),
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'default' => sprintf( __( '<a href="%s" target="_blank">Click here</a> to visit documentation.', 'cssjockey-add-ons' ), $api_docs_link ),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	);
}

echo $this->helpers->renderAdminForm( $cjaddons_core_welcome );

require_once 'core-welcome-addons.php';