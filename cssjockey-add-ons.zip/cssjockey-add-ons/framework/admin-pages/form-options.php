<?php
global $cjaddons_options;
$helpers = cjaddons_helpers::getInstance();
$yes_no_array = $helpers->arrays( 'yes-no' );
$file_name = str_replace( '.php', '', basename( __FILE__ ) );

$screenshots_array = array(
	'default' => '//placehold.it/400x400/222222/aaaaaa&text=Default',
	'one' => '//placehold.it/400x400/cccccc/aaaaaa&text=Option+One',
	'two' => '//placehold.it/400x400/cc0000/ffffff&text=Option+Two',
);

$cjaddons_options[ $file_name ] = array(
	array(
		'type' => 'heading',
		'id' => 'form-options-heading',
		'label' => __( 'Heading', 'cssjockey-add-ons' ),
		'info' => 'this is heading info',
		'suffix' => '',
		'prefix' => '',
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'nav_menu',
		'id' => 'nav_menu',
		'label' => __( 'Navigation Menus', 'cssjockey-add-ons' ),
		'info' => __( 'this is information', 'cssjockey-add-ons' ),
		'suffix' => '',
		'prefix' => '',
		'default' => '', // use this instead of options.
		'options' => '', // not applicable
	),
	array(
		'type' => 'sidebar',
		'id' => 'sidebar',
		'label' => __( 'Sidebar', 'cssjockey-add-ons' ),
		'info' => __( 'this is information', 'cssjockey-add-ons' ),
		'suffix' => '',
		'prefix' => '',
		'default' => '', // use this instead of options.
		'options' => '', // not applicable
	),
	array(
		'type' => 'screenshot',
		'id' => 'screenshots',
		'label' => __( 'Screenshots', 'cssjockey-add-ons' ),
		'info' => __( 'this is information', 'cssjockey-add-ons' ),
		'suffix' => '',
		'prefix' => '',
		'default' => 'default', // use this instead of options.
		'options' => $screenshots_array, // not applicable
	),
	array(
		'type' => 'gradient',
		'id' => 'gradient',
		'label' => __( 'Gradient', 'cssjockey-add-ons' ),
		'info' => __( 'this is information', 'cssjockey-add-ons' ),
		'suffix' => '',
		'prefix' => '',
		'default' => '', // use this instead of options.
		'options' => '', // not applicable
	),
	array(
		'type' => 'taxonomy-terms',
		'id' => 'taxonomy_terms',
		'label' => __( 'Taxonomy Terms', 'cssjockey-add-ons' ),
		'info' => 'this is info',
		'suffix' => '',
		'prefix' => '',
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),

	array(
		'type' => 'button-with-icon',
		'id' => 'button-with-icon',
		'label' => __( 'Text with icon', 'cssjockey-add-ons' ),
		'info' => 'this is info',
		'suffix' => '',
		'prefix' => '',
		'gap_class' => 'cj-is-4',
		'params' => array(
			'placeholder' => 'Specify button text'
		),
		'default' => array(
			'icon' => 'fa-facebook',
			'text' => 'Facebook',
			'align' => 'left',
		),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),

	// group
	array(
		'type' => 'group',
		'id' => 'parent-option',
		'group' => 'group-name',
		'label' => esc_attr__( 'Group Dropdown', 'cssjockey-add-ons' ),
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'default' => 'one',
		'options' => array('one' => 'One', 'two' => 'Two'), // array in case of dropdown, checkbox and radio buttons
		'options_disable_blank' => true,
		'items' => array(
			'one' => array(
				'test-1' => array(
					'id' => 'test-1',
					'type' => 'text',
					'label' => 'Group ~ One',
					'info' => 'info',
					'default' => 'test 1 value',
					'options' => '', // array in case of dropdown, checkbox and radio buttons
				),
				'test-2' => array(
					'id' => 'test-2',
					'type' => 'text',
					'label' => 'Group ~ One',
					'info' => 'info',
					'default' => 'test 2 value',
					'options' => '', // array in case of dropdown, checkbox and radio buttons
				)
			),
			'two' => array(
				'test-3' => array(
					'id' => 'test-3',
					'type' => 'text',
					'label' => 'Group ~ Two',
					'info' => 'info',
					'default' => 'test 3 value',
					'options' => '', // array in case of dropdown, checkbox and radio buttons
				)
			),
		)
	),

	array(
		'type' => 'css-styles',
		'id' => 'css-styles',
		'label' => __( 'CSS Styles', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => '',
		'prefix' => '',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => 'default value',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),

	array(
		'type' => 'min-max',
		'id' => 'min-max',
		'label' => __( 'Min Max', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => '',
		'prefix' => '',
		'min_params' => array(),
		'max_params' => array(),
		'default' => 'default value',
		'options' => array('$/SF' => '$/SF', '$/Acre' => '$/Acre'), // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'text',
		'id' => 'text-box',
		'label' => __( 'Text box', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => '<i class="fa fa-user"></i>',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => 'default value',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'text-readonly',
		'id' => 'text-readonly',
		'label' => __( 'Readonly Text box', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => '',
		'prefix' => '',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => 'default value',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'text-disabled',
		'id' => 'text-disabled',
		'label' => __( 'Disabled Text box', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => '',
		'prefix' => '',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => 'default value',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'number',
		'id' => 'number',
		'label' => __( 'Number', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => 1234,
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'email',
		'id' => 'email',
		'label' => __( 'Email', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => 'admin@cssjockey.com',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'password',
		'id' => 'password',
		'label' => __( 'Password', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => 'default value',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'url',
		'id' => 'url',
		'label' => __( 'Url', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => ''),
		'default' => 'https://cssjockey.com',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'sub-heading',
		'id' => 'sub-heading',
		'label' => __( 'Sub Heading', 'cssjockey-add-ons' ),
		'info' => 'this is sub-heading info',
		'suffix' => '',
		'prefix' => '',
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'hidden',
		'id' => 'hidden',
		'label' => __( 'Hidden', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => 'default value',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'info',
		'id' => 'info',
		'label' => __( 'Info', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'params' => '',
		'default' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'info-full',
		'id' => 'info-full',
		'label' => __( 'Info Full', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'params' => '',
		'default' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget.',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'textarea',
		'id' => 'textarea',
		'label' => __( 'Textarea', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => 'default value',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'dropdown',
		'id' => 'dropdown',
		'label' => __( 'Dropdown', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => array('no'),
		'options' => $yes_no_array, // array in case of dropdown, checkbox and radio buttons
		'options_disable_blank' => false,
	),
	array(
		'type' => 'multi-dropdown',
		'id' => 'multi-dropdown',
		'label' => __( 'Multi Dropdown', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => array('no'),
		'options' => $yes_no_array, // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'checkbox',
		'id' => 'checkbox',
		'label' => __( 'Checkbox', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => array('no'),
		'options' => $yes_no_array, // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'radio',
		'id' => 'radio',
		'label' => __( 'Radio', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => 'no',
		'options' => $yes_no_array, // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'checkbox-inline',
		'id' => 'checkbox-inline',
		'label' => __( 'Checkbox Inline', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => array('no'),
		'options' => $yes_no_array, // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'radio-inline',
		'id' => 'radio-inline',
		'label' => __( 'Radio Inline', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => 'no',
		'options' => $yes_no_array, // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'sub-heading',
		'id' => 'wordpress-fields',
		'label' => 'WordPress fields demo here..',
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'default' => __( 'WordPress Fields', 'cssjockey-add-ons' ),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'user',
		'id' => 'user',
		'label' => __( 'User', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'users',
		'id' => 'users',
		'label' => __( 'Users', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'role',
		'id' => 'role',
		'label' => __( 'Role', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'roles',
		'id' => 'roles',
		'label' => __( 'Roles', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'page',
		'id' => 'page',
		'label' => __( 'Page', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'pages',
		'id' => 'pages',
		'label' => __( 'Pages', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'post',
		'id' => 'post',
		'label' => __( 'Post', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'posts',
		'id' => 'posts',
		'label' => __( 'Posts', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'post-type',
		'id' => 'post-type',
		'label' => __( 'Post Type', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'post-types',
		'id' => 'post-types',
		'label' => __( 'Post Types', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'category',
		'id' => 'category',
		'label' => __( 'Category', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'categories',
		'id' => 'categories',
		'label' => __( 'Categories', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'taxonomy',
		'id' => 'taxonomy',
		'label' => __( 'Taxonomy', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'taxonomies',
		'id' => 'taxonomies',
		'label' => __( 'Taxonomies', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'taxonomy-terms',
		'id' => 'taxonomy_terms',
		'label' => __( 'Taxonomy Terms', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'get_terms_params' => array('parent' => 0),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'tag',
		'id' => 'tag',
		'label' => __( 'tag', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'tags',
		'id' => 'tags',
		'label' => __( 'Tags', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'sub-heading',
		'id' => 'special-fields',
		'label' => 'Special fields demo here..',
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'default' => __( 'Special Fields', 'cssjockey-add-ons' ),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'date',
		'id' => 'date',
		'label' => __( 'Date', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'date-time',
		'id' => 'date-time',
		'label' => __( 'Date Time', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'time',
		'id' => 'time',
		'label' => __( 'Time', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'color',
		'id' => 'color',
		'label' => __( 'Color', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '#cc0000',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'code-css',
		'id' => 'code-css',
		'label' => __( 'CSS Code', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'code-js',
		'id' => 'code-js',
		'label' => __( 'JS Code', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => 'alert("hello");',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'code-html',
		'id' => 'code-html',
		'label' => __( 'HTML Code', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => '<div class="cj-hidden">this is html content</div>',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'file',
		'id' => 'file',
		'label' => __( 'Upload File', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'multiple' => 0,
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => 'http://supportezzy.dev/wp-content/uploads/2017/04/icon-128.png',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'files',
		'id' => 'files',
		'label' => __( 'Upload Files', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'multiple' => 1,
		'params' => '',
		'default' => array('http://supportezzy.dev/wp-content/uploads/2017/04/icon-128.png', 'http://supportezzy.dev/wp-content/uploads/2017/04/icon-128.png', 'http://supportezzy.dev/wp-content/uploads/2017/04/icon-128.png'),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'file-raw',
		'id' => 'file-raw',
		'label' => __( 'Upload Files in Raw Format', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'multiple' => 1,
		'params' => '',
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'sortable',
		'id' => 'sortable',
		'label' => __( 'Sortable', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => '',
		'prefix' => '',
		'params' => '',
		'default' => $yes_no_array,
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'repeatable',
		'id' => 'repeat-test',
		'label' => __( 'Repeatable', 'cssjockey-add-ons' ),
		'info' => __( 'Specify a name for your api', 'cssjockey-add-ons' ),
		'suffix' => '',
		'prefix' => '',
		'default' => array('one', 'two'), // use this instead of options.
		'options' => '', // not applicable
	),
	array(
		'type' => 'wysiwyg',
		'id' => 'wysiwyg',
		'label' => __( 'WYSIWYG', 'cssjockey-add-ons' ),
		'label_suffix' => '<i>' . __( 'This is label suffix', 'cssjockey-add-ons' ) . '</i>',
		'info' => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.', 'cssjockey-add-ons' ),
		'suffix' => 'suffix',
		'prefix' => 'prefix',
		'params' => array('placeholder' => 'this is placeholder'),
		'default' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget.',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'google_recaptcha',
		'id' => 'google_recaptcha',
		'label' => __( 'Google Recaptcha', 'cssjockey-add-ons' ),
		'info' => __( 'Specify a name for your api', 'cssjockey-add-ons' ),
		'suffix' => '',
		'prefix' => '',
		'api_key' => '6LcSwOASAAAAAPV_u44OZeVac6IcaU4XeHpbkbNB',
		'api_secret' => '6LcSwOASAAAAACZEFdpj34Vcc638GDXIxA5oSMCr',
		'theme' => 'light',
		'language' => 'en',
		'default' => '',
		'options' => '',
	),

	array(
		'type' => 'google-address',
		'id' => 'google-address',
		'label' => __( 'Google Address', 'cssjockey-add-ons' ),
		'info' => __( 'Specify a name for your api', 'cssjockey-add-ons' ),
		'suffix' => '',
		'prefix' => '',
		'default' => '', // use this instead of options.
		'options' => '', // not applicable
	),
	array(
		'type' => 'auto-complete',
		'id' => 'auto-complete',
		'label' => esc_attr__( 'Auto Complete', 'cssjockey-add-ons' ),
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'default' => '',
		'settings' => array(
			'url' => admin_url( 'admin-ajax.php' ) . '?action=cjaddons_query_users',
			'post_data' => array(
				'orderby' => 'login',
				'order' => 'ASC',
				'search' => '*input_query*',
			),
			'key_field' => 'ID',
			'value_field' => 'display_name',
			'search_field' => 'user_login',
		),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'submit',
		'id' => 'submit-form',
		'info' => 'This is info for the button',
		'label' => '',
		'prefix' => '',
		'suffix' => '',
		'params' => array(
			'class' => 'cj-button cj-is-primary cj-is-medium'
		),
		'default' => __( 'Submit', 'cssjockey-add-ons' ),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),

);
echo '<form action="" method="post">';
echo $this->helpers->renderAdminForm( $cjaddons_options[ $file_name ] );
echo '</form>';