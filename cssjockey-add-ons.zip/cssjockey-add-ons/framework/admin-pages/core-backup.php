<?php
global $wpdb;
$errors = null;
$table_names = array();
$tables = array_keys( $this->helpers->item_vars['migrations'] );
$dump = array();
foreach( $tables as $key => $table ) {
	$table_name = $wpdb->prefix . $table;
	$dump[ $table_name ] = $wpdb->get_results( "SELECT * FROM $table_name" );
	$table_names[] = $table_name;
}

if( isset( $_POST['import'] ) ) {
	if( $_POST['backup-string'] != '' ) {
		$db_tables = @unserialize( urldecode( $_POST['backup-string'] ) );
		if( is_array( $db_tables ) ) {
			foreach( $db_tables as $table_name => $rows ) {
				$wpdb->query( "TRUNCATE TABLE $table_name" );
				foreach( $rows as $key => $data ) {
					$this->helpers->insert( $table_name, $data );
				}
			}
		} else {
			$errors[] = __( 'Invalid backup data.', 'cssjockey-add-ons' );
		}
	} else {
		$errors[] = __( 'We need the crazy string to import from your previous backup.', 'cssjockey-add-ons' );
	}
}

if( ! is_null( $errors ) ) {
	echo $this->helpers->alert( 'error', $errors );
}

$export_fields = array(
	array(
		'type' => 'sub-heading',
		'id' => 'core_export_heading',
		'label' => __( 'Export Settings', 'cssjockey-add-ons' ),
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'search-form' => false,
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'textarea',
		'id' => 'export',
		'label' => __( 'Export Settings and Options', 'cssjockey-add-ons' ),
		'label_suffix' => __( '<i>All database tables and settings.</i>', 'cssjockey-add-ons' ),
		'info' => sprintf( __( 'This crazy string contain all data saved in following database tables: <p class="cj-color-info">%s</p>', 'cssjockey-add-ons' ), implode( ', ', $table_names ) ),
		'suffix' => '',
		'prefix' => '',
		'params' => array('readonly' => 'true'),
		'default' => urlencode( serialize( $dump ) ),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
);

$import_fields = array(
	array(
		'type' => 'sub-heading',
		'id' => 'core_import_heading',
		'label' => __( 'Import from previous backup', 'cssjockey-add-ons' ),
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'search-form' => false,
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'textarea',
		'id' => 'backup-string',
		'label' => __( 'Crazy String', 'cssjockey-add-ons' ),
		'label_suffix' => __( '<i>Yes we need the crazy string here.</i>', 'cssjockey-add-ons' ),
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'params' => '',
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'submit',
		'id' => 'import',
		'label' => '',
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'params' => array('class' => 'cj-button cj-is-medium cj-is-primary'),
		'default' => __( 'Import Backup', 'cssjockey-add-ons' ),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
);

echo '<form action="" method="post" enctype="multipart/form-data">';
echo $this->helpers->renderAdminForm( $export_fields );
echo '</form>';

echo '<form action="" method="post" enctype="multipart/form-data" class="cj-mt-30">';
echo $this->helpers->renderAdminForm( $import_fields );
echo '</form>';