<?php

if( $this->helpers->itemInfo( 'rest_api' ) ) {

	$rest = wp_remote_get( $this->helpers->apiUrl() );
	$response = json_decode( $rest['body'] );

	$routes = array();
	$options = array();
	$options['heading'] = array(
		'type' => 'heading',
		'id' => 'api-routes-heading',
		'label' => __( 'REST API Routes', 'cssjockey-add-ons' ),
		'info' => sprintf( __( 'You can install <a target="_blank" href="%s">Postman</a> app to test api routes.', 'cssjockey-add-ons' ), 'https://www.getpostman.com/' ),
		'suffix' => '',
		'prefix' => '',
		'default' => '',
		'options' => '',
	);

	foreach( $response->routes as $key => $route_info ) {
		if( strstr( $key, 'cjaddons/' ) ) {
			$methods = implode( ' | ', $route_info->methods );
			$endpoint = $route_info->_links->self;
			$options[ $key ] = array(
				'type' => 'info',
				'id' => sanitize_title( $key ),
				'label' => '<span>' . $methods . '</span>',
				'info' => '',
				'suffix' => '',
				'prefix' => '',
				'default' => '<span class="cj-color-info" data-clipboard-text="' . $endpoint . '">' . $endpoint . '</span>',
				'options' => '',
			);
		}
	}
	echo $this->helpers->renderAdminForm( $options );
} else {
	echo $this->helpers->alert( 'danger', __( 'No REST API routes found.', 'cssjockey-add-ons' ), null, false );
}