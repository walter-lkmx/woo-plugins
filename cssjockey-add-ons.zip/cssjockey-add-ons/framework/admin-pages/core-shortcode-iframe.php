<?php
$form_fields = null;
$shortcode_class_name = $_GET['shortcode'] . '_shortcode';
$shortcode_defaults = [];
if( class_exists( $shortcode_class_name ) ) {
	$shortcode_class = $shortcode_class_name::getInstance();
	$shortcode_defaults = $shortcode_class->defaults();
}
if( isset( $shortcode_defaults['options'] ) && is_array( $shortcode_defaults['options'] ) ) {
	$close_btn = '<a class="cj-is-pulled-right cj-close-shortcodes-panel"><i class="fa fa-times-circle"></i></a>';
	$info_fields['shortcode_name'] = array(
		'id' => 'shortcode_name',
		'type' => 'heading',
		'label' => $close_btn . $shortcode_defaults['info']['name'],
		'default' => '',
		'search_form' => 0,
		'info' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	);
	$info_fields['shortcode_description'] = array(
		'id' => 'shortcode_name',
		'type' => 'info-full',
		'label' => '',
		'default' => $shortcode_defaults['info']['description'],
		'info' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	);
	if( ! $shortcode_defaults['info']['single'] ) {
		$info_fields['shortcode_description'] = array(
			'id' => 'default_content',
			'type' => (isset( $shortcode_defaults['info']['default_content_type'] )) ? $shortcode_defaults['info']['default_content_type'] : 'wysiwyg',
			'label' => __( 'Content', 'cssjockey-add-ons' ),
			'default' => (isset( $shortcode_defaults['info']['default_content'] )) ? $shortcode_defaults['info']['default_content'] : '',
			'info' => '',
			'options' => '', // array in case of dropdown, checkbox and radio buttons
		);
	}
	$form_fields = $shortcode_defaults['options'];
	$form_fields = array_merge( $info_fields, $form_fields );

	$form_fields['shortcode_tag'] = array(
		'type' => 'hidden',
		'id' => 'shortcode_tag',
		'label' => '',
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'default' => $shortcode_defaults['info']['tag'],
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	);

	$form_fields['shortcode_type'] = array(
		'type' => 'hidden',
		'id' => 'shortcode_type',
		'label' => '',
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'default' => ($shortcode_defaults['info']['single']) ? '' : 'closed',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	);

	$form_fields['submit'] = array(
		'id' => 'submit',
		'type' => 'submit',
		'label' => '',
		'params' => array('class' => 'cj-button cj-is-primary cj-is-medium'),
		'info' => '',
		'default' => __( 'Insert Shortcode', 'cssjockey-add-ons' ),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	);
}
?>

<div class="cj-shortcode-loading">
    <i class="fa fa-spinner fa-spin"></i>
</div>
<form id="cj-shortcode-form">
	<?php echo $this->helpers->renderAdminForm( $form_fields ); ?>
</form>
<style>
    #wpadminbar,
    #wpfooter,
    #adminmenuback,
    .cssjockey-ui .main-menu,
    .cssjockey-ui h1,
    #cj-admin-content #cj-shortcode-generator,
    #adminmenuwrap {
        display: none;
    }

    .cssjockey-ui .cj-admin-form .cj-info {
        padding-left: 0 !important;
    }

    #cj-shortcode-form.cj-mt-30 {
        margin-top: 0 !important;
    }

    body {
        overflow: hidden;
    }

    #cj-shortcode-form {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        overflow-x: hidden;
        overflow-y: scroll !important;
        z-index: 1;
    }

    body {
        background: #ffffff !important;
    }

    .cj-admin-form {
        border: 0px !important;
    }

    .cj-shortcode-loading {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 2;
        background: #ffffff;
        color: #d8d8d8;
        text-align: center;
    }

    .cj-shortcode-loading i.fa-spin {
        display: inline-block;
        margin-top: 100px;
        font-size: 60px;
    }

</style>
<script>
    var $ = jQuery;
    $(document).ready(function () {
        $(document).unbind('submit').on('submit', '#cj-shortcode-form', function () {
            var data = {
                'action': 'prepare_shortcode_tag',
                'form_data': $(this).serialize()
            };
            $.post(ajaxurl, data, function (response) {
                window.parent.postMessage(['shortcodeTag', response], '*');
                return false;
            });
            return false;
        });

        $(document).on('click', '.cj-close-shortcodes-panel', function () {
            window.parent.postMessage(['closeShortcodesPanel', 1], '*');
        });

    });
    $(window).load(function () {
        $('.cj-shortcode-loading').fadeOut();
        window.parent.postMessage(['shortcodeSettingsLoaded', 'yes'], '*');
    });
</script>
