<?php
global $wpdb, $cjaddons_item_vars;
$cjaddons_item_info = $cjaddons_item_vars['info'];
$text_domain_string = $this->helpers->itemInfo( 'text_domain' );
$results = $wpdb->get_results( "SHOW TABLES LIKE '%'" );
$uninstall_tables = [];
foreach( $results as $index => $value ) {
	foreach( $value as $tableName ) {
		if( strpos( $tableName, $text_domain_string ) ) {
			$uninstall_tables[] = $tableName;
		}
	}
}

$sync_db_nonce = wp_create_nonce( 'cjaddons-sync-db-options' );
$sync_options_url = $this->helpers->queryString( $this->helpers->callbackUrl( 'config', 'core-uninstall' ) ) . 'cjaddons-sync-db=' . $sync_db_nonce;
$actions = '';
$actions .= '<a href="' . $sync_options_url . '" class="cj-button cj-is-success cj-mr-10 cj-confirm" data-confirm="' . __( "Are you sure? You must take a backup of your database to be sure.", 'cssjockey-add-ons' ) . '">' . __( 'Sync Options', 'cssjockey-add-ons' ) . '</a>';
$actions .= '<a href="' . wp_nonce_url( $this->helpers->callbackUrl( 'config', 'core-uninstall' ) . '&cjaddons-action=reset-all-data' ) . '" class="cj-button cj-is-danger cj-mr-10 cj-confirm" data-confirm="' . __( "Are you sure?\nThis will reset all settings and data saved by this plugin.", 'cssjockey-add-ons' ) . '">' . __( 'Reset All Data', 'cssjockey-add-ons' ) . '</a>';
$actions .= '<a href="' . wp_nonce_url( $this->helpers->callbackUrl( 'config', 'core-uninstall' ) . '&cjaddons-action=uninstall' ) . '" class="cj-button cj-is-danger cj-mr-10 cj-confirm" data-confirm="' . __( "Are you sure?\nThis will remove all data, database tables listed on this page and deactivate itself.", 'cssjockey-add-ons' ) . '">' . __( 'Complete Uninstall', 'cssjockey-add-ons' ) . '</a>';

if( isset( $_GET['cjaddons-action'] ) && $_GET['cjaddons-action'] == 'reset-all-data' ) {
	if( wp_verify_nonce( $_GET['_wpnonce'] ) ) {
		$tables = array_keys( $cjaddons_item_vars['migrations'] );
		foreach( $tables as $key => $table_name ) {
			$remove_table = $wpdb->prefix . $table_name;
			$wpdb->query( "DROP TABLE {$remove_table}" );
		}
		delete_option( "cjaddons_db_version" );
	}
	$this->helpers->removeSupportingOptions();
	$location = $this->helpers->queryString( $this->helpers->callbackUrl( 'config', 'core-uninstall' ) ) . 'cjaddons_redirect=' . urlencode( $this->helpers->callbackUrl( 'config', 'core-welcome' ) );
	wp_redirect( $location );
	exit;
}

if( isset( $_GET['cjaddons_redirect'] ) && $_GET['cjaddons_redirect'] != '' ) {
	$location = $_GET['cjaddons_redirect'];
	wp_redirect( $location );
	exit;
}

if( isset( $_GET['cjaddons-action'] ) && $_GET['cjaddons-action'] == 'uninstall' ) {
	if( wp_verify_nonce( $_GET['_wpnonce'] ) ) {

		$tables = array_keys( $cjaddons_item_vars['migrations'] );
		foreach( $tables as $key => $table_name ) {
			$remove_table = $wpdb->prefix . $table_name;
			$wpdb->query( "DROP TABLE {$remove_table}" );
		}

		$table_options = $wpdb->base_prefix . $this->helpers->itemInfo( 'options_table' );
		$cjaddons_plugin_options = $wpdb->get_results( "SELECT option_name FROM $wpdb->options" );
		if( is_array( $cjaddons_plugin_options ) && ! empty( $cjaddons_plugin_options ) ) {
			foreach( $cjaddons_plugin_options as $o_key => $o_value ) {
				if( strstr( $o_value->option_name, 'cjaddons_' ) ) {
					delete_option( $o_value->option_name );
				}
			}
		}

		delete_option( "cjaddons_db_version" );
		$plugin_name = basename( $this->helpers->root_dir );
		$active_plugins = get_option( 'active_plugins' );
		foreach( $active_plugins as $key => $plugin ) {
			if( substr_count( $plugin, $plugin_name ) > 0 ) {
				unset( $active_plugins[ $key ] );
			}
		}

		$this->helpers->removeSupportingOptions();

		update_option( 'active_plugins', $active_plugins );
		wp_redirect( admin_url( 'plugins.php' ) );
		exit;
	} else {
		wp_redirect( admin_url( 'plugins.php' ) );
		exit;
	}
}

$cjaddons_core_welcome = array(
	array(
		'type' => 'sub-heading',
		'id' => 'item-info',
		'label' => sprintf( __( 'Uninstall %s', 'cssjockey-add-ons' ), ucwords( $cjaddons_item_info['item_name'] ) ),
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'search-form' => false,
		'default' => '',
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'info-full',
		'id' => 'table-names',
		'label' => '',
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'default' => sprintf( __( 'To uninstall completely, de-activate this %s and remove the following tables from database. <p class="cj-mt-10 cj-color-danger">%s</p>', 'cssjockey-add-ons' ), $cjaddons_item_info['item_type'], implode( '<br>', $uninstall_tables ) ),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
	array(
		'type' => 'info-full',
		'id' => 'confirm',
		'label' => '',
		'label_suffix' => '',
		'info' => '',
		'suffix' => '',
		'prefix' => '',
		'params' => '',
		'default' => $actions,
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	),
);

echo '<form action="" method="post" enctype="multipart/form-data" class="cj-mt-30">';
echo $this->helpers->renderAdminForm( $cjaddons_core_welcome );
echo '</form>';