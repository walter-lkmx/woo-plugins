<?php
    $page_url = $this->helpers->callbackUrl('config', 'core-ui-blocks', 'cjaddons', true);
    if(!isset($_GET['tab'])){
        wp_redirect($page_url.'tab=saved');
        exit;
    }
?>
<div id="cj-vue-ui-block-selector">
    <cjaddons-ui-block-selector></cjaddons-ui-block-selector>
</div>
<style>
    html {
        padding-top: 0 !important;
    }

    #wpcontent, #wpbody-content {
        margin: 0 !important;
        padding: 0 !important;
    }

    #wpbody-content .wrap {
        padding: 0 !important;
        margin: 0 !important;
    }

    .wrap h1.breadcrumb,
    .wrap .cj-main-menu,
    #wpadminbar, #adminmenumain {
        margin: 0 !important;
        padding: 0 !important;
        display: none !important;
    }

    #cj-admin-content {
        margin-top: 0 !important;
    }
    #wpfooter{
        display: none !important;
    }
</style>