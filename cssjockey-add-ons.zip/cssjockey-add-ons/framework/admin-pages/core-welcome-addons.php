<?php
global $wpdb, $cjaddons_item_vars;
$modules = (isset($cjaddons_item_vars['module_info']) && is_array($cjaddons_item_vars['module_info'])) ? $cjaddons_item_vars['module_info'] : array();
$upgrades = get_option( 'cjaddons_upgrades_available', array() );

$addons_form_fields = array();
$addons_form_fields['heading'] = array(
	'id' => 'download_heading',
	'type' => 'sub-heading',
	'label' => '',
	'info' => '',
	'default' => '<a href="https://cssjockey.com/shop" target="_blank" class="cj-button cj-is-small cj-mt-inverse-3 cj-is-primary cj-is-pulled-right">' . __( 'Get Add-ons', 'cssjockey-add-ons' ) . '</a>' . __( 'Activate & Download', 'cssjockey-add-ons' ),
	'options' => '', // array in case of dropdown, checkbox and radio buttons
);

$plugin_dir = WP_PLUGIN_DIR;
if( is_writable( $plugin_dir ) ) {
	$message = __( '<h2>Click or Drag and Drop Addon ZIP file here.</h2>', 'cssjockey-add-ons' );
	$upload_app_ui = '<div id="cjaddons_upload_addon"><upload-addon message="' . $message . '"></upload-addon></div>';
} else {
	$message = sprintf( __( 'Upload directory is NOT writable, please fix directory permissions and refresh this page.<br>%s', 'cssjockey-add-ons' ), $plugin_dir );
	$upload_app_ui = $this->helpers->alert( 'danger', $message );
}

$addons_form_fields['upload-app'] = array(
	'id' => 'upload-app',
	'type' => 'info-full',
	'label' => '',
	'info' => '',
	'default' => $upload_app_ui,
	'options' => '', // array in case of dropdown, checkbox and radio buttons
);

if( is_array( $modules ) && ! empty( $modules ) ) {
	foreach( $modules as $key => $module_info ) {

		$installed_version = $module_info['module_version'];
		$license_key = get_option( 'cjaddons_license_' . $module_info['module_id'], '' );
		$suffix_text = '';
		$info = 'Installed Version: ' . $installed_version;
		$label_suffix = '<a target="_blank" class="cj-color-info" href="https://cssjockey.com/documentation/' . $module_info['module_id'] . '">' . __( 'Documentation', 'cssjockey-add-ons' ) . '</a> | <a target="_blank" class="cj-color-info" href="https://cssjockey.com/support">' . __( 'Support', 'cssjockey-add-ons' ) . '</a>';

		if( $license_key == '' ) {
			$suffix_text = '<span class="cj-color-danger">' . __( 'Activate', 'cssjockey-add-ons' ) . '</span>';
		}
		if( $license_key != '' ) {
			$suffix_text = '<span class="cj-color-success">' . __( 'Download', 'cssjockey-add-ons' ) . '</span>';
		}
		if( isset( $upgrades[ $module_info['module_id'] ] ) && $module_info['module_version'] != $upgrades[ $module_info['module_id'] ] ) {
			$info .= '<span class="cj-opacity-50 cj-p-10">|</span>';
			$info .= '<span class="cj-color-success">' . sprintf( __( 'Upgrade Available (%s)', 'cssjockey-add-ons' ), $upgrades[ $module_info['module_id'] ] ) . '</span>';
			$info .= '<span class="cj-opacity-50 cj-p-10">|</span>';
			$info .= '<a target="_blank" href="https://cssjockey.com/documentation/' . $module_info['module_id'] . '/change-log">' . __( 'Change log', 'cssjockey-add-ons' ) . '</a>';
		}

		$field_params = array(
			'placeholder' => __( 'Enter your CSSJockey license key or Envato purchase code', 'cssjockey-add-ons' ),
			'data-download-update' => $module_info['module_id'],
			'data-install-url' => site_url(),
			'data-action' => ($license_key == '') ? 'activate' : 'download',
		);

		$parent_addon = get_option( 'cjaddons-' . $key . '-dependent-on' );
		if( is_array( $parent_addon ) && ! empty( $parent_addon ) ) {
			$field_params['data-parent-slug'] = $parent_addon['module_id'];
			$license_key = get_option( 'cjaddons_license_' . $parent_addon['module_id'], '' );
			$label_suffix .= '<p class="cj-mt-5 cj-text-italic cj-mb-0">' . sprintf( __( 'Bundled with %s', 'cssjockey-add-ons' ), $parent_addon['module_name'] ) . '</p>';
		}

		if( $license_key !== '' ) {
			$info .= '<span class="cj-opacity-50 cj-p-10">|</span>';
			$info .= '<a href="#" data-slug="'.$module_info['module_id'].'" data-reset-license="' . $license_key . '" data-install-url="' . site_url() . '">' . __( 'Reset License', 'cssjockey-add-ons' ) . '</a>';
		}

		if( $module_info['item_id'] != 'NA' ) {
			$addons_form_fields[ $key ] = array(
				'id' => $key,
				'type' => 'text',
				'label' => $module_info['module_name'],
				'label_suffix' => $label_suffix,
				'info' => $info,
				'suffix' => $suffix_text,
				'params' => $field_params,
				'default' => $license_key,
				'options' => '', // array in case of dropdown, checkbox and radio buttons
			);
		}
	}
} else {
	$addons_form_fields['not-found'] = array(
		'id' => 'not-found',
		'type' => 'info-full',
		'label' => '',
		'info' => '',
		'default' => __( 'We did not find any active addons on this website.', 'cssjockey-add-ons' ),
		'options' => '', // array in case of dropdown, checkbox and radio buttons
	);
}

echo '<div class="cj-mt-30">';
echo $this->helpers->renderAdminForm( $addons_form_fields );
echo '<div>';