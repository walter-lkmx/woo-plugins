<?php
$assistant = get_option( 'cjaddons_setup_assistant' );

if( is_array( $assistant ) && isset( $assistant['status'] ) && $assistant['status'] == 'active' ) { ?>

	<?php if( $assistant['step'] == 1 ): ?>
        <div class="cjaddons-assistant-overlay"></div>
	<?php endif; ?>

    <div class="cjaddons-assistant">
        <div class="logo">
            <i class="icon-cssjockey cj-color-cj-red"></i>
        </div>
        <h3 class="cj-heading"><?php echo sprintf( __( '%s Setup Assistant', 'cssjockey-add-ons' ), $this->helpers->itemInfo( 'item_name' ) ) ?></h3>
		<?php
		$step_file = dirname( __FILE__ ) . '/steps/step-' . $assistant['step'] . '.php';
		if( file_exists( $step_file ) ) {
			ob_start();
			require_once $step_file;
			echo ob_get_clean();
		}
		?>
    </div>
<?php }