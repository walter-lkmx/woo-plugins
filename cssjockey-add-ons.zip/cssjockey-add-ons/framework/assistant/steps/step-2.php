<?php $current_user = wp_get_current_user(); ?>
    <div class="cssjockey-ui">
        <p>
            You can use auto setup feature which will automatically create required pages and add shortcodes to display forms for login, register and other features.
        </p>
    </div>
<?php
$next_link = $this->helpers->callbackUrl( 'addon-frontend-auth', 'page-setup' );
echo $this->buttons( $next_link, __('Next', 'cssjockey-add-ons') );
?>