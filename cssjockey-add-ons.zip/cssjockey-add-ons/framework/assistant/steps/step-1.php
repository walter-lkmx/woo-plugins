<?php $current_user = wp_get_current_user(); ?>
    <div class="cssjockey-ui">
        <p>Hello <b><?php echo $current_user->display_name; ?></b>! Thank you for choosing <?php echo $this->helpers->itemInfo('item_name'); ?>.</p>
        <p>
            I will help you setup this plugin and show you some of it's awesome features.
        </p>
        <p>
            First of all we would need to create a few pages with specific shortcodes to enable auth functionality.
        </p>
    </div>
<?php
$next_link = $this->helpers->callbackUrl( 'addon-frontend-auth', 'page-setup' );
echo $this->buttons( $next_link, __('Next', 'cssjockey-add-ons') );
?>