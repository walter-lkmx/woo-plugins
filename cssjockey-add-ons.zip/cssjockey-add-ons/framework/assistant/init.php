<?php
if( ! class_exists( 'cjaddons_setup_assistant' ) ) {
	class cjaddons_setup_assistant {
		public $helpers, $assistant;
		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_helpers::getInstance();
			if( $this->helpers->itemInfo( 'assistant' ) ) {
				$assistant_init = array(
					'status' => 'active',
					'step' => 1,
				);
				$this->assistant = get_option( 'cjaddons_setup_assistant' );
				if( ! $this->assistant ) {
					add_option( 'cjaddons_setup_assistant', $assistant_init );
				}
				add_action( 'admin_footer', array($this, 'init') );
				add_action( 'admin_init', array($this, 'handleButtons') );
			}
		}

		public function init() {
			ob_start();
			require_once 'steps.php';
			echo ob_get_clean();
		}

		public function buttons( $next_link = '', $next_text = '' ) {
			$exit_link = $this->helpers->queryString( $this->helpers->callbackUrl() ) . 'cjaddons_assistant=exit';
			$buttons = '';
			$prev_link = '';

			$prev_step = $this->assistant['step'] - 1;
			if( file_exists( dirname( __FILE__ ) . '/steps/step-' . $prev_step . '.php' ) ) {
				$prev_link = $this->helpers->queryString( $this->helpers->callbackUrl() ) . 'cjaddons_assistant=previous';
			}

			if( $prev_link != '' ) {
				$buttons .= '<a href="' . $prev_link . '"  class="button-primary" style="margin-right: 10px;">' . __( 'Back', 'cssjockey-add-ons' ) . '</a>';
			}
			if( $next_link != '' ) {
				$next_step = $this->assistant['step'] + 1;
				$next_link = $this->helpers->queryString( $next_link ) . 'cjaddons_assistant=next&step=' . $next_step;
				$next_text = ($next_text == '') ? __( 'Next', 'cssjockey-add-ons' ) : $next_text;
				$buttons .= '<a href="' . $next_link . '"  class="button-primary" style="margin-right: 10px;">' . $next_text . '</a>';
			}
			$buttons .= '<a href="' . $exit_link . '" class="button-secondary" style="float:right;">' . __( 'Exit', 'cssjockey-add-ons' ) . '</a>';

			return '<div style="margin-top: 20px;">' . $buttons . '</div>';
		}

		public function handleButtons() {

			if( isset( $_GET['cjaddons_assistant'] ) ) {

				switch( $_GET['cjaddons_assistant'] ) {
					case "exit":
						update_option( 'cjaddons_setup_assistant', array(
							'status' => 'inactive',
							'step' => 1,
						) );
						wp_redirect( $this->helpers->callbackUrl() );
						exit;
						break;
					case "restart":
						update_option( 'cjaddons_setup_assistant', array(
							'status' => 'active',
							'step' => 1,
						) );
						wp_redirect( $this->helpers->callbackUrl() );
						exit;
						break;
					case "previous":
						if( isset( $this->assistant['step'] ) && $this->assistant['step'] > 1 ) {
							$prev_step = $this->assistant['step'] - 1;
							update_option( 'cjaddons_setup_assistant', array(
								'status' => 'active',
								'step' => $prev_step,
							) );
							wp_redirect( $this->helpers->callbackUrl() );
							exit;
						}
						break;
					case "next":
						$url = explode( '&cjaddons_assistant=next', $this->helpers->currentUrl() );
						$next_setup = $_GET['step'];
						if( file_exists( dirname( __FILE__ ) . '/steps/step-' . $next_setup . '.php' ) ) {
							update_option( 'cjaddons_setup_assistant', array(
								'status' => 'active',
								'step' => $_GET['step']
							) );
						} else {
							update_option( 'cjaddons_setup_assistant', array(
								'status' => 'inactive',
								'step' => 1
							) );
						}
						wp_redirect( $url[0] );
						exit;
						break;
					default:
						echo "";
				}
			}
		}

	}

	// cjaddons_setup_assistant::getInstance();
}