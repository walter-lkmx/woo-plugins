<?php
if( ! class_exists( 'cjaddons_framework' ) ) {
	class cjaddons_framework {
		public $root_dir, $root_url, $theme_url, $helpers, $item_vars, $item_info, $installed_modules, $installed_products, $product_versions;
		private static $instance;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->root_dir = wp_normalize_path( dirname( dirname( __FILE__ ) ) );
			if( ! class_exists( 'CMB2' ) ) {
				require_once sprintf( '%s/framework/lib/cmb2/init.php', $this->root_dir );
			}
			require_once sprintf( '%s/framework/classes/helpers.php', $this->root_dir );
			// require_once sprintf( '%s/framework/assistant/init.php', $this->root_dir );
			$this->helpers = cjaddons_helpers::getInstance();
			$this->root_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $this->root_dir );

			$this->item_vars = $this->helpers->itemVars();
			$this->item_info = $this->helpers->itemInfo();
			$this->product_versions = get_option( 'cssjockey_product_version' );
			$this->installed_products = get_option( 'cssjockey_installed_products' );
			$this->theme_dir = get_stylesheet_directory();
			$this->theme_url = get_stylesheet_directory_uri();
			add_filter( 'widget_text', 'do_shortcode' );
			add_action( 'wp_footer', array($this, 'frontendNotifications'), 99 );
			add_action( 'init', array($this, 'disableAdminBar') );
		}

		public function init() {
			require_once $this->root_dir . '/framework/autoload.php';
		}

		/**
		 * Disable WordPress admin bar based on roles selected.
		 */
		public function disableAdminBar() {
			if( is_user_logged_in() ):
				$current_user = wp_get_current_user();
				$roles = $this->helpers->savedOption( 'core_admin_bar' );
				if( is_array( $roles ) ) {
					if( in_array( 'everyone', $roles ) ) {
						add_filter( 'show_admin_bar', '__return_false' );
						show_admin_bar( false );
					}
					if( ! is_array( $roles ) && $roles != '' ) {
						$roles = array($roles);
					}
				}
				if( array_key_exists( '0', $current_user->roles ) ) {
					if( is_array( $roles ) && in_array( $current_user->roles[0], $roles ) ) {
						add_filter( 'show_admin_bar', '__return_false' );
						show_admin_bar( false );
					}
				}
			endif;
		}

		public function frontendNotifications() {
			if( isset( $_SESSION['notification'] ) && is_array( $_SESSION['notification'] ) ) {
				$class = $_SESSION['notification']['class'];
				$message = $_SESSION['notification']['message'];
				$close_button = (isset( $_SESSION['notification']['close_button'] )) ? $_SESSION['notification']['close_button'] : false;
				echo $this->helpers->notification( $class, $message, $close_button );
				$_SESSION['notification'] = '';
			}
		}

	}
}