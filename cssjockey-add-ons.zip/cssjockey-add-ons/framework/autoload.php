<?php
global $cjaddons_item_vars;
if( ! defined( 'WPINC' ) ) {
	die;
}
require_once 'lib/vendor/autoload.php';
$autoload_dir_path = dirname( __FILE__ ) . '/autoload/';
$autoload_dirs = preg_grep( '/^([^.])/', scandir( $autoload_dir_path ) );
if( is_array( $autoload_dirs ) ) {
	foreach( $autoload_dirs as $key => $file_name ) {
		$file_path = $autoload_dir_path . $file_name;
		if( ! is_dir( $file_path ) && file_exists( $file_path ) ) {
			require_once $file_path;
		}
	}
}