<?php

class cjaddons_activate {
	public static function run() {
		do_action( 'cjaddons_activation_hook' );
		$db_init = cjaddons_db_setup::getInstance();
		$db_init->dbSetup();
		update_option( 'cssjockey-framework', cjaddons_version );
	}
}