<?php

class cjaddons_deactivate {

	public static function run() {
		do_action( 'cjaddons_deactivation_hook' );
		delete_option( 'cssjockey-framework' );
	}

}