<?php

use Leafo\ScssPhp\Compiler;
use Leafo\ScssPhp\Exception\CompilerException;
use Phelium\Component\reCAPTCHA;

if( ! class_exists( 'cjaddons_helpers' ) ) {
	class cjaddons_helpers {

		public $root_dir,
			$root_url,
			$upload_dir,
			$upload_path,
			$upload_url,
			$default_avatar_url,
			$item_vars,
			$text_domain,
			$installed_products,
			$product_versions,
			$saved_options,
			$token_key,
			$token_expire_key,
			$table_options,
			$helpers_css_url,
			$module_dir,
			$ui_base_css_url;

		private static $instance;

		public static function getInstance() {

			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->root_dir = wp_normalize_path( dirname( dirname( dirname( __FILE__ ) ) ) );
			$this->root_url = str_replace( ABSPATH, site_url( '/' ), $this->root_dir );
			$this->upload_dir = wp_upload_dir();
			$this->upload_path = $this->upload_dir['basedir'];
			$this->upload_url = $this->upload_dir['baseurl'];
			$this->text_domain = 'cssjockey-add-ons'; // must be hard coded
			$this->item_vars = $this->getItemVars();
			$this->module_dir = null;
			$this->item_info = $this->item_vars['info'];
			$this->table_options = $this->wpTableName( $this->item_info['options_table'] );
			if( ! get_option( 'cjaddons_modules_deactivated' ) ) {
				update_option( 'cjaddons_modules_deactivated', array() );
			}
			$this->deactivated_modules = get_option( 'cjaddons_modules_deactivated' );
			$this->installed_products = get_option( 'cssjockey_installed_products', array() );

			$this->saved_options = ( ! is_array( $this->saved_options )) ? $this->getOption() : $this->saved_options;
			$this->ui_base_css_url = $this->upload_url . '/cssjockey-ui/ui-base.min.css';
			$this->helpers_css_url = $this->upload_url . '/cssjockey-ui/helpers.min.css';
			$this->product_versions = get_option( 'cssjockey_product_version' );
			$this->default_avatar_url = $this->root_url . '/assets/cssjockey/images/avatar.jpg';
			add_action( 'admin_footer', array($this, 'getMenuLocations') );
		}

		public function getTemplateType() {
			$queried_object = get_queried_object();

			if( is_front_page() && is_home() ) {
				return 'blog-page';
			} elseif( is_front_page() ) {
				return 'homepage';
			} elseif( is_home() ) {
				return 'blog-page';
			}

			if( is_404() ) {
				return '404-page';
			}

			if( is_singular( 'attachment' ) ) {
				return 'attachment';
			}

			if( is_singular( 'post' ) ) {
				return 'single-post';
			}

			if( is_singular( 'page' ) ) {
				return 'single-page';
			}

			if( is_singular() ) {
				$post_type = (isset( $queried_object->post_type )) ? '-' . str_replace( '_', '-', $queried_object->post_type ) : '';

				return 'single' . $post_type;
			}

			if( is_post_type_archive() ) {
				return 'archive-post-type-' . str_replace( '_', '-', $queried_object->name );
			}

			if( is_tax() ) {
				return 'archive-taxonomy-' . str_replace( '_', '-', $queried_object->taxonomy );
			}

			if( is_category() ) {
				return 'archive-category';
			}

			if( is_tag() ) {
				return 'archive-tag';
			}

			if( is_author() ) {
				return 'archive-author';
			}

			if( is_archive() ) {
				return 'archive-default';
			}

			if( is_date() || is_year() || is_month() || is_day() || is_time() || is_new_day() || is_time() ) {
				return 'archive-default';
			}

			if( is_search() ) {
				return 'search';
			}
		}

		public function postDefault( $key, $default = '' ) {
			return (isset( $_POST[ $key ] )) ? $_POST[ $key ] : $default;
		}

		public function flashNotification( $class, $message, $close_button ) {
			$_SESSION['notification'] = array();
			$_SESSION['notification']['class'] = $class;
			$_SESSION['notification']['message'] = $message;
			$_SESSION['notification']['close_button'] = $close_button;

			return $_SESSION['notification'];
		}

		public function notification( $class, $message, $close_button = false ) {
			$id = $this->uniqueString( 'notification' );
			$display = array();
			$display[] = '<div class="cssjockey-ui">';
			$display[] = '<div id="' . $id . '">';
			$display[] = '<div class="cj-notify">';
			$display[] = '<div class="cj-notification animated cj-p-20 cj-text-left cj-flash cj-is-' . $class . '">';
			if( $close_button ) {
				$display[] = '<a class="cj-delete cj-is-pulled-right" data-toggle="class" data-target="#' . $id . '" data-classes="cj-flash cj-hidden"></a>';
			}
			$display[] = $message;
			$display[] = '</div>';
			$display[] = '</div>';
			$display[] = '</div>';
			$display[] = '</div>';

			return $_SESSION['notification'] = implode( '', $display );
		}

		public function activeAddons() {
			$activated_plugins = get_option( 'active_plugins' );
			$installed_plugins = array();
			if( is_array( $activated_plugins ) ) {
				foreach( $activated_plugins as $key => $plugin ) {
					$plugin = explode( '/', $plugin );
					$plugin = $plugin[0];
					$installed_plugins[ $plugin ] = $plugin;
				}
			}

			// in-built modules
			$installed_inbuilt_modules = array();
			$modules_path = $this->root_dir . '/modules/';
			if( is_dir( $modules_path ) ) {
				$module_dirs = preg_grep( '/^([^.])/', scandir( $modules_path ) );
				if( is_array( $module_dirs ) && ! empty( $module_dirs ) ) {
					foreach( $module_dirs as $key => $module_dir ) {
						$module_path = $modules_path . $module_dir;
						if( is_dir( $module_path ) ) {
							$installed_inbuilt_modules[ $module_dir ] = $module_dir;
						}
					}
				}
			}

			return array_merge( $installed_inbuilt_modules, $installed_plugins );
		}

		public function getItemVars() {
			global $cjaddons_item_vars;

			$this->deactivated_modules = get_option( 'cjaddons_modules_deactivated', array() );
			$config_files = array();

			require_once(sprintf( '%s/config.php', $this->root_dir ));
			$config_dir = $this->root_dir . '/config/';
			$dirs = preg_grep( '/^([^.])/', scandir( $config_dir ) );
			foreach( $dirs as $key => $value ) {
				if( file_exists( $config_dir . $value ) ) {
					require($config_dir . $value);
				}
			}

			// modules
			$modules_dir = $this->root_dir . '/modules/';
			if( is_dir( $modules_dir ) ) {
				$dirs = preg_grep( '/^([^.])/', scandir( $modules_dir ) );
				foreach( $dirs as $key => $module ) {
					if( ! is_file( $module ) && is_dir( $modules_dir . $module ) ) {
						if( file_exists( $modules_dir . $module . '/config.php' ) ) {
							$config_files[ $module ] = $modules_dir . $module . '/config.php';
						}
					}
				}
			}

			// plugins
			$plugins_path = trailingslashit( WP_PLUGIN_DIR );
			$plugins_dirs = preg_grep( '/^([^.])/', scandir( $plugins_path ) );
			foreach( $plugins_dirs as $p_key => $plugin_dir ) {
				if( is_dir( $plugins_path . $plugin_dir ) && file_exists( $plugins_path . $plugin_dir . '/cssjockey-addon.php' ) ) {
					$config_files[ $plugin_dir ] = $plugins_path . $plugin_dir . '/config.php';
				}
			}

			$active_addons = $this->activeAddons();
			if( ! empty( $config_files ) ) {
				foreach( $config_files as $key => $path ) {
					if( in_array( $key, array_keys( $active_addons ) ) ) {
						require_once $path;
					}
				}
			}
			$cjaddons_item_vars = apply_filters( 'cjaddons_item_vars', $cjaddons_item_vars );

			return $cjaddons_item_vars;
		}

		public function localizeScripts() {
			global $cjaddons_item_vars;
			$cjaddons_item_vars['locale']['site_url'] = site_url();
			$cjaddons_item_vars['locale']['site_name'] = get_bloginfo( 'name' );
			$cjaddons_item_vars['locale']['api_url'] = $this->apiUrl();
			$cjaddons_item_vars['locale']['api_nonce'] = wp_create_nonce( 'wp_rest' );
			$installed_addons = $this->getInstalledModules();
			$cjaddons_item_vars['locale']['installed_addons'] = array_keys( $installed_addons );
			$cjaddons_item_vars['locale']['activation_required'] = array();
			foreach( $installed_addons as $key => $installed_addon ) {
				if( $installed_addon['item_id'] != 'NA' ) {
					$license_key = get_option( 'cjaddons_license_' . $key, '' );
					if( $license_key == '' ) {
						$cjaddons_item_vars['locale']['activation_required'][] = $installed_addon;
					}
				}
			}
			if( is_array( $cjaddons_item_vars['locale'] ) && ! empty( $cjaddons_item_vars['locale'] ) ) {
				foreach( $cjaddons_item_vars['locale'] as $key => $locale ) {
					unset( $cjaddons_item_vars['locale']['core']['item_info']['author_url'] );
					unset( $cjaddons_item_vars['locale']['core']['item_info']['addons_url'] );
					unset( $cjaddons_item_vars['locale']['core']['item_info']['docs_url'] );
					unset( $cjaddons_item_vars['locale']['core']['item_info']['support_url'] );
					unset( $cjaddons_item_vars['locale']['core']['item_info']['customization_url'] );
					unset( $cjaddons_item_vars['locale']['core']['item_info']['hire_us_url'] );
					unset( $cjaddons_item_vars['locale']['core']['item_info']['license_url'] );
					unset( $cjaddons_item_vars['locale']['core']['item_info']['rest_api'] );
					unset( $cjaddons_item_vars['locale']['core']['item_info']['assistant'] );
					unset( $cjaddons_item_vars['locale']['core']['item_info']['options_table'] );
					unset( $cjaddons_item_vars['locale']['core']['item_info']['page_title'] );
					unset( $cjaddons_item_vars['locale']['core']['item_info']['menu_title'] );
					unset( $cjaddons_item_vars['locale']['core']['item_info']['page_slug'] );
					unset( $cjaddons_item_vars['locale']['core']['item_info']['api_nonce'] );
					// unset( $cjaddons_item_vars['locale']['core']['item_info']['verification_url'] );
					// unset( $cjaddons_item_vars['locale']['core']['item_info']['cssjockey_api_url'] );
					unset( $cjaddons_item_vars['locale']['api_nonce'] );
					if( isset( $locale['module_info'] ) ) {
						unset( $cjaddons_item_vars['locale'][ $key ]['module_info']['module_path'] );
						unset( $cjaddons_item_vars['locale'][ $key ]['module_info']['item_id'] );
						unset( $cjaddons_item_vars['locale'][ $key ]['module_info']['module_id'] );
						unset( $cjaddons_item_vars['locale'][ $key ]['module_info']['envato_id'] );
						unset( $cjaddons_item_vars['locale'][ $key ]['module_info']['core'] );
						unset( $cjaddons_item_vars['locale'][ $key ]['module_info']['docs_url'] );
						unset( $cjaddons_item_vars['locale'][ $key ]['module_info']['pro_version_url'] );
						unset( $cjaddons_item_vars['locale'][ $key ]['module_info']['dependencies'] );
					}
				}
			}
			$cjaddons_item_vars['locale'] = apply_filters( 'cjaddons_locale', $cjaddons_item_vars['locale'] );

			return $cjaddons_item_vars['locale'];
		}

		protected function dbInfo() {
			global $wpdb;

			return array(
				'database_type' => 'mysql',
				'database_name' => DB_NAME,
				'server' => DB_HOST,
				'username' => DB_USER,
				'password' => DB_PASSWORD,
				'charset' => 'utf8',
				'prefix' => $wpdb->prefix,
			);
		}

		public function itemEnvatoLicense() {
			if( $this->itemInfo( 'item_id' ) == 'NA' ) {
				return __( 'Not Applicable', 'cssjockey-add-ons' );
			} else {
				$license_info = get_option( 'cj_license_info_' . $this->itemInfo( 'item_id' ) );
				if( ! $license_info ) {
					ob_start();
					require_once($this->root_dir . '/framework/html/activation-form-envato.php');

					return ob_get_clean();
				}
			}
		}

		public function itemCSSJockeyLicense() {

			if( $this->itemInfo( 'item_id' ) == 'NA' ) {
				return __( 'Not Applicable', 'cssjockey-add-ons' );
			} else {
				$license_info = get_option( 'cj_license_info_' . $this->itemInfo( 'item_id' ) );
				if( ! $license_info ) {
					ob_start();
					require_once($this->root_dir . '/framework/html/activation-form-cssjockey.php');

					return ob_get_clean();
				}
			}
		}

		public function getInstalledModules( $module_dir_name = null ) {
			$return = array();
			$vars = $this->getItemVars();
			$inbuilt_modules = get_option( 'cjaddons_inbuilt_modules', array() );
			if( isset( $vars['module_info'] ) ) {
				$active_addons = $this->activeAddons();
				$modules_info = $vars['module_info'];
				foreach( $active_addons as $key => $active_addon ) {
					if( isset( $modules_info[ $active_addon ] ) ) {
						$return[ $active_addon ] = $modules_info[ $active_addon ];
						if( count( explode( '/modules/', $return[ $active_addon ]['module_path'] ) ) == 1 ) {
							// plugin activated
							$return[ $active_addon ]['active'] = 1;
						} else {
							// inbuilt module
							$return[ $active_addon ]['active'] = (isset( $inbuilt_modules[ $active_addon ] ) && $inbuilt_modules[ $active_addon ] == 1) ? 1 : 0;
						}
					}
				}
			}
			if( ! is_null( $module_dir_name ) && isset( $return[ $module_dir_name ] ) ) {
				return $return[ $module_dir_name ];
			}

			return $return;
		}

		public function getDeactivatedModules() {

			return $this->deactivated_modules;
		}

		public function moduleInfo( $module_key = null ) {
			$module_vars = $this->itemVars( 'module_info' );
			if( isset( $module_vars[ $module_key ] ) ) {
				return (is_null( $module_key )) ? $module_vars : $module_vars[ $module_key ];
			}

			return array();
		}

		public function productVersions() {

			return $this->product_versions;
		}

		public function isLocal() {
			$local_servers = array(
				'::1',
				'127.0.0.1',
			);
			$local = (in_array( $_SERVER['REMOTE_ADDR'], $local_servers )) ? 1 : 0;

			return $local;
		}

		public function callbackUrl( $module = 'config', $file_name = 'core-welcome', $page = null, $query_string = null ) {

			if( is_null( $page ) ) {
				$get_page = (isset( $_GET['page'] ) ? $_GET['page'] : '');
				if( $get_page == '' ) {
					$get_page = $this->itemInfo( 'text_domain' );
				}
				$return = $this->queryString( admin_url( 'admin.php?page=' . $get_page ) ) . "callback={$module}~" . $file_name;
			} else {
				$return = $this->queryString( admin_url( 'admin.php?page=' . $page ) ) . "callback={$module}~" . $file_name;
			}

			return (is_null( $query_string )) ? $return : $this->queryString( $return );
		}

		public function shortcodeGuiUrl( $shortcode_tag = null ) {

			if( is_null( $shortcode_tag ) ) {
				$return = $this->queryString( $this->callbackUrl( 'config', 'core-shortcode-iframe' ) ) . 'iframe=1&shortcode=';
			} else {
				$return = $this->queryString( $this->callbackUrl( 'config', 'core-shortcode-iframe' ) ) . 'iframe=1&shortcode=' . $shortcode_tag;
			}

			return $return;
		}

		public function shortcodePreviewUrl( $shortcode_tag = null ) {

			if( is_null( $shortcode_tag ) ) {
				$return = $this->queryString( site_url() ) . '&cj-shortcode-preview=1&iframe=1&shortcode=';
			} else {
				$return = $this->queryString( site_url() ) . '&cj-shortcode-preview=1&iframe=1&shortcode=' . $shortcode_tag;
			}

			return $return;
		}

		public function queryString( $string = null ) {
			if( ! is_null( $string ) ) {
				if( strpos( $string, '?' ) > 0 ) {
					return $string . '&';
				} else {
					return $string . '?';
				}
			}
		}

		public function uniqueString( $prefix = null ) {
			$unique_string = sprintf( "%04s%03s%s", base_convert( mt_rand( 0, pow( 36, 4 ) - 1 ), 10, 36 ), base_convert( mt_rand( 0, pow( 36, 3 ) - 1 ), 10, 36 ), substr( sha1( md5( strtotime( date( 'Y-m-d H:i:s' ) ) ) ), 7, 3 ) );

			return $prefix . strtoupper( $unique_string );
		}

		public function cleanString( $string ) {
			$string = str_replace( ' ', '-', $string ); // Replaces all spaces with hyphens.
			$string = str_replace( array('[', ']', '(', ')', '{', '}'), '-', $string ); // Replaces all spaces with hyphens.
			$string = preg_replace( '/[^A-Za-z0-9\-]/', '-', $string ); // Removes special chars.

			return preg_replace( '/-+/', '-', $string ); // Replaces multiple hyphens with single one.
		}

		public function generateLicenseKey( $number = 4 ) {
			$key = [];
			for( $i = 0; $i < $number; $i ++ ) {
				$key[] = $this->uniqueString();
			}

			return implode( '-', $key );
		}

		public function renderAdminForm( $form_options = array(), $form_defaults = array(), $debug = false ) {
			ob_start();
			require($this->root_dir . "/framework/html/admin-form.php");

			return ob_get_clean();
		}

		public function formField( $option ) {
			ob_start();
			require($this->root_dir . "/framework/html/form-field.php");

			return ob_get_clean();
		}

		public function renderFrontendForm( $form_options = array(), $form_defaults = array(), $debug = false ) {
			ob_start();
			require($this->root_dir . "/framework/html/frontend-form.php");

			return ob_get_clean();
		}

		public function renderWidgetForm( $options, $form_instance ) {

			ob_start();
			require($this->root_dir . "/framework/html/widget-form.php");

			return ob_get_clean();
		}

		public function alert( $class = 'cj-danger', $messages, $heading = null, $close_btn = true ) {
			$return = '';
			$return .= '<div class="cj-notification cj-is-' . $class . '">';
			if( $close_btn ) {
				$return .= '<a href="#" class="cj-close cj-delete" data-dismiss="alert" aria-label="close"></a>';
			}
			$return .= ( ! is_null( $heading )) ? '<div class="cj-mb-3"><b>' . $heading . '</b></div>' : '';
			$return .= is_array( $messages ) ? implode( '<br>', $messages ) : $messages;
			$return .= '</div>';

			return $return;
		}

		public function addOption( $name, $value ) {
			global $wpdb;
			$return = '';
			$exists = $wpdb->get_row( "SELECT * FROM $this->table_options WHERE option_name = '{$name}'" );
			$value = (is_array( $value )) ? serialize( $value ) : $value;
			$option_data = array(
				'option_name' => $name,
				'option_value' => stripcslashes( $value ),
			);
			if( is_null( $exists ) ) {
				$return = $this->insert( $this->table_options, $option_data );
			}

			return $return;
		}

		public function saveOptionsToSync( $post_data ) {
			$options_to_save = get_option( 'cjaddons_all_options' );
			if( ! is_array( $options_to_save ) ) {
				$options_to_save = array();
			}
			foreach( $post_data as $key => $value ) {
				$value = (is_serialized( $value )) ? unserialize( $value ) : $value;
				$options_to_save[ $key ] = $value;
			}
			update_option( 'cjaddons_all_options', $options_to_save );

			return $options_to_save;
		}

		public function appendOption( $name, $key, $value ) {
			if( ! get_option( $name ) ) {
				update_option( $name, array() );
			}
			if( ! is_array( $this->saved_options[ $name ] ) ) {
				$option[ $key ] = esc_textarea( $value );
				$this->updateOption( $name, $option );
			}
			if( is_array( $this->saved_options[ $name ] ) ) {
				$this->saved_options[ $name ][ $key ] = $value;
				$this->updateOption( $name, $this->saved_options[ $name ] );
			}
		}

		public function unsetOption( $name, $key ) {
			if( is_array( $this->saved_options[ $name ] ) ) {
				unset( $this->saved_options[ $name ][ $key ] );
				$this->updateOption( $name, $this->saved_options[ $name ] );
			}
		}

		public function itemInfo( $var = null ) {

			$item_info = $this->itemVars( 'info' );

			if( is_null( $var ) ) {
				return $item_info;
			} else {
				if( isset( $item_info[ $var ] ) ) {
					return $item_info[ $var ];
				} else {
					return false;
				}
			}
		}

		public function itemVars( $var = null ) {
			if( is_null( $var ) ) {
				return $this->item_vars;
			} else {
				if( isset( $this->item_vars[ $var ] ) ) {
					return $this->item_vars[ $var ];
				} else {
					return array();
				}
			}
		}

		public function insert( $table, $data ) {

			global $wpdb;
			foreach( $data as $field => $value ) {
				$value = (is_array( $value )) ? serialize( $value ) : $value;
				$fields[] = '`' . esc_sql( $field ) . '`';
				$values[] = "'" . esc_sql( $value ) . "'";
			}
			$field_list = join( ',', $fields );
			$value_list = join( ', ', $values );
			$query = "INSERT INTO `" . $table . "` (" . $field_list . ") VALUES (" . $value_list . ")";
			$wpdb->query( $query );

			return $wpdb->insert_id;
		}

		public function updateOption( $name, $value ) {
			global $wpdb;
			$options_table = $wpdb->prefix . $this->itemInfo( 'options_table' );
			$exists = $wpdb->get_row( "SELECT * FROM $options_table WHERE option_name = '{$name}'" );
			//$value = ( ! is_array( $value )) ? esc_textarea( $value ) : $value;
			$value = (is_array( $value )) ? serialize( $value ) : $value;
			$option_data = array(
				'option_name' => $name,
				'option_value' => $value,
			);
			if( is_null( $exists ) ) {
				$return = $this->insert( $options_table, $option_data );
			} else {
				$return = $this->update( $options_table, $option_data, 'option_id', $exists->option_id );
			}

			$post_data = array();
			$post_data[ $name ] = $value;
			$this->saveOptionsToSync( $post_data );

			return $return;
		}

		public function deleteOption( $name ) {
			global $wpdb;
			$table_name = $this->wpTableName( $this->itemInfo( 'options_table' ) );
			$return = $wpdb->query( "DELETE FROM $table_name WHERE option_name = $name" );

			return $return;
		}

		public function update( $table, $data, $id_field, $id_value ) {

			global $wpdb;
			foreach( $data as $field => $value ) {
				$fields[] = sprintf( "`%s` = '%s'", $field, esc_sql( $value ) );
			}
			$field_list = join( ',', $fields );
			$query = sprintf( "UPDATE `%s` SET %s WHERE `%s` = %s", $table, $field_list, $id_field, intval( $id_value ) );
			$wpdb->query( $query );

			return intval( $id_value );
		}

		public function getDefaultOptions() {
			global $wpdb;
			$cjaddons_options = [];
			$return = [];
			$option_files = $this->itemVars( 'option_files' );
			if( is_array( $option_files ) ) {
				foreach( $option_files as $key => $files ) {
					if( $key != 'config' ) {
						$module_info = $this->moduleInfo( $key );
						$dir = $module_info['module_path'] . '/admin-pages';
					} else {
						$dir = $this->root_dir . '/framework/admin-pages';
					}
					foreach( $files as $f_key => $file_name ) {
						$file_name = $dir . '/' . $file_name . '.php';
						if( file_exists( $file_name ) ) {
							require($file_name);
						}
					}
				}
			}
			if( ! empty( $cjaddons_options ) ) {
				foreach( $cjaddons_options as $key => $options ) {
					foreach( $options as $option_key => $option ) {
						$return[ $option['id'] ] = $option['default'];
						if( isset( $option['group'] ) ) {
							$group_value = array();
							$group_value['selected_value'] = $option['default'];
							foreach( $option['options'] as $o_key => $o_value_array ) {
								foreach( $option['items'] as $i_key => $i_value ) {
									foreach( $i_value as $k => $v ) {
										$group_value['items'][ $i_key ][ $k ] = $v['default'];
									}
								}
							}
							$return[ $option['id'] ] = $group_value;
						}
					}
				}
			}

			return $return;
		}

		public function currentUrl( $trim_query_string = false, $add_query_separator = false, $additional_query_params = '' ) {
			$pageURL = (isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] == 'on') ? "https://" : "http://";
			$pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
			if( ! $trim_query_string ) {
				$return_url = $pageURL;
			} else {
				$url = explode( '?', $pageURL );
				$return_url = $url[0];
			}
			$return_url = $return_url . $additional_query_params;

			return ($add_query_separator) ? $this->queryString( $return_url ) : $return_url;
		}

		public function generateSafeLink( $page_link, $page_args = array() ) {

			$url = '';
			if( ! empty( $page_args ) ) {
				$query_args = add_query_arg( $page_args, $page_link );
				$url = esc_url( $query_args );
			} else {
				$url = esc_url( $page_link );
			}

			return $url;
		}

		public function parseDomain( $url, $return = null ) {

			// possible values host, path, scheme
			$parse = parse_url( $url );

			return ( ! is_null( $return )) ? $parse[ $return ] : $parse;
		}

		public function removeQueryStringVar( $url, $key ) {

			$url = preg_replace( '/(.*)(?|&)' . $key . '=[^&]+?(&)(.*)/i', '$1$2$4', $url . '&' );
			$url = substr( $url, 0, - 1 );

			return $url;
		}

		public function jsonError( $data, $store = array() ) {
			$output = array(
				'success' => 0,
				'data' => $data,
				'store' => $store,
			);

			return json_encode( $output );
		}

		public function jsonSuccess( $data, $store = array() ) {
			$output = array(
				'success' => 1,
				'data' => $data,
				'store' => $store,
			);

			return json_encode( $output );
		}

		public function jsonData( $data, $store = array() ) {

			$output = array(
				'success' => 1,
				'data' => $data,
				'store' => $store,
			);

			return json_encode( $output );
		}

		public function jsonEncode( $array ) {
			return htmlspecialchars( json_encode( $array ), ENT_QUOTES, 'UTF-8' );
		}

		public function getUserByMeta( $meta_key, $meta_value ) {

			global $wpdb;
			$user_meta = $wpdb->get_row( "SELECT * FROM $wpdb->usermeta WHERE meta_key = '{$meta_key}' AND meta_value = '{$meta_value}'" );
			if( is_null( $user_meta ) ) {
				return array();
			} else {
				return $this->userInfo( $user_meta->user_id );
			}
		}

		public function userInfo( $var, $fields_array = array() ) {
			global $wpdb;
			$return = array();
			$exclude_strings = array('user_pass', 'session', 'wp_', 'meta-box', 'screen_layout');
			if( is_numeric( $var ) ) {
				$column = 'ID';
			} elseif( substr_count( $var, '@' ) ) {
				$column = 'user_email';
			} else {
				$column = 'user_login';
			}
			$user_data = $wpdb->get_row( "SELECT * FROM $wpdb->users WHERE {$column} = '{$var}'", ARRAY_A );
			if( ! is_array( $user_data ) ) {
				return [];
			}
			foreach( $user_data as $key => $value ) {
				$return_value = (is_serialized( $value )) ? unserialize( $value ) : $value;
				if( is_numeric( $return_value ) ) {
					$return_value = (int) $return_value;
				}
				$return[ $key ] = $return_value;
			}
			$user_meta = $wpdb->get_results( "SELECT * FROM $wpdb->usermeta WHERE user_id = '{$user_data['ID']}'", ARRAY_A );
			if( is_array( $user_meta ) ) {
				foreach( $user_meta as $meta ) {
					$return[ $meta['meta_key'] ] = (is_serialized( $meta['meta_value'] )) ? unserialize( $meta['meta_value'] ) : $meta['meta_value'];
				}
			}
			$first_name = (isset( $return['first_name'] ) && $return['first_name'] != '') ? $return['first_name'] : '';
			$last_name = (isset( $return['last_name'] ) && $return['last_name'] != '') ? ' ' . $return['last_name'] : '';
			$return['display_name'] = ($first_name != '') ? $first_name . $last_name : $return['nickname'];
			$return['posts_link_url'] = get_author_posts_url( $return['ID'], $return['nickname'] );
			$return['gravatar'] = $this->gravatar( $return['ID'] );
			$return['default_avatar'] = $this->root_url . '/framework/html/images/default-avatar.png';
			$return['user_avatar'] = (isset( $return['user_avatar'] ) && $return['user_avatar'] != '') ? $return['user_avatar'] : $return['gravatar'];
			//$return['user_avatar'] = $return['default_avatar'];

			// crop user avatar is not square
			/*if( ! strpos( $return['user_avatar'], 'gravatar' ) ) {
				list( $width, $height, $type, $attr ) = getimagesize( $return['user_avatar'] );
				if( $width !== $height ) {
					$cropped = $this->imageResize( $return['user_avatar'], array(256, 256), true );
					update_user_meta( $return['ID'], 'default_avatar', $cropped );
					update_user_meta( $return['ID'], 'user_avatar', $cropped );
					$return['user_avatar'] = get_user_meta( $return['ID'], 'user_avatar', true );
					$return['default_avatar'] = get_user_meta( $return['ID'], 'user_avatar', true );
				}
			}*/

			$return['last_login'] = (isset( $return['last_login'] )) ? $this->wpDate( $return['last_login'] ) : '';
			$return['access_token'] = (isset( $return['X-Authorization'] )) ? $return['X-Authorization'] : '';
			$return['access_token_expires'] = (isset( $return['X-Authorization-Expires'] )) ? $return['X-Authorization-Expires'] : '';
			$wp_user_data = get_userdata( $return['ID'] );
			$return['roles'] = $wp_user_data->roles;

			foreach( $return as $key => $value ) {
				if( is_string( $value ) && $value != '' ) {
					$return[ $key ] = urldecode( $value );
				}
			}

			if( isset( $return['X-Authorization-Expires'] ) && time() > $return['X-Authorization-Expires'] ) {
				unset( $return['cjaddons_auth_token'] );
				delete_user_meta( $return['ID'], 'X-Authorization' );
				delete_user_meta( $return['ID'], 'X-Authorization-Expires' );
			}
			unset( $return['X-Authorization'] );
			unset( $return['X-Authorization-Expires'] );

			foreach( array_keys( $return ) as $key ) {
				foreach( $exclude_strings as $string ) {
					if( substr_count( $key, $string ) > 0 ) {
						unset( $return[ $key ] );
					}
				}
			}
			if( empty( $fields_array ) ) {
				return $return;
			} else {
				$fields = array();
				if( ! empty( $fields_array ) ) {
					foreach( $fields_array as $f_key => $f_value ) {
						if( isset( $return[ $f_value ] ) ) {
							$fields[ $f_value ] = $return[ $f_value ];
						}
					}
				}

				return $fields;
			}
		}

		public function getApiUserInfo( $request ) {
			$token = $request->get_header( 'x_authorization' );

			return $this->getUserByToken( $token );
		}

		public function updateUserInfo( $user_id, $data ) {
			global $wpdb;
			$prefix = (is_multisite()) ? $wpdb->base_prefix : $wpdb->prefix;
			$table_name = $prefix . 'users';
			$user_table_fields = array();
			$user_data = array();
			$exclude_users_table_fields = array('ID', 'user_pass', 'user_login');
			foreach( $wpdb->get_col( "DESC " . $table_name, 0 ) as $column_name ) {
				$user_table_fields[] = $column_name;
				if( ! in_array( $column_name, $exclude_users_table_fields ) ) {
					if( isset( $data[ $column_name ] ) ) {
						$user_data[ $column_name ] = $data[ $column_name ];
					}
				}
			}
			if( is_array( $user_data ) ) {
				$user_data['ID'] = $user_id;
				wp_update_user( $user_data );
			}
			foreach( $data as $meta_key => $meta_value ) {
				if( ! in_array( $meta_key, $user_table_fields ) ) {
					update_user_meta( $user_id, $meta_key, $meta_value );
				}
			}

			return $this->userInfo( $user_id );
		}

		public function processUserVariables( $user_id, $string ) {
			$user_info = $this->userInfo( $user_id );
			if( ! empty( $user_info ) ) {
				foreach( $user_info as $key => $value ) {
					$value = (is_serialized( $value )) ? unserialize( $value ) : $value;
					if( ! $this->containsArray( $value ) ) {
						$value = (is_array( $value )) ? implode( '|', $value ) : $value;
						$string = str_replace( '%%' . $key . '%%', $value, $string );
					}
				}
			}

			return $string;
		}

		public function gravatar( $user_email, $size = 150 ) {

			$gravatar = get_avatar( $user_email, $size, null );
			preg_match( "/src='(.*?)'/i", $gravatar, $matches );
			$return = ( ! empty( $matches ) && is_array( $matches )) ? $matches[1] : null;

			return $return;
		}

		public function userRole( $user_var ) {

			global $wpdb;
			if( ! $user_var ) {
				return false;
			}
			if( is_numeric( $user_var ) ) {
				$user_data = get_userdata( $user_var );

				return $user_data->roles;
			} elseif( substr_count( $user_var, '@' ) ) {
				$column = 'user_email';
			} else {
				$column = 'user_login';
			}
			$user = $wpdb->get_row( "SELECT * FROM $wpdb->users WHERE {$column} = '{$user_var}'", ARRAY_A );
			$user_data = get_userdata( $user['ID'] );

			return ( ! is_null( $user_data->roles )) ? $user_data->roles : [];
		}

		public function uniqueUsername( $user_login, $separator = '' ) {
			global $wpdb;
			if( $this->isValidEmail( $user_login ) ) {
				$user_login = explode( '@', $user_login );
				$user_login = $user_login[0];
			}
			$user_login = preg_replace( "/-$/", "", preg_replace( '/[^a-z0-9]+/i', "-", $user_login ) );
			$query = $wpdb->get_row( "SELECT * FROM $wpdb->users WHERE user_login = '{$user_login}'" );
			if( count( $query ) == 0 ) {
				return $user_login;
			} else {
				preg_match( '/(.+)-([0-9]+)$/', $user_login, $match );
				$new_user_login = isset( $match[2] ) ? $match[1] . $separator . ($match[2] + 1) : $user_login . $separator . count( $query );
				if( count( $query ) == 0 ) {
					return $new_user_login;
				} else {
					return $this->uniqueUsername( $new_user_login, $separator );
				}
			}
		}

		public function uniqueColumnValue( $string, $table, $column ) {

			global $wpdb;
			$string = preg_replace( "/-$/", "", preg_replace( '/[^a-z0-9]+/i', "-", $string ) );
			$query = $wpdb->get_row( "SELECT * FROM {$table} WHERE {$column} = '{$string}'" );
			if( count( $query ) == 0 ) {
				return $string;
			} else {
				preg_match( '/(.+)-([0-9]+)$/', $string, $match );
				$new_string = isset( $match[2] ) ? $match[1] . '-' . ($match[2] + 1) : $string . '-' . count( $query );
				if( count( $query ) == 0 ) {
					return $new_string;
				} else {
					return $this->uniqueColumnValue( $new_string, $table, $column );
				}
			}
		}

		public function getPostsFromCustomPostType( $post_type ) {
			global $wpdb;
			$query_str = "SELECT * FROM $wpdb->posts WHERE $wpdb->posts.post_type = '{$post_type}' AND $wpdb->posts.post_status = 'publish' ORDER BY $wpdb->posts.post_date DESC";
			$query_str = apply_filters( 'cssjockey_custom_post_type_query', $query_str );
			$custom_post_types_posts = $wpdb->get_results( $query_str, ARRAY_A );
			/**
			 * Sample Format of data returned
			 * Array
			 * (
			 * [0] => Array
			 * (
			 * [ID] => 47
			 * [post_author] => 1
			 * [post_date] => 2016-10-19 10:13:19
			 * [post_date_gmt] => 2016-10-19 10:13:19
			 * [post_content] =>
			 * [post_title] => Frontend Auth ~ Set new password
			 * [post_excerpt] =>
			 * [post_status] => publish
			 * [comment_status] => closed
			 * [ping_status] => closed
			 * [post_password] =>
			 * [post_name] => cjaddons_frontend_auth_do_set_new_password
			 * [to_ping] =>
			 * [pinged] =>
			 * [post_modified] => 2016-10-19 10:13:19
			 * [post_modified_gmt] => 2016-10-19 10:13:19
			 * [post_content_filtered] =>
			 * [post_parent] => 0
			 * [guid] => https://cssjockey.com/cjfm/cjaddons-forms/frontend-auth-set-new-password/
			 * [menu_order] => 0
			 * [post_type] => cj-custom-forms
			 * [post_mime_type] =>
			 * [comment_count] => 0
			 * )
			 * )
			 */
			if( is_array( $custom_post_types_posts ) && ! empty( $custom_post_types_posts ) ) {
				return $custom_post_types_posts;
			} else {
				return '';
			}
		}

		public function postInfo( $post_id_or_slug, $filters = array() ) {
			global $wpdb;
			$postID = (is_numeric( $post_id_or_slug )) ? $post_id_or_slug : 'slug';
			$return = array();
			$post_data_fields = (isset( $filters['post_data_fields'] )) ? implode( ',', $filters['post_data_fields'] ) : '*';
			if( $postID != 'slug' ) {
				$post_data = $wpdb->get_row( "SELECT {$post_data_fields} FROM $wpdb->posts WHERE ID = '{$post_id_or_slug}'", ARRAY_A );
			} else {
				$post_data = $wpdb->get_row( "SELECT {$post_data_fields} FROM $wpdb->posts WHERE post_name = '{$post_id_or_slug}'", ARRAY_A );
			}
			if( ! is_array( $post_data ) ) {
				return array();
			}
			foreach( $post_data as $key => $value ) {
				$return[ $key ] = (is_serialized( $value )) ? unserialize( $value ) : $value;
			}

			$post_meta_fields = (isset( $filters['post_meta_fields'] ) && is_array( $filters['post_meta_fields'] )) ? '"' . implode( '","', $filters['post_meta_fields'] ) . '"' : null;
			if( ! is_null( $post_meta_fields ) ) {
				$post_meta = $wpdb->get_results( "SELECT * FROM $wpdb->postmeta WHERE post_id = '{$post_data['ID']}' AND meta_key IN ($post_meta_fields)", ARRAY_A );
			} else {
				$post_meta = $wpdb->get_results( "SELECT * FROM $wpdb->postmeta WHERE post_id = '{$post_data['ID']}'", ARRAY_A );
			}

			if( is_array( $post_meta ) ) {
				foreach( $post_meta as $meta ) {
					$meta_value = $meta['meta_value'];
					if( is_serialized( $meta['meta_value'] ) ) {
						$meta_value = @unserialize( $meta['meta_value'] );
					}
					$return[ $meta['meta_key'] ] = $meta_value;
				}
			}
			$return['post_excerpt'] = ($post_data['post_excerpt'] == '') ? $this->trimChars( strip_shortcodes( strip_tags( $post_data['post_content'] ) ), 160, '..' ) : $post_data['post_excerpt'];
			$return['permalink'] = get_permalink( $post_data['ID'] );

			if( has_post_thumbnail( $return['ID'] ) ) {
				$thumb_id = get_post_thumbnail_id( $return['ID'] );
				$full_url = wp_get_attachment_image_src( $thumb_id, 'full', true );
				$return['featured_image_url'] = $full_url[0];
				$return['featured_images'] = array();
				if( function_exists( 'get_intermediate_image_sizes' ) ) {
					$image_sizes = get_intermediate_image_sizes();
					foreach( $image_sizes as $image_key => $image_size ) {
						$image = wp_get_attachment_image_src( $thumb_id, $image_size, true );
						$return['featured_images'][ $image_size ] = $image[0];
					}
				}
			} else {
				$return['featured_image_url'] = '//placehold.it/960x540/cccccc/aaaaaa&text=THUMBNAIL';
			}

			$return['attached_images'] = $this->getPostImages( $post_data['ID'] );

			if( isset( $post_data['post_author'] ) ) {
				$post_author_info = $this->userInfo( $post_data['post_author'] );
				if( is_array( $post_author_info ) && ! empty( $post_author_info ) ) {
					$return['post_author_name'] = (isset( $post_author_info['display_name'] )) ? $post_author_info['display_name'] : '';
					$return['post_author_posts_url'] = (isset( $post_author_info['posts_link_url'] )) ? $post_author_info['posts_link_url'] : '';
					$return['post_author_link'] = '<a href="' . $post_author_info['posts_link_url'] . '" title="' . $post_author_info['display_name'] . '">' . $post_author_info['display_name'] . '</a>';
				}
			}

			$post_taxonomies = get_post_taxonomies( $post_data['ID'] );
			$taxonomy_links = array();
			if( ! empty( $post_taxonomies ) ) {
				foreach( $post_taxonomies as $key => $post_taxonomy ) {
					$terms = wp_get_object_terms( $post_data['ID'], $post_taxonomy );
					$count = - 1;
					foreach( $terms as $t_key => $term ) {
						$count ++;
						$term_link = get_term_link( $term );
						$return['taxonomies'][ $post_taxonomy ][ $count ]['term_id'] = $term->term_id;
						$return['taxonomies'][ $post_taxonomy ][ $count ]['term_name'] = $term->name;
						$return['taxonomies'][ $post_taxonomy ][ $count ]['term_url'] = $term_link;
						$return['taxonomies'][ $post_taxonomy ][ $count ]['term_slug'] = $term->slug;
						$return['taxonomies'][ $post_taxonomy ][ $count ]['term_permalink'] = '<a href="' . $term_link . '" title="' . $term->name . '">' . $term->name . '</a>';
						$return['taxonomies'][ $post_taxonomy ][ $count ]['term_data'] = $term;

						$taxonomy_links[] = '<a href="' . get_term_link( $term ) . '" title="' . $term->name . '">' . $term->name . '</a>';
						$return['taxonomy_links'][ $post_taxonomy ] = ( ! empty( $taxonomy_links )) ? implode( ', ', $taxonomy_links ) : '';
					}
				}
			}

			$return['category_links'] = ( ! empty( $taxonomy_links )) ? implode( ', ', $taxonomy_links ) : '';

			if( isset( $filters['html_fields'] ) ) {
				foreach( $filters['html_fields'] as $key => $field ) {
					if( isset( $return[ $field ] ) ) {
						$return[ $field ] = wpautop( $return[ $field ] );
					}
				}
			}
			$return['post_content'] = wpautop( $return['post_content'], true );
			$return['post_excerpt'] = esc_attr( $return['post_excerpt'] );
			$return['comments_string'] = '';
			if( $return['comment_count'] == 0 ) {
				$return['comments_string'] = __( 'No comments', 'lang-cjaddons' );
			} elseif( $return['comment_count'] == 1 ) {
				$return['comments_string'] = __( '1 Comment', 'lang-cjaddons' );
			} elseif( $return['comment_count'] > 1 ) {
				$return['comments_string'] = sprintf( __( '%s Comments', 'lang-cjaddons' ), $return['comment_count'] );
			}

			return $return;
		}

		public function getPostMeta( $post_id ) {
			global $wpdb;
			$result = $wpdb->get_results( "SELECT * FROM $wpdb->postmeta WHERE post_id = '{$post_id}'" );
			$return = array();
			if( ! empty( $result ) ) {
				foreach( $result as $key => $value ) {
					$meta_value = (is_serialized( $value->meta_value )) ? unserialize( $value->meta_value ) : $value->meta_value;
					$return[ $value->meta_key ] = $meta_value;
				}
			}

			return $return;
		}

		public function parseMetaString( $string = 'Posted by %%author%% on %%date%% %%time%% in %%terms%% | %%comments%%', $post_info = array() ) {

			if( is_array( $post_info ) && ! empty( $post_info ) ) {
				$post_date = $this->wpDate( $post_info['post_date'], 'date' );
				$post_time = $this->wpDate( $post_info['post_date'], 'time' );
				$edit_link = get_edit_post_link( $post_info['ID'], 'EDIT' );
				$string = str_replace( '%%author%%', '<span class="cj-post-meta-item cj-meta-author-link">' . $post_info['post_author_link'] . '</span>', $string );
				$string = str_replace( '%%date%%', '<span class="cj-post-meta-item cj-meta-date">' . $post_date . '</span>', $string );
				$string = str_replace( '%%time%%', '<span class="cj-post-meta-item cj-meta-time">' . $post_time . '</span>', $string );
				$string = str_replace( '%%terms%%', '<span class="cj-post-meta-item cj-meta-terms">' . $post_info['category_links'] . '</span>', $string );
				$string = str_replace( '%%comments%%', '<span class="cj-post-meta-item cj-meta-comments-link"><a href="' . $post_info['permalink'] . '#comments" title="' . $post_info['comments_string'] . '">' . $post_info['comments_string'] . '</a></span>', $string );
				if( current_user_can( 'publish_posts' ) ) {
					$string .= ' ';
					$string .= sprintf( __( '<a href="%s" target="_blank" rel="nofollow"> | Edit %s</a>', 'lang-cjaddons' ), $edit_link, $post_info['post_type'] );
				}

				return $string;
			} else {
				return '';
			}
		}

		public function updatePostInfo( $post_id, $data ) {
			global $wpdb;
			$prefix = (is_multisite()) ? $wpdb->base_prefix : $wpdb->prefix;
			$table_name = $prefix . 'posts';
			$posts_table_fields = array();
			$post_data = array();
			$exclude_posts_table_fields = array('ID');
			foreach( $wpdb->get_col( "DESC " . $table_name, 0 ) as $column_name ) {
				$posts_table_fields[] = $column_name;
				if( ! in_array( $column_name, $exclude_posts_table_fields ) ) {
					if( isset( $data[ $column_name ] ) ) {
						$post_data[ $column_name ] = $data[ $column_name ];
					}
				}
			}
			if( is_array( $post_data ) ) {
				$post_data['ID'] = $post_id;
				wp_update_post( $post_data );
			}
			if( is_array( $data ) && ! empty( $data ) ) {
				foreach( $data as $meta_key => $meta_value ) {
					if( ! in_array( $meta_key, $posts_table_fields ) ) {
						update_post_meta( $post_id, $meta_key, $meta_value );
					}
				}
			}

			if( isset( $data['set_post_terms'] ) && ! empty( $data['set_post_terms'] ) ) {
				foreach( $data['set_post_terms'] as $post_taxonomy => $terms ) {
					wp_set_object_terms( $post_id, $terms, $post_taxonomy, false );
				}
			}
			if( isset( $data['add_post_terms'] ) && ! empty( $data['add_post_terms'] ) ) {
				foreach( $data['add_post_terms'] as $post_taxonomy => $terms ) {
					wp_set_object_terms( $post_id, $terms, $post_taxonomy, true );
				}
			}

			return $this->postInfo( $post_id );
		}

		public function updateCommentInfo( $comment_id, $data ) {
			global $wpdb;
			$prefix = (is_multisite()) ? $wpdb->base_prefix : $wpdb->prefix;
			$table_name = $prefix . 'comments';
			$comments_table_fields = array();
			$comment_data = array();
			$exclude_comments_table_fields = array('comment_ID');
			foreach( $wpdb->get_col( "DESC " . $table_name, 0 ) as $column_name ) {
				$comments_table_fields[] = $column_name;
				if( ! in_array( $column_name, $exclude_comments_table_fields ) ) {
					if( isset( $data[ $column_name ] ) ) {
						$comment_data[ $column_name ] = $data[ $column_name ];
					}
				}
			}
			if( is_array( $comment_data ) ) {
				$comment_data['comment_ID'] = $comment_id;
				wp_update_comment( $comment_data );
			}
			foreach( $data as $meta_key => $meta_value ) {
				if( ! in_array( $meta_key, $comments_table_fields ) ) {
					update_comment_meta( $comment_id, $meta_key, $meta_value );
				}
			}

			return $this->commentInfo( $comment_id );
		}

		public function postsArray( $args, $key, $value ) {
			$return = array();
			$posts = get_posts( $args );
			if( is_array( $posts ) ) {
				foreach( $posts as $p_key => $p_value ) {
					$return[ $p_value->$key ] = $p_value->$value;
				}
			}

			return $return;
		}

		public function relatedPosts( $post_info ) {
			$tax_query = array();
			foreach( $post_info['taxonomies'] as $key => $terms ) {
				$term_ids = array();
				foreach( $terms as $t_key => $term ) {
					$term_ids[] = $term['term_id'];
				}
				$tax_query[] = array(
					'taxonomy' => $key,
					'field' => 'id',
					'terms' => $term_ids,
					'operator' => 'IN' //Or 'AND' or 'NOT IN'
				);
			}
			$related = get_posts( array(
				'post_type' => $post_info['post_type'],
				'numberposts' => 12,
				'post__not_in' => array($post_info['ID']),
				'tax_query' => array(
					array(
						'taxonomy' => 'cj_freebies_category',
						'field' => 'id',
						'terms' => $term_ids,
						'operator' => 'IN' //Or 'AND' or 'NOT IN'
					)
				),
			) );

			return $related;
		}

		public function containsArray( $array ) {
			if( is_array( $array ) ) {
				foreach( $array as $value ) {
					if( is_array( $value ) ) {
						return true;
					}
				}
			}

			return false;
		}

		public function processPostVariables( $post_id, $string ) {
			$post_info = $this->postInfo( $post_id );
			if( ! empty( $post_info ) ) {
				foreach( $post_info as $key => $value ) {
					$value = (is_serialized( $value )) ? unserialize( $value ) : $value;
					if( ! $this->containsArray( $value ) ) {
						$value = (is_array( $value )) ? implode( '|', $value ) : $value;
						$string = str_replace( '%%' . $key . '%%', $value, $string );
					}
				}
			}

			return $string;
		}

		public function getPosts( $args, $r_key = null, $r_value = null ) {
			$posts_query = get_posts( $args );
			$posts = array();
			if( ! empty( $posts_query ) ) {
				foreach( $posts_query as $key => $post ) {
					if( isset( $post->$r_key ) && isset( $post->$r_value ) ) {
						$posts[] = (array) $post;
					} else {
						$posts[] = $this->postInfo( $post->ID );
					}
				}
			}

			if( ! empty( $posts ) && ! is_null( $r_key ) && ! is_null( $r_value ) ) {
				$return = array();
				foreach( $posts as $k => $v ) {
					$return[ $v[ $r_key ] ] = $v[ $r_value ];
				}

				return $return;
			}

			return $posts;
		}

		public function getPostsByMetaKey( $meta_key, $meta_value, $output = 'meta' ) {
			global $wpdb;
			$return = [];
			$posts = $wpdb->get_results( "SELECT * FROM $wpdb->postmeta WHERE meta_key = '{$meta_key}' AND meta_value = '{$meta_value}'", 'ARRAY_A' );
			if( ! empty( $posts ) && $output == 'meta' ) {
				return $posts;
			}
			if( ! empty( $posts ) && $output != 'meta' ) {
				foreach( $posts as $key => $post_meta ) {
					$return[] = $this->postInfo( $post_meta['post_id'] );
				}

				return $return;
			}
		}

		public function getPostByMetaKey( $meta_key, $meta_value = null ) {
			global $wpdb;
			$return = [];
			if( ! is_null( $meta_value ) ) {
				$post_meta = $wpdb->get_row( "SELECT * FROM $wpdb->postmeta WHERE meta_key = '{$meta_key}' AND meta_value = '{$meta_value}'", 'ARRAY_A' );
			} else {
				$post_meta = $wpdb->get_row( "SELECT * FROM $wpdb->postmeta WHERE meta_key = '{$meta_key}'", 'ARRAY_A' );
			}

			if( ! is_null( $post_meta['post_id'] ) ) {
				$return = $this->postInfo( $post_meta['post_id'] );
			}

			return $return;
		}

		public function postTaxonomies( $post_info = array(), $taxonomy = 'category', $return = 'array', $html_sep = ', ' ) {

			$data = $post_info['taxonomies'][ $taxonomy ];
			if( empty( $data ) ) {
				return array();
			}
			if( $return == 'array' ) {
				return $data;
			}
			if( $return == 'html' ) {
				$return = array();
				foreach( $data as $key => $value ) {
					$return[] = '<a href="' . $value['url'] . '" title="' . $value['name'] . '">' . $value['name'] . '</a>';
				}

				return implode( $html_sep, $return );
			}
		}

		public function getTerms( $taxonomy = 'category', $return = 'array', $html_sep = ', ' ) {

			$terms = get_terms( $taxonomy );
			$data = array();
			if( empty( $terms ) ) {
				return ($return == 'array') ? array() : '';
			}
			if( ! empty( $terms ) ) {
				$term_links = array();
				foreach( $terms as $key => $term ) {
					$data[ $term->term_id ]['term_id'] = $term->term_id;
					$data[ $term->term_id ]['name'] = $term->name;
					$data[ $term->term_id ]['slug'] = $term->slug;
					$data[ $term->term_id ]['term'] = $term;
					$url = get_term_link( $term );
					$data[ $term->term_id ]['url'] = $url;
					$term_links[] = '<a href="' . $url . '" title="' . $term->name . '">' . $term->name . '</a>';
				}

				return ($return == 'array') ? $data : implode( $html_sep, $term_links );
			}
		}

		public function featuredImage( $post_id, $resize = true, $size = array(1024, 1024), $crop = true, $quality = 100 ) {
			if( has_post_thumbnail( $post_id ) ) {
				$thumbnail = get_the_post_thumbnail( $post_id, 'full' );
				$thumbnail = $this->getImageSrc( $thumbnail );
				if( $resize ) {
					$thumbnail = $this->imageResize( $thumbnail, $size, $crop, $quality );
				}
				if( ! is_null( $thumbnail ) ) {
					return $thumbnail;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}

		public function featuredImageUrl( $post_id ) {

			if( has_post_thumbnail( $post_id ) ) {
				$thumbnail = get_the_post_thumbnail( $post_id, 'full' );
				$thumbnail = $this->getImageSrc( $thumbnail );
				if( ! is_null( $thumbnail ) ) {
					return $thumbnail;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}

		public function getImageSrc( $image ) {
			if( gettype( $image ) == 'string' && strpos( $image, 'img' ) > 0 ) {
				$xpath = new DOMXPath( @DOMDocument::loadHTML( $image ) );
				$src = $xpath->evaluate( "string(//img/@src)" );

				return $src;
			} else {
				return $image;
			}
		}

		public function imageResize( $image, $size = array(), $crop = false, $quality = 100 ) {
			$img = wp_get_image_editor( $image );
			if( ! is_wp_error( $img ) ) {
				$path = dirname( str_replace( $this->root_dir, $this->root_url, $image ) );
				$img->resize( $size[0], $size[1], $crop );
				$img->set_quality( $quality );
				$suffix = $img->get_suffix();
				$filename = $img->generate_filename( $suffix, $path, 'png' );
				$saved = $img->save( $filename );

				if( ! is_wp_error( $saved ) ) {
					return str_replace( $this->root_dir, $this->root_url, $saved['path'] );
				}
			} else {
				return null;
			}
		}

		public function getPostImages( $post_id ) {

			global $wpdb;
			$images = [];
			$query = $wpdb->get_results( "SELECT * FROM $wpdb->posts WHERE post_parent = '{$post_id}' AND post_type = 'attachment' AND post_mime_type LIKE 'image%'" );
			if( ! empty( $query ) ) {
				foreach( $query as $key => $value ) {
					$images[ $value->ID ] = $value->guid;
				}
			}

			return $images;
		}

		public function getPostUrl( $var ) {

			global $wpdb;
			$postID = (is_numeric( $var )) ? $var : 'slug';
			$return = null;
			if( $postID != 'slug' ) {
				$post_data = $wpdb->get_row( "SELECT * FROM $wpdb->posts WHERE ID = '{$var}'", ARRAY_A );
			} else {
				$post_data = $wpdb->get_row( "SELECT * FROM $wpdb->posts WHERE post_name = '{$var}'", ARRAY_A );
			}

			return get_permalink( $post_data['ID'] );
		}

		public function postTerms( $post_id, $taxonomy = null ) {

			$return = null;
			$post = get_post( $post_id );
			if( ! is_null( $taxonomy ) ) {
				$return[ $taxonomy ] = wp_get_post_terms( $post_id, $taxonomy );
			} else {
				$post_taxonomies = get_object_taxonomies( $post );
				foreach( $post_taxonomies as $key => $taxonomy ) {
					$return[ $taxonomy ] = wp_get_post_terms( $post_id, $taxonomy );
				}
			}

			return $return;
		}

		public function commentInfo( $comment_id, $fields = array(), $user_info_fields = array() ) {
			global $wpdb;
			$comments_table_data = $wpdb->get_row( "SELECT * FROM $wpdb->comments WHERE comment_ID = '{$comment_id}'", 'ARRAY_A' );
			$comment_data = array();
			if( is_array( $comments_table_data ) && ! empty( $comments_table_data ) ) {
				foreach( $comments_table_data as $key => $value ) {
					$value = (is_serialized( $value )) ? unserialize( $value ) : $value;
					$comment_data[ $key ] = $value;
				}
				$comment_data['user_info'] = $this->userInfo( $comment_data['user_id'], $user_info_fields );
			}

			$comment_meta = array();
			$comment_meta_data = $wpdb->get_results( "SELECT * FROM $wpdb->commentmeta WHERE comment_ID = '{$comment_id}'", 'ARRAY_A' );
			if( ! empty( $comment_meta_data ) ) {
				foreach( $comment_meta_data as $key => $meta ) {
					if( ! in_array( $meta['meta_key'], array_keys( $comment_data ) ) ) {
						$meta['meta_value'] = (is_serialized( $meta['meta_value'] )) ? @unserialize( $meta['meta_value'] ) : $meta['meta_value'];
						$comment_meta[ $meta['meta_key'] ] = $meta['meta_value'];
					}
				}
			}

			$return = array_merge( $comment_data, $comment_meta );

			$return['comment_content'] = wpautop( $return['comment_content'], true );

			if( empty( $fields ) ) {
				return $return;
			} else {
				$return_fields = array();
				foreach( $fields as $f_key => $f_value ) {
					$return_fields[ $f_value ] = $return[ $f_value ];
				}

				return $return_fields;
			}
		}

		public function setCookie( $name, $value = '', $expire = 86400, $path = '/', $domain = '', $secure = null, $httponly = false ) {

			$_COOKIE[ $name ] = $value;
			$expire = time() + $expire;

			$secure = (is_null( $secure )) ? is_ssl() : $secure;

			return setcookie( $name, $value, $expire, $path, $domain, $secure, $httponly );
		}

		public function getCookie( $name ) {

			return (isset( $_COOKIE[ $name ] )) ? $_COOKIE[ $name ] : null;
		}

		public function deleteCookie( $name ) {
			return $this->setcookie( $name, 0, - 1, '/', '', false, false );
		}

		public function setWordPressTimezone() {

			$timezone_string = get_option( 'timezone_string' );
			$system_timezone_string = date_default_timezone_get();
			$set_timezone_string = ($timezone_string == '') ? $system_timezone_string : $timezone_string;
			if( $set_timezone_string == '' ) {
				$set_timezone_string = 'UTC';
			}
			date_default_timezone_set( $set_timezone_string );
		}

		public function getWordPressTimezone() {

			return date_default_timezone_get();
		}

		public function wpDate( $date_or_timestamp = null, $output = 'date-time', $timezone = false ) {
			$default_timezone = ini_get( 'date.timezone' );
			if( $default_timezone == '' ) {
				$default_timezone = 'UTC';
			}
			$date_format = get_option( 'date_format' );
			$time_format = get_option( 'time_format' );
			if( is_null( $date_or_timestamp ) ) {
				$date_or_timestamp = time();
			}
			$timestamp = (is_numeric( $date_or_timestamp )) ? $date_or_timestamp : strtotime( $date_or_timestamp );
			if( $timezone ) {
				$timezone_string = get_option( 'timezone_string' );
				$timezone_string = ($timezone_string != '') ? $timezone_string : $default_timezone;
				if( $timezone_string == '' ) {
					$timezone_string = 'UTC';
				}
				date_default_timezone_set( $timezone_string );
				$timestamp = (is_numeric( $date_or_timestamp )) ? $date_or_timestamp : strtotime( $date_or_timestamp );
			}
			switch( $output ) {
				case 'date-time':
					$return = date( $date_format . ' ' . $time_format, $timestamp );
					break;
				case 'date':
					$return = date( $date_format, $timestamp );
					break;
				case 'time':
					$return = date( $time_format, $timestamp );
					break;
				default:
					$return = date( $output, $timestamp );
			}
			date_default_timezone_set( $default_timezone );

			return $return;
		}

		public function generatePostsDayLink( $date = null ) {
			$timestamp = time();
			if( ! is_null( $date ) ) {
				$timestamp = strtotime( $date );
			}

			return get_day_link( date( 'Y', $timestamp ), date( 'm', $timestamp ), date( 'd', $timestamp ) );
		}

		public function html2text( $html, $cut = null ) {
			$html = strip_tags( $html );
			$html = preg_replace( "/&#?[a-z0-9]{2,8};/i", "", $html );
			$html = html_entity_decode( $html, ENT_QUOTES, 'UTF-8' );
			if( ! is_null( $cut ) ) {
				$html = $this->trimChars( $html, $cut );
			}

			return $html;
		}

		public function trimChars( $str, $cut = 200, $after_trim = '…' ) {

			$str_length = strlen( $str );
			if( $str_length > $cut ) {
				return substr( $str, 0, $cut ) . $after_trim;
			} else {
				return $str;
			}
		}

		public function trimWords( $str, $cut = 10, $after_trim = '…' ) {

			$str_length = str_word_count( $str );
			$return = '';
			if( $str_length > $cut ) {
				foreach( str_word_count( $str, 1 ) as $key => $word ) {
					if( $key <= $cut - 1 ) {
						$return[] = $word;
					}
				}

				return implode( ' ', $return ) . $after_trim;
			} else {
				return $str;
			}
		}

		public function formatCurrency( $amount = null, $symbol = '$', $align = 'left', $decimal = 2 ) {

			$amount = number_format( $amount, $decimal );
			$return = ($align == 'left') ? $symbol . '' . $amount : $amount . ' ' . $symbol;

			return $return;
		}

		public function getCurrencyExchangeRate( $from = 'USD', $to = 'INR' ) {

			$exchange_rate_data = wp_remote_get( 'http://currency-api.appspot.com/api/' . $from . '/' . $to . '.json?amount=1.00' );
			if( ! is_wp_error( $exchange_rate_data ) ) {
				$return = json_decode( $exchange_rate_data['body'] );

				return $return->rate;
			} else {
				return 0;
			}
		}

		public function uploadFile( $file, $allowed_width = null, $allowed_height = null, $allowed_file_types = null, $allowed_file_size = null, $output = 'guid', $upload_dir = null ) {
			global $wpdb;

			if( ! function_exists( 'wp_handle_upload' ) ) {
				require_once(ABSPATH . 'wp-admin/includes/file.php');
			}
			$KB = '1024';
			$MB = $KB * 1024;
			$GB = $MB * 1024;
			$TB = $GB * 1024;
			$errors = null;
			if( is_null( $upload_dir ) ) {
				$wp_upload_dir = wp_upload_dir();
				$targetPath = $wp_upload_dir['path'] . '/';
			} else {
				$this->createDirectory( $upload_dir );
				$targetPath = $upload_dir . '/';
			}
			$tempFile = @$file['tmp_name'];
			$targetFile = @$file['name'];
			$fileParts = @pathinfo( $file['name'] );
			$ext = '.' . @$fileParts['extension'];
			$file_size = @$file['size'];
			if( ! is_null( $allowed_file_size ) && $file_size > ($allowed_file_size * $KB) ) {
				$errors[] = sprintf( esc_attr__( 'File size must be below %s kilobytes.', 'cssjockey-add-ons' ), $allowed_file_size );
			}
			list( $img_width, $img_height ) = @getimagesize( $tempFile );
			if( ! is_null( $allowed_width ) && $img_width > $allowed_width ) {
				$errors[] = sprintf( esc_attr__( 'Image width must be %s pixels.', 'cssjockey-add-ons' ), $allowed_width );
			}
			if( ! is_null( $allowed_height ) && $img_height > $allowed_height ) {
				$errors[] = sprintf( esc_attr__( 'Image height must be %s pixels.', 'cssjockey-add-ons' ), $allowed_height );
			}
			if( ! $this->isFileMimeTypeAllowed( $file['type'] ) ) {
				$errors[] = esc_attr__( 'File format is not allowed.', 'cssjockey-add-ons' );
			} else if( ! is_null( $allowed_file_types ) && ! in_array( str_replace( '.', '', $ext ), explode( '|', $allowed_file_types ) ) ) {
				$errors[] = esc_attr__( 'File format is not allowed.', 'cssjockey-add-ons' );
			}
			if( is_array( $errors ) ) {
				return array('errors' => $errors);
			} else {
				$newFileName = wp_unique_filename( $targetPath, $targetFile );
				$targetFile = str_replace( '//', '/', $targetPath ) . $newFileName;
				$filename = $targetFile;
				$wp_file_type = wp_check_filetype( basename( $filename ), null );

				if( ! is_null( $upload_dir ) ) {
					$upload_overrides = array('test_form' => false);
					$file_handler = wp_handle_upload( $file, $upload_overrides );
					if( $file_handler && ! isset( $file_handler['error'] ) ) {
						return $file_handler['url'];
					} else {
						return array('errors' => $file_handler['error']);
					}
				}

				$attachment = array(
					'guid' => $wp_upload_dir['baseurl'] . '/' . _wp_relative_upload_path( $filename ),
					'post_mime_type' => $wp_file_type['type'],
					'post_title' => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
					'post_content' => '',
					'post_status' => 'inherit',
				);
				$attach_id = wp_insert_attachment( $attachment, $filename );
				require_once(wp_normalize_path( ABSPATH . 'wp-admin/includes/image.php' ));
				require_once(wp_normalize_path( ABSPATH . 'wp-admin/includes/media.php' ));
				$attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
				wp_update_attachment_metadata( $attach_id, $attach_data );
				$guid = $wpdb->get_row( "SELECT * FROM $wpdb->posts WHERE ID = '{$attach_id}'" );
				if( $output == 'guid' ) {
					return $guid->guid;
				} else {
					return array(
						'ID' => $guid->ID,
						'guid' => $guid->guid
					);
				}
			}
		}

		public function getUniqueArrayAssoc( $array, $return = array() ) {

			for( $x = 0; $x <= count( $array ); $x ++ ) {
				if( isset( $array[ $x ] ) && is_array( $array[ $x ] ) ) {
					$return = $this->getUniqueArrayAssoc( $array[ $x ], $return );
				} else {
					if( isset( $array[ $x ] ) ) {
						$return[] = $array[ $x ];
					}
				}
			}

			return array_unique( $return );
		}

		public function getAddressesByPostcode( $post_code, $only_zip = false ) {
			$return = $this->getAddressFromGoogle( $post_code );

			return $return;
		}

		public function getAddressByCoords( $lat, $lng ) {
			$return = array();
			$url = 'http://maps.googleapis.com/maps/api/geocode/json?latlng=' . trim( $lat ) . ',' . trim( $lng ) . '&sensor=false';
			$json = $this->wpRemoteGet( $url );
			$data = json_decode( $json );
			$status = $data->status;
			if( $status == "OK" ) {
				if( count( $data->results ) > 0 ) {
					foreach( $data->results as $key => $value ) {
						$return[ $key ]['address'] = $data->results[ $key ]->formatted_address;
						$return[ $key ]['latlng'] = $data->results[ $key ]->geometry->location;
						$return[ $key ]['street_number'] = '';
						$return[ $key ]['establishment'] = '';
						$return[ $key ]['route'] = '';
						$return[ $key ]['locality'] = '';
						$return[ $key ]['sublocality'] = '';
						$return[ $key ]['city'] = '';
						$return[ $key ]['state'] = '';
						$return[ $key ]['country'] = '';
						$return[ $key ]['zipcode'] = '';
						foreach( $data->results[ $key ]->address_components as $akey => $avalue ) {
							if( in_array( 'street_number', $avalue->types ) ) {
								$return[ $key ]['street_number'] = $avalue->long_name;
							}
							if( in_array( 'route', $avalue->types ) ) {
								$return[ $key ]['route'] = $avalue->long_name;
							}
							if( in_array( 'neighborhood', $avalue->types ) ) {
								$return[ $key ]['address_line_2'] = $avalue->long_name;
							}
							if( in_array( 'locality', $avalue->types ) ) {
								$return[ $key ]['locality'] = $avalue->long_name;
							}
							if( in_array( 'sublocality', $avalue->types ) ) {
								$return[ $key ]['sublocality'] = $avalue->long_name;
							}
							if( in_array( 'administrative_area_level_2', $avalue->types ) ) {
								$return[ $key ]['city'] = $avalue->long_name;
							}
							if( in_array( 'administrative_area_level_1', $avalue->types ) ) {
								$return[ $key ]['state'] = $avalue->long_name;
							}
							if( in_array( 'country', $avalue->types ) ) {
								$return[ $key ]['country'] = $avalue->long_name;
							}
							if( in_array( 'postal_code', $avalue->types ) ) {
								$return[ $key ]['zipcode'] = $avalue->long_name;
							}
							$return[ $key ]['address_line_1'] = $return[ $key ]['street_number'] . ' ' . $return[ $key ]['route'];
						}
					}
				}
			}

			return $return;
		}

		public function getCoordsByAddress( $address ) {

			$url = 'http://maps.googleapis.com/maps/api/geocode/json?address=' . urlencode( $address ) . '&sensor=false';
			$json = $this->wpRemoteGet( $url );
			$data = json_decode( $json );
			$lng = $data->results[0]->geometry->location->lng;
			$lat = $data->results[0]->geometry->location->lat;
			$return['lat'] = $lat;
			$return['lng'] = $lng;

			return $return;
		}

		public function getAddressFromGoogle( $address, $region = '' ) {
			$region_string = ($region != '') ? '&region=' . $region : '';
			$url = 'http://maps.googleapis.com/maps/api/geocode/json?address=' . urlencode( $address ) . $region_string . '&sensor=false';
			$json = $this->wpRemoteGet( $url );
			$data = json_decode( $json );
			$return = array();
			if( isset( $data->results ) && is_array( $data->results ) && ! empty( $data->results ) ) {
				foreach( $data->results as $key => $value ) {
					$return[ $key ]['address'] = $data->results[ $key ]->formatted_address;
					$return[ $key ]['latlng'] = $data->results[ $key ]->geometry->location;
					$return[ $key ]['street_number'] = '';
					$return[ $key ]['establishment'] = '';
					$return[ $key ]['route'] = '';
					$return[ $key ]['locality'] = '';
					$return[ $key ]['sublocality'] = '';
					$return[ $key ]['city'] = '';
					$return[ $key ]['state'] = '';
					$return[ $key ]['country'] = '';
					$return[ $key ]['zipcode'] = '';
					foreach( $data->results[ $key ]->address_components as $akey => $avalue ) {
						if( in_array( 'street_number', $avalue->types ) ) {
							$return[ $key ]['street_number'] = $avalue->long_name;
						}
						if( in_array( 'route', $avalue->types ) ) {
							$return[ $key ]['route'] = $avalue->long_name;
						}
						if( in_array( 'neighborhood', $avalue->types ) ) {
							$return[ $key ]['address_line_2'] = $avalue->long_name;
						}
						if( in_array( 'locality', $avalue->types ) ) {
							$return[ $key ]['locality'] = $avalue->long_name;
						}
						if( in_array( 'sublocality', $avalue->types ) ) {
							$return[ $key ]['sublocality'] = $avalue->long_name;
						}
						if( in_array( 'administrative_area_level_2', $avalue->types ) ) {
							$return[ $key ]['city'] = $avalue->long_name;
						}
						if( in_array( 'administrative_area_level_1', $avalue->types ) ) {
							$return[ $key ]['state'] = $avalue->long_name;
						}
						if( in_array( 'country', $avalue->types ) ) {
							$return[ $key ]['country'] = $avalue->long_name;
						}
						if( in_array( 'postal_code', $avalue->types ) ) {
							$return[ $key ]['zipcode'] = $avalue->long_name;
						}
						$return[ $key ]['address_line_1'] = $return[ $key ]['street_number'] . ' ' . $return[ $key ]['route'];
					}
				}
			}

			return $return;
		}

		public function fontAwesomeIconsArray( $icon = null ) {
			ob_start();
			require $this->root_dir . '/framework/json/font-awesome-icons.json';
			$json = ob_get_clean();
			$return = array('none' => __( 'None', 'cssjockey-add-ons' ));
			$icons = (array) json_decode( $json );

			$icons_array = array_merge( $return, $icons );

			return (is_null( $icon )) ? (array) $icons_array : $icons_array[ $icon ];
		}

		public function getGoogleFonts( $field = 'font-name' ) {
			$g_fonts = array();
			// delete_transient( 'cj_google_fonts' );
			//Set WP Transient Cache to cache the request for 1 week
			if( false === ($cj_google_fonts = get_transient( 'cj_google_fonts' )) ) {
				$url = 'https://www.googleapis.com/webfonts/v1/webfonts?key=AIzaSyAcppe5laBbe858wNvCsNs6sA3FC5AFwsA';
				$cj_google_fonts = (array) json_decode( $this->wpRemoteGet( $url ) );
				set_transient( 'cj_google_fonts', $cj_google_fonts, 1 * (24 * 3600 * 7) );
			} else {
				$cj_google_fonts = get_transient( 'cj_google_fonts' );
			}
			if( ! empty( $cj_google_fonts ) ) {
				foreach( $cj_google_fonts as $cj_google_font ) {
					$cj_gfonts = (array) $cj_google_font;
					foreach( $cj_gfonts as $value ) {
						$val = (array) $value;
						if( array_key_exists( 'family', $val ) ) {
							$g_fonts[ $val['family'] ] = $val['family'];
						}
					}
				}
			}
			if( ! empty( $g_fonts ) ) {
				return $g_fonts;
			}
		}

		public function arrays( $type = null ) {

			$arrays['yes-no'] = array(
				'yes' => esc_attr__( 'Yes', 'cssjockey-add-ons' ),
				'no' => esc_attr__( 'No', 'cssjockey-add-ons' ),
			);
			$arrays['on-off'] = array(
				'on' => esc_attr__( 'On', 'cssjockey-add-ons' ),
				'off' => esc_attr__( 'Off', 'cssjockey-add-ons' ),
			);
			$arrays['yes-no-maybe'] = array(
				'yes' => esc_attr__( 'Yes', 'cssjockey-add-ons' ),
				'no' => esc_attr__( 'No', 'cssjockey-add-ons' ),
				'maybe' => esc_attr__( 'May be', 'cssjockey-add-ons' ),
			);
			$arrays['enable-disable'] = array(
				'enable' => esc_attr__( 'Enable', 'cssjockey-add-ons' ),
				'disable' => esc_attr__( 'Disable', 'cssjockey-add-ons' ),
			);
			$arrays['active-inactive'] = array(
				'active' => esc_attr__( 'Active', 'cssjockey-add-ons' ),
				'inactive' => esc_attr__( 'Inactive', 'cssjockey-add-ons' ),
			);
			$arrays['register-type'] = array(
				'normal' => esc_attr__( 'Normal', 'cssjockey-add-ons' ),
				'approvals' => esc_attr__( 'Approvals Required', 'cssjockey-add-ons' ),
				'invitations' => esc_attr__( 'Invitations Only', 'cssjockey-add-ons' ),
			);
			$arrays['register-password-type'] = array(
				'enable' => esc_attr__( 'Allow users to set their passwords while registration.', 'cssjockey-add-ons' ),
				'disable' => esc_attr__( 'Generate password automatically and send via email.', 'cssjockey-add-ons' ),
			);
			$arrays['avatar-type'] = array(
				'gravatar' => esc_attr__( 'Use Gravatar', 'cssjockey-add-ons' ),
				'custom' => esc_attr__( 'Allow custom profile picture upload', 'cssjockey-add-ons' ),
				'social' => esc_attr__( 'Use Social Profile Avatar', 'cssjockey-add-ons' ),
			);
			$arrays['spam-pages'] = array(
				'none' => esc_attr__( 'None', 'cssjockey-add-ons' ),
				'login' => esc_attr__( 'Login Form', 'cssjockey-add-ons' ),
				'register' => esc_attr__( 'Registration Form', 'cssjockey-add-ons' ),
				'reset_password' => esc_attr__( 'Reset Password Form', 'cssjockey-add-ons' ),
			);
			$arrays['spam-theme'] = array(
				'light' => esc_attr__( 'light', 'cssjockey-add-ons' ),
				'dark' => esc_attr__( 'dark', 'cssjockey-add-ons' ),
			);
			$arrays['mm-themes'] = array(
				'default' => esc_attr__( 'Default', 'cssjockey-add-ons' ),
			);
			$arrays['mm-timer'] = array(
				'days-left' => esc_attr__( 'Days Left', 'cssjockey-add-ons' ),
				'clock' => esc_attr__( 'Countdown Clock', 'cssjockey-add-ons' ),
			);
			$arrays['body-bg'] = array(
				'color' => '#f7f7f7',
				'image' => null,
				'bg_repeat' => 'no-repeat',
				'bg_size' => 'cover',
				'bg_attachment' => 'inherit',
				'bg_position' => 'top center',
			);
			$arrays['background-repeat'] = array(
				'inherit' => __( 'Inherit', 'cssjockey-add-ons' ),
				'repeat' => __( 'Repeat All', 'cssjockey-add-ons' ),
				'repeat-x' => __( 'Repeat Horizontal', 'cssjockey-add-ons' ),
				'repeat-y' => __( 'Repeat Vertical', 'cssjockey-add-ons' ),
				'no-repeat' => __( 'Do not repeat', 'cssjockey-add-ons' ),
			);
			$arrays['background-size'] = array(
				'inherit' => __( 'Inherit', 'cssjockey-add-ons' ),
				'cover' => __( 'Cover', 'cssjockey-add-ons' ),
				'contain' => __( 'Contain', 'cssjockey-add-ons' ),
			);
			$arrays['background-attachment'] = array(
				'inherit' => __( 'Inherit', 'cssjockey-add-ons' ),
				'fixed' => __( 'Fixed', 'cssjockey-add-ons' ),
				'scroll' => __( 'Scroll', 'cssjockey-add-ons' ),
			);
			$arrays['background-position'] = array(
				'inherit' => __( 'Inherit', 'cssjockey-add-ons' ),
				'top left' => __( 'Top Left', 'cssjockey-add-ons' ),
				'top center' => __( 'Top Center', 'cssjockey-add-ons' ),
				'top right' => __( 'Top Right', 'cssjockey-add-ons' ),
				'bottom left' => __( 'Bottom Left', 'cssjockey-add-ons' ),
				'bottom center' => __( 'Bottom Center', 'cssjockey-add-ons' ),
				'bottom right' => __( 'Bottom Right', 'cssjockey-add-ons' ),
				'center left' => __( 'Center Left', 'cssjockey-add-ons' ),
				'center center' => __( 'Center Center', 'cssjockey-add-ons' ),
				'center right' => __( 'Center Right', 'cssjockey-add-ons' ),
			);
			$arrays['border-style'] = array(
				"solid" => __( 'Solid', 'cssjockey-add-ons' ),
				"dotted" => __( 'Dotted', 'cssjockey-add-ons' ),
				"dashed" => __( 'Dashed', 'cssjockey-add-ons' ),
				"none" => __( 'None', 'cssjockey-add-ons' ),
				"hidden" => __( 'Hidden', 'cssjockey-add-ons' ),
				"double" => __( 'Double', 'cssjockey-add-ons' ),
				"groove" => __( 'Groove', 'cssjockey-add-ons' ),
				"ridge" => __( 'Ridge', 'cssjockey-add-ons' ),
				"inset" => __( 'Inset', 'cssjockey-add-ons' ),
				"outset" => __( 'Outset', 'cssjockey-add-ons' ),
				"initial" => __( 'Initial', 'cssjockey-add-ons' ),
				"inherit" => __( 'Inherit', 'cssjockey-add-ons' ),
			);
			$arrays['position'] = array(
				"absolute" => __( 'absolute', 'cssjockey-add-ons' ),
				"fixed" => __( 'fixed', 'cssjockey-add-ons' ),
				"relative" => __( 'relative', 'cssjockey-add-ons' ),
				"static" => __( 'static', 'cssjockey-add-ons' ),
				"inherit" => __( 'inherit', 'cssjockey-add-ons' ),
			);
			$arrays['display'] = array(
				'none' => __( 'None', 'cssjockey-add-ons' ),
				'inline' => __( 'Inline', 'cssjockey-add-ons' ),
				'block' => __( 'Block', 'cssjockey-add-ons' ),
				'flex' => __( 'Flex', 'cssjockey-add-ons' ),
				'inline-block' => __( 'Inline Block', 'cssjockey-add-ons' ),
				'inline-flex' => __( 'Inline Flex', 'cssjockey-add-ons' ),
				'inline-table' => __( 'Inline Table', 'cssjockey-add-ons' ),
				'list-item' => __( 'List Item', 'cssjockey-add-ons' ),
				'run-in' => __( 'Run In', 'cssjockey-add-ons' ),
				'table' => __( 'Table', 'cssjockey-add-ons' ),
				'table-caption' => __( 'Table Caption', 'cssjockey-add-ons' ),
				'table-column-group' => __( 'Table Column Group', 'cssjockey-add-ons' ),
				'table-header-group' => __( 'Table Header Group', 'cssjockey-add-ons' ),
				'table-footer-group' => __( 'Table Footer Group', 'cssjockey-add-ons' ),
				'table-row-group' => __( 'Table Row Group', 'cssjockey-add-ons' ),
				'table-cell' => __( 'Table Cell', 'cssjockey-add-ons' ),
				'table-column' => __( 'Table Column', 'cssjockey-add-ons' ),
				'table-row' => __( 'Table Row', 'cssjockey-add-ons' ),
			);

			$arrays['float'] = array(
				'none' => __( 'None', 'cssjockey-add-ons' ),
				'left' => __( 'Left', 'cssjockey-add-ons' ),
				'right' => __( 'Right', 'cssjockey-add-ons' ),
			);
			$arrays['clear'] = array(
				'none' => __( 'None', 'cssjockey-add-ons' ),
				'left' => __( 'Left', 'cssjockey-add-ons' ),
				'right' => __( 'Right', 'cssjockey-add-ons' ),
				'both' => __( 'Both', 'cssjockey-add-ons' ),
			);
			$arrays['visibility'] = array(
				'hidden' => __( 'Hidden', 'cssjockey-add-ons' ),
				'visible' => __( 'Visible', 'cssjockey-add-ons' ),
				'collapse' => __( 'Collapse', 'cssjockey-add-ons' ),
			);
			$arrays['overflow'] = array(
				'hidden' => __( 'Hidden', 'cssjockey-add-ons' ),
				'visible' => __( 'Visible', 'cssjockey-add-ons' ),
				'scroll' => __( 'Scroll', 'cssjockey-add-ons' ),
				'auto' => __( 'Auto', 'cssjockey-add-ons' ),
			);

			$arrays['font-weight'] = array(
				'inherit' => esc_attr__( 'Inherit', 'cssjockey-add-ons' ),
				'bold' => esc_attr__( 'Bold', 'cssjockey-add-ons' ),
				'bolder' => esc_attr__( 'Bolder', 'cssjockey-add-ons' ),
				'normal' => esc_attr__( 'Normal', 'cssjockey-add-ons' ),
				'lighter' => esc_attr__( 'Lighter', 'cssjockey-add-ons' ),
				'100' => esc_attr__( '100', 'cssjockey-add-ons' ),
				'200' => esc_attr__( '200', 'cssjockey-add-ons' ),
				'300' => esc_attr__( '300', 'cssjockey-add-ons' ),
				'400' => esc_attr__( '400', 'cssjockey-add-ons' ),
				'500' => esc_attr__( '500', 'cssjockey-add-ons' ),
				'600' => esc_attr__( '600', 'cssjockey-add-ons' ),
				'700' => esc_attr__( '700', 'cssjockey-add-ons' ),
				'800' => esc_attr__( '800', 'cssjockey-add-ons' ),
				'900' => esc_attr__( '900', 'cssjockey-add-ons' ),
			);
			$arrays['font-style'] = array(
				'inherit' => esc_attr__( 'Inherit', 'cssjockey-add-ons' ),
				'italic' => esc_attr__( 'Italic', 'cssjockey-add-ons' ),
				'oblique' => esc_attr__( 'Oblique', 'cssjockey-add-ons' ),
				'normal' => esc_attr__( 'Normal', 'cssjockey-add-ons' ),
			);
			for( $i = 8; $i < 37; $i ++ ) {
				$arrays['font-size'][ $i . 'px' ] = $i . 'px';
			}
			$arrays['text-align'] = array(
				'inherit' => esc_attr__( 'Inherit', 'cssjockey-add-ons' ),
				'left' => esc_attr__( 'Left', 'cssjockey-add-ons' ),
				'right' => esc_attr__( 'Right', 'cssjockey-add-ons' ),
				'center' => esc_attr__( 'Center', 'cssjockey-add-ons' ),
				'justify' => esc_attr__( 'Justify', 'cssjockey-add-ons' ),
			);
			$arrays['image-align'] = array(
				'none' => esc_attr__( 'None', 'cssjockey-add-ons' ),
				'left' => esc_attr__( 'Left', 'cssjockey-add-ons' ),
				'right' => esc_attr__( 'Right', 'cssjockey-add-ons' ),
				'center' => esc_attr__( 'Center', 'cssjockey-add-ons' ),
			);
			$arrays['text-decoration'] = array(
				'inherit' => esc_attr__( 'Inherit', 'cssjockey-add-ons' ),
				'underline' => esc_attr__( 'Underline', 'cssjockey-add-ons' ),
				'overline' => esc_attr__( 'Overline', 'cssjockey-add-ons' ),
				'line-through' => esc_attr__( 'Line Through', 'cssjockey-add-ons' ),
				'initial' => esc_attr__( 'initial', 'cssjockey-add-ons' ),
			);
			$arrays['text-transform'] = array(
				'none' => esc_attr__( 'None', 'cssjockey-add-ons' ),
				'capitalize' => esc_attr__( 'Capitalize', 'cssjockey-add-ons' ),
				'uppercase' => esc_attr__( 'Uppercase', 'cssjockey-add-ons' ),
				'lowercase' => esc_attr__( 'Lowercase', 'cssjockey-add-ons' ),
				'initial' => esc_attr__( 'Initial', 'cssjockey-add-ons' ),
				'inherit' => esc_attr__( 'Inherit', 'cssjockey-add-ons' ),
			);
			$arrays['font-variant'] = array(
				'normal' => esc_attr__( 'Normal', 'cssjockey-add-ons' ),
				'small-caps' => esc_attr__( 'Small Caps', 'cssjockey-add-ons' ),
			);
			$arrays['white-space'] = array(
				'normal' => __( 'normal', 'cssjockey-add-ons' ),
				'nowrap' => __( 'nowrap', 'cssjockey-add-ons' ),
				'pre' => __( 'pre', 'cssjockey-add-ons' ),
				'pre-line' => __( 'pre-line', 'cssjockey-add-ons' ),
				'pre-wrap' => __( 'pre-wrap', 'cssjockey-add-ons' ),
				'initial' => __( 'initial', 'cssjockey-add-ons' ),
				'inherit' => __( 'inherit', 'cssjockey-add-ons' ),
			);
			$arrays['button-size'] = array(
				'mini' => esc_attr__( 'mini', 'cssjockey-add-ons' ),
				'small' => esc_attr__( 'small', 'cssjockey-add-ons' ),
				'default' => esc_attr__( 'medium', 'cssjockey-add-ons' ),
				'large' => esc_attr__( 'large', 'cssjockey-add-ons' ),
			);
			$arrays['link-target'] = array(
				'_self' => esc_attr__( 'Same window', 'cssjockey-add-ons' ),
				'_blank' => esc_attr__( 'New window', 'cssjockey-add-ons' ),
			);

			$arrays['animate-css'] = array(
				'bounce' => 'bounce',
				'flash' => 'flash',
				'pulse' => 'pulse',
				'rubberBand' => 'rubberBand',
				'shake' => 'shake',
				'headShake' => 'headShake',
				'swing' => 'swing',
				'tada' => 'tada',
				'wobble' => 'wobble',
				'jello' => 'jello',
				'bounceIn' => 'bounceIn',
				'bounceInDown' => 'bounceInDown',
				'bounceInLeft' => 'bounceInLeft',
				'bounceInRight' => 'bounceInRight',
				'bounceInUp' => 'bounceInUp',
				'bounceOut' => 'bounceOut',
				'bounceOutDown' => 'bounceOutDown',
				'bounceOutLeft' => 'bounceOutLeft',
				'bounceOutRight' => 'bounceOutRight',
				'bounceOutUp' => 'bounceOutUp',
				'fadeIn' => 'fadeIn',
				'fadeInDown' => 'fadeInDown',
				'fadeInDownBig' => 'fadeInDownBig',
				'fadeInLeft' => 'fadeInLeft',
				'fadeInLeftBig' => 'fadeInLeftBig',
				'fadeInRight' => 'fadeInRight',
				'fadeInRightBig' => 'fadeInRightBig',
				'fadeInUp' => 'fadeInUp',
				'fadeInUpBig' => 'fadeInUpBig',
				'fadeOut' => 'fadeOut',
				'fadeOutDown' => 'fadeOutDown',
				'fadeOutDownBig' => 'fadeOutDownBig',
				'fadeOutLeft' => 'fadeOutLeft',
				'fadeOutLeftBig' => 'fadeOutLeftBig',
				'fadeOutRight' => 'fadeOutRight',
				'fadeOutRightBig' => 'fadeOutRightBig',
				'fadeOutUp' => 'fadeOutUp',
				'fadeOutUpBig' => 'fadeOutUpBig',
				'flipInX' => 'flipInX',
				'flipInY' => 'flipInY',
				'flipOutX' => 'flipOutX',
				'flipOutY' => 'flipOutY',
				'lightSpeedIn' => 'lightSpeedIn',
				'lightSpeedOut' => 'lightSpeedOut',
				'rotateIn' => 'rotateIn',
				'rotateInDownLeft' => 'rotateInDownLeft',
				'rotateInDownRight' => 'rotateInDownRight',
				'rotateInUpLeft' => 'rotateInUpLeft',
				'rotateInUpRight' => 'rotateInUpRight',
				'rotateOut' => 'rotateOut',
				'rotateOutDownLeft' => 'rotateOutDownLeft',
				'rotateOutDownRight' => 'rotateOutDownRight',
				'rotateOutUpLeft' => 'rotateOutUpLeft',
				'rotateOutUpRight' => 'rotateOutUpRight',
				'hinge' => 'hinge',
				'rollIn' => 'rollIn',
				'rollOut' => 'rollOut',
				'zoomIn' => 'zoomIn',
				'zoomInDown' => 'zoomInDown',
				'zoomInLeft' => 'zoomInLeft',
				'zoomInRight' => 'zoomInRight',
				'zoomInUp' => 'zoomInUp',
				'zoomOut' => 'zoomOut',
				'zoomOutDown' => 'zoomOutDown',
				'zoomOutLeft' => 'zoomOutLeft',
				'zoomOutRight' => 'zoomOutRight',
				'zoomOutUp' => 'zoomOutUp',
				'slideInDown' => 'slideInDown',
				'slideInLeft' => 'slideInLeft',
				'slideInRight' => 'slideInRight',
				'slideInUp' => 'slideInUp',
				'slideOutDown' => 'slideOutDown',
				'slideOutLeft' => 'slideOutLeft',
				'slideOutRight' => 'slideOutRight',
				'slideOutUp' => 'slideOutUp',
			);

			$arrays['captcha-lang'] = array(
				'ar' => 'Arabic',
				'bg' => 'Bulgarian',
				'ca' => 'Catalan',
				'zh-CN' => 'Chinese (Simplified)',
				'zh-TW' => 'Chinese (Traditional)',
				'hr' => 'Croatian',
				'cs' => 'Czech',
				'da' => 'Danish',
				'nl' => 'Dutch',
				'en-GB' => 'English (UK)',
				'en' => 'English (US)',
				'fil' => 'Filipino',
				'fi' => 'Finnish',
				'fr' => 'French',
				'fr-CA' => 'French (Canadian)',
				'de' => 'German',
				'de-AT' => 'German (Austria)',
				'de-CH' => 'German (Switzerland)',
				'el' => 'Greek',
				'iw' => 'Hebrew',
				'hi' => 'Hindi',
				'hu' => 'Hungarain',
				'id' => 'Indonesian',
				'it' => 'Italian',
				'ja' => 'Japanese',
				'ko' => 'Korean',
				'lv' => 'Latvian',
				'lt' => 'Lithuanian',
				'no' => 'Norwegian',
				'fa' => 'Persian',
				'pl' => 'Polish',
				'pt' => 'Portuguese',
				'pt-BR' => 'Portuguese (Brazil)',
				'pt-PT' => 'Portuguese (Portugal)',
				'ro' => 'Romanian',
				'ru' => 'Russian',
				'sr' => 'Serbian',
				'sk' => 'Slovak',
				'sl' => 'Slovenian',
				'es' => 'Spanish',
				'es-419' => 'Spanish (Latin America)',
				'sv' => 'Swedish',
				'th' => 'Thai',
				'tr' => 'Turkish',
				'uk' => 'Ukrainian',
				'vi' => 'Vietnamese',
			);

			$arrays['moment-locales'] = array(
				'en' => 'en',
				'af' => 'af',
				'ar-dz' => 'ar-dz',
				'ar-kw' => 'ar-kw',
				'ar-ly' => 'ar-ly',
				'ar-ma' => 'ar-ma',
				'ar-sa' => 'ar-sa',
				'ar-tn' => 'ar-tn',
				'ar' => 'ar',
				'az' => 'az',
				'be' => 'be',
				'bg' => 'bg',
				'bn' => 'bn',
				'bo' => 'bo',
				'br' => 'br',
				'bs' => 'bs',
				'ca' => 'ca',
				'cs' => 'cs',
				'cv' => 'cv',
				'cy' => 'cy',
				'da' => 'da',
				'de-at' => 'de-at',
				'de-ch' => 'de-ch',
				'de' => 'de',
				'dv' => 'dv',
				'el' => 'el',
				'en-au' => 'en-au',
				'en-ca' => 'en-ca',
				'en-gb' => 'en-gb',
				'en-ie' => 'en-ie',
				'en-nz' => 'en-nz',
				'eo' => 'eo',
				'es-do' => 'es-do',
				'es' => 'es',
				'et' => 'et',
				'eu' => 'eu',
				'fa' => 'fa',
				'fi' => 'fi',
				'fo' => 'fo',
				'fr-ca' => 'fr-ca',
				'fr-ch' => 'fr-ch',
				'fr' => 'fr',
				'fy' => 'fy',
				'gd' => 'gd',
				'gl' => 'gl',
				'gom-latn' => 'gom-latn',
				'he' => 'he',
				'hi' => 'hi',
				'hr' => 'hr',
				'hu' => 'hu',
				'hy-am' => 'hy-am',
				'id' => 'id',
				'is' => 'is',
				'it' => 'it',
				'ja' => 'ja',
				'jv' => 'jv',
				'ka' => 'ka',
				'kk' => 'kk',
				'km' => 'km',
				'kn' => 'kn',
				'ko' => 'ko',
				'ky' => 'ky',
				'lb' => 'lb',
				'lo' => 'lo',
				'lt' => 'lt',
				'lv' => 'lv',
				'me' => 'me',
				'mi' => 'mi',
				'mk' => 'mk',
				'ml' => 'ml',
				'mr' => 'mr',
				'ms-my' => 'ms-my',
				'ms' => 'ms',
				'my' => 'my',
				'nb' => 'nb',
				'ne' => 'ne',
				'nl-be' => 'nl-be',
				'nl' => 'nl',
				'nn' => 'nn',
				'pa-in' => 'pa-in',
				'pl' => 'pl',
				'pt-br' => 'pt-br',
				'pt' => 'pt',
				'ro' => 'ro',
				'ru' => 'ru',
				'sd' => 'sd',
				'se' => 'se',
				'si' => 'si',
				'sk' => 'sk',
				'sl' => 'sl',
				'sq' => 'sq',
				'sr-cyrl' => 'sr-cyrl',
				'sr' => 'sr',
				'ss' => 'ss',
				'sv' => 'sv',
				'sw' => 'sw',
				'ta' => 'ta',
				'te' => 'te',
				'tet' => 'tet',
				'th' => 'th',
				'tl-ph' => 'tl-ph',
				'tlh' => 'tlh',
				'tr' => 'tr',
				'tzl' => 'tzl',
				'tzm-latn' => 'tzm-latn',
				'tzm' => 'tzm',
				'uk' => 'uk',
				'ur' => 'ur',
				'uz-latn' => 'uz-latn',
				'uz' => 'uz',
				'vi' => 'vi',
				'x-pseudo' => 'x-pseudo',
				'yo' => 'yo',
				'zh-cn' => 'zh-cn',
				'zh-hk' => 'zh-hk',
				'zh-tw' => 'zh-tw',
			);

			$arrays['social-logins'] = array(
				'Facebook',
				'Twitter',
				'Google',
				'Yahoo',
				'Live',
				'LinkedIn',
				'Foursquare',
				'OpenID',
				'Github',
				'LastFM',
				'Vimeo',
				'Viadeo',
				'Identica',
				'Tumblr',
				'Goodreads',
				'QQ',
				'Sina',
				'Murmur',
				'Pixnet',
				'Plurk',
				'Skyrock',
				'Geni',
				'FamilySearch',
				'MyHeritage',
				'px500',
				'Vkontakte',
				'Mail.ru',
				'Yandex',
				'Odnoklassniki',
				'Instagram',
				'TwitchTV',
				'Steam',
			);

			$arrays['social-icons'] = array(
				'pe-so-500px' => 'pe-so-500px',
				'pe-so-aim' => 'pe-so-aim',
				'pe-so-amazon' => 'pe-so-amazon',
				'pe-so-android' => 'pe-so-android',
				'pe-so-app-store' => 'pe-so-app-store',
				'pe-so-apple' => 'pe-so-apple',
				'pe-so-behance' => 'pe-so-behance',
				'pe-so-bitbucket' => 'pe-so-bitbucket',
				'pe-so-blogger' => 'pe-so-blogger',
				'pe-so-codepen' => 'pe-so-codepen',
				'pe-so-css3' => 'pe-so-css3',
				'pe-so-deviantart-1' => 'pe-so-deviantart-1',
				'pe-so-deviantart-2' => 'pe-so-deviantart-2',
				'pe-so-digg' => 'pe-so-digg',
				'pe-so-dribbble' => 'pe-so-dribbble',
				'pe-so-dropbox' => 'pe-so-dropbox',
				'pe-so-drupal' => 'pe-so-drupal',
				'pe-so-etsy' => 'pe-so-etsy',
				'pe-so-evernote' => 'pe-so-evernote',
				'pe-so-facebook' => 'pe-so-facebook',
				'pe-so-firefox' => 'pe-so-firefox',
				'pe-so-flattr' => 'pe-so-flattr',
				'pe-so-forrst' => 'pe-so-forrst',
				'pe-so-foursquare' => 'pe-so-foursquare',
				'pe-so-git' => 'pe-so-git',
				'pe-so-github' => 'pe-so-github',
				'pe-so-google-plus' => 'pe-so-google-plus',
				'pe-so-grooveshark' => 'pe-so-grooveshark',
				'pe-so-habbo' => 'pe-so-habbo',
				'pe-so-hacker-news' => 'pe-so-hacker-news',
				'pe-so-html5' => 'pe-so-html5',
				'pe-so-ie' => 'pe-so-ie',
				'pe-so-instagram' => 'pe-so-instagram',
				'pe-so-jsfiddle' => 'pe-so-jsfiddle',
				'pe-so-lanyrd' => 'pe-so-lanyrd',
				'pe-so-lastfm' => 'pe-so-lastfm',
				'pe-so-linkedin' => 'pe-so-linkedin',
				'pe-so-linux' => 'pe-so-linux',
				'pe-so-love' => 'pe-so-love',
				'pe-so-myspace' => 'pe-so-myspace',
				'pe-so-odnolassniki' => 'pe-so-odnolassniki',
				'pe-so-openid' => 'pe-so-openid',
				'pe-so-opera' => 'pe-so-opera',
				'pe-so-paypal-1' => 'pe-so-paypal-1',
				'pe-so-paypal-2' => 'pe-so-paypal-2',
				'pe-so-pied-piper' => 'pe-so-pied-piper',
				'pe-so-pinterest' => 'pe-so-pinterest',
				'pe-so-qq' => 'pe-so-qq',
				'pe-so-qzone' => 'pe-so-qzone',
				'pe-so-rdio' => 'pe-so-rdio',
				'pe-so-reddit' => 'pe-so-reddit',
				'pe-so-renren' => 'pe-so-renren',
				'pe-so-rss' => 'pe-so-rss',
				'pe-so-safari-1' => 'pe-so-safari-1',
				'pe-so-safari-2' => 'pe-so-safari-2',
				'pe-so-share' => 'pe-so-share',
				'pe-so-skype' => 'pe-so-skype',
				'pe-so-slideshare' => 'pe-so-slideshare',
				'pe-so-soundcloud' => 'pe-so-soundcloud',
				'pe-so-spotify' => 'pe-so-spotify',
				'pe-so-stack-exchange' => 'pe-so-stack-exchange',
				'pe-so-stack-overflow' => 'pe-so-stack-overflow',
				'pe-so-steam' => 'pe-so-steam',
				'pe-so-stumbleupon' => 'pe-so-stumbleupon',
				'pe-so-tencent-weibo' => 'pe-so-tencent-weibo',
				'pe-so-trello' => 'pe-so-trello',
				'pe-so-tripadvisor' => 'pe-so-tripadvisor',
				'pe-so-tumblr' => 'pe-so-tumblr',
				'pe-so-twitch' => 'pe-so-twitch',
				'pe-so-twitter' => 'pe-so-twitter',
				'pe-so-viadeo' => 'pe-so-viadeo',
				'pe-so-vimeo' => 'pe-so-vimeo',
				'pe-so-vine' => 'pe-so-vine',
				'pe-so-vk' => 'pe-so-vk',
				'pe-so-wechat' => 'pe-so-wechat',
				'pe-so-weibo' => 'pe-so-weibo',
				'pe-so-wikipedia' => 'pe-so-wikipedia',
				'pe-so-windows' => 'pe-so-windows',
				'pe-so-wordpress-1' => 'pe-so-wordpress-1',
				'pe-so-wordpress-2' => 'pe-so-wordpress-2',
				'pe-so-xing' => 'pe-so-xing',
				'pe-so-yahoo-1' => 'pe-so-yahoo-1',
				'pe-so-yahoo-2' => 'pe-so-yahoo-2',
				'pe-so-yelp' => 'pe-so-yelp',
				'pe-so-youtube-1' => 'pe-so-youtube-1',
				'pe-so-youtube-2' => 'pe-so-youtube-2',
				'pe-so-zerply' => 'pe-so-zerply',
				'pe-so-bootstrap' => 'pe-so-bootstrap',
				'pe-so-pixeden' => 'pe-so-pixeden',
				'pe-so-magento' => 'pe-so-magento',
				'pe-so-sass' => 'pe-so-sass',
				'pe-so-ubuntu' => 'pe-so-ubuntu',
				'pe-so-like' => 'pe-so-like',
				'pe-so-chrome' => 'pe-so-chrome',
				'pe-so-delicious' => 'pe-so-delicious',
				'pe-so-ebay' => 'pe-so-ebay',
				'pe-so-flickr' => 'pe-so-flickr',
				'pe-so-google-drive' => 'pe-so-google-drive',
				'pe-so-joomla' => 'pe-so-joomla',
				'pe-so-picasa' => 'pe-so-picasa',
			);

			$arrays['mime-types'] = array(
				'x-world/x-3dmf' => '3dm',
				'x-world/x-3dmf' => '3dmf',
				'application/octet-stream' => 'a',
				'application/x-authorware-bin' => 'aab',
				'application/x-authorware-map' => 'aam',
				'application/x-authorware-seg' => 'aas',
				'text/vnd.abc' => 'abc',
				'text/html' => 'acgi',
				'video/animaflex' => 'afl',
				'application/postscript' => 'ai',
				'audio/aiff' => 'aif',
				'audio/x-aiff' => 'aif',
				'audio/aiff' => 'aifc',
				'audio/x-aiff' => 'aifc',
				'audio/aiff' => 'aiff',
				'audio/x-aiff' => 'aiff',
				'application/x-aim' => 'aim',
				'text/x-audiosoft-intra' => 'aip',
				'application/x-navi-animation' => 'ani',
				'application/x-nokia-9000-communicator-add-on-software' => 'aos',
				'application/mime' => 'aps',
				'application/octet-stream' => 'arc',
				'application/arj' => 'arj',
				'application/octet-stream' => 'arj',
				'image/x-jg' => 'art',
				'video/x-ms-asf' => 'asf',
				'text/x-asm' => 'asm',
				'text/asp' => 'asp',
				'application/x-mplayer2' => 'asx',
				'video/x-ms-asf' => 'asx',
				'video/x-ms-asf-plugin' => 'asx',
				'audio/basic' => 'au',
				'audio/x-au' => 'au',
				'application/x-troff-msvideo' => 'avi',
				'video/avi' => 'avi',
				'video/msvideo' => 'avi',
				'video/x-msvideo' => 'avi',
				'video/avs-video' => 'avs',
				'application/x-bcpio' => 'bcpio',
				'application/mac-binary' => 'bin',
				'application/macbinary' => 'bin',
				'application/octet-stream' => 'bin',
				'application/x-binary' => 'bin',
				'application/x-macbinary' => 'bin',
				'image/bmp' => 'bm',
				'image/bmp' => 'bmp',
				'image/x-windows-bmp' => 'bmp',
				'application/book' => 'boo',
				'application/book' => 'book',
				'application/x-bzip2' => 'boz',
				'application/x-bsh' => 'bsh',
				'application/x-bzip' => 'bz',
				'application/x-bzip2' => 'bz2',
				'text/plain' => 'c',
				'text/x-c' => 'c',
				'text/plain' => 'c++',
				'application/vnd.ms-pki.seccat' => 'cat',
				'text/plain' => 'cc',
				'text/x-c' => 'cc',
				'application/clariscad' => 'ccad',
				'application/x-cocoa' => 'cco',
				'application/cdf' => 'cdf',
				'application/x-cdf' => 'cdf',
				'application/x-netcdf' => 'cdf',
				'application/pkix-cert' => 'cer',
				'application/x-x509-ca-cert' => 'cer',
				'application/x-chat' => 'cha',
				'application/x-chat' => 'chat',
				'application/java' => 'class',
				'application/java-byte-code' => 'class',
				'application/x-java-class' => 'class',
				'application/octet-stream' => 'com',
				'text/plain' => 'com',
				'text/plain' => 'conf',
				'application/x-cpio' => 'cpio',
				'text/x-c' => 'cpp',
				'application/mac-compactpro' => 'cpt',
				'application/x-compactpro' => 'cpt',
				'application/x-cpt' => 'cpt',
				'application/pkcs-crl' => 'crl',
				'application/pkix-crl' => 'crl',
				'application/pkix-cert' => 'crt',
				'application/x-x509-ca-cert' => 'crt',
				'application/x-x509-user-cert' => 'crt',
				'application/x-csh' => 'csh',
				'text/x-script.csh' => 'csh',
				'application/x-pointplus' => 'css',
				'text/css' => 'css',
				'text/plain' => 'cxx',
				'application/x-director' => 'dcr',
				'application/x-deepv' => 'deepv',
				'text/plain' => 'def',
				'application/x-x509-ca-cert' => 'der',
				'video/x-dv' => 'dif',
				'application/x-director' => 'dir',
				'video/dl' => 'dl',
				'video/x-dl' => 'dl',
				'application/msword' => 'doc',
				'application/msword' => 'dot',
				'application/commonground' => 'dp',
				'application/drafting' => 'drw',
				'application/octet-stream' => 'dump',
				'video/x-dv' => 'dv',
				'application/x-dvi' => 'dvi',
				'drawing/x-dwf (old)' => 'dwf',
				'model/vnd.dwf' => 'dwf',
				'application/acad' => 'dwg',
				'image/vnd.dwg' => 'dwg',
				'image/x-dwg' => 'dwg',
				'application/dxf' => 'dxf',
				'image/vnd.dwg' => 'dxf',
				'image/x-dwg' => 'dxf',
				'application/x-director' => 'dxr',
				'text/x-script.elisp' => 'el',
				'application/x-bytecode.elisp (compiled elisp)' => 'elc',
				'application/x-elc' => 'elc',
				'application/x-envoy' => 'env',
				'application/postscript' => 'eps',
				'application/x-esrehber' => 'es',
				'text/x-setext' => 'etx',
				'application/envoy' => 'evy',
				'application/x-envoy' => 'evy',
				'application/octet-stream' => 'exe',
				'text/plain' => 'f',
				'text/x-fortran' => 'f',
				'text/x-fortran' => 'f77',
				'text/plain' => 'f90',
				'text/x-fortran' => 'f90',
				'application/vnd.fdf' => 'fdf',
				'application/fractals' => 'fif',
				'image/fif' => 'fif',
				'video/fli' => 'fli',
				'video/x-fli' => 'fli',
				'image/florian' => 'flo',
				'text/vnd.fmi.flexstor' => 'flx',
				'video/x-atomic3d-feature' => 'fmf',
				'text/plain' => 'for',
				'text/x-fortran' => 'for',
				'image/vnd.fpx' => 'fpx',
				'image/vnd.net-fpx' => 'fpx',
				'application/freeloader' => 'frl',
				'audio/make' => 'funk',
				'text/plain' => 'g',
				'image/g3fax' => 'g3',
				'image/gif' => 'gif',
				'video/gl' => 'gl',
				'video/x-gl' => 'gl',
				'audio/x-gsm' => 'gsd',
				'audio/x-gsm' => 'gsm',
				'application/x-gsp' => 'gsp',
				'application/x-gss' => 'gss',
				'application/x-gtar' => 'gtar',
				'application/x-compressed' => 'gz',
				'application/x-gzip' => 'gz',
				'application/x-gzip' => 'gzip',
				'multipart/x-gzip' => 'gzip',
				'text/plain' => 'h',
				'text/x-h' => 'h',
				'application/x-hdf' => 'hdf',
				'application/x-helpfile' => 'help',
				'application/vnd.hp-hpgl' => 'hgl',
				'text/plain' => 'hh',
				'text/x-h' => 'hh',
				'text/x-script' => 'hlb',
				'application/hlp' => 'hlp',
				'application/x-helpfile' => 'hlp',
				'application/x-winhelp' => 'hlp',
				'application/vnd.hp-hpgl' => 'hpg',
				'application/vnd.hp-hpgl' => 'hpgl',
				'application/binhex' => 'hqx',
				'application/binhex4' => 'hqx',
				'application/mac-binhex' => 'hqx',
				'application/mac-binhex40' => 'hqx',
				'application/x-binhex40' => 'hqx',
				'application/x-mac-binhex40' => 'hqx',
				'application/hta' => 'hta',
				'text/x-component' => 'htc',
				'text/html' => 'htm',
				'text/html' => 'html',
				'text/html' => 'htmls',
				'text/webviewhtml' => 'htt',
				'text/html' => 'htx',
				'x-conference/x-cooltalk' => 'ice',
				'image/x-icon' => 'ico',
				'text/plain' => 'idc',
				'image/ief' => 'ief',
				'image/ief' => 'iefs',
				'application/iges' => 'iges',
				'model/iges' => 'iges',
				'application/iges' => 'igs',
				'model/iges' => 'igs',
				'application/x-ima' => 'ima',
				'application/x-httpd-imap' => 'imap',
				'application/inf' => 'inf',
				'application/x-internett-signup' => 'ins',
				'application/x-ip2' => 'ip',
				'video/x-isvideo' => 'isu',
				'audio/it' => 'it',
				'application/x-inventor' => 'iv',
				'i-world/i-vrml' => 'ivr',
				'application/x-livescreen' => 'ivy',
				'audio/x-jam' => 'jam',
				'text/plain' => 'jav',
				'text/x-java-source' => 'jav',
				'text/plain' => 'java',
				'text/x-java-source' => 'java',
				'application/x-java-commerce' => 'jcm',
				'image/jpeg' => 'jfif',
				'image/pjpeg' => 'jfif',
				'image/jpeg' => 'jfif-tbnl',
				'image/jpeg' => 'jpe',
				'image/pjpeg' => 'jpe',
				'image/jpeg' => 'jpeg',
				'image/pjpeg' => 'jpeg',
				'image/jpeg' => 'jpg',
				'image/pjpeg' => 'jpg',
				'image/x-jps' => 'jps',
				'application/x-javascript' => 'js',
				'application/javascript' => 'js',
				'application/ecmascript' => 'js',
				'text/javascript' => 'js',
				'text/ecmascript' => 'js',
				'image/jutvision' => 'jut',
				'audio/midi' => 'kar',
				'music/x-karaoke' => 'kar',
				'application/x-ksh' => 'ksh',
				'text/x-script.ksh' => 'ksh',
				'audio/nspaudio' => 'la',
				'audio/x-nspaudio' => 'la',
				'audio/x-liveaudio' => 'lam',
				'application/x-latex' => 'latex',
				'application/lha' => 'lha',
				'application/octet-stream' => 'lha',
				'application/x-lha' => 'lha',
				'application/octet-stream' => 'lhx',
				'text/plain' => 'list',
				'audio/nspaudio' => 'lma',
				'audio/x-nspaudio' => 'lma',
				'text/plain' => 'log',
				'application/x-lisp' => 'lsp',
				'text/x-script.lisp' => 'lsp',
				'text/plain' => 'lst',
				'text/x-la-asf' => 'lsx',
				'application/x-latex' => 'ltx',
				'application/octet-stream' => 'lzh',
				'application/x-lzh' => 'lzh',
				'application/lzx' => 'lzx',
				'application/octet-stream' => 'lzx',
				'application/x-lzx' => 'lzx',
				'text/plain' => 'm',
				'text/x-m' => 'm',
				'video/mpeg' => 'm1v',
				'audio/mpeg' => 'm2a',
				'video/mpeg' => 'm2v',
				'audio/x-mpequrl' => 'm3u',
				'application/x-troff-man' => 'man',
				'application/x-navimap' => 'map',
				'text/plain' => 'mar',
				'application/mbedlet' => 'mbd',
				'application/x-magic-cap-package-1.0' => 'mc$',
				'application/mcad' => 'mcd',
				'application/x-mathcad' => 'mcd',
				'image/vasa' => 'mcf',
				'text/mcf' => 'mcf',
				'application/netmc' => 'mcp',
				'application/x-troff-me' => 'me',
				'message/rfc822' => 'mht',
				'message/rfc822' => 'mhtml',
				'application/x-midi' => 'mid',
				'audio/midi' => 'mid',
				'audio/x-mid' => 'mid',
				'audio/x-midi' => 'mid',
				'music/crescendo' => 'mid',
				'x-music/x-midi' => 'mid',
				'application/x-midi' => 'midi',
				'audio/midi' => 'midi',
				'audio/x-mid' => 'midi',
				'audio/x-midi' => 'midi',
				'music/crescendo' => 'midi',
				'x-music/x-midi' => 'midi',
				'application/x-frame' => 'mif',
				'application/x-mif' => 'mif',
				'message/rfc822' => 'mime',
				'www/mime' => 'mime',
				'audio/x-vnd.audioexplosion.mjuicemediafile' => 'mjf',
				'video/x-motion-jpeg' => 'mjpg',
				'application/base64' => 'mm',
				'application/x-meme' => 'mm',
				'application/base64' => 'mme',
				'audio/mod' => 'mod',
				'audio/x-mod' => 'mod',
				'video/quicktime' => 'moov',
				'video/quicktime' => 'mov',
				'video/x-sgi-movie' => 'movie',
				'audio/mpeg' => 'mp2',
				'audio/x-mpeg' => 'mp2',
				'video/mpeg' => 'mp2',
				'video/x-mpeg' => 'mp2',
				'video/x-mpeq2a' => 'mp2',
				'audio/mpeg3' => 'mp3',
				'audio/x-mpeg-3' => 'mp3',
				'video/mpeg' => 'mp3',
				'video/x-mpeg' => 'mp3',
				'audio/mpeg' => 'mpa',
				'video/mpeg' => 'mpa',
				'application/x-project' => 'mpc',
				'video/mpeg' => 'mpe',
				'video/mpeg' => 'mpeg',
				'audio/mpeg' => 'mpg',
				'video/mpeg' => 'mpg',
				'audio/mpeg' => 'mpga',
				'application/vnd.ms-project' => 'mpp',
				'application/x-project' => 'mpt',
				'application/x-project' => 'mpv',
				'application/x-project' => 'mpx',
				'application/marc' => 'mrc',
				'application/x-troff-ms' => 'ms',
				'video/x-sgi-movie' => 'mv',
				'audio/make' => 'my',
				'application/x-vnd.audioexplosion.mzz' => 'mzz',
				'image/naplps' => 'nap',
				'image/naplps' => 'naplps',
				'application/x-netcdf' => 'nc',
				'application/vnd.nokia.configuration-message' => 'ncm',
				'image/x-niff' => 'nif',
				'image/x-niff' => 'niff',
				'application/x-mix-transfer' => 'nix',
				'application/x-conference' => 'nsc',
				'application/x-navidoc' => 'nvd',
				'application/octet-stream' => 'o',
				'application/oda' => 'oda',
				'application/x-omc' => 'omc',
				'application/x-omcdatamaker' => 'omcd',
				'application/x-omcregerator' => 'omcr',
				'text/x-pascal' => 'p',
				'application/pkcs10' => 'p10',
				'application/x-pkcs10' => 'p10',
				'application/pkcs-12' => 'p12',
				'application/x-pkcs12' => 'p12',
				'application/x-pkcs7-signature' => 'p7a',
				'application/pkcs7-mime' => 'p7c',
				'application/x-pkcs7-mime' => 'p7c',
				'application/pkcs7-mime' => 'p7m',
				'application/x-pkcs7-mime' => 'p7m',
				'application/x-pkcs7-certreqresp' => 'p7r',
				'application/pkcs7-signature' => 'p7s',
				'application/pro_eng' => 'part',
				'text/pascal' => 'pas',
				'image/x-portable-bitmap' => 'pbm',
				'application/vnd.hp-pcl' => 'pcl',
				'application/x-pcl' => 'pcl',
				'image/x-pict' => 'pct',
				'image/x-pcx' => 'pcx',
				'chemical/x-pdb' => 'pdb',
				'application/pdf' => 'pdf',
				'audio/make' => 'pfunk',
				'audio/make.my.funk' => 'pfunk',
				'image/x-portable-graymap' => 'pgm',
				'image/x-portable-greymap' => 'pgm',
				'image/pict' => 'pic',
				'image/pict' => 'pict',
				'application/x-newton-compatible-pkg' => 'pkg',
				'application/vnd.ms-pki.pko' => 'pko',
				'text/plain' => 'pl',
				'text/x-script.perl' => 'pl',
				'application/x-pixclscript' => 'plx',
				'image/x-xpixmap' => 'pm',
				'text/x-script.perl-module' => 'pm',
				'application/x-pagemaker' => 'pm4',
				'application/x-pagemaker' => 'pm5',
				'image/png' => 'png',
				'application/x-portable-anymap' => 'pnm',
				'image/x-portable-anymap' => 'pnm',
				'application/mspowerpoint' => 'pot',
				'application/vnd.ms-powerpoint' => 'pot',
				'model/x-pov' => 'pov',
				'application/vnd.ms-powerpoint' => 'ppa',
				'image/x-portable-pixmap' => 'ppm',
				'application/mspowerpoint' => 'pps',
				'application/vnd.ms-powerpoint' => 'pps',
				'application/mspowerpoint' => 'ppt',
				'application/powerpoint' => 'ppt',
				'application/vnd.ms-powerpoint' => 'ppt',
				'application/x-mspowerpoint' => 'ppt',
				'application/mspowerpoint' => 'ppz',
				'application/x-freelance' => 'pre',
				'application/pro_eng' => 'prt',
				'application/postscript' => 'ps',
				'application/octet-stream' => 'psd',
				'paleovu/x-pv' => 'pvu',
				'application/vnd.ms-powerpoint' => 'pwz',
				'text/x-script.phyton' => 'py',
				'application/x-bytecode.python' => 'pyc',
				'audio/vnd.qcelp' => 'qcp',
				'x-world/x-3dmf' => 'qd3',
				'x-world/x-3dmf' => 'qd3d',
				'image/x-quicktime' => 'qif',
				'video/quicktime' => 'qt',
				'video/x-qtc' => 'qtc',
				'image/x-quicktime' => 'qti',
				'image/x-quicktime' => 'qtif',
				'audio/x-pn-realaudio' => 'ra',
				'audio/x-pn-realaudio-plugin' => 'ra',
				'audio/x-realaudio' => 'ra',
				'audio/x-pn-realaudio' => 'ram',
				'application/x-cmu-raster' => 'ras',
				'image/cmu-raster' => 'ras',
				'image/x-cmu-raster' => 'ras',
				'image/cmu-raster' => 'rast',
				'text/x-script.rexx' => 'rexx',
				'image/vnd.rn-realflash' => 'rf',
				'image/x-rgb' => 'rgb',
				'application/vnd.rn-realmedia' => 'rm',
				'audio/x-pn-realaudio' => 'rm',
				'audio/mid' => 'rmi',
				'audio/x-pn-realaudio' => 'rmm',
				'audio/x-pn-realaudio' => 'rmp',
				'audio/x-pn-realaudio-plugin' => 'rmp',
				'application/ringing-tones' => 'rng',
				'application/vnd.nokia.ringing-tone' => 'rng',
				'application/vnd.rn-realplayer' => 'rnx',
				'application/x-troff' => 'roff',
				'image/vnd.rn-realpix' => 'rp',
				'audio/x-pn-realaudio-plugin' => 'rpm',
				'text/richtext' => 'rt',
				'text/vnd.rn-realtext' => 'rt',
				'application/rtf' => 'rtf',
				'application/x-rtf' => 'rtf',
				'text/richtext' => 'rtf',
				'application/rtf' => 'rtx',
				'text/richtext' => 'rtx',
				'video/vnd.rn-realvideo' => 'rv',
				'text/x-asm' => 's',
				'audio/s3m' => 's3m',
				'application/octet-stream' => 'saveme',
				'application/x-tbook' => 'sbk',
				'application/x-lotusscreencam' => 'scm',
				'text/x-script.guile' => 'scm',
				'text/x-script.scheme' => 'scm',
				'video/x-scm' => 'scm',
				'text/plain' => 'sdml',
				'application/sdp' => 'sdp',
				'application/x-sdp' => 'sdp',
				'application/sounder' => 'sdr',
				'application/sea' => 'sea',
				'application/x-sea' => 'sea',
				'application/set' => 'set',
				'text/sgml' => 'sgm',
				'text/x-sgml' => 'sgm',
				'text/sgml' => 'sgml',
				'text/x-sgml' => 'sgml',
				'application/x-bsh' => 'sh',
				'application/x-sh' => 'sh',
				'application/x-shar' => 'sh',
				'text/x-script.sh' => 'sh',
				'application/x-bsh' => 'shar',
				'application/x-shar' => 'shar',
				'text/html' => 'shtml',
				'text/x-server-parsed-html' => 'shtml',
				'audio/x-psid' => 'sid',
				'application/x-sit' => 'sit',
				'application/x-stuffit' => 'sit',
				'application/x-koan' => 'skd',
				'application/x-koan' => 'skm',
				'application/x-koan' => 'skp',
				'application/x-koan' => 'skt',
				'application/x-seelogo' => 'sl',
				'application/smil' => 'smi',
				'application/smil' => 'smil',
				'audio/basic' => 'snd',
				'audio/x-adpcm' => 'snd',
				'application/solids' => 'sol',
				'application/x-pkcs7-certificates' => 'spc',
				'text/x-speech' => 'spc',
				'application/futuresplash' => 'spl',
				'application/x-sprite' => 'spr',
				'application/x-sprite' => 'sprite',
				'application/x-wais-source' => 'src',
				'text/x-server-parsed-html' => 'ssi',
				'application/streamingmedia' => 'ssm',
				'application/vnd.ms-pki.certstore' => 'sst',
				'application/step' => 'step',
				'application/sla' => 'stl',
				'application/vnd.ms-pki.stl' => 'stl',
				'application/x-navistyle' => 'stl',
				'application/step' => 'stp',
				'application/x-sv4cpio' => 'sv4cpio',
				'application/x-sv4crc' => 'sv4crc',
				'image/vnd.dwg' => 'svf',
				'image/x-dwg' => 'svf',
				'application/x-world' => 'svr',
				'x-world/x-svr' => 'svr',
				'application/x-shockwave-flash' => 'swf',
				'application/x-troff' => 't',
				'text/x-speech' => 'talk',
				'application/x-tar' => 'tar',
				'application/toolbook' => 'tbk',
				'application/x-tbook' => 'tbk',
				'application/x-tcl' => 'tcl',
				'text/x-script.tcl' => 'tcl',
				'text/x-script.tcsh' => 'tcsh',
				'application/x-tex' => 'tex',
				'application/x-texinfo' => 'texi',
				'application/x-texinfo' => 'texinfo',
				'application/plain' => 'text',
				'text/plain' => 'text',
				'application/gnutar' => 'tgz',
				'application/x-compressed' => 'tgz',
				'image/tiff' => 'tif',
				'image/x-tiff' => 'tif',
				'image/tiff' => 'tiff',
				'image/x-tiff' => 'tiff',
				'application/x-troff' => 'tr',
				'audio/tsp-audio' => 'tsi',
				'application/dsptype' => 'tsp',
				'audio/tsplayer' => 'tsp',
				'text/tab-separated-values' => 'tsv',
				'image/florian' => 'turbot',
				'text/plain' => 'txt',
				'text/x-uil' => 'uil',
				'text/uri-list' => 'uni',
				'text/uri-list' => 'unis',
				'application/i-deas' => 'unv',
				'text/uri-list' => 'uri',
				'text/uri-list' => 'uris',
				'application/x-ustar' => 'ustar',
				'multipart/x-ustar' => 'ustar',
				'application/octet-stream' => 'uu',
				'text/x-uuencode' => 'uu',
				'text/x-uuencode' => 'uue',
				'application/x-cdlink' => 'vcd',
				'text/x-vcalendar' => 'vcs',
				'application/vda' => 'vda',
				'video/vdo' => 'vdo',
				'application/groupwise' => 'vew',
				'video/vivo' => 'viv',
				'video/vnd.vivo' => 'viv',
				'video/vivo' => 'vivo',
				'video/vnd.vivo' => 'vivo',
				'application/vocaltec-media-desc' => 'vmd',
				'application/vocaltec-media-file' => 'vmf',
				'audio/voc' => 'voc',
				'audio/x-voc' => 'voc',
				'video/vosaic' => 'vos',
				'audio/voxware' => 'vox',
				'audio/x-twinvq-plugin' => 'vqe',
				'audio/x-twinvq' => 'vqf',
				'audio/x-twinvq-plugin' => 'vql',
				'application/x-vrml' => 'vrml',
				'model/vrml' => 'vrml',
				'x-world/x-vrml' => 'vrml',
				'x-world/x-vrt' => 'vrt',
				'application/x-visio' => 'vsd',
				'application/x-visio' => 'vst',
				'application/x-visio' => 'vsw',
				'application/wordperfect6.0' => 'w60',
				'application/wordperfect6.1' => 'w61',
				'application/msword' => 'w6w',
				'audio/wav' => 'wav',
				'audio/x-wav' => 'wav',
				'application/x-qpro' => 'wb1',
				'image/vnd.wap.wbmp' => 'wbmp',
				'application/vnd.xara' => 'web',
				'application/msword' => 'wiz',
				'application/x-123' => 'wk1',
				'windows/metafile' => 'wmf',
				'text/vnd.wap.wml' => 'wml',
				'application/vnd.wap.wmlc' => 'wmlc',
				'text/vnd.wap.wmlscript' => 'wmls',
				'application/vnd.wap.wmlscriptc' => 'wmlsc',
				'application/msword' => 'word',
				'application/wordperfect' => 'wp',
				'application/wordperfect' => 'wp5',
				'application/wordperfect6.0' => 'wp5',
				'application/wordperfect' => 'wp6',
				'application/wordperfect' => 'wpd',
				'application/x-wpwin' => 'wpd',
				'application/x-lotus' => 'wq1',
				'application/mswrite' => 'wri',
				'application/x-wri' => 'wri',
				'application/x-world' => 'wrl',
				'model/vrml' => 'wrl',
				'x-world/x-vrml' => 'wrl',
				'model/vrml' => 'wrz',
				'x-world/x-vrml' => 'wrz',
				'text/scriplet' => 'wsc',
				'application/x-wais-source' => 'wsrc',
				'application/x-wintalk' => 'wtk',
				'image/x-xbitmap' => 'xbm',
				'image/x-xbm' => 'xbm',
				'image/xbm' => 'xbm',
				'video/x-amt-demorun' => 'xdr',
				'xgl/drawing' => 'xgz',
				'image/vnd.xiff' => 'xif',
				'application/excel' => 'xl',
				'application/excel' => 'xla',
				'application/x-excel' => 'xla',
				'application/x-msexcel' => 'xla',
				'application/excel' => 'xlb',
				'application/vnd.ms-excel' => 'xlb',
				'application/x-excel' => 'xlb',
				'application/excel' => 'xlc',
				'application/vnd.ms-excel' => 'xlc',
				'application/x-excel' => 'xlc',
				'application/excel' => 'xld',
				'application/x-excel' => 'xld',
				'application/excel' => 'xlk',
				'application/x-excel' => 'xlk',
				'application/excel' => 'xll',
				'application/vnd.ms-excel' => 'xll',
				'application/x-excel' => 'xll',
				'application/excel' => 'xlm',
				'application/vnd.ms-excel' => 'xlm',
				'application/x-excel' => 'xlm',
				'application/excel' => 'xls',
				'application/vnd.ms-excel' => 'xls',
				'application/x-excel' => 'xls',
				'application/x-msexcel' => 'xls',
				'application/excel' => 'xlt',
				'application/x-excel' => 'xlt',
				'application/excel' => 'xlv',
				'application/x-excel' => 'xlv',
				'application/excel' => 'xlw',
				'application/vnd.ms-excel' => 'xlw',
				'application/x-excel' => 'xlw',
				'application/x-msexcel' => 'xlw',
				'audio/xm' => 'xm',
				'application/xml' => 'xml',
				'text/xml' => 'xml',
				'xgl/movie' => 'xmz',
				'application/x-vnd.ls-xpix' => 'xpix',
				'image/x-xpixmap' => 'xpm',
				'image/xpm' => 'xpm',
				'image/png' => 'x-png',
				'video/x-amt-showrun' => 'xsr',
				'image/x-xwd' => 'xwd',
				'image/x-xwindowdump' => 'xwd',
				'chemical/x-pdb' => 'xyz',
				'application/x-compress' => 'z',
				'application/x-compressed' => 'z',
				'application/x-compressed' => 'zip',
				'application/x-zip-compressed' => 'zip',
				'application/zip' => 'zip',
				'multipart/x-zip' => 'zip',
				'application/octet-stream' => 'zoo',
				'text/x-script.zsh' => 'zsh',
			);

			$arrays['meta-robots'] = array(
				'index, nofollow' => 'index, nofollow',
				'noindex, follow' => 'noindex, follow',
				'noindex, nofollow' => 'noindex, nofollow'
			);

			$arrays['gradient-types'] = array(
				'horizontal' => 'Horizontal',
				'vertical' => 'Vertical',
				'directional' => 'Directional (45deg)',
				'radial' => 'Radial',
			);

			$arrays['brand-colors'] = array(
				'primary' => __( 'Primary', 'cssjockey-add-ons' ),
				'success' => __( 'Success', 'cssjockey-add-ons' ),
				'danger' => __( 'Danger', 'cssjockey-add-ons' ),
				'info' => __( 'Info', 'cssjockey-add-ons' ),
				'warning' => __( 'Warning', 'cssjockey-add-ons' ),
				'dark' => __( 'Dark', 'cssjockey-add-ons' ),
				'light' => __( 'Light', 'cssjockey-add-ons' ),
			);

			if( is_null( $type ) ) {
				return $arrays;
			} else {
				return $arrays[ $type ];
			}
		}

		public function userSassVariables( $var = null ) {
			$return = array(
				'body-size' => array(
					'type' => 'number',
					'id' => 'body-size',
					'label' => 'Primary Font Size',
					'default' => '16',
					'suffix' => 'px',
				),
				'family-headings' => array(
					'type' => 'font-family',
					'id' => 'family-headings',
					'label' => 'Font family headings',
					'default' => 'inherit',
				),
				'family-primary' => array(
					'type' => 'font-family',
					'id' => 'family-primary',
					'label' => 'Font family primary',
					'default' => 'inherit',
				),
				'family-code' => array(
					'type' => 'font-family',
					'id' => 'family-code',
					'label' => 'Font family code',
					'default' => 'Source Code Pro',
				),

				'dark' => array(
					'id' => 'dark',
					'type' => 'color',
					'label' => 'Color dark',
					'default' => '#222222',
				),
				'dark-invert' => array(
					'id' => 'dark-invert',
					'type' => 'color',
					'label' => 'Color dark invert',
					'default' => '#ffffff',
				),
				'light' => array(
					'id' => 'light',
					'type' => 'color',
					'label' => 'Color light',
					'default' => '#ffffff',
				),
				'light-invert' => array(
					'id' => 'light-invert',
					'type' => 'color',
					'label' => 'Color light invert',
					'default' => '#222222',
				),
				'primary' => array(
					'id' => 'primary',
					'type' => 'color',
					'label' => 'Color primary',
					'default' => '#337ab7',
				),
				'primary-invert' => array(
					'id' => 'primary-invert',
					'type' => 'color',
					'label' => 'Color primary invert',
					'default' => '#ffffff',
				),
				'success' => array(
					'id' => 'success',
					'type' => 'color',
					'label' => 'Color success',
					'default' => '#5cb85c',
				),
				'success-invert' => array(
					'id' => 'success-invert',
					'type' => 'color',
					'label' => 'Color success invert',
					'default' => '#ffffff',
				),
				'danger' => array(
					'id' => 'danger',
					'type' => 'color',
					'label' => 'Color danger',
					'default' => '#d9534f',
				),
				'danger-invert' => array(
					'id' => 'danger-invert',
					'type' => 'color',
					'label' => 'Color danger invert',
					'default' => '#ffffff',
				),
				'info' => array(
					'id' => 'info',
					'type' => 'color',
					'label' => 'Color info',
					'default' => '#5bc0de',
				),
				'info-invert' => array(
					'id' => 'info-invert',
					'type' => 'color',
					'label' => 'Color info invert',
					'default' => '#ffffff',
				),
				'warning' => array(
					'id' => 'warning',
					'type' => 'color',
					'label' => 'Color warning',
					'default' => '#f0ad4e',
				),
				'warning-invert' => array(
					'id' => 'warning-invert',
					'type' => 'color',
					'label' => 'Color warning invert',
					'default' => '#ffffff',
				),
				'radius' => array(
					'id' => 'radius',
					'type' => 'number',
					'label' => 'Radius',
					'default' => '3',
					'suffix' => 'px',
				),
				'radius-small' => array(
					'id' => 'radius-small',
					'type' => 'number',
					'label' => 'Radius small',
					'default' => '2',
					'suffix' => 'px',
				),
				'radius-large' => array(
					'id' => 'radius-large',
					'type' => 'number',
					'label' => 'Radius large',
					'default' => '5',
					'suffix' => 'px',
				),
				'input-radius' => array(
					'id' => 'input-radius',
					'type' => 'number',
					'label' => 'Input radius',
					'default' => '2',
					'suffix' => 'px',
				),

			);

			return (is_null( $var )) ? $return : $return[ $var ];
		}

		public function coreSassVariables() {
			ob_start();
			echo '$family-headings: inherit !default; $family-sans-serif: inherit !default; $family-monospace: inherit !default; ';
			echo '$cj-bg: #F9F8F6 !default; $cj-red: #DA461E !default; $cj-primary: #DA461E !default; $cj-green: #86C0BF !default; $cj-border: darken($cj-bg, 4%) !default; $cj-border-color: darken($cj-bg, 10%) !default; $cj-heading: #54575A !default; $cj-text: #54575A !default;';
			require_once $this->root_dir . '/framework/lib/sass/framework/utilities/_initial-variables.scss';
			require_once $this->root_dir . '/framework/lib/sass/framework/utilities/_derived-variables.scss';
			require_once $this->root_dir . '/framework/lib/sass/framework/utilities/_variables.scss';
			return ob_get_clean();
		}

		public function arrayInterlace() {

			$args = func_get_args();
			$total = count( $args );
			if( $total < 2 ) {
				return false;
			}
			$i = 0;
			$j = 0;
			$arr = array();
			foreach( $args as $arg ) {
				foreach( $arg as $key => $v ) {
					$arr[ $key ] = $v;
				}
			}
			ksort( $arr );

			return $arr;
		}

		public function getMenuLocations() {
			$menu_locations = get_registered_nav_menus();
			update_option( 'cjaddons_user_menus', $menu_locations );
		}

		public function getTaxonomyArray( $taxonomy = 'category' ) {

			$taxonomies = array($taxonomy);
			$args = array(
				'orderby' => 'name',
				'order' => 'ASC',
				'hide_empty' => false,
				'include' => array(),
				'exclude' => array(),
				'exclude_tree' => array(),
				'number' => '',
				'offset' => '',
				'fields' => 'all',
				'name' => '',
				'slug' => '',
				'hierarchical' => false,
				'search' => '',
				'name__like' => '',
				'description__like' => '',
				'pad_counts' => false,
				'get' => '',
				'child_of' => 0,
				'parent' => 0,
				'childless' => false,
				'cache_domain' => 'core',
				'update_term_meta_cache' => true,
				'meta_query' => '',
			);
			$terms = get_terms( $taxonomies, $args );
			$options = array();
			foreach( $terms as $term ) {
				$options[ $term->slug ] = $term->name;
			}

			return $options;
		}

		public function pageUrlsFromOption( $option ) {

			if( $this->saved_options[ $option ] != '' ) :
				$page_urls = '<a target="_blank" href="' . site_url() . '?p=' . $this->saved_options[ $option ] . '">' . esc_attr__( 'View', $this->text_domain ) . '</a>';
				$page_urls .= ' | ';
				$page_urls .= '<a target="_blank" href="' . admin_url( 'post.php' ) . '?post=' . $this->saved_options[ $option ] . '&action=edit">' . esc_attr__( 'Edit', $this->text_domain ) . '</a>';
			else:
				$page_urls = '';
			endif;

			return $page_urls;
		}

		public function getOption( $var = null, $default = null ) {
			global $wpdb;
			if( $wpdb->get_var( "SHOW TABLES LIKE '$this->table_options'" ) != $this->table_options ) {
				return array();
			}

			if( ! is_null( $var ) ) {
				$option = $wpdb->get_row( "SELECT * FROM $this->table_options WHERE option_name = '{$var}'" );
				if( $option ) {
					$return_value = (is_serialized( $option->option_value ) && $option->option_value != '') ? @unserialize( $option->option_value ) : stripcslashes( $option->option_value );

					return ( ! is_null( $option )) ? $return_value : false;
				}
			}

			if( is_null( $var ) ) {
				$return = array();
				$options = $wpdb->get_results( "SELECT * FROM $this->table_options ORDER BY option_id" );
				if( is_array( $options ) ) {
					foreach( $options as $key => $option ) {
						$return[ $option->option_name ] = (is_serialized( $option->option_value ) && $option->option_value != '') ? @unserialize( $option->option_value ) : stripcslashes( $option->option_value );
					}
				}

				return $return;
			}
		}

		public function savedOption( $var, $default = '' ) {
			$return = $default;
			if( isset( $this->saved_options[ $var ] ) ) {
				$return = $this->saved_options[ $var ];
			}

			return $return;
		}

		public function isJson( $string ) {
			json_decode( $string );

			return (json_last_error() == JSON_ERROR_NONE);
		}

		public function getGroupOption( $var, $array = array() ) {
			$return = array();
			if( empty( $array ) ) {
				$saved_options = $this->saved_options;
				if( isset( $saved_options[ $var ] ) ) {
					$selected_value = (isset( $saved_options[ $var ]['selected_value'] )) ? $saved_options[ $var ]['selected_value'] : '';
					$return = (isset( $saved_options[ $var ]['items'][ $selected_value ] )) ? $saved_options[ $var ]['items'][ $selected_value ] : array($selected_value => true);
				}
			}
			if( is_array( $array ) && ! empty( $array ) && isset( $array[ $var ] ) ) {
				$selected_value = $array[ $var ]['selected_value'];
				$return = (isset( $array[ $var ]['items'][ $selected_value ] )) ? $array[ $var ]['items'][ $selected_value ] : array($selected_value => true);
			}

			return $return;
		}

		public function getTaxonomiesOption( $var ) {
			$return = [];
			$array = explode( '|', $var );
			foreach( $array as $array_key => $array_value ) {
				$terms_array = explode( '@', $array_value );
				$term_slug = $terms_array[0];
				$taxonomy = $terms_array[1];
				$term = get_term_by( 'slug', $term_slug, $taxonomy );
				$term_link = get_term_link( $term );
				$return[ $term_slug ]['term_id'] = $term->term_id;
				$return[ $term_slug ]['term_name'] = $term->name;
				$return[ $term_slug ]['term_url'] = $term_link;
				$return[ $term_slug ]['term_slug'] = $term->slug;
				$return[ $term_slug ]['term_permalink'] = '<a href="' . $term_link . '" title="' . $term->name . '">' . $term->name . '</a>';
				$return[ $term_slug ]['term_data'] = $term;
			}

			return $return;
		}

		public function getOptionPageUrl( $var, $query_string = false ) {
			if( $this->saved_options[ $var ] == '' ) {
				return '';
			}
			$page_url = get_permalink( $this->saved_options[ $var ] );

			return ( ! $query_string) ? $page_url : $this->queryString( $page_url );
		}

		public function getServerInfo( $var = null ) {
			return (is_null( $var )) ? $_SERVER : $_SERVER[ $var ];
		}

		public function getIPAddress() {
			if( isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
				// They are using a proxy, so we grab the forwarded for IP
				$theirIP = $_SERVER['HTTP_X_FORWARDED_FOR'];
			} elseif( isset( $_SERVER['REMOTE_ADDR'] ) ) {
				// No proxy, grab the normal IP
				$theirIP = $_SERVER['REMOTE_ADDR'];
			} else {
				// No IP (unlikely).
				$theirIP = false;
			}

			return $theirIP;
		}

		public function getIpInfo() {
			$return = [];
			$query = $this->wpRemoteGet( 'http://ip-api.com/php/' );

			if( $query ) {
				$result = (is_serialized( $query )) ? unserialize( $query ) : array();
				$return = array(
					'country' => (isset( $result['country'] )) ? $result['country'] : '',
					'country_code' => (isset( $result['countryCode'] )) ? $result['countryCode'] : '',
					'region' => (isset( $result['region'] )) ? $result['region'] : '',
					'region_name' => (isset( $result['regionName'] )) ? $result['regionName'] : '',
					'city' => (isset( $result['city'] )) ? $result['city'] : '',
					'latitude' => (isset( $result['lat'] )) ? $result['lat'] : '',
					'longitude' => (isset( $result['lon'] )) ? $result['lon'] : '',
					'isp' => (isset( $result['isp'] )) ? $result['isp'] : '',
					'postcode' => (isset( $result['zip'] )) ? $result['zip'] : '',
					'timezone' => (isset( $result['timezone'] )) ? $result['timezone'] : '',
					'ip_address' => (isset( $result['query'] )) ? $result['query'] : '',
				);
			}

			return $return;
		}

		public function httpUserAgent() {

			$agent = strtolower( $_SERVER['HTTP_USER_AGENT'] );
			if( stristr( $agent, 'msie' ) ) {
				return 'msie';
			} elseif( stristr( $agent, 'firefox' ) ) {
				return 'firefox';
			} elseif( stristr( $agent, 'chrome' ) ) {
				return 'chrome';
			} elseif( stristr( $agent, 'safari' ) ) {
				return 'safari';
			} elseif( stristr( $agent, 'opera' ) ) {
				return 'opera';
			} else {
				return 'unknown';
			}
		}

		public function sendEmail( $email_data = array(), $attachments = array(), $service = 'wp-mail' ) {
			if( empty( $email_data ) ) {
				return;
			}
			$to = $email_data['to'];
			$from_name = stripcslashes( html_entity_decode( $email_data['from_name'], ENT_QUOTES ) );
			$from = $email_data['from_email'];
			$subject = stripcslashes( html_entity_decode( $email_data['subject'], ENT_QUOTES ) );
			$content = $email_data['message'];
			$content_above = '';
			$content_below = '';
			$msg = apply_filters( 'cjaddons_content_above_email', $content_above, 10, 1 );
			$msg .= $content;
			$msg .= apply_filters( 'cjaddons_content_below_email', $content_below, 10, 1 );
			$message = $msg;

			if( $service == 'wp-mail' ) {
				$headers[] = "From: {$from_name} <{$from}>";
				$headers[] = "Return-Path: {$from}";
				$headers[] = "MIME-Version: 1.0";
				if( isset( $email_data['headers'] ) ) {
					foreach( $email_data['headers'] as $h_key => $h_value ) {
						$headers[] = "{$h_key}: {$h_value}";
					}
				}
				add_filter( 'wp_mail_content_type', array($this, 'setHtmlContentTypeForEmail') );
				add_filter( 'wp_mail_charset', array($this, 'setCharsetForEmail') );
				$return = wp_mail( $to, $subject, $message, $headers, $attachments );
				remove_filter( 'wp_mail_content_type', array($this, 'setHtmlContentTypeForEmail') );
				remove_filter( 'wp_mail_charset', array($this, 'setCharsetForEmail') );

				return $return;
			} else {
				$headers = "From: {$from_name} <{$from}>" . "\r\n\\";
				$headers .= "Return-Path: {$from}\r\n";
				$headers .= "MIME-Version: 1.0\r\n";
				$headers .= "Content-Type: text/html; charset=utf-8\r\n";
				if( isset( $email_data['headers'] ) ) {
					foreach( $email_data['headers'] as $h_key => $h_value ) {
						$headers .= "{$h_key}: {$h_value}";
					}
				}

				return mail( $to, $subject, $message, $headers );
			}
		}

		public function setHtmlContentTypeForEmail() {
			return 'text/html';
		}

		public function setCharsetForEmail() {
			return 'utf8';
		}

		public function debugEmail( $to, $subject, $array ) {
			$message = '';
			if( is_array( $array ) ) {
				foreach( $array as $key => $value ) {
					$message .= $key . ' => ' . $value . "\n <br>";
				}
			}
			$email_data = array(
				'to' => $to,
				'from_name' => 'Debug Info - ',
				get_bloginfo( 'name' ),
				'from_email' => 'admin@cssjockey.com',
				'subject' => $subject,
				'message' => $message,
			);
			$this->sendEmail( $email_data );
		}

		public function isValidEmail( $email ) {
			return (filter_var( $email, FILTER_VALIDATE_EMAIL )) ? true : false;
		}

		public function isStrongPassword( $string ) {
			if( $string != '' ) {
				$uppercase = preg_match( '@[A-Z]@', $string );
				$lowercase = preg_match( '@[a-z]@', $string );
				$number = preg_match( '@[0-9]@', $string );
				$special_char = preg_match( '/[\'\/~`\!@#\$%\^&\*\(\)_\-\+=\{\}\[\]\|;:"\<\>,\.\?\\\]/', $string );
				if( $string != '' && $uppercase && $lowercase && $number && $special_char ) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}

		public function isValidArray( $var ) {

			$return = false;
			if( is_array( $var ) && ! in_array( 'none', $var ) && isset( $var[0] ) && $var[0] != '' ) {
				$return = true;
			}

			return $return;
		}

		public function wpRemotePost( $url, $post_vars = array(), $args = array(), $return = 'body' ) {
			$args_array = array(
				'method' => 'POST',
				'timeout' => 120,
				'redirection' => 5,
				'httpversion' => '1.0',
				'blocking' => true,
				'headers' => array(),
				'body' => $post_vars,
				'cookies' => array(),
			);
			if( ! empty( $args ) ) {
				foreach( $args as $key => $value ) {
					$args_array[ $key ] = $value;
				}
			}

			$response = wp_remote_post( $url, $args_array );

			if( $return != 'body' ) {
				return $response;
			}

			if( is_wp_error( $response ) ) {
				return ['error' => implode( '', $response->get_error_messages() )];
			}
			if( is_wp_error( $response ) ) {
				$error_message = $response->get_error_message();

				return ['error' => $error_message];
			} else {
				return $response['body'];
			}
		}

		public function wpRemoteGet( $url, $post_vars = null, $args = null, $return = 'body' ) {

			$args_array = array(
				'method' => 'GET',
				'timeout' => 120,
				'redirection' => 5,
				'httpversion' => '1.0',
				'blocking' => true,
				'headers' => array(),
				'body' => (is_array( $post_vars ) && ! empty( $post_vars )) ? $post_vars : array(),
				'cookies' => array(),
			);

			if( is_array( $args ) && ! empty( $args ) && ! empty( $args ) ) {
				foreach( $args as $key => $value ) {
					$args_array[ $key ] = $value;
				}
			}

			$response = wp_remote_get( $url, $args_array );

			if( $return != 'body' ) {
				return $response;
			}

			if( is_wp_error( $response ) ) {
				$error_message = $response->get_error_message();

				return $this->jsonError( $error_message );
			} else {
				return $response['body'];
			}
		}

		public function cUrl( $url, $data ) {
			$ch = curl_init();
			curl_setopt( $ch, CURLOPT_URL, $url );
			curl_setopt( $ch, CURLOPT_POST, 1 );
			curl_setopt( $ch, CURLOPT_POSTFIELDS, $data );
			curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
			$server_output = curl_exec( $ch );
			curl_close( $ch );

			return $server_output;
		}

		public function getAdminPagesList( $parent, $offset = 3 ) {

			global $submenu;
			if( is_array( $submenu ) && isset( $submenu[ $parent ] ) ) {
				foreach( (array) $submenu[ $parent ] as $item ) {
					if( $parent == $item[2] || $parent == $item[2] ) {
						continue;
					}
					// 0 = name, 1 = capability, 2 = file
					if( current_user_can( $item[1] ) ) {
						$menu_file = $item[2];
						if( false !== ($pos = strpos( $menu_file, '?' )) ) {
							$menu_file = substr( $menu_file, 0, $pos );
						}
						if( file_exists( ABSPATH . "wp-admin/$menu_file" ) ) {
							//$options[] = "<a href='{$item[2]}'$class>{$item[0]}</a>";
							$options[ $item[2] ] = $item[ $offset ];
						} else {
							//$options[] = "<a href='admin.php?page={$item[2]}'>{$item[0]}</a>";
							$options[ $item[2] ] = $item[ $offset ];
						}
					}
				}

				return $options;
			}
		}

		public function createDirectory( $path ) {
			global $wp_filesystem;
			// filesystem vars
			$url = wp_nonce_url( $this->currentUrl(), 'cssjockey-add-ons' );
			$method = null;
			$context = '';
			$fields = array('file-data');
			if( false === ($credentials = request_filesystem_credentials( $url, $method, false, $context, $fields )) ) {
				return false;
			}
			if( ! WP_Filesystem( $credentials ) ) {
				request_filesystem_credentials( $url, $method, true, $context );

				return false;
			}

			if( is_dir( $path ) ) {
				return $path;
			}

			if( ! is_dir( $path ) ) {
				$wp_filesystem->mkdir( $path );

				return $path;
			}

			return false;
		}

		public function getFileContents( $source_file ) {
			global $wp_filesystem;
			// filesystem vars
			$url = wp_nonce_url( $this->currentUrl(), 'cssjockey-add-ons' );
			$method = null;
			$context = '';
			$fields = array('file-data');
			if( false === ($credentials = request_filesystem_credentials( $url, $method, false, $context, $fields )) ) {
				return false;
			}
			if( ! WP_Filesystem( $credentials ) ) {
				request_filesystem_credentials( $url, $method, true, $context );

				return false;
			}

			return $wp_filesystem->get_contents( $source_file );
		}

		public function putFileContents( $file_path, $file_content ) {
			global $wp_filesystem;
			// filesystem vars
			$url = wp_nonce_url( $this->currentUrl(), 'cssjockey-add-ons' );
			$method = null;
			$context = '';
			$fields = array('file-data');
			if( false === ($credentials = request_filesystem_credentials( $url, $method, false, $context, $fields )) ) {
				return false;
			}
			if( ! WP_Filesystem( $credentials ) ) {
				request_filesystem_credentials( $url, $method, true, $context );

				return false;
			}

			return $wp_filesystem->put_contents(
				$file_path,
				$file_content,
				FS_CHMOD_FILE // predefined mode settings for WP files
			);
		}

		public function replaceFileContents( $source_file, $destination_file, $replace, $with ) {

			global $wp_filesystem;
			// filesystem vars
			$url = wp_nonce_url( $this->currentUrl(), 'cssjockey-add-ons' );
			$method = null;
			$context = '';
			$fields = array('file-data');
			if( false === ($credentials = request_filesystem_credentials( $url, $method, false, $context, $fields )) ) {
				return false;
			}
			if( ! WP_Filesystem( $credentials ) ) {
				request_filesystem_credentials( $url, $method, true, $context );

				return false;
			}
			if( file_exists( $source_file ) ) {
				$css = $wp_filesystem->get_contents( $source_file );
				$css = str_replace( $replace, $with, $css );
				$wp_filesystem->put_contents( $destination_file, $css, FS_CHMOD_FILE );

				return 'done';
			} else {
				return 'file not found';
			}
		}

		public function connectFileSystem( $url, $method, $context, $fields = null ) {

			if( false === ($credentials = request_filesystem_credentials( $url, $method, false, $context, $fields )) ) {
				return false;
			}
			if( ! WP_Filesystem( $credentials ) ) {
				request_filesystem_credentials( $url, $method, true, $context );

				return false;
			}

			return true;
		}

		public function unzipFile( $source_zip_file = null, $destination_path = null ) {

			$errors = null;
			if( is_null( $source_zip_file ) ) {
				$errors[] = __( 'You must specify source zip file.', 'cssjockey-add-ons' );

				return $errors;
			}
			if( is_null( $destination_path ) ) {
				$errors[] = __( 'You must specify a destination path.', 'cssjockey-add-ons' );

				return $errors;
			}

			$url = wp_nonce_url( $this->currentUrl(), 'cssjockey-add-ons' );
			if( $this->connectFileSystem( $url, '', '', 'module-file' ) ) {
				$unzip_file = unzip_file( $source_zip_file, $destination_path );
				if( $unzip_file ) {
					return true;
				} else {
					$errors[] = __( 'There was an error unzipping the file.', 'cssjockey-add-ons' );

					return $errors;
				}
			}
		}

		public function deleteFile( $file_path = null ) {

			$errors = null;
			if( is_null( $file_path ) ) {
				$errors[] = __( 'You must specify a file path.', 'cssjockey-add-ons' );

				return $errors;
			}
			$url = wp_nonce_url( $this->currentUrl(), 'cssjockey-add-ons' );
			if( $this->connectFileSystem( $url, '', '', 'module-file' ) ) {
				unlink( $file_path );

				return true;
			}
		}

		public function deleteDirectory( $dir_path = null ) {

			$errors = null;
			if( is_null( $dir_path ) ) {
				$errors[] = __( 'You must specify a file path.', 'cssjockey-add-ons' );

				return $errors;
			}
			$url = wp_nonce_url( $this->currentUrl(), 'cssjockey-add-ons' );
			if( $this->connectFileSystem( $url, '', '', 'module-file' ) ) {
				$files = array_diff( scandir( $dir_path ), array('.', '..') );
				foreach( $files as $file ) {
					(is_dir( "$dir_path/$file" )) ? $this->deleteDirectory( "$dir_path/$file" ) : unlink( "$dir_path/$file" );
				}
				rmdir( $dir_path );

				return true;
			}
		}

		public function zipFolder( $source, $destination ) {
			if( extension_loaded( 'zip' ) ) {
				if( file_exists( $source ) ) {
					$zip = new ZipArchive();
					if( $zip->open( $destination, ZIPARCHIVE::CREATE ) ) {
						$source = realpath( $source );
						if( is_dir( $source ) ) {
							$iterator = new RecursiveDirectoryIterator( $source );
							// skip dot files while iterating
							$iterator->setFlags( RecursiveDirectoryIterator::SKIP_DOTS );
							$files = new RecursiveIteratorIterator( $iterator, RecursiveIteratorIterator::SELF_FIRST );
							foreach( $files as $file ) {
								$file = realpath( $file );
								if( is_dir( $file ) ) {
									$zip->addEmptyDir( str_replace( $source . '/', '', $file . '/' ) );
								} else if( is_file( $file ) ) {
									$zip->addFromString( str_replace( $source . '/', '', $file ), file_get_contents( $file ) );
								}
							}
						} else if( is_file( $source ) ) {
							$zip->addFromString( basename( $source ), file_get_contents( $source ) );
						}
					}

					return $zip->close();
				}
			}

			return false;
		}

		public function renderAdminFormField( $option ) {
			if( ! is_array( $option ) ) {
				return false;
			}
			ob_start();
			require sprintf( '%s/framework/html/admin-form-field.php', $this->root_dir );

			return ob_get_clean();
		}

		public function convertArrayToCss( $array, $tag = '' ) {
			unset( $array['custom-css-code'] );
			unset( $array['form-field-type-css-styles'] );
			unset( $array['custom-classes'] );
			$css_code = '';
			$tag_start = '';
			$tag_end = '';
			foreach( array_filter( $array ) as $key => $value ) {
				if( is_numeric( $value ) ) {
					$value = $value . 'px';
				}
				if( $key == 'background-image' ) {
					$value = "url('" . $value . "')";
				}
				$css_code .= $key . ':' . strtolower( $value ) . ';';
			}
			if( $tag != '' ) {
				$tag_start = $tag . '{';
				$tag_end = '}';
			}

			return $tag_start . $css_code . $tag_end;
		}

		public function generateShortcodeTag( $shortcode_tag = null ) {

			if( is_null( $shortcode_tag ) ) {
				$errors['errors'][] = __( 'Please specify shortcode tag.', 'cssjockey-add-ons' );

				return $errors;
			}

			$shortcode_class_name = $shortcode_tag . '_shortcode';
			if( ! class_exists( $shortcode_class_name ) ) {
				$errors['errors'][] = __( 'Shortcode class not found.', 'cssjockey-add-ons' );

				return $errors;
			}

			$return = '';
			$shortcode_class = $shortcode_class_name::getInstance();
			$shortcode_defaults = $shortcode_class->defaults();

			if( is_array( $shortcode_defaults ) && isset( $shortcode_defaults['info'] ) && isset( $shortcode_defaults['options'] ) ) {
				$info = $shortcode_defaults['info'];
				$options = $shortcode_defaults['options'];

				$return .= '[';
				$return .= $info['tag'];

				if( is_array( $options ) ) {
					foreach( $options as $key => $option ) {
						if( $key !== 'default-content' ) {
							$default_value = (is_array( $option['default'] )) ? implode( '|', $option['default'] ) : $option['default'];
							$opts[] = $option['id'] . '="' . $default_value . '"';
						}
					}
					$return .= ' ';
					$return .= implode( ' ', $opts );
				}

				$return .= ']';
				if( ! $info['single'] ) {
					$return .= $options['default-content']['default'];
					$return .= '[/';
					$return .= $info['tag'];
					$return .= ']';
				}

				return $return;
			}
		}

		public function adminNotice( $name, $type = 'notice', $content, $title = null, $dismissable = true ) {

			if( ! is_admin() ) {
				return;
			}

			$current_user = wp_get_current_user();
			if( ! current_user_can( 'manage_options' ) ) {
				return false;
			}
			$dismissed_notices = array();
			if( $current_user->ID > 0 ) {
				$dismissed_notices = get_user_meta( $current_user->ID, 'cjaddons_dismissed_notices', true );
				if( ! is_array( $dismissed_notices ) ) {
					$dismissed_notices = array();
				}
			}
			if( isset( $dismissed_notices[ 'notice-' . $name ] ) ) {
				return false;
			}

			$type = str_replace( 'cj-', '', $type );

			$type_fix = array(
				'primary' => 'success',
				'danger' => 'error',
				'warning' => 'warning',
				'info' => 'info',
				'error' => 'error',
				'success' => 'success',
			);

			$display = [];
			$dismissable_class = '';
			if( $dismissable ) {
				$dismissable_class = ' is-dismissible cj-is-dismissible';
			}

			$display[] = '<div id=notice-' . $name . ' class="cssjockey-ui cj-notice notice notice-' . $type_fix[ $type ] . $dismissable_class . ' ">';
			$display[] = '<div class="cj-pt-10 cj-pb-10">';
			$display[] = ( ! is_null( $title )) ? '<div class="cj-text-bold cj-mb-5 cj-fs-14">' . $title . '</div>' : '';
			$display[] = $content;
			$display[] = '</div>';
			$display[] = '</div>';

			echo implode( '', $display );

			return false;
		}

		public function adminPointer( $pointers ) {

			add_filter( 'cjaddons_admin_pointers-dashboard', array($this, 'cjaddons_register_pointer_dashboard') );

			$pointers['xyz140'] = array(
				'target' => '#cjaddons_dashboard_widget',
				'options' => array(
					'content' => sprintf( '<h3> %s </h3> <p> %s </p>',
						__( 'Title', 'cssjockey-add-ons' ),
						__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'cssjockey-add-ons' )
					),
					'position' => array('edge' => 'left', 'align' => 'top')
				)
			);

			return $pointers;
		}

		public function getShortcodeDefaults( $shortcode_tag = null ) {
			if( is_null( $shortcode_tag ) ) {
				$errors['errors'][] = __( 'Please specify shortcode tag.', 'cssjockey-add-ons' );

				return $errors;
			}
			$shortcode_class_name = $shortcode_tag . '_shortcode';
			if( ! class_exists( $shortcode_class_name ) ) {
				$errors['errors'][] = __( 'Shortcode class not found.', 'cssjockey-add-ons' );

				return $errors;
			}
			$shortcode_class = $shortcode_class_name::getInstance();
			$shortcode_defaults = $shortcode_class->defaults();

			return $shortcode_defaults;
		}

		public function wpTableName( $table ) {
			global $wpdb;

			return $wpdb->prefix . $table;
		}

		public function slackNotification( $webhook_url, $message ) {
			$data = [
				'payload' => json_encode( array('text' => $message) )
			];
			$response = $this->wpRemotePost( $webhook_url, $data );
			if( $response = 'ok' ) {
				return ['success' => true];
			} else {
				return ['success' => false, 'msg' => $response];
			}
		}

		public function userRoles() {
			global $wp_roles;
			$return = $wp_roles->get_names();

			/*$options = get_option( 'wp_envato_user_roles' );
			$return = [];

			if( is_array( $options ) && ! empty( $options ) ) {
				foreach( $options as $role_key => $role ) {
					$return[ $role_key ] = $role['name'];
				}
			}*/

			return $return;
		}

		public function compileFontStyles( $element, $array = array() ) {
			$css[] = '';
			if( is_array( $array ) && ! empty( $array ) ) {
				$css[] = $element . '{';
				foreach( $array as $key => $value ) {
					$quotes = '';
					$suffix = '';
					if( $key == 'line-height' ) {
						$suffix = 'px';
					}
					if( $key == 'font-size' ) {
						$suffix = 'px';
					}
					if( $key == 'font-family' ) {
						$quotes = '"';
					}
					$css[] = $key . ':' . $quotes . $value . $quotes . $suffix . ';';
				}
				$css[] = '}';
			}

			return implode( '', $css );
		}

		public function getWPUserRoles() {
			global $wp_roles;
			if( ! isset( $wp_roles ) ) {
				$wp_roles = new WP_Roles();
			}

			return $wp_roles->get_names();
		}

		public function pagination( $limit = 10, $total_items, $page = 0 ) {
			$current_page = (int) $page;
			$total_pages = ceil( $total_items / $limit );
			$return['limit'] = $limit;
			$return['offset'] = ($page > 0) ? $limit * ($current_page - 1) : 0;
			$return['current_page'] = $current_page;
			$return['total_pages'] = $total_pages;
			if( $total_pages > $current_page ) {
				$return['next_page'] = $page + 1;
			}
			if( $page <= $total_pages && $page > 1 ) {
				$return['previous_page'] = $page - 1;
			}

			return $return;
		}

		public function prepareValidationRules( $array ) {
			$boolean_fields = array(
				'required',
				'valid_email',
				'valid_name',
				'valid_url',
				'valid_cc',
				'iban',
				'street_address',
				'phone_number',
				'alpha',
				'alpha_numeric',
				'alpha_dash',
				'alpha_space',
				'numeric',
				'integer',
				'float',
				'valid_ip',
				'valid_ipv4',
				'valid_ipv6',
			);
			$input_fields = array(
				'max_len',
				'min_len',
				'exact_len',
				'contains',
			);
			$validation_rules = array();
			foreach( $array as $key => $value ) {
				if( in_array( $key, $boolean_fields ) && $value == 'yes' ) {
					$validation_rules[] = $key;
				}
				if( in_array( $key, $input_fields ) && $value != '' ) {
					$validation_rules[] = $key . ',' . $value;
				}
			}

			return implode( '|', $validation_rules );
		}

		public function validateFormWithGump( $post_data, $validation_rules, $options_array = array(), $return = 'all|messages' ) {
			if( ! class_exists( 'GUMP_ext' ) ) {
				require sprintf( '%s/framework/lib/form-validation/gump-class-extension.php', $this->root_dir );
			}
			$gump_ext = new GUMP_ext();
			$new_options = array();
			if( ! empty( $options_array ) ) {
				foreach( $options_array as $key => $value ) {
					if( array_key_exists( 'id', $value ) ) {
						$new_options[ $value['id'] ] = $value;
					}
				}
			}

			$errors = $gump_ext->validation_errors( $post_data, $validation_rules, $new_options );

			if( $errors ) {
				if( $return == 'all|messages' ) {
					return $errors;
				}
				if( $return == 'all' ) {
					return $errors;
				}
				if( $return == 'messages' ) {
					$return = array();
					foreach( $errors as $key => $value ) {
						$return[ $key ] = sprintf( __( '%s', 'cssjockey-add-ons' ), array_values( $value )[0]['error_msg'] );
					}

					return $return;
				}
			} else {
				return null;
			}
		}

		public function compileGroupItems( $option ) {
			$group_options = array();
			if( isset( $option['items'] ) && is_array( $option['items'] ) && ! empty( $option['items'] ) ) {
				foreach( $option['items'] as $option_key => $item_options ) {
					foreach( $item_options as $item_key => $item_array ) {
						$item_array['container_class'] = '';
						$item_array['id'] = "{$option['id']}[items][{$option_key}][{$item_array['id']}]";
						$item_array['container_class'] = 'group-item group-item-' . $option['group'] . ' group-' . $option['group'] . '-' . $option_key;
						$group_options[ $item_key ] = $item_array;
						if( isset( $item_array['items'] ) ) {
							$group_options[ $item_key ][ $item_array['id'] ] = $this->compileGroupItems( $item_array );
						}
					}
				}
			}

			return $group_options;
		}

		public function paginate( $total ) {
			require_once sprintf( '%s/framework/lib/pagination/Pagination.class.php', $this->root_dir );
			$page = isset( $_GET['show-page'] ) ? ((int) $_GET['show-page']) : 1;
			$pagination = (new Pagination());
			$pagination->setCurrent( $page );
			$pagination->setTotal( $total );

			return $pagination->parse();
		}

		public function splitUpperCaseLetters( $str ) {
			$array = preg_split( '/(?=[A-Z])/', $str );

			return array_filter( $array );
		}

		public function apiUrl( $endpoint = '' ) {
			$url = trailingslashit( rest_url( $this->itemInfo( 'text_domain' ) ) );
			if( $endpoint == '' ) {
				return $url;
			} else {
				return $url . $endpoint . '/';
			}
		}

		public function apiMethodsArray( $var = null ) {
			$methods_array = array(
				'get' => WP_REST_Server::READABLE,
				'post' => WP_REST_Server::CREATABLE,
				'put' => WP_REST_Server::EDITABLE,
				'patch' => WP_REST_Server::EDITABLE,
				'delete' => WP_REST_Server::DELETABLE,
				'all' => WP_REST_Server::ALLMETHODS,
			);

			return (is_null( $var )) ? $methods_array : $methods_array[ $var ];
		}

		public function apiSecret() {
			$api_secret_key = sha1( md5( site_url() . wp_salt( 'nonce' ) ) );

			return strtoupper( $api_secret_key );
		}

		public function apiHeaders( $var = null ) {
			$headers = getallheaders();

			return (is_null( $var )) ? $headers : $headers[ $var ];
		}

		public function apiResponse( $request, $data = array(), $links = array() ) {
			$core_links = array();
			$core_links['base']['href'] = $this->apiUrl();
			$core_links['self']['href'] = rest_url( $request->get_route() );
			$res['data'] = $data;
			$res['_links'] = array_merge( $core_links, $links );
			$response = new WP_REST_Response( $res );
			$response = rest_ensure_response( $response );

			return $response;
		}

		public function apiError( $request, $code, $message, $status, $data = array() ) {
			$core_links = array();
			$core_links['_links']['self']['href'] = rest_url( $request->get_route() );
			$core_links['_links']['base']['href'] = $this->apiUrl();
			$status_data = array(
				'status' => $status,
				'errors' => $data
			);
			$status_data = array_merge( $status_data, $data, $core_links );

			return new WP_Error( 'api_error', $message, $status_data );
		}

		public function generateToken() {
			$api_secret_key = sha1( time() . site_url() );
			$token = bin2hex( openssl_random_pseudo_bytes( 128 ) );

			return $token . $api_secret_key;
		}

		public function setUserToken( $user_id ) {
			$token_key = 'X-Authorization';
			$token_expire_key = 'X-Authorization-Expires';
			$token_expire = 4;
			$token = $this->generateToken();
			update_user_meta( $user_id, $token_key, $token );
			update_user_meta( $user_id, $token_expire_key, strtotime( "{$token_expire} hours" ) );
			$this->setCookie( 'cjaddons_token', $token );

			return $token;
		}

		public function getUserByToken( $token ) {
			$token_key = 'X-Authorization';
			$user_info = $this->getUserByMeta( $token_key, $token );
			if( ! isset( $user_info['access_token'] ) ) {
				return array();
			}
			$expires = (int) $user_info['access_token_expires'];
			$now = time();
			if( $now > $expires ) {
				return array();
			}

			return $user_info;
		}

		public function extendUserToken( $user_id ) {
			$token_expire_key = 'X-Authorization-Expires';
			$token_expire = 4;
			$token_expire = ($token_expire == '') ? 2 : $token_expire;
			update_user_meta( $user_id, $token_expire_key, $token_expire );
		}

		public function getTableColumns( $table, $exclude = array() ) {
			global $wpdb;
			$table_name = $wpdb->prefix . $table;
			$existing_columns = $wpdb->get_col( "DESC {$table_name}", 0 );
			$return = array();
			if( is_array( $existing_columns ) && ! empty( $existing_columns ) ) {
				foreach( $existing_columns as $column ) {
					$return[ $column ] = $column;
				}
			}

			if( is_array( $exclude ) && ! empty( $exclude ) ) {
				foreach( $exclude as $key => $exclude_col ) {
					unset( $return[ $exclude_col ] );
				}
			}

			return $return;
		}

		public function objectToArray( $obj, &$arr ) {
			if( ! is_object( $obj ) && ! is_array( $obj ) ) {
				$arr = $obj;

				return $arr;
			}
			foreach( $obj as $key => $value ) {
				if( ! empty( $value ) ) {
					$arr[ $key ] = array();
					$this->objectToArray( $value, $arr[ $key ] );
				} else {
					$arr[ $key ] = $value;
				}
			}

			return $arr;
		}

		public function getFileIcon( $url ) {
			$mimes = get_allowed_mime_types();
			$file_ext = explode( '.', basename( $url ) );
			if( is_array( $file_ext ) ) {
				$file_ext = $file_ext[ count( $file_ext ) - 1 ];
				foreach( $mimes as $type => $mime ) {
					if( strstr( $type, $file_ext ) !== false ) {
						return wp_mime_type_icon( $mime );
					}
				}
			}

			return '';
		}

		public function isFileMimeTypeAllowed( $mime_type ) {
			$mimes = get_allowed_mime_types();

			return in_array( $mime_type, $mimes );
		}

		public function compileSass( $sass_to_compile ) {
			if( ! class_exists( 'Leafo\ScssPhp\Base\Range' ) ) {
				require $this->root_dir . '/framework/lib/scssphp/scss.inc.php';
			}
			$scss = new Compiler();
			$scss->setFormatter( 'Leafo\ScssPhp\Formatter\Compressed' );

			$import_paths = array(
				'core' => $this->root_dir . '/framework/lib/sass/'
			);
			$import_paths = apply_filters( 'cjaddons_imagination_sass_import_paths', $import_paths );
			$scss->setImportPaths( $import_paths );
			$sass_core_variables = $this->coreSassVariables();
			$saved_sass_variables = $this->savedOption( 'core_sass_variables' );

			$user_sass_variables = '';
			if( is_array( $saved_sass_variables ) ) {
				foreach( $saved_sass_variables as $key => $value ) {
					if( is_numeric( $value ) ) {
						$value = $value . 'px';
					}
					$user_sass_variables .= '$' . $key . ': ' . $value . ';' . "\n";
				}
				$user_sass_variables .= '$white: #ffffff;' . "\n";
			}
			//$sass = '@import "global/mixins";';
			$sass = $user_sass_variables;
			$sass .= $sass_core_variables;
			$sass .= $sass_to_compile;

			try{
				$output = $scss->compile( $sass );
			}catch(\Exception $e){
				$output = sprintf('/* %s */', $e->getMessage());
			}

			return $output;
		}

		public function compileSassFile( $sass_file_path ) {
			if( file_exists( $sass_file_path ) ) {
				ob_start();
				require $sass_file_path;
				$sass = ob_get_clean();

				return $this->compileSass( $sass );
			}

			return '/* sass file does not exists */';
		}

		public function createCSV( $filename = null, $headings_array = null, $row_array = null ) {

			ob_get_clean();

			$output_file = (is_null( $filename )) ? date( 'Y-m-d-H-i-s' ) : $filename;

			if( is_null( $row_array ) ) {
				return;
			}

			// output headers so that the file is downloaded rather than displayed
			header( "Content-type: Application/CSV" );
			header( 'Content-Disposition: attachment; filename=' . $output_file . '.csv' );
			header( 'Cache-Control: cache, must-revalidate' ); // HTTP/1.1
			header( 'Pragma: public' ); // HTTP/1.0

			ob_start();
			ob_flush();

			// create a file pointer connected to the output stream
			$output = @fopen( 'php://output', 'w' );

			ob_end_clean();

			// output the column headings
			fputcsv( $output, $headings_array );

			// loop over the rows, outputting them
			foreach( $row_array as $key => $value ) {
				fputcsv( $output, $value );
			}
			fclose( $output );
			exit;
		}

		public function removeSupportingOptions() {
			global $wpdb;
			$query = $wpdb->get_results( "SELECT * FROM wp_options WHERE option_name LIKE 'cjaddons%'" );
			foreach( $query as $key => $option ) {
				delete_option( $option->option_name );
			}
			$query = $wpdb->get_results( "SELECT * FROM wp_options WHERE option_name LIKE 'cssjockey%'" );
			foreach( $query as $key => $option ) {
				delete_option( $option->option_name );
			}
			$query = $wpdb->get_results( "SELECT * FROM wp_options WHERE option_name LIKE 'cj-%'" );
			foreach( $query as $key => $option ) {
				delete_option( $option->option_name );
			}
			$query = $wpdb->get_results( "SELECT * FROM wp_options WHERE option_name LIKE 'cj_%'" );
			foreach( $query as $key => $option ) {
				delete_option( $option->option_name );
			}
		}

		public function ucWords( $str, $replace = array('-', '_') ) {
			return ucwords( str_replace( $replace, ' ', $str ) );
		}

		public function inputTextFieldTypes() {
			return ['text', 'textarea', 'number', 'email', 'url', 'search', 'text', 'text-readonly', 'text-disabled', 'number', 'email', 'url', 'password', 'date', 'date-time', 'date-range', 'time', 'google-address', 'gradient'];
		}

		public function selectFields() {
			return ['select', 'dropdown', 'taxonomy-terms', 'user', 'users', 'page', 'pages', 'post', 'posts', 'role', 'roles', 'taxonomy', 'taxonomies', 'category', 'categories', 'post-type', 'post-types', 'tag', 'tags', 'nav_menu', 'nav-menu', 'sidebar', 'icon'];
		}

		public function componentsArray( $class_name = null ) {
			$components = array();
			$classes = get_declared_classes();
			if( is_array( $classes ) ) {
				foreach( $classes as $key => $class ) {
					if( strstr( $class, 'cjaddons_component' ) ) {
						$components[ $class ] = $class::getInstance();
					}
					if( strstr( $class, 'cjaddons_uib' ) ) {
						$components[ $class ] = $class::getInstance();
					}
				}
			}

			return (is_null( $class_name )) ? $components : $components[ $class_name ];
		}

		public function usersTableFields() {
			$users_table_fields = array('ID', 'user_login', 'user_pass', 'user_pass_confirmation', 'user_nicename', 'user_email', 'user_url', 'user_registered', 'user_activation_key', 'user_status', 'display_name');

			return $users_table_fields;
		}

		public function createNewAccount( $user_login, $user_email, $user_pass, $all_profile_fields = array(), $do_login = false, $notify = null ) {
			$post_data = $all_profile_fields;

			do_action( 'cjaddons_before_register', $post_data );
			$new_user_id = wp_create_user( $user_login, $user_pass, $user_email );
			if( is_wp_error( $new_user_id ) ) {
				return false;
			}
			if( ! is_null( $notify ) && function_exists( 'wp_new_user_notification' ) ) {
				wp_new_user_notification( $new_user_id, null, $notify );
			}
			$user_data = array(
				'ID' => $new_user_id,
				'user_nicename' => (isset( $post_data['user_nicename'] )) ? $post_data['user_nicename'] : '',
				'user_url' => (isset( $post_data['user_url'] )) ? $post_data['user_url'] : '',
				'display_name' => (isset( $post_data['display_name'] )) ? $post_data['display_name'] : '',
				'role' => (isset( $post_data['user_role'] )) ? $post_data['user_role'] : get_option( 'default_role' ),
			);
			wp_update_user( $user_data );
			foreach( $all_profile_fields as $meta_key => $meta_value ) {
				if( ! in_array( $meta_key, $this->usersTableFields() ) ) {
					$meta_value = (is_array( $meta_value )) ? serialize( $meta_value ) : $meta_value;
					update_user_meta( $new_user_id, $meta_key, esc_attr( $meta_value ) );
				}
			}
			$this->setUserToken( $new_user_id );
			update_user_meta( $new_user_id, 'cjaddons_user_salt', base64_encode( $user_pass ) );
			update_user_meta( $new_user_id, 'cjaddons_api_salt', base64_encode( $user_login . ':' . $user_pass ) );

			do_action( 'cjaddons_after_register', $new_user_id );

			if( $do_login ) {
				return $this->login( $user_login, $user_pass );
			}

			return $new_user_id;
		}

		public function login( $user_login, $user_pass ) {
			do_action( 'cjaddons_before_login', $user_login, $user_pass );
			$login_data = array();
			$login_data['user_login'] = $user_login;
			$login_data['user_password'] = $user_pass;
			$login_data['remember'] = true;
			$user = wp_signon( $login_data, is_ssl() );
			if( is_wp_error( $user ) ) {
				return false;
			} else {
				$this->setUserToken( $user->ID );
				update_user_meta( $user->ID, 'cjaddons_user_salt', base64_encode( $user_pass ) );
				update_user_meta( $user->ID, 'cjaddons_api_salt', base64_encode( $user_login . ':' . $user_pass ) );
				do_action( 'cjaddons_after_login', $user_login, $user_pass );

				return $user->ID;
			}
		}

		public function loginWithSalt( $user_identifiers, $new_password = null ) {
			$user_info = $this->userInfo( $user_identifiers );
			if( empty( $user_info ) ) {
				return false;
			}

			$password_hash = wp_hash_password( $new_password );

			if( ! isset( $user_info['cjaddons_api_salt'] ) || $user_info['cjaddons_api_salt'] == '' ) {
				$this->dbUpdate( 'users', array('user_pass' => $password_hash), 'ID', $user_info['ID'] );
				$this->setUserToken( $user_info['ID'] );
				update_user_meta( $user_info['ID'], 'cjaddons_user_salt', base64_encode( $new_password ) );
				update_user_meta( $user_info['ID'], 'cjaddons_api_salt', base64_encode( $user_info['user_login'] . ':' . $new_password ) );
				$user_info = $this->userInfo( $user_identifiers );
			}

			$login_data = explode( ':', base64_decode( $user_info['cjaddons_api_salt'] ) );
			$login_data['user_login'] = $login_data[0];
			$login_data['user_password'] = $login_data[1];
			$login_data['remember'] = true;
			$user = wp_signon( $login_data, is_ssl() );

			if( is_wp_error( $user ) ) {
				if( ! function_exists( 'wp_password_change_notification' ) ) {
					function wp_password_change_notification() {
					}
				}
				wp_set_password( $new_password, $user_info['ID'] );
				$this->setUserToken( $user_info['ID'] );
				update_user_meta( $user_info['ID'], 'cjaddons_user_salt', base64_encode( $new_password ) );
				update_user_meta( $user_info['ID'], 'cjaddons_api_salt', base64_encode( $user_info['user_login'] . ':' . $new_password ) );

				return $this->login( $user_info['user_login'], $new_password );
			} else {
				$this->setUserToken( $user->ID );
				update_user_meta( $user->ID, 'cjaddons_user_salt', base64_encode( $login_data[0] ) );
				update_user_meta( $user->ID, 'cjaddons_api_salt', base64_encode( $login_data[0] . ':' . $login_data[1] ) );

				return $user->ID;
			}
		}

		public function getSvgCode( $path ) {
			return file_get_contents( $path );
		}

		public function autoCreateUiBlock( $component_info, $force_create = false ) {
			global $wpdb;
			$class_name = $component_info['class'];
			$check_existing = $wpdb->query( "SELECT * FROM $wpdb->postmeta WHERE meta_key = '_component_class_name' AND meta_value = '{$class_name}'" );

			if( $force_create ) {
				$check_existing = false;
			}
			if( $check_existing ) {
				return false;
			} else {
				if( ! empty( $component_info['module_info'] ) ) {
					$post_title = $component_info['name'] . ' ~ ' . $component_info['module_info']['module_name'];
				} else {
					$post_title = $component_info['name'];
				}
				$post_data = array(
					'post_title' => $post_title,
					'post_type' => 'cj-ui-blocks',
					'post_status' => 'publish',
				);
				$block_id = wp_insert_post( $post_data );
				update_post_meta( $block_id, '_component_class_name', $component_info['class'] );
				$component_options = $component_info['options'];
				if( is_array( $component_options ) && ! empty( $component_options ) ) {
					foreach( $component_options as $key => $component_option ) {
						update_post_meta( $block_id, $component_option['id'], $component_option['default'] );
					}
				}
				$component_settings = array();
				foreach( $component_options as $key => $value ) {
					$component_settings[ $value['id'] ] = $value['default'];
				}
				update_post_meta( $block_id, '_component_settings', $component_settings );
				if( isset( $component_info['module_info']['module_id'] ) ) {
					update_post_meta( $block_id, '_module_id', $component_info['module_info']['module_id'] );
				}
				$sass_file = $component_info['path'] . '/style.scss';
				if( file_exists( $sass_file ) ) {
					ob_start();
					include $component_info['path'] . '/style.scss';
					$sass = ob_get_clean();
					$component_css = $this->compileSass( $sass );
					update_post_meta( $block_id, '_component_css', $component_css );
				}
				$js_file = $component_info['path'] . '/script.min.js';
				if( file_exists( $js_file ) ) {
					ob_start();
					include $component_info['path'] . '/script.min.js';
					$component_js = ob_get_clean();
					update_post_meta( $block_id, '_component_js', $component_js );
				}

				return $block_id;
			}
		}

		public function updateUiCssAndJs( $block_id ) {
			$class_name = get_post_meta( $block_id, '_component_class_name', true );
			if( $class_name != '' ) {
				$class_instance = $class_name::getInstance();
				// compile css
				$sass_file = $class_instance->info( 'path' ) . '/style.scss';
				if( file_exists( $sass_file ) ) {
					ob_start();
					include $sass_file;
					$sass = ob_get_clean();
					$component_css = $this->compileSass( $sass );
					update_post_meta( $block_id, '_component_css', $component_css );
				}
				// compile js
				$js_file = $class_instance->info( 'path' ) . '/script.min.js';
				if( file_exists( $js_file ) ) {
					ob_start();
					include $js_file;
					$component_js = ob_get_clean();
					update_post_meta( $block_id, '_component_js', $component_js );
				}
			}
		}

		public function updateUiBlockSettings( $block_id, $post_data = array() ) {

			$form_fields = array();
			$block_info = $this->postInfo( $block_id );
			$class_name = $block_info['_component_class_name'];
			if( $class_name == '' ) {
				return false;
			}
			$class_instance = $class_name::getInstance();
			$component_options = $class_instance->info['options'];
			$component_post_data = array();

			foreach( $component_options as $key => $form_field ) {
				$save_value = $post_data[ $form_field['id'] ];
				update_post_meta( $block_id, $form_field['id'], $save_value );
				if( isset( $post_data[ $form_field['id'] ] ) ) {
					$component_post_data[ $form_field['id'] ] = $post_data[ $form_field['id'] ];
				}
			}

			if( isset( $class_instance->info( 'module_info' )['module_id'] ) ) {
				update_post_meta( $block_id, '_module_id', $class_instance->info( 'module_info' )['module_id'] );
			}

			update_post_meta( $block_id, '_component_settings', $component_post_data );

			$additional_settings = array(
				'_content_above',
				'_content_below',
				'_margin',
				'_padding',
				'_custom_css_code',
			);

			foreach( $additional_settings as $key => $value ) {
				if( isset( $_POST[ $value ] ) ) {
					update_post_meta( $block_id, $value, $_POST[ $value ] );
				}
			}

			ob_start();
			include $class_instance->info( 'path' ) . '/style.scss';
			$sass = ob_get_clean();
			$component_css = $this->compileSass( $sass );
			update_post_meta( $block_id, '_component_css', $component_css );

			ob_start();
			include $class_instance->info( 'path' ) . '/script.min.js';
			$component_js = ob_get_clean();
			update_post_meta( $block_id, '_component_js', $component_js );

			return $block_id;
		}

		public function renderUiBlock( $block_info ) {

			if( isset( $block_info['_cjaddons_compile_sass'] ) && $block_info['_cjaddons_compile_sass'] === 'yes' ) {
				$this->updateUiCssAndJs( $block_info['ID'] );
				delete_post_meta( $block_info['ID'], '_cjaddons_compile_sass' );
			}
			$class_name = $block_info['_component_class_name'];
			$class_info = $class_name::getInstance();
			$component_info = $class_info->info();
			ob_start();
			$queried_object = get_queried_object();

			$block_spacing_styles = '';

			if( isset( $block_info['_margin'] ) ) {
				$margin = $block_info['_margin'];
				if( ! empty( $margin ) ) {
					foreach( $margin as $m_key => $m_value ) {
						if( $m_value != '' ) {
							$block_spacing_styles .= 'margin-' . $m_key . ':' . $m_value . ';';
						}
					}
				}
			}

			if( isset( $block_info['_padding'] ) ) {
				$padding = $block_info['_padding'];
				if( ! empty( $padding ) ) {
					foreach( $padding as $p_key => $p_value ) {
						if( $p_value != '' ) {
							$block_spacing_styles .= 'padding-' . $p_key . ':' . $p_value . ';';
						}
					}
				}
			}

			// set block container params in block render function.
			$params = ' ';
			$block_params = (isset( $block_info['_container_params'] ) && is_array( $block_info['_container_params'] ) && ! empty( $block_info['_container_params'] )) ? $block_info['_container_params'] : array();
			if( ! empty( $block_params ) ) {
				foreach( $block_params as $param_key => $param_value ) {
					$params .= ' ' . $param_key . '="' . $param_value . '"';
				}
			}

			echo '<div class="cjaddons-ui-block-' . $block_info['ID'] . ' cssjockey-ui cj-block cj-clearfix cjaddons-ui-block"' . $params . '>';

			echo '<div style="' . $block_spacing_styles . '">';
			if( isset( $block_info['_content_above'] ) && $block_info['_content_above'] != '' ) {
				echo do_shortcode( $block_info['_content_above'] );
			}

			/* actual block content */
			include $component_info['path'] . '/content.php';
			/* actual block content */

			if( isset( $block_info['_content_below'] ) && $block_info['_content_below'] != '' ) {
				echo do_shortcode( $block_info['_content_below'] );
			}
			echo '</div>';

			if( isset( $block_info['_custom_css_code'] ) && $block_info['_custom_css_code'] != '' ) {
				echo '<style type="text/css">' . $block_info['_custom_css_code'] . '</style>';
			}

			if( ! isset( $_GET['cjaddons-action'] ) && ! isset( $_GET['cjaddons-preview-ui-block'] ) && current_user_can( 'publish_posts' ) ) {
				echo '<a href="' . admin_url( 'post.php?post=' . $block_info['ID'] . '&action=edit' ) . '" target="_blank" data-tooltip="' . __( 'Edit UI Block', 'cssjockey-add-ons' ) . '" class="cj-tooltip cj-is-tooltip-right cj-edit-block-button"><i class="fa fa-edit"></i></a>';
			}

			if( current_user_can( 'publish_posts' ) && isset( $queried_object->ID ) && isset( $_GET['cjaddons-action'] ) && $_GET['cjaddons-action'] == 'cj-show-frontend-ui-blocks-editor' ) {
				$shortcode_atts = (isset( $block_info['_shortcode_atts'] )) ? $block_info['_shortcode_atts'] : array();
				$shortcode_atts['sort_id'] = (isset( $shortcode_atts['sort_id'] )) ? $shortcode_atts['sort_id'] : '';
				$shortcode_atts['placement'] = (isset( $shortcode_atts['placement'] )) ? $shortcode_atts['placement'] : '';
				if( $shortcode_atts['sort_id'] != '' ) {
					$show_sort_arrows = array();
					if( isset( $shortcode_atts['sort_arrows'] ) ) {
						$show_sort_arrows = explode( '|', $shortcode_atts['sort_arrows'] );
					}
					$edit_url = admin_url( 'post.php?post=' . $block_info['ID'] . '&action=edit' );
					echo '<span class="cj-edit-block-actions">';
					if( in_array( 'up', $show_sort_arrows ) ) {
						echo '<a href="#up" data-move="up" data-post-id="' . $queried_object->ID . '" data-block-id="' . $block_info['ID'] . '" data-sort-id="' . $shortcode_atts['sort_id'] . '" data-placement="' . $shortcode_atts['placement'] . '"  class="cj-frontend-sort-ui-block cj-button cj-is-small cj-bg-cj-red cj-color-white cj-no-borders"><span class="cj-icon cj-is-small"><i class="fa fa-arrow-up"></i></span></a>';
					}
					if( in_array( 'down', $show_sort_arrows ) ) {
						echo '<a href="#down" data-move="down" data-post-id="' . $queried_object->ID . '" data-block-id="' . $block_info['ID'] . '" data-sort-id="' . $shortcode_atts['sort_id'] . '" data-placement="' . $shortcode_atts['placement'] . '"  class="cj-frontend-sort-ui-block cj-button cj-is-small cj-bg-cj-red cj-color-white cj-no-borders"><span class="cj-icon cj-is-small"><i class="fa fa-arrow-down"></i></span></a>';
					}
					echo '<a href="#duplicate" data-post-id="' . $queried_object->ID . '" data-block-class-name="' . $block_info['_component_class_name'] . '" data-placement="' . $shortcode_atts['placement'] . '" class="cj-frontend-duplicate-ui-block cj-button cj-is-small cj-bg-cj-red cj-color-white cj-no-borders"><span class="cj-icon cj-is-small"><i class="fa fa-copy"></i></span></a>';
					echo '<a href="' . $edit_url . '" target="_blank"  class="cj-button cj-is-small cj-bg-cj-red cj-color-white cj-no-borders"><span class="cj-icon cj-is-small"><i class="fa fa-pencil"></i></span></a>';
					echo '<a href="#delete-block" data-post-id="' . $queried_object->ID . '" data-block-id="' . $block_info['ID'] . '" data-sort-id="' . $shortcode_atts['sort_id'] . '" data-placement="' . $shortcode_atts['placement'] . '" class="cj-frontend-delete-ui-block cj-button cj-is-small cj-bg-cj-red cj-color-white cj-no-borders"><span class="cj-icon cj-is-small"><i class="fa fa-trash"></i></span></a>';
					echo '</span>';
				}
			}

			echo '</div>';
			echo ob_get_clean();
			add_filter( 'cjaddons_ui_block_assets', function ( $block_ids ) use ( $block_info ) {
				$block_ids[ $block_info['ID'] ] = $block_info['ID'];

				return $block_ids;
			}, 10, 1 );
		}

		public function getBrowser( $agent = null, $var = null ) {
			$u_agent = ($agent != null) ? $agent : $_SERVER['HTTP_USER_AGENT'];
			$browser_name = 'Unknown';
			$platform = 'Unknown';
			$version = "";

			//First get the platform?
			if( preg_match( '/linux/i', $u_agent ) ) {
				$platform = 'linux';
			} elseif( preg_match( '/macintosh|mac os x/i', $u_agent ) ) {
				$platform = 'mac';
			} elseif( preg_match( '/windows|win32/i', $u_agent ) ) {
				$platform = 'windows';
			}

			// Next get the name of the useragent yes seperately and for good reason
			if( preg_match( '/MSIE/i', $u_agent ) && ! preg_match( '/Opera/i', $u_agent ) ) {
				$browser_name = 'Internet Explorer';
				$ub = "MSIE";
			} elseif( preg_match( '/Firefox/i', $u_agent ) ) {
				$browser_name = 'Mozilla Firefox';
				$ub = "Firefox";
			} elseif( preg_match( '/Chrome/i', $u_agent ) ) {
				$browser_name = 'Google Chrome';
				$ub = "Chrome";
			} elseif( preg_match( '/Safari/i', $u_agent ) ) {
				$browser_name = 'Apple Safari';
				$ub = "Safari";
			} elseif( preg_match( '/Opera/i', $u_agent ) ) {
				$browser_name = 'Opera';
				$ub = "Opera";
			} elseif( preg_match( '/Netscape/i', $u_agent ) ) {
				$browser_name = 'Netscape';
				$ub = "Netscape";
			}

			// finally get the correct version number
			$known = array('Version', $ub, 'other');
			$pattern = '#(?<browser>' . join( '|', $known ) .
			           ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
			if( ! preg_match_all( $pattern, $u_agent, $matches ) ) {
				// we have no matching number just continue
			}

			// see how many we have
			$i = count( $matches['browser'] );
			if( $i != 1 ) {
				//we will have two since we are not using 'other' argument yet
				//see if version is before or after the name
				if( strripos( $u_agent, "Version" ) < strripos( $u_agent, $ub ) ) {
					$version = $matches['version'][0];
				} else {
					$version = $matches['version'][1];
				}
			} else {
				$version = $matches['version'][0];
			}

			// check if we have a number
			if( $version == null || $version == "" ) {
				$version = "?";
			}

			$return = array(
				'userAgent' => $u_agent,
				'name' => $browser_name,
				'type' => sanitize_title( $browser_name ),
				'version' => $version,
				'platform' => $platform,
				'pattern' => $pattern
			);

			return (is_null( $var )) ? $return : $return[ $var ];
		}

		public function getSharingUrl( $service, $url_to_share, $title = '', $description = '' ) {
			$url = $url_to_share;
			$services = array(
				'facebook' => 'https://www.facebook.com/sharer/sharer.php?u=' . $url,
				'twitter' => 'https://twitter.com/home?status=' . $url,
				'google' => 'https://plus.google.com/share?url=' . $url,
				'linkedin' => 'https://www.linkedin.com/shareArticle?mini=true&url=' . $url . '&title=' . $title . '&summary=' . $description . '&source=' . $url,
				'pinterest' => 'http://pinterest.com/pin/create/button/?url=' . $url . '&description=' . $description,
			);

			return (isset( $services[ $service ] )) ? $services[ $service ] : '#service-not-available';
		}

		public function tableExists( $table_name ) {
			global $wpdb;

			return ($wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) == $table_name);
		}

		// db functions
		public function dbUpdate( $table, $data, $id_field, $id_value ) {
			global $wpdb;
			$table = $this->wpTableName( $table );
			foreach( $data as $field => $value ) {
				$fields[] = sprintf( "`%s` = '%s'", $field, esc_sql( $value ) );
			}
			$field_list = join( ',', $fields );
			$query = sprintf( "UPDATE `%s` SET %s WHERE `%s` = %s", $table, $field_list, $id_field, intval( $id_value ) );
			$wpdb->query( $query );

			return intval( $id_value );
		}

		public function dbInsert( $table, $data ) {
			global $wpdb;
			$table = $this->wpTableName( $table );
			foreach( $data as $field => $value ) {
				$value = (is_array( $value )) ? serialize( $value ) : $value;
				$fields[] = '`' . esc_sql( $field ) . '`';
				$values[] = "'" . esc_sql( $value ) . "'";
			}
			$field_list = join( ',', $fields );
			$value_list = join( ', ', $values );
			$query = "INSERT INTO `" . $table . "` (" . $field_list . ") VALUES (" . $value_list . ")";
			$wpdb->query( $query );

			return $wpdb->insert_id;
		}

		public function dbSelect( $table, $columns = '*', $where = array() ) {
			global $wpdb;
			$query_string = array();
			$table_name = $this->wpTableName( $table );
			$query_string[] = "SELECT $columns FROM $table_name ";
			if( is_array( $where ) && ! empty( $where ) ) {
				$query_string[] = $this->whereClause( $where );
			}
			$query_string = implode( ' ', $query_string );

			return $wpdb->get_results( $query_string, 'ARRAY_A' );
		}

		public function dbGet( $table, $columns = '*', $where = array() ) {
			global $wpdb;
			$query_string = array();
			$table_name = $this->wpTableName( $table );
			$query_string[] = "SELECT $columns FROM $table_name ";
			if( is_array( $where ) && ! empty( $where ) ) {
				$query_string[] = $this->whereClause( $where );
			}
			$query_string = implode( ' ', $query_string );
			$return = $wpdb->get_row( $query_string, 'ARRAY_A' );

			return ( ! is_null( $return )) ? $return : false;
		}

		public function dbDelete( $table, $where = array() ) {
			global $wpdb;
			$query_string = array();
			$table_name = $this->wpTableName( $table );
			$query_string[] = "DELETE FROM $table_name ";
			if( is_array( $where ) && ! empty( $where ) ) {
				$query_string[] = $this->whereClause( $where );
			}
			if( ! is_array( $where ) ) {
				$query_string[] = $where;
			}
			$query_string = implode( ' ', $query_string );

			$return = $wpdb->query( $query_string );

			return ( ! is_null( $return )) ? $return : false;
		}

		public function dbCount( $table, $field, $where = array() ) {
			global $wpdb;
			$query_string = array();
			$table_name = $this->wpTableName( $table );
			$query_string[] = "SELECT COUNT($field) FROM $table_name ";
			if( is_array( $where ) && ! empty( $where ) ) {
				$query_string[] = $this->whereClause( $where );
			}
			$query_string = implode( ' ', $query_string );
			$return = (int) $wpdb->get_var( $query_string );

			return $return;
		}

		public function whereClause( $where ) {
			$operator = '=';
			$return[] = 'WHERE';
			$exclude_operators = array('AND', 'OR');
			$count = 0;
			foreach( $where as $key => $value ) {
				$count ++;
				if( $count > 1 ) {
					$return[] = 'AND';
				}
				if( ! in_array( $key, $exclude_operators ) ) {
					$return[] = $key . $operator . "'$value'";
				}
			}

			if( isset( $where['AND'] ) ) {
				$count = 0;
				foreach( $where['AND'] as $key => $value ) {
					$count ++;
					if( $count > 1 ) {
						$return[] = 'AND';
					}
					$return[] = $key . $operator . "'$value'";
				}
			}

			if( isset( $where['OR'] ) ) {
				$count = 0;
				foreach( $where['OR'] as $key => $value ) {
					$count ++;
					if( $count > 1 ) {
						$return[] = 'OR';
					}
					$return[] = $key . $operator . "'$value'";
				}
			}
			$return = implode( ' ', $return );

			return $return;
		}

		public function columnClasses( $suffix ) {
			$classes = array();
			$classes[""] = __( 'Auto', 'cssjockey-add-ons' );
			$classes["cj-is-hidden-{$suffix}"] = __( 'Hidden', 'cssjockey-add-ons' );
			for( $i = 1; $i <= 12; $i ++ ) {
				$classes["cj-is-{$i}-{$suffix}"] = $i . '/12';
			}

			return $classes;
		}

		public function reCaptcha() {
			if( ! class_exists( 'Phelium\Component\reCAPTCHA' ) ) {
				return false;
			}
			$site_key = $this->savedOption( 'core_google_recaptcha_site_key' );
			$site_secret = $this->savedOption( 'core_google_recaptcha_site_secret' );
			$theme = $this->savedOption( 'core_google_recaptcha_theme' );
			$language = $this->savedOption( 'core_google_recaptcha_language' );
			if( $site_key != '' && $site_secret != '' ) {
				$recaptcha_instance = new reCAPTCHA( $site_key, $site_secret );
				if( $language != '' ) {
					$recaptcha_instance->setLanguage( $language );
				}
				if( $theme != '' ) {
					$recaptcha_instance->setTheme( $theme );
				}

				return $recaptcha_instance;
			}

			return false;
		}

		public function removeAutoP( $content, $auto_p = false ) {
			if( $auto_p ) { // Possible to use !preg_match('('.WPBMap::getTagsRegexp().')', $content)
				$content = wpautop( preg_replace( '/<\/?p\>/', "\n", $content ) . "\n" );
			}

			return do_shortcode( shortcode_unautop( $content ) );
		}

		public function breadcrumbs( $separator = ' &raquo; ' ) {
			/* === OPTIONS === */
			$text['home'] = __( 'Home', 'lang-cjaddons' ); // text for the 'Home' link
			$text['blog'] = __( 'Blog', 'lang-cjaddons' ); // text for the 'Home' link
			$text['category'] = __( 'Archive by Category "%s"', 'lang-cjaddons' ); // text for a category page
			$text['tax'] = __( 'Archive for "%s"', 'lang-cjaddons' ); // text for a taxonomy page
			$text['search'] = __( 'Search Results for "%s"', 'lang-cjaddons' ); // text for a search results page
			$text['tag'] = __( 'Posts Tagged "%s"', 'lang-cjaddons' ); // text for a tag page
			$text['author'] = __( 'Articles Posted by %s', 'lang-cjaddons' ); // text for an author page
			$text['404'] = __( 'Error 404', 'lang-cjaddons' ); // text for the 404 page

			$showCurrent = 1; // 1 - show current post/page title in breadcrumbs, 0 - don't show
			$showOnHome = 1; // 1 - show breadcrumbs on the homepage, 0 - don't show
			$delimiter = '<span class="cj-separator">' . $separator . '</span>'; // delimiter between crumbs
			//$delimiter = ' <span class="cj-icon cj-is-small cj-p-5 cj-opacity-50"><i class="fa fa-angle-double-right"></i></span> '; // delimiter between crumbs
			$before = '<span class="cj-is-current">'; // tag before the current crumb
			$after = '</span>'; // tag after the current crumb
			/* === END OF OPTIONS === */

			$display = '';

			global $post;
			$page_for_posts = get_option( 'page_for_posts' );
			$homeLink = get_bloginfo( 'url' ) . '/';
			$blogLink = get_permalink( $page_for_posts );
			$linkBefore = '<span typeof="v:Breadcrumb">';
			$linkAfter = '</span>';
			$linkAttr = ' rel="v:url" property="v:title"';
			$link = $linkBefore . '<a' . $linkAttr . ' href="%1$s">%2$s</a>' . $linkAfter;

			if( is_front_page() && is_home() ) {
				$display .= '<span class="cj-breadcrumbs"><a href="' . $homeLink . '">' . $text['home'] . '</a> ' . $delimiter . ' ' . $text['blog'] . '</span>';
			} elseif( is_front_page() ) {
				if( $showOnHome == 1 ) {
					$display .= '<span class="cj-breadcrumbs"><a href="' . $homeLink . '">' . $text['home'] . '</a></span>';
				}
			} elseif( is_home() ) {
				$display .= '<span class="cj-breadcrumbs"><a href="' . $homeLink . '">' . $text['home'] . '</a> ' . $delimiter . ' ' . $text['blog'] . '</span>';
			} else {

				$display .= '<span class="cj-breadcrumbs" xmlns:v="http://rdf.data-vocabulary.org/#">' . sprintf( $link, $homeLink, $text['home'] ) . $delimiter;

				if( is_category() ) {
					$thisCat = get_category( get_query_var( 'cat' ), false );
					if( $thisCat->parent != 0 ) {
						$cats = get_category_parents( $thisCat->parent, true, $delimiter );
						$cats = str_replace( '<a', $linkBefore . '<a' . $linkAttr, $cats );
						$cats = str_replace( '</a>', '</a>' . $linkAfter, $cats );
						$display .= $cats;
					}
					$display .= $before . sprintf( $text['category'], single_cat_title( '', false ) ) . $after;
				} elseif( is_tax() ) {
					$thisCat = get_category( get_query_var( 'cat' ), false );
					if( $thisCat->parent != 0 ) {
						$cats = get_category_parents( $thisCat->parent, true, $delimiter );
						$cats = str_replace( '<a', $linkBefore . '<a' . $linkAttr, $cats );
						$cats = str_replace( '</a>', '</a>' . $linkAfter, $cats );
						$display .= $cats;
					}
					$display .= $before . sprintf( $text['tax'], single_cat_title( '', false ) ) . $after;
				} elseif( is_search() ) {
					$display .= $before . sprintf( $text['search'], get_search_query() ) . $after;
				} elseif( is_day() ) {
					$display .= sprintf( $link, get_year_link( get_the_time( 'Y' ) ), get_the_time( 'Y' ) ) . $delimiter;
					$display .= sprintf( $link, get_month_link( get_the_time( 'Y' ), get_the_time( 'm' ) ), get_the_time( 'F' ) ) . $delimiter;
					$display .= $before . get_the_time( 'd' ) . $after;
				} elseif( is_month() ) {
					$display .= sprintf( $link, get_year_link( get_the_time( 'Y' ) ), get_the_time( 'Y' ) ) . $delimiter;
					$display .= $before . get_the_time( 'F' ) . $after;
				} elseif( is_year() ) {
					$display .= $before . get_the_time( 'Y' ) . $after;
				} elseif( is_single() && ! is_attachment() ) {
					if( get_post_type() != 'post' ) {
						$post_type = get_post_type_object( get_post_type() );
						$slug = $post_type->rewrite;
						printf( $link, $homeLink . '/' . $slug['slug'] . '/', $post_type->labels->singular_name );
						if( $showCurrent == 1 ) {
							$display .= $delimiter . $before . get_the_title() . $after;
						}
					} else {
						$cat = get_the_category();
						$cat = $cat[0];
						$cats = get_category_parents( $cat, true, $delimiter );
						if( $showCurrent == 0 ) {
							$cats = preg_replace( "#^(.+)$delimiter$#", "$1", $cats );
						}
						$cats = str_replace( '<a', $linkBefore . '<a' . $linkAttr, $cats );
						$cats = str_replace( '</a>', '</a>' . $linkAfter, $cats );
						$display .= $cats;
						if( $showCurrent == 1 ) {
							$display .= $before . get_the_title() . $after;
						}
					}
				} elseif( ! is_single() && ! is_page() && get_post_type() != 'post' && ! is_404() ) {
					$post_type = get_post_type_object( get_post_type() );
					$display .= $before . $post_type->labels->singular_name . $after;
				} elseif( is_attachment() ) {
					$parent = get_post( $post->post_parent );
					$cat = get_the_category( $parent->ID );
					$cat = $cat[0];
					$cats = get_category_parents( $cat, true, $delimiter );
					$cats = str_replace( '<a', $linkBefore . '<a' . $linkAttr, $cats );
					$cats = str_replace( '</a>', '</a>' . $linkAfter, $cats );
					$display .= $cats;
					printf( $link, get_permalink( $parent ), $parent->post_title );
					if( $showCurrent == 1 ) {
						$display .= $delimiter . $before . get_the_title() . $after;
					}
				} elseif( is_page() && ! $post->post_parent ) {
					if( $showCurrent == 1 ) {
						$display .= $before . get_the_title() . $after;
					}
				} elseif( is_page() && $post->post_parent ) {
					$parent_id = $post->post_parent;
					$breadcrumbs = array();
					while( $parent_id ) {
						$page = get_page( $parent_id );
						$breadcrumbs[] = sprintf( $link, get_permalink( $page->ID ), get_the_title( $page->ID ) );
						$parent_id = $page->post_parent;
					}
					$breadcrumbs = array_reverse( $breadcrumbs );
					for( $i = 0; $i < count( $breadcrumbs ); $i ++ ) {
						$display .= $breadcrumbs[ $i ];
						if( $i != count( $breadcrumbs ) - 1 ) {
							$display .= $delimiter;
						}
					}
					if( $showCurrent == 1 ) {
						$display .= $delimiter . $before . get_the_title() . $after;
					}
				} elseif( is_tag() ) {
					$display .= $before . sprintf( $text['tag'], single_tag_title( '', false ) ) . $after;
				} elseif( is_author() ) {
					global $author;
					$userdata = get_userdata( $author );
					$display .= $before . sprintf( $text['author'], $userdata->display_name ) . $after;
				} elseif( is_404() ) {
					$display .= $before . $text['404'] . $after;
				}

				if( get_query_var( 'paged' ) ) {
					if( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) {
						$display .= ' (';
					}
					$display .= __( 'Page' ) . ' ' . get_query_var( 'paged' );
					if( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) {
						$display .= ')';
					}
				}

				$display .= '</span>';
			}

			return $display;
		}

	}
}