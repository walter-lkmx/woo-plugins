<?php
$uid = $this->helpers->uniqueString( 'progress-' );
$value = (isset( $instance['value'] ) && $instance['value'] != '') ? $instance['value'] : '75';
$style = (isset( $instance['style'] ) && $instance['style'] != '') ? 'cj-is-' . $instance['style'] : 'cj-is-primary';
$size = (isset( $instance['size'] ) && $instance['size'] != '') ? 'cj-is-' . $instance['size'] : 'cj-is-default';
?>
<span id="<?php echo $uid; ?>" class="cssjockey-ui">
    <progress class="cj-progress <?php echo $style . ' ' . $size; ?> cj-progress-animated cj-mb-15" data-value="<?php echo $value; ?>" value="0" max="100"><?php echo $value; ?>%</progress>
</span>
