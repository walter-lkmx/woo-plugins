<?php
$uid = $this->helpers->uniqueString( 'icon-' );
$icon = (isset( $instance['icon'] ) && $instance['icon'] != '') ? $instance['icon'] : '';
$size = (isset( $instance['size'] ) && $instance['size'] != '') ? $instance['size'] : 'small';
$color = (isset( $instance['color'] ) && $instance['color'] != '') ? $instance['color'] : '';
$background = (isset( $instance['background'] ) && $instance['background'] != '') ? $instance['background'] : '';
$background_class = (isset( $instance['background'] ) && $instance['background'] != '') ? 'cj-icon-has-background' : '';
if($icon == ''){
    return false;
}
?>
<span id="<?php echo $uid; ?>" class="cssjockey-ui cj-icon-shortcode">
    <?php echo (isset($instance['link']) && $instance['link'] != '') ? '<a href="'.$instance['link'].'" target="'.$instance['target'].'">' : ''; ?>
    <span class="cj-icon cj-bg-<?php echo $background.' '.$background_class; ?> cj-color-<?php echo $color; ?> cj-is-<?php echo $size; ?>"><i class="fa <?php echo $instance['icon'] ?>"></i></span>
	<?php echo (isset($instance['link']) && $instance['link'] != '') ? '</a>' : ''; ?>
</span>