<?php
$uid = $this->helpers->uniqueString( 'modal-' );
$animation = (isset( $instance['animation'] ) && $instance['animation'] != '') ? $instance['animation'] : 'bounceInUp';
$button_text = (isset( $instance['button_text'] ) && $instance['button_text'] != '') ? $instance['button_text'] : 'Show Modal';
$button_style = (isset( $instance['button_style'] ) && $instance['button_style'] != '') ? $instance['button_style'] : 'default';
$button_size = (isset( $instance['button_size'] ) && $instance['button_size'] != '') ? $instance['button_size'] : 'default';

$button_class = '';
if( $button_style !== 'default' ) {
	$button_class = 'cj-button cj-is-' . $button_size . ' cj-is-' . $button_style . ' cj-mb-15';
}

?>
<span id="<?php echo $uid; ?>" class="cssjockey-ui">
    <a href="#" data-toggle="class" data-target="#modal-<?php echo $uid ?>" data-classes="cj-is-active" class="<?php echo $button_class; ?>"><?php echo $button_text; ?></a>
    <div id="modal-<?php echo $uid ?>" class="cj-modal">
        <div data-toggle="class" data-target="#modal-<?php echo $uid ?>" data-classes="cj-is-active" class="cj-modal-background"></div>
        <div class="cj-modal-content animated <?php echo $animation ?>">
            <div class="cj-box"><?php echo do_shortcode( $content ); ?></div>
        </div>
        <button data-toggle="class" data-target="#modal-<?php echo $uid ?>" data-classes="cj-is-active" class="cj-modal-close" aria-label="close"></button>
    </div>
</span>