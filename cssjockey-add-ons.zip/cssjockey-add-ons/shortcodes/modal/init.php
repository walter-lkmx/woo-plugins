<?php
/*
 * Class name should be cjaddons_NAME_shortcode
 * Shortcode Tag will be cjaddons_NAME
 * */
if( ! class_exists( 'cjaddons_modal_shortcode' ) ) {
	class cjaddons_modal_shortcode {

		public $defaults, $helpers, $render_forms, $textdomain, $shortcode_tag;

		private static $instance;

		public function defaults() {
			$defaults['info'] = array(
				'single' => false,
				'tag' => $this->shortcode_tag,
				'name' => esc_attr__( 'Modal', $this->textdomain ),
				'description' => esc_attr__( 'Displays a link which opens a modal box with custom content. You can also use shortcodes in the content.', $this->textdomain ),
				'screenshot' => $this->getScreenshotUrl(),
				'default_content' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget.',
				//'default_content_type' => 'hidden',
				'group' => 'cjaddons',
				'textdomain' => 'cjaddons',
				'item_name' => $this->helpers->itemInfo( 'item_name' ),
				'preview' => true,
			);
			$defaults['options'] = array(
				array(
					'id' => 'animation',
					'type' => 'dropdown',
					'label' => __( 'Modal animation', 'cssjockey-add-ons' ),
					'info' => __( 'Specify animation for the modal box.', 'cssjockey-add-ons' ),
					'default' => 'bounceInUp',
					'options' => $this->helpers->arrays('animate-css'),
				),
				array(
					'id' => 'button_text',
					'type' => 'text',
					'label' => __( 'Button Text', 'cssjockey-add-ons' ),
					'info' => __( 'Specify text for the button.', 'cssjockey-add-ons' ),
					'default' => 'Show Modal',
					'options' => '',
				),
				array(
					'id' => 'button_style',
					'type' => 'dropdown',
					'label' => __( 'Button Style', 'cssjockey-add-ons' ),
					'info' => __( 'Specify style for the button.', 'cssjockey-add-ons' ),
					'default' => '',
					'options' => $this->helpers->arrays('brand-colors'),
				),
				array(
					'id' => 'button_size',
					'type' => 'dropdown',
					'label' => __( 'Button Size', 'cssjockey-add-ons' ),
					'info' => __( 'Specify size of the button.', 'cssjockey-add-ons' ),
					'default' => 'default',
					'options' => array(
						'default' => __('Default', 'cssjockey-add-ons'),
						'small' => __('Small', 'cssjockey-add-ons'),
						'medium' => __('Medium', 'cssjockey-add-ons'),
						'large' => __('Large', 'cssjockey-add-ons'),
					),
				)
			);

			return $defaults;
		}

		public static function getInstance() {

			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {

			$this->shortcode_tag = str_replace( '_shortcode', '', get_class( $this ) );
			add_shortcode( $this->shortcode_tag, array($this, 'run') );
			$this->helpers = cjaddons_helpers::getInstance();
			$this->textdomain = $this->helpers->itemInfo( 'text_domain' );
			$this->defaults = $this->defaults();
		}

		public function getScreenshotUrl() {
			$name = ucwords(str_replace( array('cjaddons_', '_shortcode'), '', get_class( $this ) ));
			$screen_shot_url = '//placehold.it/800x450/DA461E/ffffff&text=' . ucwords(str_replace('_', ' ', $name));
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.svg';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.png';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.jpg';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}

			return $screen_shot_url;
		}

		public function run( $atts, $content = null ) {
			$defaults = array();
			$shortcode_params = $this->defaults();
			if( is_array( $shortcode_params['options'] ) && ! empty( $shortcode_params['options'] ) ) {
				foreach( $shortcode_params['options'] as $key => $param ) {
					$default_key = str_replace( '-', '_', $param['id'] );
					$default_value = (isset( $param['default'] ) && is_array( $param['default'] )) ? implode( '|', $param['default'] ) : $param['default'];
					$defaults[ $default_key ] = $default_value;
				}
			}
			$instance = shortcode_atts( $defaults, $atts );
			$output = '';
			$content_file_path = dirname( __FILE__ ) . '/content.php';
			if( file_exists( $content_file_path ) ) {
				ob_start();
				require($content_file_path);
				$output .= ob_get_clean();
				$output = apply_filters( 'cjaddons_shortcode_before_output', $output, $shortcode_params );
				$output = apply_filters( 'cjaddons_shortcode_after_output', $output, $shortcode_params );
			} else {
				$output .= '<div class="cj-notification cj-is-info">';
				$output .= sprintf( __( 'Shortcode content file not found.<br>%s', 'cjaddons' ), str_replace( dirname( dirname( __FILE__ ) ), '', $content_file_path ) );
				$output .= '</div>';
			}

			return $output;
		}

	}

	cjaddons_modal_shortcode::getInstance();
}