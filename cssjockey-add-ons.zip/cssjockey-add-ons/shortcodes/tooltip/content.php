<?php
$uid = $this->helpers->uniqueString( 'tooltip-' );
$text = (isset( $instance['text'] ) && $instance['text'] != '') ? $instance['text'] : '';
$position = (isset( $instance['position'] ) && $instance['position'] != '') ? 'cj-is-tooltip-' . $instance['position'] : 'cj-is-tooltip-top';
?>
<span id="<?php echo $uid; ?>" class="cssjockey-ui">
	<span class="cj-tooltip cj-shortcode-tooltip <?php echo $position; ?>" data-tooltip="<?php echo $text ?>">
		<?php echo $content; ?>
	</span>
</span>