<?php
$uid = $this->helpers->uniqueString( 'notification-' );
$style = (isset( $instance['style'] ) && $instance['style'] != '') ? 'cj-is-' . $instance['style'] : 'cj-is-danger';
$close_button = (isset( $instance['close_button'] ) && $instance['close_button'] != '') ? $instance['close_button'] : 'no';
$animation_out_class = (isset( $instance['animation_out_class'] ) && $instance['animation_out_class'] != '') ? $instance['animation_out_class'] : 'fadeOut';
$notification_class = array();
$notification_class[] = $style;
$notification_class[] = ($close_button == 'no') ? 'cj-pr-25' : '';

$show_icon = (isset( $instance['show_icon'] ) && $instance['show_icon'] != '') ? $instance['show_icon'] : 'none';
$notification_class[] = ($show_icon != '' && $show_icon != 'none') ? 'cj-has-icon-left' : '';

?>
<div class="cssjockey-ui">
    <div id="<?php echo $uid ?>" class="cj-notification cj-mb-15 animated <?php echo implode( ' ', $notification_class ); ?>">
		<?php if( $show_icon != '' && $show_icon != 'none' ) { ?>
            <span class="cj-icon"><i class="fa <?php echo $show_icon; ?>"></i></span>
		<?php } ?>
		<?php echo ($close_button == 'yes') ? '<button data-toggle="class" data-target="#' . $uid . '" data-classes="' . $animation_out_class . '" data-delayed-classes="600|cj-hidden" class="cj-delete"></button>' : ''; ?>
		<div class="cj-content"><?php echo do_shortcode( $content ) ?></div>
    </div>
</div>