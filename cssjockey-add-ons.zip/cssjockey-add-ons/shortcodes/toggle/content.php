<?php
$uid = $this->helpers->uniqueString( 'message-' );
$style = (isset( $instance['style'] ) && $instance['style'] != '') ? $instance['style'] : 'primary';
$open_icon = (isset( $instance['open_icon'] ) && $instance['open_icon'] != '') ? $instance['open_icon'] : 'fa-arrow-down';
$close_icon = (isset( $instance['close_icon'] ) && $instance['close_icon'] != '') ? $instance['close_icon'] : 'fa-arrow-up';
$title = (isset( $instance['title'] ) && $instance['title'] != '') ? $instance['title'] : '';
if( $title == '' ) {
	return false;
}

?>
<div id="<?php echo $uid; ?>" class="cssjockey-ui">
    <ul class="cj-toggle cj-has-bg">
        <li class="cj-toggle-item">
            <a href="#" class="cj-bg-<?php echo $style; ?> cj-color-<?php echo $style; ?>-invert">
                <span class="cj-open-icon cj-is-pulled-right cj-button cj-is-link cj-color-<?php echo $style; ?>-invert cj-is-small"><span class="cj-icon cj-is-small"><i class="fa <?php echo $open_icon ?> "></i></span></span>
                <span class="cj-close-icon cj-is-pulled-right cj-button cj-is-link cj-color-<?php echo $style; ?>-invert cj-is-small"><span class="cj-icon cj-is-small"><i class="fa <?php echo $close_icon ?> "></i></span></span>
				<?php echo $title; ?>
            </a>
            <div class="cj-content cj-toggle-content">
				<?php echo $content; ?>
            </div>
        </li>
    </ul>
</div>


