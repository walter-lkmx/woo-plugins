<?php
$uid = $this->helpers->uniqueString( 'before-after-' );
$before_image = (isset( $instance['before_image'] ) && $instance['before_image'] != '') ? $instance['before_image'] : '';
$after_image = (isset( $instance['after_image'] ) && $instance['after_image'] != '') ? $instance['after_image'] : '';

if( $before_image == '' || $after_image == '' ) {
	return false;
}

?>
<div id="<?php echo $uid; ?>" class="cssjockey-ui">
    <div class="cj-before-after cj-mb-15">
        <img src="<?php echo $before_image; ?>" class="base"/>
        <div class="before"><img src="<?php echo $before_image; ?>"/></div>
        <div class="after"><img src="<?php echo $after_image; ?>"/></div>
    </div>
</div>
