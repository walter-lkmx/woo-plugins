<?php
$uid = $this->helpers->uniqueString( 'image-' );

$img_width = null;

if( $instance['url'] !== '' ) {
	list( $img_width, $img_height ) = @getimagesize( $instance['url'] );
}

if( $instance['url'] == '' || is_null( $img_width ) ) {
	if( current_user_can( 'edit_posts' ) ) {
		echo $this->helpers->alert( 'warning', 'Invalid image url', '', false );
	}

	return false;
}

$url = (isset( $instance['url'] ) && $instance['url'] != '') ? $instance['url'] : '';
$alt = (isset( $instance['alt'] ) && $instance['alt'] != '') ? $instance['alt'] : '';
$caption = (isset( $instance['caption'] ) && $instance['caption'] != '') ? $instance['caption'] : '';
$width = (isset( $instance['width'] ) && $instance['width'] != '') ? $instance['width'] : '';
$height = (isset( $instance['height'] ) && $instance['height'] != '') ? $instance['height'] : '';
$border = (isset( $instance['border'] ) && $instance['border'] != '') ? $instance['border'] : '0';
$icon_size = (isset( $instance['icon_size'] ) && $instance['icon_size'] != '') ? $instance['icon_size'] : 'medium';
$align = (isset( $instance['align'] ) && $instance['align'] != '') ? $instance['align'] : '';
$overlay_color = (isset( $instance['overlay_color'] ) && $instance['overlay_color'] != '') ? $instance['overlay_color'] : '';

$align_class = '';
$align_class = ($align == 'left') ? 'cj-is-pulled-left' : $align_class;
$align_class = ($align == 'right') ? 'cj-is-pulled-right' : $align_class;
$align_class = ($align == 'center') ? 'cj-text-center' : $align_class;

$instance['margin_top'] = str_replace( array('px', '%'), '', $instance['margin_top'] );
$instance['margin_bottom'] = str_replace( array('px', '%'), '', $instance['margin_bottom'] );

$css_style = array();
$css_style[] = 'style="';
$css_style[] = 'max-width: 100%; width: ' . $img_width . 'px;';
$css_style[] = (isset( $instance['margin_top'] ) && $instance['margin_top'] != '') ? 'margin-top:' . $instance['margin_top'] . 'px;' : '';
$css_style[] = (isset( $instance['margin_bottom'] ) && $instance['margin_bottom'] != '') ? 'margin-bottom:' . $instance['margin_bottom'] . 'px;' : '';
$css_style[] = '"';
?>
<div id="<?php echo $uid; ?>" class="cssjockey-ui cj-image-shortcode <?php echo $align_class; ?>">
    <span class="cj-image-wrapper" data-toggle="class" data-target="#image-modal-<?php echo $uid; ?>" data-classes="cj-is-active" <?php echo implode( '', $css_style ) ?>>
        <img src="<?php echo $url ?>" alt="<?php echo $alt; ?>" width="<?php echo $width ?>" height="<?php echo $height ?>"/>
        <div class="cj-overlay cj-overlay-<?php echo $overlay_color; ?> cj-opacity-60"></div>
        <div class="cj-button cj-is-link cj-is-medium cj-v-align">
            <span class="cj-icon cj-is-<?php echo $icon_size; ?>"><i class="fa fa-search-plus cj-color-<?php echo $overlay_color; ?>-invert"></i></span>
        </div>
	    <?php echo ($caption !== '') ? '<div class="cj-image-caption">' . $caption . '</div>' : ''; ?>
    </span>

    <div id="image-modal-<?php echo $uid; ?>" class="cj-modal">
        <div class="cj-modal-background" data-toggle="class" data-target="#image-modal-<?php echo $uid; ?>" data-classes="cj-is-active"></div>
        <div class="cj-modal-content animated fadeIn cj-text-center">
            <img src="<?php echo $url ?>" alt="<?php echo $alt; ?>"/>
        </div>
        <button class="cj-modal-close cj-is-large" aria-label="close" data-toggle="class" data-target="#image-modal-<?php echo $uid; ?>" data-classes="cj-is-active"></button>
    </div>

</div>