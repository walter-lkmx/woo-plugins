<?php
$uid = $this->helpers->uniqueString( 'icon-progress-' );
$icon = (isset( $instance['icon'] ) && $instance['icon'] != '') ? $instance['icon'] : '';
$size = (isset( $instance['size'] ) && $instance['size'] != '') ? $instance['size'] : 'small';
$style = (isset( $instance['style'] ) && $instance['style'] != '') ? $instance['style'] : '';
$total_count = (isset( $instance['total_count'] ) && $instance['total_count'] != '') ? $instance['total_count'] : '';
$active_count = (isset( $instance['active_count'] ) && $instance['active_count'] != '') ? $instance['active_count'] : '';
if( $icon == '' ) {
	return false;
}
?>
<div id="<?php echo $uid; ?>" class="cssjockey-ui cj-icon-progress-shortcode">
	<?php for( $i = 1; $i <= $total_count; $i ++ ) {
		$inactive_class = 'cj-color-' . $style;
		if( $i > $active_count ) {
			$inactive_class = 'cj-color-dark cj-opacity-30';
		}
		?>
        <span class="cj-icon cj-mb-15 cj-is-<?php echo $size . ' ' . $inactive_class; ?>"><i class="fa <?php echo $icon; ?>"></i></span>
	<?php } ?>
</div>