<?php
$uid = $this->helpers->uniqueString( 'drop-cap-' );

$color = (isset( $instance['color'] ) && $instance['color'] != '') ? 'cj-dropcap-color-'.$instance['color'] : 'cj-dropcap-color-primary';
$background = (isset( $instance['background'] ) && $instance['background'] != '') ? 'cj-dropcap-bg-'.$instance['background'] : '';
$class = $color;
if($background != ''){
	$class = $background;
}
?>
<span class="cssjockey-ui">
	<span class="cj-dropcap <?php echo $class; ?>">
		<?php echo $content; ?>
	</span>
</span>