<?php
$uid = $this->helpers->uniqueString( 'code-block-' );
$content = shortcode_unautop($content);
$display = '';
$display .= '<span class="cssjockey-ui cjaddons-shortcode-ui-block">';
if( strpos( $content, "\n" ) ) {
	$display .= '<pre id="'.$uid.'">'.$content.'</pre>';
}else{
	$display .= '<code id="'.$uid.'">'.$content.'</code>';
}
$display .= '</span>';
$display = str_replace("\n", '', $display);
echo $display;
