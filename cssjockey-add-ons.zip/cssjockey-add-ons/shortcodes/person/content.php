<?php
$uid = $this->helpers->uniqueString( 'person-' );
$social_profiles = array();
if( isset( $instance['social_profiles'] ) && $instance['social_profiles'] != '' ) {
	$social_profiles = explode( '|', $instance['social_profiles'] );
}
$name = (isset( $instance['name'] ) && $instance['name'] != '') ? $instance['name'] : 'John Doe';
?>
<div id="<?php echo $uid; ?>" class="cssjockey-ui">
    <div class="cj-mb-15">
        <img src="<?php echo $instance['image_url'] ?>" alt="<?php echo $name ?>" width="100%"/>
        <div class="cj-content cj-mt-15 cj-mb-15">

			<?php if( ! empty( $social_profiles ) ) { ?>
                <div class="cj-is-pulled-right">
					<?php foreach( $social_profiles as $key => $profile ) {
						$profile_data = explode( '=', $profile );
						$tooltip_text = ucwords( str_replace( 'fa-', '', $profile_data[0] ) );
						$icon = str_replace( 'fa-', 'pe-so-', $profile_data[0] );
						?>
                        <a href="<?php echo $profile_data[1]; ?>" class="cj-color-dark cj-icon cj-tooltip" data-tooltip="<?php echo $tooltip_text; ?>"><i class="cj-fs-18 <?php echo $icon; ?> pe-hover"></i></a>
					<?php } ?>
                </div>
			<?php } ?>

            <h4 class="cj-title cj-m-0">
				<?php echo $name; ?>
            </h4>
			<?php if( $instance['designation'] != '' ) { ?>
                <p class="cj-heading cj-opacity-50"><?php echo $instance['designation']; ?></p>
			<?php } ?>
			<?php if( $content != '' ) { ?>
                <div class="cj-fs-14 cj-opacity-70"><?php echo wpautop( $content ); ?></div>
			<?php } ?>
        </div>
    </div>
</div>