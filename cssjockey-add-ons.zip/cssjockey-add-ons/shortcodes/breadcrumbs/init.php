<?php
/*
 * Class name should be cjaddons_NAME_shortcode
 * Shortcode Tag will be cjaddons_NAME
 * */
if( ! class_exists( 'cjaddons_breadcrumbs_shortcode' ) ) {
	class cjaddons_breadcrumbs_shortcode {

		public $defaults, $helpers, $render_forms, $textdomain, $shortcode_tag;

		private static $instance;

		public function defaults() {
			$defaults['info'] = array(
				'single' => true,
				'tag' => $this->shortcode_tag,
				'name' => esc_attr__( 'Breadcrumbs', $this->textdomain ),
				'description' => esc_attr__( 'Renders breadcrumbs with various options and styles.', $this->textdomain ),
				'screenshot' => $this->getScreenshotUrl(),
				'default_content' => '',
				'group' => 'cjaddons',
				'textdomain' => 'cjaddons',
				'item_name' => $this->helpers->itemInfo( 'item_name' ),
				'preview' => true,
			);
			$defaults['options'] = array(
				array(
					'id' => 'separator',
					'type' => 'text',
					'label' => __( 'Separator', 'cssjockey-add-ons' ),
					'info' => __( 'Specify separator text or symbol here.', 'cssjockey-add-ons' ),
					'default' => '&nbsp;&raquo;&nbsp;',
					'options' => '',
				),
				array(
					'id' => 'style',
					'type' => 'dropdown',
					'label' => __( 'Choose Style', 'cssjockey-add-ons' ),
					'info' => __( 'You can change UI Colors under UI Style Variables page.', 'cssjockey-add-ons' ),
					'default' => '',
					'options' => $this->helpers->arrays( 'brand-colors' ),
				),
				array(
					'id' => 'rounded',
					'type' => 'dropdown',
					'label' => __( 'Rounded Corners?', 'cssjockey-add-ons' ),
					'info' => __( 'Specify if corners should be rounded or not.<br>Only works if brand style is selected.', 'cssjockey-add-ons' ),
					'default' => 'no',
					'options' => $this->helpers->arrays( 'yes-no' ),
				),
				array(
					'id' => 'outlined',
					'type' => 'dropdown',
					'label' => __( 'Outlined?', 'cssjockey-add-ons' ),
					'info' => __( 'Specify if style should be outlined or not.<br>Only works if brand style is selected.', 'cssjockey-add-ons' ),
					'default' => 'no',
					'options' => $this->helpers->arrays( 'yes-no' ),
				),
			);

			return $defaults;
		}

		public static function getInstance() {

			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {

			$this->shortcode_tag = str_replace( '_shortcode', '', get_class( $this ) );
			add_shortcode( $this->shortcode_tag, array($this, 'run') );
			$this->helpers = cjaddons_helpers::getInstance();
			$this->textdomain = $this->helpers->itemInfo( 'text_domain' );
			$this->defaults = $this->defaults();
		}

		public function getScreenshotUrl() {
			$name = ucwords(str_replace( array('cjaddons_', '_shortcode'), '', get_class( $this ) ));
			$screen_shot_url = '//placehold.it/800x450/DA461E/ffffff&text=' . ucwords(str_replace('_', ' ', $name));
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.svg';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.png';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.jpg';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}

			return $screen_shot_url;
		}

		public function run( $atts, $content = null ) {
			$defaults = array();
			$shortcode_params = $this->defaults();
			if( is_array( $shortcode_params['options'] ) && ! empty( $shortcode_params['options'] ) ) {
				foreach( $shortcode_params['options'] as $key => $param ) {
					$default_key = str_replace( '-', '_', $param['id'] );
					$default_value = (isset( $param['default'] ) && is_array( $param['default'] )) ? implode( '|', $param['default'] ) : $param['default'];
					$defaults[ $default_key ] = $default_value;
				}
			}
			$instance = shortcode_atts( $defaults, $atts );
			$output = '';
			$content_file_path = dirname( __FILE__ ) . '/content.php';
			if( file_exists( $content_file_path ) ) {
				ob_start();
				require($content_file_path);
				$output .= ob_get_clean();
				$output = apply_filters( 'cjaddons_shortcode_before_output', $output, $shortcode_params );
				$output = apply_filters( 'cjaddons_shortcode_after_output', $output, $shortcode_params );
			} else {
				$output .= '<div class="cj-notification cj-is-info">';
				$output .= sprintf( __( 'Shortcode content file not found.<br>%s', 'cjaddons' ), str_replace( dirname( dirname( __FILE__ ) ), '', $content_file_path ) );
				$output .= '</div>';
			}

			return $output;
		}

	}

	cjaddons_breadcrumbs_shortcode::getInstance();
}