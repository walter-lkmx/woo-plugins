<?php
$uid = $this->helpers->uniqueString( 'breadcrumbs-' );
$separator = (isset( $instance['separator'] ) && $instance['separator'] != '') ? $instance['separator'] : '&nbsp;&raquo;&nbsp;';
$style = (isset( $instance['style'] ) && $instance['style'] != '') ? 'cj-is-' . $instance['style'] : '';
$rounded = (isset( $instance['style'] ) && $instance['style'] != '' && isset( $instance['rounded'] ) && $instance['rounded'] == 'yes') ? ' cj-is-rounded' : '';
$outlined = (isset( $instance['style'] ) && $instance['style'] != '' && isset( $instance['outlined'] ) && $instance['outlined'] == 'yes') ? ' cj-is-outlined' : '';
?>
<div class="cssjockey-ui">
    <div id="<?php echo $uid; ?>" class="cj-breadcrumbs <?php echo $style . $rounded . $outlined; ?>">
		<?php echo $this->helpers->breadcrumbs( $separator ); ?>
    </div>
</div>