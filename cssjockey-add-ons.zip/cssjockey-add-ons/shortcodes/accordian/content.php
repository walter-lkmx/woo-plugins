<?php
$uid = $this->helpers->uniqueString( 'accordion-' );
$shortcode_params = array();
if( isset( $instance['open_icon'] ) && $instance['open_icon'] != '' ) {
	$shortcode_params[] = sprintf( 'open_icon="%s"', $instance['open_icon'] );
}
if( isset( $instance['close_icon'] ) && $instance['close_icon'] != '' ) {
	$shortcode_params[] = sprintf( 'close_icon="%s"', $instance['close_icon'] );
}
if( isset( $instance['background'] ) && $instance['background'] != '' ) {
	$shortcode_params[] = sprintf( 'background="%s"', $instance['background'] );
}
$shortcode_params = implode( ' ', $shortcode_params );
$content = str_replace( '[cjaddons_accordion_item', '[cjaddons_accordion_item ' . $shortcode_params, $content );

$background_class = (isset( $instance['background'] ) && $instance['background'] != '') ? 'cj-has-bg' : '';

?>
<div id="<?php echo $uid; ?>" class="cssjockey-ui">
    <ul class="cj-accordion <?php echo $background_class; ?>">
		<?php echo do_shortcode( $content ); ?>
    </ul>
</div>
