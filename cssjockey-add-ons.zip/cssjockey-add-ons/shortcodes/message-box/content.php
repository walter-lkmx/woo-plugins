<?php
$uid = $this->helpers->uniqueString( 'message-box-' );
$color = (isset($instance['style']) && $instance['style'] != '') ? 'cj-is-'.$instance['style'] : 'cj-is-primary';
$size = (isset($instance['size']) && $instance['size'] != '') ? 'cj-is-'.$instance['size'] : 'cj-is-default';
?>
<div id="<?php echo $uid; ?>" class="cssjockey-ui">
    <div class="cj-message <?php echo $color.' '.$size; ?> cj-mb-15">
	    <?php if(isset($instance['heading']) && $instance['heading'] != ''){ ?>
            <div class="cj-message-header">
                <p class="cj-mb-0"><?php echo $instance['heading']; ?></p>
            </div>
	    <?php } ?>
        <div class="cj-message-body">
	        <?php echo do_shortcode( $content ); ?>
        </div>
    </div>
</div>