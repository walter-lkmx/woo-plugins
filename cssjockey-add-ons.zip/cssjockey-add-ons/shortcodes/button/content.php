<?php

$uid = $this->helpers->uniqueString( 'button-' );
$button_text = (isset( $instance['text'] ) && $instance['text'] != '') ? $instance['text'] : 'Button';
$button_link = (isset( $instance['link'] ) && $instance['link'] != '') ? 'cj-is-' . $instance['link'] : '#';
$button_target = (isset( $instance['target'] ) && $instance['target'] != '') ? 'cj-is-' . $instance['target'] : '_self';

$style = (isset( $instance['style'] ) && $instance['style'] != '') ? 'cj-is-' . $instance['style'] : 'cj-is-primary';
$size = (isset( $instance['size'] ) && $instance['size'] != '') ? 'cj-is-' . $instance['size'] : '';
$outlined = (isset( $instance['outlined'] ) && $instance['outlined'] == 'yes') ? 'cj-is-outlined' : '';
$rounded = (isset( $instance['rounded'] ) && $instance['rounded'] == 'yes') ? 'cj-is-rounded' : '';

$button_class = array();
$button_class[] = $style;
$button_class[] = $size;
$button_class[] = $outlined;
$button_class[] = $rounded;

$icon_size = ($size == 'cj-is-default' || $size == '') ? 'cj-is-small' : 'cj-is-' . $size;
$icon_left = (isset( $instance['icon_left'] ) && $instance['icon_left'] != '') ? 'cj-is-' . $instance['icon_left'] : '';
$icon_right = (isset( $instance['icon_right'] ) && $instance['icon_right'] != '') ? 'cj-is-' . $instance['icon_right'] : '';

?>
<span class="cssjockey-ui">
    <a id="<?php echo $uid; ?>" href="<?php echo $button_link; ?>" target="<?php echo $button_target; ?>" class="cj-button cj-mb-15 <?php echo implode( ' ', $button_class ); ?>">
        <?php echo ($icon_left != '') ? '<span class="cj-icon ' . $icon_size . ' cj-mr-3"><i class="fa ' . $icon_left . '"></i></span>' : ''; ?>
        <span><?php echo $button_text; ?></span>
	    <?php echo ($icon_right != '') ? '<span class="cj-icon ' . $icon_size . ' cj-ml-3"><i class="fa ' . $icon_right . '"></i></span>' : ''; ?>
    </a>
</span>