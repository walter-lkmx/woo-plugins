<?php
$uid = $this->helpers->uniqueString( 'pullquote-' );
$class = array();
$class[] = (isset($instance['position']) && $instance['position'] != '') ? 'cj-is-pulled-'.$instance['position'] : 'cj-is-pulled-right';
$class[] = (isset($instance['style']) && $instance['style'] != '') ? 'cj-is-'.$instance['style'] : 'cj-is-light';
?>
<div id="<?php echo $uid; ?>" class="cssjockey-ui">
    <div class="cj-pullquote <?php echo implode(' ', $class); ?>">
        <span class="cj-pullquote-icon"><i class="fa fa-quote-left"></i></span>
	    <span class="cj-content"><?php echo $content; ?></span>
    </div>
</div>