<?php
/*
 * Class name should be cjaddons_NAME_shortcode
 * Shortcode Tag will be cjaddons_NAME
 * */
if( ! class_exists( 'cjaddons_loop_grid_shortcode' ) ) {
	class cjaddons_loop_grid_shortcode {

		public $defaults, $helpers, $render_forms, $textdomain, $shortcode_tag;

		private static $instance;

		public function defaults() {
			$defaults['info'] = array(
				'single' => true,
				'tag' => $this->shortcode_tag,
				'name' => esc_attr__( 'Posts Loop Grid', $this->textdomain ),
				'description' => esc_attr__( 'Display posts grid with various options and styles.', $this->textdomain ),
				'screenshot' => $this->getScreenshotUrl(),
				'default_content' => '',
				//'default_content_type' => 'hidden',
				'group' => 'cjaddons',
				'textdomain' => 'cjaddons',
				'item_name' => $this->helpers->itemInfo( 'item_name' ),
				'preview' => true,
			);

			$themes_array = array(
				'default' => __( 'Default', 'lang-cjaddons' ),
				'box' => __( 'Boxed', 'lang-cjaddons' ),
				'overlap-bottom' => __( 'Bottom Overlap', 'lang-cjaddons' ),
				'overlay-bottom' => __( 'Overlay Bottom', 'lang-cjaddons' ),
				'overlay-top' => __( 'Overlay Top', 'lang-cjaddons' ),
				'overlay-center' => __( 'Overlay Center', 'lang-cjaddons' ),
				'mini' => __( 'Mini', 'lang-cjaddons' ),
				'mini-rounded' => __( 'Mini Rounded', 'lang-cjaddons' ),
				'mini-no-image' => __( 'Mini without images', 'lang-cjaddons' ),
			);

			$post_types_array = get_post_types();
			unset( $post_types_array['cj-ui-blocks'] );
			unset( $post_types_array['cjaddons-templates'] );
			unset( $post_types_array['cjaddons-sidebars'] );
			unset( $post_types_array['cjaddons-post-types'] );
			unset( $post_types_array['cjaddons-taxonomies'] );
			$number_of_posts = get_option( 'posts_per_page' );
			$columns_array = array(
				'1' => __( 'Single Column', 'lang-cjaddons' ),
				'2' => __( 'Two Columns', 'lang-cjaddons' ),
				'3' => __( 'Three Columns', 'lang-cjaddons' ),
				'4' => __( 'Four Columns', 'lang-cjaddons' ),
			);
			$meta_string_variables = '<p><code>%%author%%</code> : will render post author name linked to author archive page.<br>';
			$meta_string_variables .= '<code>%%date%%</code> : will render post date with format specified on general settings page.<br>';
			$meta_string_variables .= '<code>%%time%%</code> : will render post time with format specified on general settings page.<br>';
			$meta_string_variables .= '<code>%%terms%%</code> : will render post taxonomy names separated by comma linked to archive pages.<br>';
			$meta_string_variables .= '<code>%%comments%%</code> : will render post comments number linked to single post page comments section.</p>';
			$defaults['options'] = array(
				array(
					'id' => 'column',
					'type' => 'dropdown',
					'label' => __( 'Columns', 'lang-cjaddons' ),
					'info' => __( 'Specify number of columns for this grid.', 'lang-cjaddons' ),
					'default' => 3,
					'options' => $columns_array,
				),
				array(
					'id' => 'theme',
					'type' => 'dropdown',
					'label' => __( 'Layout', 'lang-cjaddons' ),
					'info' => __( 'Specify layout style.', 'lang-cjaddons' ),
					'default' => 'default',
					'options' => $themes_array,
				),
				array(
					'id' => 'post_type',
					'type' => 'post-type',
					'label' => __( 'Post Type', 'lang-cjaddons' ),
					'info' => __( 'Specify post type for this loop. Default is "post".', 'lang-cjaddons' ),
					'default' => 'post',
					'options' => $post_types_array,
				),
				array(
					'id' => 'posts_per_page',
					'type' => 'number',
					'label' => __( 'Posts per page', 'lang-cjaddons' ),
					'info' => __( 'Specify number of posts to display.', 'lang-cjaddons' ),
					'default' => $number_of_posts,
					'options' => $post_types_array,
				),
				array(
					'id' => 'meta_string',
					'type' => 'text',
					'label' => __( 'Post meta string', 'lang-cjaddons' ),
					'info' => sprintf( __( '<p>Specify post meta string with following variables.</p>%s', 'lang-cjaddons' ), $meta_string_variables ),
					'default' => '%%date%% &nbsp;//&nbsp; %%terms%%',
					'params' => array(
						'placeholder' => '%%author%% on %%date%% %%time%% in %%terms%% | %%comments%%'
					),
					'options' => '',
				)
			);

			return $defaults;
		}

		public static function getInstance() {

			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {

			$this->shortcode_tag = str_replace( '_shortcode', '', get_class( $this ) );
			add_shortcode( $this->shortcode_tag, array($this, 'run') );
			$this->helpers = cjaddons_helpers::getInstance();
			$this->textdomain = $this->helpers->itemInfo( 'text_domain' );
			$this->defaults = $this->defaults();
		}

		public function getScreenshotUrl() {
			$name = ucwords( str_replace( array('cjaddons_', '_shortcode'), '', get_class( $this ) ) );
			$screen_shot_url = '//placehold.it/800x450/DA461E/ffffff&text=' . ucwords( str_replace( '_', ' ', $name ) );
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.svg';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.png';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.jpg';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}

			return $screen_shot_url;
		}

		public function run( $atts, $content = null ) {
			$defaults = array();
			$shortcode_params = $this->defaults();
			if( is_array( $shortcode_params['options'] ) && ! empty( $shortcode_params['options'] ) ) {
				foreach( $shortcode_params['options'] as $key => $param ) {
					$default_key = str_replace( '-', '_', $param['id'] );
					$default_value = (isset( $param['default'] ) && is_array( $param['default'] )) ? implode( '|', $param['default'] ) : $param['default'];
					$defaults[ $default_key ] = $default_value;
				}
			}
			$instance = shortcode_atts( $defaults, $atts );
			add_filter( 'excerpt_more', function ( $more ) {
				return '';
			} );
			add_filter( 'the_excerpt', function ( $excerpt ) {
				return $this->helpers->trimChars( $excerpt, 160, '..' );
			} );
			$output = '';
			$content_file_path = dirname( __FILE__ ) . '/content.php';
			if( file_exists( $content_file_path ) ) {
				ob_start();
				require($content_file_path);
				$output .= ob_get_clean();
				$output = apply_filters( 'cjaddons_shortcode_before_output', $output, $shortcode_params );
				$output = apply_filters( 'cjaddons_shortcode_after_output', $output, $shortcode_params );
			} else {
				$output .= '<div class="cj-notification cj-is-info">';
				$output .= sprintf( __( 'Shortcode content file not found.<br>%s', 'cjaddons' ), str_replace( dirname( dirname( __FILE__ ) ), '', $content_file_path ) );
				$output .= '</div>';
			}

			return $output;
		}

	}

	cjaddons_loop_grid_shortcode::getInstance();
}