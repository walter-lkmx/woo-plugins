<?php $post_type_info = get_post_type_object('post'); ?>
<div class="cj-content">
    <h3 class="cj-title cj-m-0 cj-mb-10"><?php _e('Nothing found!', 'lang-cjaddons') ?></h3>
    <p><?php echo sprintf(__('No <span class="cj-text-lower">%s</span> found based on your query.', 'lang-cjaddons'), $post_type_info->labels->name) ?></p>
</div>