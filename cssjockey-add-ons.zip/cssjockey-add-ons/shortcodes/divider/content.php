<?php
$uid = $this->helpers->uniqueString( 'code-block-' );
$style = (isset( $instance['style'] ) && $instance['style'] != '') ? 'cj-divider-' . $instance['style'] : 'cj-divider-default';
$divider_color = (isset( $instance['divider_color'] ) && $instance['divider_color'] != '') ? ' cj-divider-' . $instance['divider_color'] : '';
$icon = (isset( $instance['icon'] ) && $instance['icon'] != '') ? $instance['icon'] : '';
$icon_color_class = (isset( $instance['icon_color'] ) && $instance['icon_color'] != '') ? 'cj-bg-'.$instance['icon_color'].' cj-color-'.$instance['icon_color'].'-invert' : 'cj-bg-primary cj-color-primary-invert';
$icon_position = (isset( $instance['icon_position'] ) && $instance['icon_position'] != '') ? 'cj-icon-is-'.$instance['icon_position'] : '';
$icon_style = (isset( $instance['icon_style'] ) && $instance['icon_style'] != '') ? 'cj-is-'.$instance['icon_style'] : 'cj-is-circle';
?>
<span class="cssjockey-ui">
	<div class="cj-divider <?php echo $style.$divider_color; ?>">
        <?php if( isset( $instance['icon'] ) && $instance['icon'] != '' ) { ?>
            <span class="cj-icon cj-is-small <?php echo $icon_color_class.' '.$icon_position.' '.$icon_style; ?>"><i class="fa <?php echo $icon ?>"></i></span>
        <?php } ?>
    </div>
</span>