<?php
/*
 * Class name should be cjaddons_NAME_shortcode
 * Shortcode Tag will be cjaddons_NAME
 * */
if( ! class_exists( 'cjaddons_divider_shortcode' ) ) {
	class cjaddons_divider_shortcode {

		public $defaults, $helpers, $render_forms, $textdomain, $shortcode_tag;

		private static $instance;

		public function defaults() {
			$defaults['info'] = array(
				'single' => true,
				'tag' => $this->shortcode_tag,
				'name' => esc_attr__( 'Divider', $this->textdomain ),
				'description' => esc_attr__( 'Renders divider with different styles.', $this->textdomain ),
				'screenshot' => $this->getScreenshotUrl(),
				'default_content' => '',
				// 'default_content_type' => 'hidden',
				'group' => 'cjaddons',
				'textdomain' => 'cjaddons',
				'item_name' => $this->helpers->itemInfo( 'item_name' ),
				'preview' => true,
			);
			$defaults['options'] = array(
				array(
					'id' => 'style',
					'type' => 'dropdown',
					'label' => __( 'Style', 'cssjockey-add-ons' ),
					'info' => __( 'Specify style for this divider.', 'cssjockey-add-ons' ),
					'default' => 'default',
					'options' => array(
						'default' => __( 'Default', 'cssjockey-add-ons' ),
						'double' => __( 'Double', 'cssjockey-add-ons' ),
						'single-dotted' => __( 'Single Dotted', 'cssjockey-add-ons' ),
						'single-dashed' => __( 'Single Dashed', 'cssjockey-add-ons' ),
						'double-dotted' => __( 'Double Dotted', 'cssjockey-add-ons' ),
						'double-dashed' => __( 'Double Dashed', 'cssjockey-add-ons' ),
					),
				),
				array(
					'id' => 'divider_color',
					'type' => 'dropdown',
					'label' => __( 'Divider color', 'cssjockey-add-ons' ),
					'info' => __( 'Specify divider color.', 'cssjockey-add-ons' ),
					'default' => '',
					'options' => $this->helpers->arrays( 'brand-colors' ),
				),
				array(
					'id' => 'icon',
					'type' => 'dropdown',
					'label' => __( 'Icon', 'cssjockey-add-ons' ),
					'info' => __( 'Specify an icon for this divider.', 'cssjockey-add-ons' ),
					'default' => '',
					'options' => $this->helpers->fontAwesomeIconsArray(),
				),
				array(
					'id' => 'icon_color',
					'type' => 'dropdown',
					'label' => __( 'Icon color', 'cssjockey-add-ons' ),
					'info' => __( 'Specify icon color for this divider.', 'cssjockey-add-ons' ),
					'default' => 'primary',
					'options' => $this->helpers->arrays( 'brand-colors' ),
				),
				array(
					'id' => 'icon_position',
					'type' => 'dropdown',
					'label' => __( 'Icon position', 'cssjockey-add-ons' ),
					'info' => __( 'Specify icon position for this divider.', 'cssjockey-add-ons' ),
					'default' => 'center',
					'options' => array(
						'center' => __( 'Center', 'cssjockey-add-ons' ),
						'left' => __( 'Left', 'cssjockey-add-ons' ),
						'right' => __( 'Right', 'cssjockey-add-ons' ),
					),
				),
				array(
					'id' => 'icon_style',
					'type' => 'dropdown',
					'label' => __( 'Icon style', 'cssjockey-add-ons' ),
					'info' => __( 'Specify icon style for this divider.', 'cssjockey-add-ons' ),
					'default' => 'circle',
					'options' => array(
						'circle' => __( 'Circle', 'cssjockey-add-ons' ),
						'square' => __( 'Square', 'cssjockey-add-ons' ),
						'rounded' => __( 'Rounded Corners', 'cssjockey-add-ons' ),
					),
				)
			);

			return $defaults;
		}

		public static function getInstance() {

			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {

			$this->shortcode_tag = str_replace( '_shortcode', '', get_class( $this ) );
			add_shortcode( $this->shortcode_tag, array($this, 'run') );
			$this->helpers = cjaddons_helpers::getInstance();
			$this->textdomain = $this->helpers->itemInfo( 'text_domain' );
			$this->defaults = $this->defaults();
		}

		public function getScreenshotUrl() {
			$name = ucwords( str_replace( array('cjaddons_', '_shortcode'), '', get_class( $this ) ) );
			$screen_shot_url = '//placehold.it/800x450/DA461E/ffffff&text=' . ucwords( str_replace( '_', ' ', $name ) );
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.svg';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.png';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.jpg';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}

			return $screen_shot_url;
		}

		public function run( $atts, $content = null ) {
			$defaults = array();
			$shortcode_params = $this->defaults();
			if( is_array( $shortcode_params['options'] ) && ! empty( $shortcode_params['options'] ) ) {
				foreach( $shortcode_params['options'] as $key => $param ) {
					$default_key = str_replace( '-', '_', $param['id'] );
					$default_value = (isset( $param['default'] ) && is_array( $param['default'] )) ? implode( '|', $param['default'] ) : $param['default'];
					$defaults[ $default_key ] = $default_value;
				}
			}
			$instance = shortcode_atts( $defaults, $atts );
			$output = '';
			$content_file_path = dirname( __FILE__ ) . '/content.php';
			if( file_exists( $content_file_path ) ) {
				ob_start();
				require($content_file_path);
				$output .= ob_get_clean();
				$output = apply_filters( 'cjaddons_shortcode_before_output', $output, $shortcode_params );
				$output = apply_filters( 'cjaddons_shortcode_after_output', $output, $shortcode_params );
			} else {
				$output .= '<div class="cj-notification cj-is-info">';
				$output .= sprintf( __( 'Shortcode content file not found.<br>%s', 'cjaddons' ), str_replace( dirname( dirname( __FILE__ ) ), '', $content_file_path ) );
				$output .= '</div>';
			}

			return $output;
		}

	}

	cjaddons_divider_shortcode::getInstance();
}