<?php
$uid = $this->helpers->uniqueString( 'tooltip-' );
?>
<div id="<?php echo $uid; ?>" class="cssjockey-ui">
    <div class="cj-box cj-mb-15"><?php echo do_shortcode( $content ); ?></div>
</div>