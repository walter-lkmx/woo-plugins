<article id="post-<?php echo $post_info['ID'] ?>" <?php post_class( 'cj-loop cj-relative ' . $theme_class ) ?>>
    <a href="<?php echo $post_info['permalink'] ?>" title="<?php echo $post_info['post_title']; ?>" class="cj-post-thumbnail" style="background-image: url('<?php echo $featured_image_url; ?>')"></a>
    <div class="cj-post-content cj-content">
        <h2 class="cj-post-title cj-text-bold cj-text-upper cj-mb-10">
            <a href="<?php echo $post_info['permalink'] ?>" title="<?php echo sprintf( __( 'Continue reading: %s', 'lang-cjaddons' ), $post_info['post_title'] ) ?>" rel="bookmark">
				<?php echo $post_info['post_title']; ?>
            </a>
        </h2>
        <div class="cj-meta">
	        <?php echo $this->helpers->parseMetaString($meta_string, $post_info); ?>
        </div>
        <div class="cj-content cj-excerpt">
			<?php the_excerpt() ?>
        </div>
        <p class="cj-read-more">
            <a href="<?php echo $post_info['permalink'] ?>" title="<?php echo sprintf( __( 'Continue reading: %s', 'lang-cjaddons' ), $post_info['post_title'] ) ?>" rel="nofollow">
				<?php _e( 'Read more <span class="cj-icon cj-is-small"><i class="fa fa-caret-right"></i></span>', 'lang-cjaddons' ) ?>
            </a>
        </p>
    </div>
</article>
