<?php
$uid = $this->helpers->uniqueString( 'loop-' );

$post_type = (isset( $instance['post_type'] ) && $instance['post_type'] != '') ? $instance['post_type'] : 'post';
$posts_per_page = (isset( $instance['posts_per_page'] ) && $instance['posts_per_page'] != '') ? $instance['posts_per_page'] : get_option( 'posts_per_page' );
$theme = (isset( $instance['theme'] ) && $instance['theme'] != '') ? $instance['theme'] : 'default';
//$column = (isset( $instance['column'] ) && $instance['column'] != '') ? $instance['column'] : 4;
$column = 1;

$theme_class = 'cj-loop-' . $theme;
$meta_string = (isset( $instance['meta_string'] ) && $instance['meta_string'] != '') ? $instance['meta_string'] : '%%author%% on %%date%% %%time%% in %%terms%% | %%comments%%';

$columns = array(
	'1' => 'cj-column cj-is-12-widescreen cj-is-12-desktop cj-is-12-tablet cj-is-12-mobile',
	'2' => 'cj-column cj-is-6-widescreen cj-is-6-desktop cj-is-12-tablet cj-is-12-mobile',
	'3' => 'cj-column cj-is-4-widescreen cj-is-4-desktop cj-is-12-tablet cj-is-12-mobile',
	'4' => 'cj-column cj-is-3-widescreen cj-is-3-desktop cj-is-12-tablet cj-is-12-mobile',
);

$query_args = array(
	'post_type' => $post_type,
	'posts_per_page' => $posts_per_page,
);

?>
<div id="<?php echo $uid; ?>" class="cssjockey-ui">
	<?php
	$the_query = new WP_Query( $query_args );
	if( $the_query->have_posts() ) {
		?>
        <div class="cj-columns cj-is-multiline cj-is-mobile cj-posts-loop-list">
			<?php
			while( $the_query->have_posts() ) {
				$the_query->the_post();
				global $post;
				$post_info = $this->helpers->postInfo( $post->ID );
				$file_name = sprintf( '%s/html/loop-%s.php', dirname( __FILE__ ), $theme );
				if( file_exists( $file_name ) ) {
					// featured images
					$featured_image_url = $post_info['featured_image_url'];
					echo '<div class="' . $columns[ $column ] . '">';
					include $file_name;
					echo '</div>';
				}
			}
			wp_reset_postdata();
			?>
        </div>
		<?php
	} else {
		require 'html/content-none.php';
	}
	?>
</div>