<?php
$uid = $this->helpers->uniqueString( 'highlight-' );
$style = (isset( $instance['style'] ) && $instance['style'] != '') ? 'cj-bg-' . $instance['style'].' cj-color-' . $instance['style'].'-invert' : 'cj-bg-primary cj-color-primary-invert';
$style .= ' cj-pt-0 cj-pb-0 cj-pl-6 cj-pr-6 cj-inline-block';
?>
<span id="<?php echo $uid; ?>" class="cssjockey-ui"><span class="<?php echo $style; ?>"><?php echo $content; ?></span></span>