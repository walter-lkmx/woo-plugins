<?php
$uid = $this->helpers->uniqueString( 'accordion-' );
$background_class = '';
if( $instance['background'] != '' ) {
	$background_class = 'cj-bg-'.$instance['background'].' cj-color-'.$instance['background'].'-invert';
}
$open_icon = '<span class="cj-open-icon cj-is-pulled-right cj-button cj-is-link cj-color-'.$instance['background'].'-invert cj-is-small"><span class="cj-icon cj-is-small"><i class="fa ' . $instance['open_icon'] . '"></i></span></span>';
$close_icon = '<span class="cj-close-icon cj-is-pulled-right cj-button cj-is-link cj-color-'.$instance['background'].'-invert cj-is-small"><span class="cj-icon cj-is-small"><i class="fa ' . $instance['close_icon'] . '"></i></span></span>';
$output = sprintf( '<li class="cj-accordion-item"><a href="#" class="%s">%s %s %s</a><div class="cj-content cj-accordion-content">%s</div></li>', $background_class, $open_icon, $close_icon, $instance['title'], do_shortcode( shortcode_unautop( wpautop( $content ) ) ) );

echo $output;