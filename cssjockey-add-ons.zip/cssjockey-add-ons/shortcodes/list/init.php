<?php
/*
 * Class name should be cjaddons_NAME_shortcode
 * Shortcode Tag will be cjaddons_NAME
 * */
if( ! class_exists( 'cjaddons_list_shortcode' ) ) {
	class cjaddons_list_shortcode {

		public $defaults, $helpers, $render_forms, $textdomain, $shortcode_tag;

		private static $instance;

		public function defaults() {
			$defaults['info'] = array(
				'single' => false,
				'tag' => $this->shortcode_tag,
				'name' => esc_attr__( 'List', $this->textdomain ),
				'description' => esc_attr__( 'Renders a list with various options.', $this->textdomain ),
				'screenshot' => $this->getScreenshotUrl(),
				'default_content' => '<ul><li>Item goes here</li><li>Item goes here</li><li>Item goes here</li></ul>',
				'group' => 'cjaddons',
				'textdomain' => 'cjaddons',
				'item_name' => $this->helpers->itemInfo( 'item_name' ),
				'preview' => true,
			);
			$defaults['options'] = array(
				array(
					'id' => 'icon',
					'type' => 'dropdown',
					'label' => __( 'Icon', 'cssjockey-add-ons' ),
					'info' => __( 'Specify an icon to display on the left side of the list items.', 'cssjockey-add-ons' ),
					'default' => '',
					'options' => $this->helpers->fontAwesomeIconsArray(),
				),
				array(
					'id' => 'icon_color',
					'type' => 'dropdown',
					'label' => __( 'Icon color', 'cssjockey-add-ons' ),
					'info' => __( 'Specify color for the icons displayed on left side of the list items.', 'cssjockey-add-ons' ),
					'default' => 'success',
					'options' => $this->helpers->arrays('brand-colors'),
				),
			);

			return $defaults;
		}

		public static function getInstance() {

			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {

			$this->shortcode_tag = str_replace( '_shortcode', '', get_class( $this ) );
			add_shortcode( $this->shortcode_tag, array($this, 'run') );
			$this->helpers = cjaddons_helpers::getInstance();
			$this->textdomain = $this->helpers->itemInfo( 'text_domain' );
			$this->defaults = $this->defaults();
		}

		public function getScreenshotUrl() {
			$name = ucwords(str_replace( array('cjaddons_', '_shortcode'), '', get_class( $this ) ));
			$screen_shot_url = '//placehold.it/800x450/DA461E/ffffff&text=' . ucwords(str_replace('_', ' ', $name));
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.svg';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.png';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.jpg';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}

			return $screen_shot_url;
		}

		public function run( $atts, $content = null ) {
			$defaults = array();
			$shortcode_params = $this->defaults();
			if( is_array( $shortcode_params['options'] ) && ! empty( $shortcode_params['options'] ) ) {
				foreach( $shortcode_params['options'] as $key => $param ) {
					$default_key = str_replace( '-', '_', $param['id'] );
					$default_value = (isset( $param['default'] ) && is_array( $param['default'] )) ? implode( '|', $param['default'] ) : $param['default'];
					$defaults[ $default_key ] = $default_value;
				}
			}
			$instance = shortcode_atts( $defaults, $atts );
			$output = '';
			$content_file_path = dirname( __FILE__ ) . '/content.php';
			if( file_exists( $content_file_path ) ) {
				ob_start();
				require($content_file_path);
				$output .= ob_get_clean();
				$output = apply_filters( 'cjaddons_shortcode_before_output', $output, $shortcode_params );
				$output = apply_filters( 'cjaddons_shortcode_after_output', $output, $shortcode_params );
			} else {
				$output .= '<div class="cj-notification cj-is-info">';
				$output .= sprintf( __( 'Shortcode content file not found.<br>%s', 'cjaddons' ), str_replace( dirname( dirname( __FILE__ ) ), '', $content_file_path ) );
				$output .= '</div>';
			}

			return $output;
		}

	}

	cjaddons_list_shortcode::getInstance();
}