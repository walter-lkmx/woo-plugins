<?php
$uid = $this->helpers->uniqueString( 'list-' );
$icon = (isset( $instance['icon'] ) && $instance['icon'] != '') ? $instance['icon'] : 'fa-check';
$icon_color = (isset( $instance['icon_color'] ) && $instance['icon_color'] != '') ? 'cj-color-'.$instance['icon_color'] : 'success';
$icon_text = '';
if( $icon !== '' ) {
	$icon_text = '<span class="cj-icon cj-is-small '.$icon_color.' cj-mr-7"><i class="fa '.$icon.'"></i></span>';
}
?>
<div class="cssjockey-ui">
    <div id="<?php echo $uid; ?>" class="cjaddons-list cj-mb-15">
		<?php echo str_replace( '<li>', '<li>' . $icon_text, $content ); ?>
    </div>
</div>