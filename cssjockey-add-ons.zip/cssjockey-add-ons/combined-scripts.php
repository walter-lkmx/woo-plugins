<?php
$root_dir = explode( 'wp-content', dirname( __FILE__ ) );
require_once $root_dir[0] . '/wp-load.php';
$js_files = get_option( 'cjaddons_combined_scripts' );
if( is_array( $js_files ) && ! empty( $js_files ) ) {
	$js = '';
	$expires = 60 * 60 * 24; // how long to cache in secs..
	header( "Pragma: public" );
	header( "Cache-Control: maxage=" . $expires );
	header( 'Expires: ' . gmdate( 'D, d M Y H:i:s', time() + $expires ) . ' GMT' );
	header( "Content-type: text/javascript; charset=utf-8" );
	foreach( $js_files as $key => $file ) {
		$js .= '/* ' . $file . ' */';
		$js .= file_get_contents( $file );
	}
	echo $js;
}