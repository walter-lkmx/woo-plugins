<?php
/*
Plugin Name: CSSJockey Add-ons
Plugin URI: http://www.cssjockey.com/
Description: Base framework plugin that allows you to install our various free and premium add-ons to enable different functionality for your WordPress website. The main goal of this plugin is to utilize the common resources and reduce the server load and make it easy to use any of our add-ons based on your requirements.
Author: Team CSSJockey
Version: 2.4.5
Author URI: https://cssjockey.com/
Text Domain: cssjockey-add-ons
*/
global $cjaddons;

if( ! defined( 'ABSPATH' ) ) {
	wp_die();
	exit;
}

define( 'cjaddons_version', '2.4.5' );

ob_start();

function cjaddons_init() {
	require_once('framework/init.php');
	$cjaddons = cjaddons_framework::getInstance();
	$cjaddons->init();
}

cjaddons_init();

add_action( 'admin_head', 'cjaddons_live_reload' );
add_action( 'wp_head', 'cjaddons_live_reload' );
function cjaddons_live_reload() {
	$dev_urls = array(
		'addons.dev',
		'cssjockey.dev',
		'cssjockey.net',
	);

	if( in_array( $_SERVER['SERVER_NAME'], $dev_urls ) || strpos( $_SERVER['SERVER_NAME'], '.dev' ) ) {
		$browser_sync_url = 'http://' . $_SERVER['SERVER_NAME'] . ':3000/browser-sync/browser-sync-client.js?v=2.16.0';

		if( is_ssl() ) {
			$browser_sync_url = str_replace( 'http://', 'https://', $browser_sync_url );
		}
		$browser_sync_server = @get_headers( $browser_sync_url );
		if( $browser_sync_server ) {
			echo '<script id="__bs_script__">//<![CDATA[
    		document.write("<script async src=' . $browser_sync_url . '><\/script>");
		//]]></script>';
		}
	}
}