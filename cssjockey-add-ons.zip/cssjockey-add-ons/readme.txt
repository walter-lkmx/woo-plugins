=== CSSJockey Add-ons ===
Contributors: cssjockey
Donate link: https://www.paypal.me/CSSJockey
Tags: admin tweaks, dashboard, add-ons, tools, features, loading panel, google analytics, CSS3 loading panel, frontend login, registration, forms
Requires at least: 4.0
Tested up to: 4.8.3
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

CSSJockey Add-ons enables various features to extend the functionality of your WordPress website with an ever growing collection of add-ons.

== Description ==

https://www.youtube.com/watch?v=gq5hKwUOL-U

CSSJockey Add-ons is a base plugin which allows you to install our various free and premium add-ons to enable different functionality for your WordPress website. The main goal of this plugin is to utilize the common resources and reduce the server load and make it easy to use any of our add-ons based on your requirements.

Our add-ons are child plugins which may have only one single file to enable a few features, or a combination of many PHP, CSS and JS files to enable a fully functional Job Portal or ERP for your WordPress website.

### Free Add-ons ######

- **WP Frontend Auth Lite** This add-on, allows you to display WordPress login, register, reset password and edit profile forms on your WordPress website frontend.
- **WP Frontend Loaders** This add-on allows you to make a lasting impression on your users by enhancing the otherwise dull process of page transitions.
- **WP Dashboard Tweaks** This add-on enables you to customize default Wordpress features in the WordPress admin dashboard to suit your requirements. This plugin, lets you change or remove Wordpress menus, help options, also the behavior of specific widgets. Eventually, your work environment is more focused on the purpose of your website.
- **WP Frontend Tweaks** This add-on helps you control the front-end of your WordPress website. You can manage WordPress default wp_head() and wp_footer() actions easily from the plugin settings page.
- **WP RSS Feed Tweaks** This add-on empowers the RSS Feeds for your WordPress website with a bundle of options. With this plugin, you can control the behavior of your site's RSS feeds by playing with options like delayed feeds, adding a custom logo, include the post featured image, exclude selective categories and so on.

[Get Free Add-ons](https://cssjockey.com/freebie-type/add-on/)

### Premium Add-ons ######

- **WP SupportEzzy** This add-on is an elegant support ticket system and faqs portal for WordPress. SupportEzzy is a stand-alone Vue.js App which runs on a single WordPress page of your website. This app does not interfere with your existing WordPress theme and plugins and will work with any WordPress site. 
- **WP Social Login** This add-on enables login and registration for your WordPress website with 73 popular social networks including Facebook, Twitter, Google, Github, Envato.
- **WP Form Builder** This WordPress plugin helps you create any number of forms with unlimited WordPress and custom form fields. Form data can be sent to an email address or any specified custom Url where you consume and process the data.
- **WP Maintenance Mode** This add-on enables an under-construction page for your WordPress website visitors. Administrators, selected user roles and even specific selected users, can manage the website with full backend and frontend access.

[Get Premium Add-ons](https://cssjockey.com/product-type/add-on/)

### More Add-ons ######

- We are working on a lot of other free and premium addons and will be releasing them as soon as they are ready and fully tested.

== Installation ==

## Plugin Installation

**Method 1: Via the built in WordPress Plugin browser**

1. Login to your WordPress website admin area. 
2. Click Plugins and search for "CSSJockey Add-ons".
3. Once you see this plugin in the list on this page, click Install and then Activate.

**Method 2: Via the built in WordPress Plugin uploader**

1. Download the [Zip file](https://wordpress.org/plugins/cssjockey-add-ons/) of this plugin and save it on your computer.
2. Login to your WordPress dashboard and go to __Plugins >> Add new__ admin menu. Click "Upload Plugin" link.
3. On Upload screen tab click Choose File button and select the downloaded zip file from your computer. Click Install Now button. This will upload and unzip the plugin files under wp-content/plugins folder on your web server.
4. WordPress will ask you to Activate the installed plugin after successful upload. In case, you miss that screen, you can find CSSJockey Add-Ons plugin listed on Plugins page in your WordPress dashboard.
5. Click activate link to enable the awesome features of the plugin.

**Method 2: Uploading the plugin via FTP client**

1. Download the [Zip file](https://wordpress.org/plugins/cssjockey-add-ons/) of this plugin and save it on your computer.
2. Then you need to unzip/extract the zip file.
3. Connect to your web server via your favorite FTP client and browse to WordPress Installation /wp-content/plugins folder under server files panel.
4. Locate the unzipped folder in the local files panel and upload the complete folder under wp-content/plugins folder on your web server.
5. Once the upload is complete, login to your WordPress dashboard and click on Plugins menu page. You will see CSSJockey Add-ons listed on this page.
6. Click Activate link and this plugin should be activated.

## Add-on Installation

All our add-ons are WordPress plugins so you you can follow the same process to upload the plugin to your WordPress website.
You can access the add-on features once installed and activated.

All addons require CSSJockey Add-ons WordPress plugin to run and you will see the instructions to download and install this plugin if its not already installed.

 
== Frequently Asked Questions ==

= Where Can I find more add-ons?  =

You can get all our [FREE](https://cssjockey.com/freebie-type/add-on/) and [PREMIUM](https://cssjockey.com/product-type/add-on/) add-ons on [CSSJockey.com](https://cssjockey.com).

= Where can I find help for this plugin? =

1. **Documentation:** Coming soon.
2. **Support Forums:** Please visit [support forums](https://wordpress.org/support/plugin/cssjockey-add-ons) to report any bugs and ask for help.


= I have an idea for an add-on or need custom functionality for my website =

Please [get in touch](https://cssjockey.com/get-in-touch/) with us via email and we can discuss this further.

== Upgrade Notice ==
This version is optimized for all our FREE and PREMIUM add-ons.  

== Changelog ==

[Click here](https://cssjockey.com/documentation/cssjockey-add-ons/change-log/) to access change log.

== Screenshots ==