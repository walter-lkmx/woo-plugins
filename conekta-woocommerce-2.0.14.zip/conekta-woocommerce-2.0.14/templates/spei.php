<?php
/*
 * Title   : Conekta Payment extension for WooCommerce
 * Author  : Cristina Randall
 * Url     : http://cristinarandall.com/
 * License : http://cristinarandall.com/
 */
?>


<span class='payment-errors required'></span>
Por favor realiza el pago el portal de tu banco utilizando la ficha de pago. Dale clic para generar la ficha de pago.