<div class="cssjockey-ui">
	<?php
	$popup_display_class = cjaddons_unlimited_popups_display::getInstance();
	$popups = get_posts( array(
		'post_type' => 'cjaddons-popups',
		'posts_per_page' => - 1,
	) );
	if( ! empty( $popups ) ) {
		foreach( $popups as $key => $popup ) {
			$popup_info = $this->helpers->postInfo( $popup->ID );
			$popup_info['ID'] = $popup_info['ID'] + rand( 9999, 9999 );
			$popup_info['featured_image_url'] = 'https://dl.dropboxusercontent.com/u/210045/graphics/nature/4.jpg';
			$popup_info['popup_cookie_expire'] = 0;
			$popup_settings = (isset( $popup_info['_popup_settings'] )) ? $popup_info['_popup_settings'] : array();
			if( ! empty( $popup_settings ) ) {
				$popup_settings['show_on_click'] = 'yes';
			}
			$popup_info['popup_cookie_expire'] = 0;
			$display_popups[ $popup_info['ID'] ]['info'] = $popup_info;
			$display_popups[ $popup_info['ID'] ]['settings'] = $popup_settings;
			$popup_display_class->renderPopup( $display_popups[ $popup_info['ID'] ] );

			echo '<div class="cj-field cj-is-grouped">';
			echo '<p class="cj-control"><a href="#" class="show-cjaddons-popup-' . $popup_info['ID'] . ' cj-button cj-is-success">' . sprintf( __( 'Show Pop-up %s', 'addon-unlimited-popups' ), $popup_info['post_title'] ) . '</a></p>';
			if( current_user_can( 'manage_options' ) ) {
				echo '<p class="cj-control"><a href="#" data-modal-id="#popup-info-modal-' . $popup_info['ID'] . '" class="toggle-popup-info-modal cj-button cj-is-info">' . __( 'Show Info', 'addon-unlimited-popups' ) . '</a></p>';
			}
			echo '</div>';
			?>
			<?php if( current_user_can( 'manage_options' ) ) { ?>
                <div id="popup-info-modal-<?php echo $popup_info['ID'] ?>" class="cj-modal">
                    <div data-modal-id="#popup-info-modal-<?php echo $popup_info['ID'] ?>" class="cj-modal-background toggle-popup-info-modal" data-classes="cj-is-active"></div>
                    <div class="cj-modal-content">
                        <div class="cj-box cj-p-0">
                            <div class="cj-tabs cj-mb-0 cjaddons-popup-info-tabs">
                                <ul>
                                    <li class="cj-is-active"><a href="#tab-display-settings-<?php echo $popup_info['ID']; ?>"><?php echo __( 'Display Settings', 'addon-unlimited-popups' ) ?></a></li>
                                    <li><a href="#tab-popup-settings-<?php echo $popup_info['ID']; ?>"><?php echo __( 'Pop-up Settings', 'addon-unlimited-popups' ) ?></a></li>
                                </ul>
                            </div>
                            <div class="cjaddons-popup-info-tab-content">
                                <div id="tab-display-settings-<?php echo $popup_info['ID']; ?>" class="cj-tab-content cj-p-10">
									<?php echo '<pre>';
									print_r( $popup_info['_popup_display_settings'] );
									echo '</pre>'; ?>
                                </div>
                                <div id="tab-popup-settings-<?php echo $popup_info['ID']; ?>" class="cj-tab-content cj-p-10 cj-hidden">
									<?php echo '<pre>';
									print_r( $popup_info['_popup_settings'] );
									echo '</pre>'; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			<?php } ?>
			<?php
		}
	}
	?>
</div>
<script type="text/javascript">
    jQuery(document).ready(function ($) {
        $(document).on('click', '.toggle-popup-info-modal', function () {
            var $modal = $($(this).data('modal-id'));
            $('.cjaddons-popup-info-tab-content .tab-content').addClass('cj-hidden');
            $('.cjaddons-popup-info-tab-content .tab-content:first-child').removeClass('cj-hidden');
            $('.cjaddons-popup-info-tabs li').removeClass('cj-is-active');
            $('.cjaddons-popup-info-tabs li:first-child').addClass('cj-is-active');
            $modal.toggleClass('cj-is-active');
            return false;
            ``
        });
        $(document).on('click', '.cjaddons-popup-info-tabs a', function () {
            var $tab = $($(this).attr('href'));
            $('.cjaddons-popup-info-tabs ul li').removeClass('cj-is-active');
            $(this).closest('li').addClass('cj-is-active');
            $('.cjaddons-popup-info-tab-content .tab-content').addClass('cj-hidden');
            $tab.removeClass('cj-hidden');
            return false;
        });
    });
</script>