<?php
/*
 * Class name should be cjaddons_NAME_shortcode
 * Shortcode Tag will be cjaddons_NAME
 * */
if( ! class_exists( 'cjaddons_popups_test_shortcode' ) ) {
	class cjaddons_popups_test_shortcode {

		public $defaults, $helpers, $render_forms, $textdomain, $shortcode_tag;

		private static $instance;

		public function defaults() {

			$defaults['info'] = array(
				'single' => true,
				'tag' => $this->shortcode_tag,
				'name' => esc_attr__( 'Test all popups', $this->textdomain ),
				'description' => esc_attr__( 'This shortcode will display all popups and its settings.', $this->textdomain ),
				'screenshot' => $this->getScreenshotUrl(),
				'default_content' => '',
				'group' => ucwords( trim( str_replace( array('addon-', '-'), ' ', basename( $this->helpers->module_dir ) ) ) ),
				'textdomain' => 'addon-unlimited-popups',
				'item_name' => $this->helpers->itemInfo( 'item_name' ),
				'preview' => true,
			);
			$defaults['options'] = array(
				/*array(
					'type' => 'hidden',
					'id' => 'providers',
					'label' => __( 'Select Social Networks', 'addon-unlimited-popups' ),
					'info' => sprintf( __( 'Select multiple networks to display login links. <br><a href="%s" target="_parent">Click here</a> to enable network.', 'addon-unlimited-popups' ), $this->helpers->callbackUrl( 'addon-social-login', 'configuration' ) ),
					'default' => $this->helpers->savedOption( 'cjsl_enabled_providers' ),
					'options' => $this->helpers->hybridAuthProvidersArray( true ), // array in case of dropdown, checkbox and radio buttons
				)*/
			);

			return $defaults;
		}

		public static function getInstance() {

			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {

			$this->shortcode_tag = str_replace( '_shortcode', '', get_class( $this ) );
			add_shortcode( $this->shortcode_tag, array($this, 'run') );
			$this->helpers = cjaddons_unlimited_popups_helpers::getInstance();
			$this->textdomain = $this->helpers->itemInfo( 'text_domain' );
			$this->defaults = $this->defaults();
		}

		public function getScreenshotUrl() {

			$screen_shot_url = null;
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.svg';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.png';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}
			$screen_shot_path = dirname( __FILE__ ) . '/screenshot.jpg';
			if( file_exists( $screen_shot_path ) ) {
				$screen_shot_url = str_replace( $this->helpers->root_dir, $this->helpers->root_url, $screen_shot_path );

				return $screen_shot_url;
			}

			return $screen_shot_url;
		}

		public function run( $atts, $content = null ) {

			$defaults = array();
			$shortcode_params = $this->defaults();
			foreach( $shortcode_params['options'] as $key => $param ) {
				$default_key = str_replace( '-', '_', $param['id'] );
				$default_value = (is_array( $param['default'] )) ? implode( '|', $param['default'] ) : $param['default'];
				$defaults[ $default_key ] = $default_value;
			}
			$instance = shortcode_atts( $defaults, $atts );
			$output = '';
			$content_file_path = dirname( __FILE__ ) . '/content.php';
			if( file_exists( $content_file_path ) ) {
				ob_start();
				require($content_file_path);
				$output .= ob_get_clean();
				$output = apply_filters( 'cjaddons_shortcode_before_output', $output, $shortcode_params );
				$output = apply_filters( 'cjaddons_shortcode_after_output', $output, $shortcode_params );
			} else {
				$output .= '<div class="cj-notification cj-is-info">';
				$output .= sprintf( __( 'Shortcode content file not found.<br>%s', 'addon-unlimited-popups' ), str_replace( dirname( dirname( __FILE__ ) ), '', $content_file_path ) );
				$output .= '</div>';
			}

			return $output;
		}

	}

	cjaddons_popups_test_shortcode::getInstance();
}