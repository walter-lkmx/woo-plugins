<p>
    This is widget content<br>
    Dropdown Value: <b><?php echo $instance['dropdown']; ?></b>
</p>