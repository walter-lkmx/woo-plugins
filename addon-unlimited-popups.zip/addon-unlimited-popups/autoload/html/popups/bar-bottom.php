<div class="cssjockey-ui cj-relative">
    <div id="cjaddons-popup-<?php echo $popup_info['ID'] ?>" class="cj-modal cjaddons-popup" data-settings='<?php echo $popup_settings_encoded ?>'>
		<?php echo $this->popupBackdrop( $popup_settings['backdrop'], $popup_info['ID'] ) ?>
        <div class="cj-modal-content animated <?php echo $popup_settings['popup_animation_in'] ?>">
            <div class="cj-content">
				<?php echo $this->popupCloseButton( $popup_settings['close_button'], $popup_info['ID'] ) ?>
				<?php
				if( $popup_settings['popup_raw_html'] !== '' ) {
					echo do_shortcode( $popup_settings['popup_raw_html'] );
				} else {
					echo wpautop( do_shortcode( $popup_info['post_content'] ), false );
				}
				?>
            </div>
        </div>
    </div>
</div>
<style>
    #cjaddons-popup-<?php echo $popup_info['ID'] ?>{
        align-items: flex-end;
    }
    #cjaddons-popup-<?php echo $popup_info['ID'] ?> .cj-modal-content {
        background: <?php echo $popup_settings['popup_background_color'] ?>;
        color: <?php echo $popup_settings['popup_text_color'] ?>;
        padding: <?php echo $popup_settings['popup_padding'] ?>;
        z-index: 999999;
        width: 100%;
    }

    #cjaddons-popup-<?php echo $popup_info['ID'] ?> .cj-modal-content div,
    #cjaddons-popup-<?php echo $popup_info['ID'] ?> .cj-modal-content p,
    #cjaddons-popup-<?php echo $popup_info['ID'] ?> .cj-modal-content label{
        color: <?php echo $popup_settings['popup_text_color'] ?> !important;
    }

    #cjaddons-popup-<?php echo $popup_info['ID'] ?> a {
        color: <?php echo $popup_settings['popup_link_color'] ?>;
    }
</style>
