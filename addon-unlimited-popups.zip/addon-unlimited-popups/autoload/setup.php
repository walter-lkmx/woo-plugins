<?php
if( ! class_exists( 'cjaddons_unlimited_popups_setup' ) ) {

	class cjaddons_unlimited_popups_setup {
		private static $instance;
		public $helpers;

		public static function getInstance() {
			if( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		public function __construct() {
			$this->helpers = cjaddons_unlimited_popups_helpers::getInstance();
			ob_start();
		}
	}

	// cjaddons_unlimited_popups_setup::getInstance();
}
