<?php
$url = admin_url('edit.php?post_type=cjaddons-popups');
wp_redirect($url);
die();