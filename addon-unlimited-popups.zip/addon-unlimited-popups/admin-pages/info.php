<?php
$callback = explode('~', $_GET['callback']);
$module_vars = $this->helpers->itemVars('module_info');
$module_info = $module_vars[$callback[0]];

$cjaddons_core_welcome = array(
    array(
        'type' => 'heading',
        'id' => 'item-info',
        'label' => ( isset( $module_info ) ) ? $module_info['module_name'] : __('Module Info', 'addon-unlimited-popups'),
        'info' => '',
        'suffix' => '',
        'prefix' => '',
        'default' => '',
        'options' => '',
    ),
    array(
        'type' => 'info-full',
        'id' => 'item-info',
        'label' => '',
        'info' => '',
        'suffix' => '',
        'prefix' => '',
        'default' => ( isset( $module_info['module_description'] ) ) ? $module_info['module_description'] : __('Not Assigned', 'addon-unlimited-popups'),
        'options' => '',
    ),
    array(
        'type' => 'info',
        'id' => 'item-id',
        'label' => __('Add-on ID', 'addon-unlimited-popups'),
        'info' => '',
        'suffix' => '',
        'prefix' => '',
        'default' => ( isset( $module_info['item_id'] ) ) ? $module_info['item_id'] : __('Not Assigned', 'addon-unlimited-popups'),
        'options' => '',
    ),
	array(
        'type' => 'info',
        'id' => 'item-slug',
        'label' => esc_attr__('Add-on Slug', 'addon-unlimited-popups'),
        'info' => '',
        'suffix' => '',
        'prefix' => '',
        'default' => ( isset( $module_info['module_id'] ) ) ? $module_info['module_id'] : __('Not Assigned', 'addon-unlimited-popups'),
        'options' => '',
    ),
    array(
        'type' => 'info',
        'id' => 'item-version',
        'label' => esc_attr__('Add-on Version', 'addon-unlimited-popups'),
        'info' => '',
        'suffix' => '',
        'prefix' => '',
        'default' => $module_info['module_version'],
        'options' => '',
    ),
);

echo $this->helpers->renderAdminForm($cjaddons_core_welcome);