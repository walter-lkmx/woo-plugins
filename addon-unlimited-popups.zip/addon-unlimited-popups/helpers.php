<?php

if (! class_exists('cjaddons_unlimited_popups_helpers')) {
    /**
     * Class cjaddons_unlimited_popups_helpers
     * Extends core helpers class /framework/classes/helpers
     */
    class cjaddons_unlimited_popups_helpers extends cjaddons_helpers
    {
        private static $instance;
        public $module_dir;
        public $module_url;
        public $available_networks;
        public $hybridauth_path;
        public $hybridauth_url;
        public $table_social_profiles;

        public static function getInstance()
        {
            if (! isset(self::$instance)) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        public function __construct()
        {
            parent::__construct();
            $this->module_dir = wp_normalize_path(dirname(__FILE__));
	        $this->module_url = str_replace( ABSPATH, site_url('/'), $this->module_dir );
        }

        public function moduleInfo($module_key = null)
        {
            $module_key = basename($this->module_dir);

            return parent::moduleInfo($module_key);
        }
    }
}
