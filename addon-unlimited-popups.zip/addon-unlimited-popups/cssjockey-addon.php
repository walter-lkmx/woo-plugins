<?php
add_action( 'after_theme_setup', function () {
	if( class_exists( 'cjaddons_framework' ) ) {
		require_once 'init.php';
	}
}, 11 );
add_action( 'admin_init', function () {
	if( !class_exists( 'cjaddons_framework' ) ) {
		add_action( 'admin_notices', function () {
			$plugin_file = dirname( __FILE__ ) . '/index.php';
			$plugin_data = get_plugin_data( $plugin_file, true, true );
			$link = 'https://downloads.wordpress.org/plugin/cssjockey-add-ons.zip';
			echo '<div class="message error">
			<p>' . sprintf( __( '<b style="color:red;">CSSJockey Add-ons base framework plugin not found!</b>.<br><b>%s</b> requires our base framework plugin which acts as a framework for all our FREE and PREMIUM add-ons.<br><a href="%s" class="button primary" style="margin-top: 5px;">Download Framework</a>', 'addon-unlimited-popups' ), $plugin_data['Name'], $link ) . '</p>
			</div>';
		} );
	}
}, 11 );