=== WP Unlimited Pop-ups ===
Contributors: cssjockey
Donate link: https://www.paypal.me/CSSJockey
Tags: admin tweaks, dashboard, add-ons, tools, features, loading panel, google analytics, CSS3 loading panel, frontend login, registration, forms
Requires at least: 4.0
Tested up to: 4.8.1
Stable tag: trunk

1. Want to grab attention of your website visitor and direct them to take an action?
1. Want to add Mailchimp and other email subscription forms and show these in modal box, or a pop-up with stylish animation?
1. Want to highlight your product video when a user land on a certain page?

With WP Unlimited Pop-ups plugin you can create different kind of pop-ups with custom styles, colors, size, display options and include any type of content, HTML, CSS, Javascript and WordPress Shortcodes.

You can easily choose and configure different pop-ups to display on all pages or specific sections of your website.

== Description ==

1. Want to grab attention of your website visitor and direct them to take an action?
1. Want to add Mailchimp and other email subscription forms and show these in modal box, or a pop-up with stylish animation?
1. Want to highlight your product video when a user land on a certain page?

With WP Unlimited Pop-ups plugin you can create different kind of pop-ups with custom styles, colors, size, display options and include any type of content, HTML, CSS, Javascript and WordPress Shortcodes.

You can easily choose and configure different pop-ups to display on all pages or specific sections of your website.

Here's an overview of what's included in this add-on:

#### 10 Different Styles
This plugin comes with 10 different pop-up styles.

<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/001.png"></p>
<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/002.png"></p>
<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/003.png"></p>
<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/004.png"></p>
<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/005.png"></p>
<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/006.png"></p>
<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/007.png"></p>
<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/008.png"></p>
<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/009.png"></p>
<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/010.png"></p>

#### Sequential Display
If you have multiple pop-ups enabled on a page, they won't show all at once. They will be displayed one by one based on the pop-up menu order which you can set while editing a pop-up the same way we can order WordPress pages.

#### Managed Display
You can choose to display the pop-up on all pages of your WordPress website or select specific sections as shown in the below image:
<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/012.png"></p>
  

#### Featured Image as Pop-up Background
While creating or editing a pop-up, you can set a featured image which will used as the pop-up background instead of the backdrop.
<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/006.png"></p>
 

#### Custom Style for each Pop-up
You can change background color, text color, link color, width and padding of each pop-up as per the content you plan to display in the pop-up. 

You can also manage the backdrop backend color, opacity and visibility. 

<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/features/popup-styles.png" /></p>

#### Custom In and Out Animation
You can choose different in and out animation for the pop-up. All animations provided with [animate.css](https://daneden.github.io/animate.css/) are supported.

<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/features/animations.png" /></p>

#### Delayed Pop-ups
You can specify number of seconds to delay any pop-up.

<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/features/delay.png" /></p>

#### Auto Hide after specified time
You can specify number of seconds to automatically hide any pop-up.

<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/features/auto-hide.png" /></p>


#### Custom close button
You can choose to enable or disable the close button and use custom style for the close button as well. You can also insert custom HTML such as font-awesome icons for the close button.

<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/features/close-button.png" /></p>


#### Close pop-up with ESC key
You can enable of disable pop-up closing with ESC key.

<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/features/esc-to-close.png" /></p>

#### Managed Page Scroll
You can choose to enable or disable the background page scroll while a pop-up is active.

<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/features/page-scroll.png" /></p>

#### Responsive Display
All pop-ups are responsive and you can also choose to display the pop-up on specific screen sizes.

<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/features/responsive-display.png" /></p>

#### Restricted Display
You can control the display of the pop-up with cookies and enable a pop-up within specific dates.

<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/features/managed-display.png" /></p>

#### Any type of content
You can display any type of content within the pop-up. Under Raw HTML, you can add any valid HTML and link with CSS and Javascript files. You can also choose to display 
an iframe to display Videos from any website. 

<p><img src="https://dl.dropboxusercontent.com/u/210045/cjaddons-media/addon-unlimited-popups/features/any-content.png" /></p>

== Installation ==
[Click here](https://cssjockey.com/documentation/addon-unlimited-popups/installation/) for installation instructions.
 
== Upgrade Notice ==
[Click here](https://cssjockey.com/documentation/addon-unlimited-popups/change-log/) to check upgrade notices.

== Changelog ==
[Click here](https://cssjockey.com/documentation/addon-unlimited-popups/change-log/) to access change log.