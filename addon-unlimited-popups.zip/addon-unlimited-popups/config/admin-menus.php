<?php
global $cjaddons_item_vars;
$dir_name = str_replace( '.php', '', basename( dirname( dirname( __FILE__ ) ) ) );

$cjaddons_item_vars['admin_menu'][ $dir_name ] = array(
	'redirect-to-post-type' => __('Manage Pop-ups', 'addon-unlimited-popups'),
);

$cjaddons_item_vars['option_files'][ $dir_name ] = array();