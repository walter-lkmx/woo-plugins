<?php
$cjaddons_item_vars['post_types']['cjaddons-popups'] = array(
	'labels' => array(
		'name' => __( 'Pop-ups', 'addon-unlimited-popups' ),
		'singular_name' => __( 'Pop-up', 'addon-unlimited-popups' ),
		'add_new' => __( 'Add New', 'Pop-ups' ),
		'add_new_item' => __( 'Add New Pop-up', 'addon-unlimited-popups' ),
		'edit_item' => __( 'Edit Pop-up', 'addon-unlimited-popups' ),
		'new_item' => __( 'New Pop-up', 'addon-unlimited-popups' ),
		'view_item' => __( 'View Pop-up', 'addon-unlimited-popups' ),
		'search_items' => __( 'Search Pop-ups', 'addon-unlimited-popups' ),
		'not_found' => __( 'No Pop-ups found', 'addon-unlimited-popups' ),
		'not_found_in_trash' => __( 'No Pop-ups found in Trash', 'addon-unlimited-popups' ),
		'parent_item_colon' => ''
	),
	'args' => array(
		'exclude_from_search' => true,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'has_archive' => true,
		'can_export' => true,
		'query_var' => true,
		'rewrite' => array('slug' => 'cjaddons-popups', 'with_front' => false, 'hierarchical' => true),
		'capability_type' => 'page',
		'taxonomies' => array(),
		'hierarchical' => false,
		'menu_position' => 20,
		'menu_icon' => 'dashicons-desktop',
		'supports' => array('title', 'editor', 'page-attributes', 'thumbnail')
	)
);

/*$cjaddons_item_vars['post_types']['sample'] = array(
	'labels' => array(
		'name' => __( 'Sample Posts', 'addon-unlimited-popups' ),
		'singular_name' => __( 'Sample Post', 'addon-unlimited-popups' ),
		'add_new' => __( 'Add New', 'Sample Posts' ),
		'add_new_item' => __( 'Add New Sample Post', 'addon-unlimited-popups' ),
		'edit_item' => __( 'Edit Sample Post', 'addon-unlimited-popups' ),
		'new_item' => __( 'New Sample Post', 'addon-unlimited-popups' ),
		'view_item' => __( 'View Sample Post', 'addon-unlimited-popups' ),
		'search_items' => __( 'Search Sample Posts', 'addon-unlimited-popups' ),
		'not_found' => __( 'No Sample Posts found', 'addon-unlimited-popups' ),
		'not_found_in_trash' => __( 'No Sample Posts found in Trash', 'addon-unlimited-popups' ),
		'parent_item_colon' => ''
	),
	'args' => array(
		'exclude_from_search' => true,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'has_archive' => true,
		'can_export' => true,
		'query_var' => true,
		'rewrite' => array('slug' => 'sample-post', 'with_front' => false, 'hierarchical' => true),
		'capability_type' => 'post',
		'taxonomies' => array(),
		'hierarchical' => false,
		'menu_position' => 20,
		'menu_icon' => 'dashicons-desktop',
		'supports' => array('title', 'editor')
	)
);

$cjaddons_item_vars['taxonomies']['sample-cat'] = array(
	'labels' => array(
		'name' => esc_attr__( 'Sample Categories', 'addon-unlimited-popups' ),
		'singular_name' => esc_attr__( 'Sample Category', 'addon-unlimited-popups' ),
		'search_items' => esc_attr__( 'Search Sample Category', 'addon-unlimited-popups' ),
		'all_items' => esc_attr__( 'All Sample Categories', 'addon-unlimited-popups' ),
		'parent_item' => esc_attr__( 'Parent Sample Category', 'addon-unlimited-popups' ),
		'parent_item_colon' => esc_attr__( 'Parent Sample Category:', 'addon-unlimited-popups' ),
		'edit_item' => esc_attr__( 'Edit Sample Category', 'addon-unlimited-popups' ),
		'update_item' => esc_attr__( 'Update Sample Category', 'addon-unlimited-popups' ),
		'add_new_item' => esc_attr__( 'Add New Sample Category', 'addon-unlimited-popups' ),
		'new_item_name' => esc_attr__( 'New Sample Category', 'addon-unlimited-popups' ),
	),
	'args' => array(
		'hierarchical' => true,
		'show_ui' => true,
		'show_admin_column' => true,
		'query_var' => true,
		'public' => false,
		'rewrite' => array('slug' => 'sample-cat', 'with_front' => false),
	),
	'post_types' => array('sample')
);*/