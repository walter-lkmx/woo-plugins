<?php
global $cjaddons_item_vars;
global $cjaddons_item_vars, $wpdb;

