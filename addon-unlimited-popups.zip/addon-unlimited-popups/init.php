<?php
require_once sprintf('%s/base.php', dirname(__FILE__));

if (!class_exists('cjaddons_unlimited_popups')) {

    /**
     * Class cjaddons_unlimited_popups
     * Extends base class from /base.php
     */
    class cjaddons_unlimited_popups extends cjaddons_unlimited_popups_base
    {
        private static $instance;

        public static function getInstance()
        {
            if (!isset(self::$instance)) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        public function __construct()
        {
            $this->helpers = cjaddons_unlimited_popups_helpers::getInstance();
            $this->module_dir = wp_normalize_path(dirname(__FILE__));
            $this->module_url = str_replace( ABSPATH, site_url('/'), $this->module_dir );
            // add custom code here..
        }

        // add custom code here..

    }

    cjaddons_unlimited_popups::getInstance();

}